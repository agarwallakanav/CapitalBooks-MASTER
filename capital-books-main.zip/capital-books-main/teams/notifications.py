"""Post-tool broadcasts to teammates.

Wired in from router.tools.execute_tool. On success, we look at the tool
name + reply and, when relevant, notify owner + finance teammates with a
short one-line summary.

Broadcast triggers (per spec):
  - Employee action (any post) → notify owner + finance ("audit trail")
  - Any expense > AED 5000                 → notify owner + finance
  - Invoice created / completed sale posted → notify owner + finance
  - Bill approved (posted) / bill paid     → notify owner + finance

All other tools (reads, holds, edits) are silent by default so we don't
spam. The suppress-sentinel from silent tools (__SUPPRESS_REPLY__) short-
circuits notifications too — those tools shipped their own message.
"""
from __future__ import annotations

import logging
import re
from typing import Any
from uuid import UUID

from teams.membership import broadcast_to_team, get_role

logger = logging.getLogger(__name__)


# Financial-action tools that should always broadcast when they succeed.
_ALWAYS_BROADCAST: frozenset[str] = frozenset({
    "create_invoice",
    "record_completed_sale",
    "approve_pending_bill",
    "pay_bill",
    "mark_bill_paid_simple",
    "confirm_payment_method",     # bill payment execution
})


# Tools where we broadcast only if the amount crossed a threshold (currently
# only expense-posting flows). Read from the reply text since we don't have
# a structured return value.
_AMOUNT_THRESHOLD_AED = 5_000.0
_LARGE_EXPENSE_TOOLS: frozenset[str] = frozenset({
    "log_expense",
    "confirm_pending_review",
    "record_bill",
})


# Tools employees can call — any of these should broadcast to owner+finance
# for audit visibility, regardless of amount.
_EMPLOYEE_AUDIT_TOOLS: frozenset[str] = frozenset({
    "log_expense",
    "record_bill",
    "create_invoice",
    "record_completed_sale",
    "confirm_pending_review",
    "correct_pending_expense",
    "approve_pending_bill",
    "reject_pending_bill",
    "edit_latest_transaction",
    "delete_latest_transaction",
})


_AMOUNT_RE = re.compile(
    r"(?:AED|USD|EUR|GBP|SAR|INR|JPY|CNY)\s+([\d,]+(?:\.\d+)?)",
    re.IGNORECASE,
)


def _extract_amount(reply: str) -> float | None:
    """Best-effort pull of an AED-equivalent-ish figure from the reply.
    We look for 'AED 5,000.00' patterns; the largest one wins."""
    if not reply:
        return None
    amounts: list[float] = []
    for m in _AMOUNT_RE.finditer(reply):
        try:
            amounts.append(float(m.group(1).replace(",", "")))
        except ValueError:
            continue
    return max(amounts) if amounts else None


def _is_error_reply(reply: str) -> bool:
    if not reply:
        return True
    prefixes = ("⚠️", "❌", "🚫", "ERROR", "Sorry", "Couldn't")
    return any(reply.lstrip().startswith(p) for p in prefixes)


def _summarize_action(
    tool: str, input_args: dict[str, Any], reply: str, actor_name: str,
) -> str:
    """Short one-line WhatsApp message summarizing an action for teammates."""
    if tool == "create_invoice":
        return f"🧾 *{actor_name}* just created a customer invoice."
    if tool == "record_completed_sale":
        return f"🧾 *{actor_name}* recorded a completed sale + tax invoice."
    if tool == "approve_pending_bill":
        return f"📥 *{actor_name}* approved a vendor bill for posting."
    if tool == "pay_bill" or tool == "mark_bill_paid_simple":
        return f"💸 *{actor_name}* paid a vendor bill."
    if tool == "confirm_payment_method":
        return f"💸 *{actor_name}* completed a bill payment."
    if tool == "log_expense" or tool == "confirm_pending_review":
        return f"🧾 *{actor_name}* logged an expense."
    if tool == "record_bill":
        return f"📥 *{actor_name}* recorded a new vendor bill."
    if tool == "correct_pending_expense":
        return f"✏️ *{actor_name}* corrected a pending expense."
    if tool == "edit_latest_transaction":
        return f"✏️ *{actor_name}* edited their most recent transaction."
    if tool == "delete_latest_transaction":
        return f"🗑️ *{actor_name}* deleted a posted transaction."
    if tool == "reject_pending_bill":
        return f"🚫 *{actor_name}* rejected a pending bill."
    return f"📎 *{actor_name}* used *{tool}*."


async def notify_after_tool(
    tool: str, input_args: dict[str, Any], reply: str, actor_client_id: UUID,
) -> None:
    """Route: employee-action ALWAYS notifies; owner/finance financial
    actions notify each other; large expenses always notify. Errors and
    __SUPPRESS_REPLY__ tools are silent."""
    if reply == "__SUPPRESS_REPLY__":
        return
    if _is_error_reply(reply):
        return

    role = await get_role(actor_client_id)
    actor_name = await _actor_name(actor_client_id)

    is_employee_audit = (
        role == "employee" and tool in _EMPLOYEE_AUDIT_TOOLS
    )
    is_always = tool in _ALWAYS_BROADCAST
    is_large_expense = False
    if tool in _LARGE_EXPENSE_TOOLS:
        amt = _extract_amount(reply)
        if amt is not None and amt >= _AMOUNT_THRESHOLD_AED:
            is_large_expense = True

    if not (is_employee_audit or is_always or is_large_expense):
        return

    summary = _summarize_action(tool, input_args, reply, actor_name)
    # Excerpt from the reply so recipients see the actual facts (vendor,
    # amount, etc.), not just "Sarah logged an expense".
    excerpt = _short_excerpt(reply)
    message = f"👥 Team activity\n{summary}"
    if excerpt:
        message += f"\n\n{excerpt}"

    # Owner+finance get every triggered notification. Employees don't
    # receive broadcasts — they didn't ask for the noise.
    n = await broadcast_to_team(
        actor_client_id, message, roles=("owner", "finance"),
    )
    if n > 0:
        logger.info("Broadcast '%s' to %d teammate(s)", tool, n)


async def _actor_name(client_id: UUID) -> str:
    from database import get_db
    try:
        r = (await get_db()).table("clients").select("company_name").eq(
            "id", str(client_id)
        ).single()
        res = await r.execute()
        return (res.data or {}).get("company_name") or "A teammate"
    except Exception:
        return "A teammate"


def _short_excerpt(reply: str, max_chars: int = 300) -> str:
    """Return the first meaningful chunk of the tool reply (skip URLs at
    the end, keep the top facts)."""
    if not reply:
        return ""
    # Trim long URLs from the excerpt
    lines = []
    for line in reply.split("\n"):
        if "https://" in line and len(line) > 60:
            # Keep the label if there is one, drop the URL
            head = line.split("https://", 1)[0].rstrip()
            if head:
                lines.append(f"{head}[link redacted]")
        else:
            lines.append(line)
    trimmed = "\n".join(lines).strip()
    if len(trimmed) <= max_chars:
        return trimmed
    return trimmed[:max_chars].rsplit("\n", 1)[0] + "…"
