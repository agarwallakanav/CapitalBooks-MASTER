"""Tool-level permission gate.

Every tool call goes through `check_tool_permission(tool_name, role)`.
Returns (allowed: bool, deny_message: str). Deny messages are user-facing.

Role model:
  owner    — everything
  finance  — everything except add_teammate / remove_teammate
  employee — only expense/bill/invoice CREATION + look-up-my-own-things.
             Blocked from financial reports, customer/vendor lists,
             payment execution, deletions, and admin tools.

The default posture is CLOSED: if a tool isn't explicitly allowed for the
role, it's denied. New tools are safe-by-default (finance/employee can't
call them until we add them here).
"""
from __future__ import annotations

from typing import Literal

Role = Literal["owner", "finance", "employee"]


# Tools that literally anyone can call (greetings, health, timezone, etc.).
_UNIVERSAL = frozenset({
    # These read-only lookups are personal-context (their own last thing).
    "get_latest_transaction",
    "get_latest_bill",
    "get_latest_invoice",
    # Confirmation follow-ups for flows the caller themselves started.
    "confirm_pending_review",
    "correct_pending_expense",
    "provide_invoice_email",
    "skip_invoice_email",
    "register_card",
    "confirm_pending_expense",   # legacy shim
})


# Everything an employee can do beyond _UNIVERSAL.
_EMPLOYEE_ALLOWED = _UNIVERSAL | frozenset({
    # Expense creation + editing what they just posted
    "log_expense",
    "record_bill",                # they can record a bill (data entry)
    "approve_pending_bill",       # …but "approve" only means "confirm my own extraction"
    "reject_pending_bill",
    "edit_latest_transaction",
    # Invoice CREATION + sending
    "create_invoice",
    "record_completed_sale",
})


# Finance can do everything except admin.
_ADMIN_ONLY = frozenset({
    "add_teammate",
    "remove_teammate",
    "list_teammates",             # keep membership visible to owner only
    # run_daily_briefing is finance+owner (not admin-only) but ALSO not
    # employee — added by omission from _EMPLOYEE_ALLOWED.
})


def check_tool_permission(tool_name: str, role: Role) -> tuple[bool, str]:
    """Returns (allowed, deny_message). deny_message is user-facing."""
    if role == "owner":
        return True, ""

    if tool_name in _ADMIN_ONLY:
        return False, (
            "🚫 That's an owner-only action (managing teammates). "
            "Ask the account owner to run it."
        )

    if role == "finance":
        return True, ""

    # Employee
    if tool_name in _EMPLOYEE_ALLOWED:
        return True, ""

    return False, (
        "🚫 That's finance-only. You can log expenses, record bills, and "
        "create invoices — but financial reports, customer/vendor lists, "
        "and payment execution are restricted. Ask your finance lead."
    )
