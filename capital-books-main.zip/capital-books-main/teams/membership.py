"""Team membership lookups + broadcast helpers.

  get_role(client_id) → Role
      Employees default to 'owner' when they have no team_members row —
      backward-compat for pre-team-feature clients.

  get_teammates(team_id, exclude_client_id) → list of dicts with phone + role.

  broadcast_to_team(client_id, message, exclude_self=True, roles=None)
      Send a WhatsApp text to every teammate (optionally filtered by role).
      Fire-and-forget: failures are logged but do not block the caller.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Iterable
from uuid import UUID

from database import get_db
from teams.permissions import Role

logger = logging.getLogger(__name__)


async def get_role(client_id: UUID) -> Role:
    """Backward-compat: a client with no team membership acts as 'owner' of
    their own books (the pre-team-feature default)."""
    db = await get_db()
    try:
        res = (
            await db.table("team_members")
            .select("role")
            .eq("client_id", str(client_id))
            .limit(1)
            .execute()
        )
        if res.data:
            r = res.data[0].get("role")
            if r in ("owner", "finance", "employee"):
                return r    # type: ignore[return-value]
    except Exception:
        logger.exception("get_role lookup failed (non-fatal; defaulting to owner)")
    return "owner"


async def get_team_id(client_id: UUID) -> UUID | None:
    """Team this client belongs to. None = solo (pre-team-feature)."""
    db = await get_db()
    try:
        res = (
            await db.table("clients")
            .select("team_id")
            .eq("id", str(client_id))
            .single()
            .execute()
        )
        tid = (res.data or {}).get("team_id")
        return UUID(tid) if tid else None
    except Exception:
        logger.exception("get_team_id lookup failed (non-fatal)")
        return None


async def get_teammates(
    team_id: UUID,
    *,
    exclude_client_id: UUID | None = None,
    roles: Iterable[Role] | None = None,
) -> list[dict]:
    """Every client in this team, optionally filtered by role. Returns
    [{client_id, phone, company_name, role}, ...]."""
    db = await get_db()
    try:
        q = (
            db.table("team_members")
            .select("client_id, role, clients(id, phone, company_name)")
            .eq("team_id", str(team_id))
        )
        if roles:
            q = q.in_("role", list(roles))
        res = await q.execute()
    except Exception:
        logger.exception("teammates lookup failed (non-fatal)")
        return []
    rows: list[dict] = []
    for r in res.data or []:
        cid = r.get("client_id")
        client = r.get("clients") or {}
        if exclude_client_id and str(exclude_client_id) == str(cid):
            continue
        if not client.get("phone"):
            continue
        rows.append({
            "client_id": UUID(cid),
            "phone": client["phone"],
            "company_name": client.get("company_name") or "",
            "role": r.get("role"),
        })
    return rows


async def broadcast_to_team(
    actor_client_id: UUID,
    message: str,
    *,
    roles: Iterable[Role] | None = ("owner", "finance"),
) -> int:
    """Send `message` via WhatsApp to teammates (default: owner + finance).
    Excludes the actor themselves. Returns count of successful sends.

    Fire-and-forget-safe: all errors are logged but never propagate."""
    if not message:
        return 0
    try:
        team_id = await get_team_id(actor_client_id)
        if not team_id:
            return 0    # solo user — nothing to broadcast
        teammates = await get_teammates(
            team_id, exclude_client_id=actor_client_id, roles=roles,
        )
        if not teammates:
            return 0
        from whatsapp.sender import send_text

        async def _one(phone: str) -> bool:
            try:
                await send_text(phone, message)
                return True
            except Exception:
                logger.exception("broadcast send to %s failed (non-fatal)", phone)
                return False

        results = await asyncio.gather(*[_one(t["phone"]) for t in teammates])
        return sum(1 for r in results if r)
    except Exception:
        logger.exception("broadcast_to_team failed (non-fatal)")
        return 0
