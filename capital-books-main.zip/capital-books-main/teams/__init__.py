"""Team membership + role-based permissions + activity broadcast."""
