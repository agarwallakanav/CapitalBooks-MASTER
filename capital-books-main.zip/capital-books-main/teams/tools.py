"""Owner-facing team management tools.

  add_teammate(phone, name, role) — Register a new phone under the same
                                    Zoho org as the owner. Creates the
                                    team on first invocation.
  list_teammates()                — Show everyone on the team + role.
"""
from __future__ import annotations

import logging
import re
from uuid import UUID, uuid4

from database import get_db
from teams.membership import get_role, get_team_id

logger = logging.getLogger(__name__)


_PHONE_RE = re.compile(r"^\+?\d{7,15}$")
_VALID_ROLES = {"owner", "finance", "employee"}


async def _ensure_team(owner_client_id: UUID, team_name: str | None = None) -> UUID:
    """Get or create the owner's team. First call for a solo client bootstraps
    the team + adds the owner as a member."""
    tid = await get_team_id(owner_client_id)
    if tid:
        return tid

    db = await get_db()
    # Pull owner's company name for a friendly default team name
    if not team_name:
        try:
            r = (await db.table("clients").select("company_name")
                 .eq("id", str(owner_client_id)).single().execute()).data or {}
            team_name = r.get("company_name") or "My Team"
        except Exception:
            team_name = "My Team"

    new_team_id = str(uuid4())
    await db.table("teams").insert({
        "id": new_team_id, "name": team_name,
    }).execute()
    await db.table("clients").update({
        "team_id": new_team_id,
    }).eq("id", str(owner_client_id)).execute()
    await db.table("team_members").insert({
        "team_id": new_team_id,
        "client_id": str(owner_client_id),
        "role": "owner",
    }).execute()
    return UUID(new_team_id)


async def add_teammate(
    owner_client_id: UUID, phone: str, name: str, role: str,
) -> str:
    """Register a new phone under owner's team + Zoho org. Returns a
    human-readable reply."""
    role = (role or "").strip().lower()
    if role not in _VALID_ROLES:
        return (
            f"❌ Invalid role '{role}'. Use one of: owner, finance, employee.\n"
            "  • owner    — everything\n"
            "  • finance  — everything except managing teammates\n"
            "  • employee — log expenses/bills, send invoices. No reports, "
            "no vendor/customer lists, no payments"
        )
    phone_clean = re.sub(r"[^0-9+]", "", phone or "")
    if not _PHONE_RE.match(phone_clean):
        return f"❌ '{phone}' doesn't look like a valid phone. Use format like 971558653850."
    if phone_clean.startswith("+"):
        phone_clean = phone_clean[1:]
    name = (name or "").strip() or "Teammate"

    caller_role = await get_role(owner_client_id)
    if caller_role != "owner":
        return "🚫 Only the account owner can add teammates."

    db = await get_db()
    # Owner's Zoho org — the teammate clones this
    owner = (await db.table("clients").select("*")
             .eq("id", str(owner_client_id)).single().execute()).data
    if not owner:
        return "❌ Couldn't find your account record."

    # Does this phone already exist?
    existing = (await db.table("clients").select("id, team_id")
                .eq("phone", phone_clean).execute()).data or []
    if existing:
        existing_row = existing[0]
        existing_tid = existing_row.get("team_id")
        team_id = await _ensure_team(owner_client_id)
        if existing_tid and existing_tid != str(team_id):
            return (
                f"❌ Phone {phone_clean} is already registered under a different team."
            )
        if not existing_tid:
            await (db.table("clients").update({"team_id": str(team_id)})
                   .eq("id", existing_row["id"]).execute())
        await db.table("team_members").upsert({
            "team_id": str(team_id),
            "client_id": existing_row["id"],
            "role": role,
        }, on_conflict="team_id,client_id").execute()
        return f"✅ {name} ({phone_clean}) added to your team as *{role}*."

    # Clone the owner's clients row, swap phone/name, keep Zoho creds
    team_id = await _ensure_team(owner_client_id)
    new_client = {k: v for k, v in owner.items()
                  if k not in ("id", "created_at", "updated_at")}
    new_client["phone"] = phone_clean
    new_client["company_name"] = name
    new_client["team_id"] = str(team_id)
    inserted = (await db.table("clients").insert(new_client).execute()).data
    if not inserted:
        return "❌ Couldn't create the teammate record. Try again in a moment."
    new_client_id = inserted[0]["id"]
    await db.table("team_members").insert({
        "team_id": str(team_id),
        "client_id": new_client_id,
        "role": role,
    }).execute()

    return (
        f"✅ *{name}* added as *{role}*.\n"
        f"Phone: {phone_clean}\n\n"
        "Next step: add their number to Meta's WhatsApp allow list in the "
        "Developers dashboard so Meta will deliver messages to them. Then "
        "they can text `hi` to the bot to start."
    )


async def list_teammates(owner_client_id: UUID) -> str:
    caller_role = await get_role(owner_client_id)
    if caller_role != "owner":
        return "🚫 Only the account owner can view team membership."

    db = await get_db()
    team_id = await get_team_id(owner_client_id)
    if not team_id:
        return "You're the only person on your team. Say 'add teammate' to invite someone."

    res = (await db.table("team_members").select(
        "role, clients(id, phone, company_name)"
    ).eq("team_id", str(team_id)).execute()).data or []

    if not res:
        return "No teammates yet."
    lines = ["👥 *Your team*", ""]
    for row in sorted(res, key=lambda r: (r.get("role") or "z")):
        c = row.get("clients") or {}
        lines.append(
            f"  • {c.get('company_name') or '(unnamed)'} — "
            f"{c.get('phone') or '?'} ({row.get('role')})"
        )
    return "\n".join(lines)
