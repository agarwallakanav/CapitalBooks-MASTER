"""Daily 09:00 UAE briefing + customer payment follow-ups.

For each active client, at 09:00 GST (05:00 UTC):

  PART A — Owner briefing:
    Pull unpaid bills + unpaid invoices from Zoho, format a single WhatsApp
    message with totals + top items, send to the client's phone.

  PART B — Customer follow-ups:
    For every overdue invoice (or due within 3 days), look up the customer's
    phone + email from Zoho contacts. Pick a tone by days-overdue bucket:
      due -3..-1  → friendly reminder
      overdue 1-7 → polite follow-up
      overdue 8-14 → firm reminder
      overdue 15-30 → urgent notice
      overdue 30+  → final notice
    Send via WhatsApp (if phone) and email (if address). All sends logged
    to `transaction_events`.

Errors are swallowed per-client so one bad org doesn't kill the sweep.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Any

from ar.email_delivery import send_invoice_email
from ar.pay_redirect import short_pay_url
from database import get_db
from orchestrator.audit import record_event
from orchestrator.engine import load_client_config
from orchestrator.zoho_client import ClientCredentials, ZohoClient
from whatsapp.sender import send_text

logger = logging.getLogger(__name__)

_TOP_N_INLINE = 5           # bills/invoices shown inline in the owner briefing
_DUE_SOON_DAYS = 3          # bucket boundary for the "due tomorrow / due soon"


# ---------------------------------------------------------------------------
# Data collection
# ---------------------------------------------------------------------------

async def _fetch_bills(z) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for status in ("open", "overdue", "partially_paid"):
        try:
            r = await z.list_entities("bills", filters={
                "status": status, "per_page": 200,
            })
            rows.extend(r.get("bills") or [])
        except Exception:
            logger.exception("bills fetch (%s) failed for daily briefing", status)
    return rows


async def _fetch_invoices(z) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for status in ("sent", "overdue", "partially_paid"):
        try:
            r = await z.list_entities("invoices", filters={
                "status": status, "per_page": 200,
            })
            rows.extend(r.get("invoices") or [])
        except Exception:
            logger.exception("invoices fetch (%s) failed for daily briefing", status)
    return rows


def _days_from_today(due_str: str | None) -> int | None:
    if not due_str:
        return None
    try:
        d = date.fromisoformat(str(due_str)[:10])
    except ValueError:
        return None
    return (d - date.today()).days


def _due_phrase(days: int | None) -> str:
    if days is None:
        return ""
    if days < 0:
        n = -days
        return f"{n} day{'s' if n != 1 else ''} overdue ⚠️"
    if days == 0:
        return "due today ⚠️"
    if days == 1:
        return "due tomorrow!"
    return f"due in {days} days"


# ---------------------------------------------------------------------------
# PART A — Owner briefing
# ---------------------------------------------------------------------------

def _fmt_money(amt: float, currency: str = "AED") -> str:
    return f"{currency} {amt:,.0f}"


def _build_owner_briefing(
    company_name: str, bills: list[dict], invoices: list[dict],
    followups_sent: int,
) -> str:
    today = date.today()
    bills_by_urgency = sorted(
        bills,
        key=lambda b: (_days_from_today(b.get("due_date")) or 999),
    )
    invoices_by_urgency = sorted(
        invoices,
        key=lambda i: (_days_from_today(i.get("due_date")) or 999),
    )

    total_payable = sum(float(b.get("balance") or 0) for b in bills)
    total_receivable = sum(float(i.get("balance") or 0) for i in invoices)
    net = total_receivable - total_payable

    lines = [
        f"Good morning ☀️",
        "",
        f"📋 *Daily summary — {today.strftime('%a %d %b %Y')}*",
    ]

    if bills:
        lines.append("")
        lines.append("💳 *Bills to pay:*")
        shown = bills_by_urgency[:_TOP_N_INLINE]
        for b in shown:
            days = _days_from_today(b.get("due_date"))
            vendor = b.get("vendor_name") or "(unknown vendor)"
            amt = float(b.get("balance") or 0)
            lines.append(f"  • {vendor} — {_fmt_money(amt)} ({_due_phrase(days)})")
        if len(bills) > _TOP_N_INLINE:
            lines.append(f"  … +{len(bills) - _TOP_N_INLINE} more")
        lines.append(f"Total payable: *{_fmt_money(total_payable)}*")

    if invoices:
        lines.append("")
        lines.append("📨 *Invoices awaiting payment:*")
        shown = invoices_by_urgency[:_TOP_N_INLINE]
        for i in shown:
            days = _days_from_today(i.get("due_date"))
            cust = i.get("customer_name") or "(unknown customer)"
            amt = float(i.get("balance") or 0)
            lines.append(f"  • {cust} — {_fmt_money(amt)} ({_due_phrase(days)})")
        if len(invoices) > _TOP_N_INLINE:
            lines.append(f"  … +{len(invoices) - _TOP_N_INLINE} more")
        lines.append(f"Total receivable: *{_fmt_money(total_receivable)}*")

    if bills or invoices:
        lines.append("")
        if net > 0:
            lines.append(f"💰 *Net position: {_fmt_money(net)} owed to you*")
        elif net < 0:
            lines.append(f"💰 *Net position: {_fmt_money(-net)} you owe out*")
        else:
            lines.append("💰 *Net position: balanced*")

    if followups_sent > 0:
        lines.append("")
        lines.append(
            f"📤 I sent {followups_sent} payment follow-up{'s' if followups_sent != 1 else ''} "
            "to customers about invoices near or past due."
        )

    if not bills and not invoices:
        lines.append("")
        lines.append("✅ Nothing outstanding — all clear!")

    lines.append("")
    lines.append(
        "Reply 'AP aging' / 'AR aging' for the full breakdown, or "
        "'pay [vendor]' to record a payment."
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# PART B — Customer follow-ups
# ---------------------------------------------------------------------------

def _followup_bucket(days_overdue: int) -> str | None:
    """days_overdue < 0 means the invoice isn't due yet (negative overdue = days until due).
    Returns one of: friendly / polite / firm / urgent / final. None = skip."""
    if -_DUE_SOON_DAYS <= days_overdue < 0:
        return "friendly"
    if 1 <= days_overdue <= 7:
        return "polite"
    if 8 <= days_overdue <= 14:
        return "firm"
    if 15 <= days_overdue <= 30:
        return "urgent"
    if days_overdue > 30:
        return "final"
    return None


def _followup_text(
    stage: str, customer_name: str, company_name: str,
    invoice_number: str, amount: float, currency: str, due_date_str: str,
    days_overdue: int, pay_url: str,
) -> tuple[str, str]:
    """Returns (whatsapp_body, email_subject_and_body_prefix)."""
    days = abs(days_overdue)
    amt = f"{currency} {amount:,.2f}"

    if stage == "friendly":
        wa = (
            f"Hi {customer_name}, this is a friendly reminder that invoice "
            f"*{invoice_number}* for {amt} from *{company_name}* is due on "
            f"{due_date_str}. You can pay securely here: {pay_url}\n\n"
            "Thanks!"
        )
        subj = f"Reminder: Invoice {invoice_number} due {due_date_str}"
    elif stage == "polite":
        wa = (
            f"Hi {customer_name}, following up on invoice *{invoice_number}* "
            f"for {amt} from *{company_name}* — it's {days} day{'s' if days != 1 else ''} "
            f"past due. Could you arrange payment when you get a chance? "
            f"Pay here: {pay_url}\n\nThanks!"
        )
        subj = f"Follow-up: Invoice {invoice_number} ({days}d overdue)"
    elif stage == "firm":
        wa = (
            f"Hi {customer_name}, invoice *{invoice_number}* for {amt} from "
            f"*{company_name}* is now {days} days overdue. Please settle at "
            f"your earliest convenience: {pay_url}\n\nHappy to help if there's "
            "any issue on your side — just reply to this message."
        )
        subj = f"Overdue: Invoice {invoice_number} ({days}d overdue)"
    elif stage == "urgent":
        wa = (
            f"Hi {customer_name}, invoice *{invoice_number}* for {amt} is now "
            f"*{days} days overdue*. This is an urgent request from *{company_name}* "
            f"— please arrange payment today: {pay_url}\n\nIf you need a "
            "different arrangement, please reach out immediately."
        )
        subj = f"URGENT: Invoice {invoice_number} — {days} days overdue"
    else:  # final
        wa = (
            f"Hi {customer_name}, this is a FINAL NOTICE for invoice "
            f"*{invoice_number}* from *{company_name}*, {days} days overdue "
            f"({amt}). Please settle immediately: {pay_url}\n\n"
            "If payment isn't received, we'll need to escalate. Please contact "
            "us today to resolve."
        )
        subj = f"FINAL NOTICE: Invoice {invoice_number} — {days} days overdue"
    return wa, subj


def _clean_phone(raw: str | None) -> str | None:
    if not raw:
        return None
    digits = "".join(c for c in raw if c.isdigit())
    if len(digits) < 7:
        return None
    return digits


async def _resolve_customer_contact(z, customer_id: str) -> tuple[str | None, str | None, str]:
    """Returns (phone, email, name). Best-effort — non-fatal on failure."""
    if not customer_id:
        return None, None, ""
    try:
        detail = await z.get_entity("contacts", customer_id)
        c = detail.get("contact") or {}
        name = c.get("contact_name") or ""
        phone = _clean_phone(c.get("mobile") or c.get("phone"))
        email = (c.get("email") or "").strip()
        if not email:
            persons = c.get("contact_persons") or []
            primary = next((p for p in persons if p.get("is_primary_contact")), None) \
                or (persons[0] if persons else None)
            if primary:
                email = (primary.get("email") or "").strip()
                if not phone:
                    phone = _clean_phone(primary.get("mobile") or primary.get("phone"))
        return phone or None, email or None, name
    except Exception:
        logger.exception("Zoho contact fetch failed for %s (non-fatal)", customer_id)
        return None, None, ""


async def _send_customer_followup(
    z, cfg, invoice: dict[str, Any],
) -> tuple[bool, str]:
    """Send one follow-up. Returns (sent, stage_or_error)."""
    days = _days_from_today(invoice.get("due_date"))
    if days is None:
        return False, "no_due_date"
    days_overdue = -days           # +N = N days late; -N = N days until due
    stage = _followup_bucket(days_overdue)
    if not stage:
        return False, "not_in_window"

    phone, email, cust_name = await _resolve_customer_contact(z, invoice.get("customer_id"))
    if not phone and not email:
        return False, "no_contact"

    amount = float(invoice.get("balance") or invoice.get("total") or 0)
    currency = invoice.get("currency_code") or "AED"
    invoice_number = invoice.get("invoice_number") or ""
    due_date_str = invoice.get("due_date") or ""
    pay_url = short_pay_url(invoice_number) if invoice_number else ""

    wa_body, subject = _followup_text(
        stage=stage, customer_name=cust_name or "there",
        company_name=cfg.company_name,
        invoice_number=invoice_number, amount=amount, currency=currency,
        due_date_str=due_date_str, days_overdue=days_overdue, pay_url=pay_url,
    )

    sent_any = False
    if phone:
        try:
            await send_text(phone, wa_body)
            sent_any = True
        except Exception:
            logger.exception("customer follow-up WhatsApp send failed")
    if email:
        try:
            ok, err = await send_invoice_email(
                to_email=email,
                bcc_email=None,
                company_name=cfg.company_name,
                customer_name=cust_name or "Customer",
                invoice_number=invoice_number,
                amount=Decimal(str(amount)),
                currency=currency,
                due_date=due_date_str,
                payment_url=pay_url,
                pdf_bytes=None,               # reminder, not the invoice itself
                description=subject,
            )
            if ok:
                sent_any = True
            else:
                logger.warning("customer follow-up email failed: %s", err)
        except Exception:
            logger.exception("customer follow-up email raised")

    if sent_any:
        await record_event(
            cfg.id, event_type="ar_reminder_sent",
            payload={
                "invoice_number": invoice_number,
                "stage": stage,
                "days_overdue": days_overdue,
                "sent_wa": bool(phone),
                "sent_email": bool(email),
            },
        )
    return sent_any, stage


# ---------------------------------------------------------------------------
# Per-client + sweep orchestration
# ---------------------------------------------------------------------------

async def brief_client(client_row: dict[str, Any]) -> dict[str, Any]:
    """Run the full briefing for one client. Returns a small summary dict."""
    client_id = client_row["id"]
    try:
        cfg = await load_client_config(client_id)
    except Exception:
        logger.exception("load_client_config failed for %s", client_id)
        return {"client_id": str(client_id), "error": "config_load_failed"}

    if not cfg.zoho_organization_id or not cfg.zoho_refresh_token:
        return {"client_id": str(client_id), "skipped": "no_zoho"}

    creds = ClientCredentials(
        client_id=cfg.id, organization_id=cfg.zoho_organization_id,
        api_domain=cfg.api_domain, access_token=cfg.zoho_access_token,
        refresh_token=cfg.zoho_refresh_token,
        token_expires_at=cfg.zoho_token_expires_at,
    )

    followups_sent = 0
    async with ZohoClient(creds) as z:
        bills, invoices = await asyncio.gather(
            _fetch_bills(z), _fetch_invoices(z),
        )

        # Fire follow-ups only for invoices in the windows we care about
        followup_tasks = []
        for inv in invoices:
            days = _days_from_today(inv.get("due_date"))
            if days is None:
                continue
            days_overdue = -days
            if _followup_bucket(days_overdue):
                followup_tasks.append(_send_customer_followup(z, cfg, inv))
        if followup_tasks:
            results = await asyncio.gather(*followup_tasks, return_exceptions=True)
            for r in results:
                if isinstance(r, tuple) and r[0]:
                    followups_sent += 1

    briefing = _build_owner_briefing(
        cfg.company_name, bills, invoices, followups_sent,
    )

    # Inventory low-stock alerts (best-effort — org may not have Inventory)
    try:
        from inventory.alerts import render_low_stock_section
        low_section = await render_low_stock_section(cfg)
        if low_section:
            briefing += "\n" + low_section
    except Exception:
        logger.exception("low-stock section failed (non-fatal)")
    if cfg.phone:
        try:
            await send_text(cfg.phone, briefing)
        except Exception:
            logger.exception("daily briefing send to %s failed", cfg.phone)

    await record_event(
        cfg.id, event_type="daily_briefing_sent",
        payload={
            "bills_count": len(bills), "invoices_count": len(invoices),
            "followups_sent": followups_sent,
        },
    )
    return {
        "client_id": str(client_id),
        "bills": len(bills),
        "invoices": len(invoices),
        "followups": followups_sent,
    }


async def _active_clients() -> list[dict[str, Any]]:
    db = await get_db()
    res = (
        await db.table("clients")
        .select("id, company_name, phone")
        .eq("is_active", True)
        .execute()
    )
    return res.data or []


async def sweep_all_clients() -> None:
    """Entry point for APScheduler — runs the briefing for every active client."""
    clients = await _active_clients()
    if not clients:
        logger.info("Daily briefing: no active clients")
        return
    logger.info("Daily briefing: %d clients", len(clients))
    results = await asyncio.gather(
        *(brief_client(c) for c in clients), return_exceptions=True,
    )
    for client, result in zip(clients, results):
        if isinstance(result, Exception):
            logger.error("Daily briefing failed for %s: %s", client["id"], result)
        else:
            logger.info("Daily briefing done for %s: %s", client["id"], result)
