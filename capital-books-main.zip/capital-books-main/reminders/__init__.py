"""Daily briefing + customer follow-up automations."""
