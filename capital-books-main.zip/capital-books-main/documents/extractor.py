"""Extract text from incoming document attachments (PDF / xlsx / csv).

Each helper returns a plain-text representation the conversational agent
can reason about. We deliberately don't try to be clever about layout —
the agent's job is to interpret content, ours is to pull it out.
"""
from __future__ import annotations

import csv
import io
import logging
from dataclasses import dataclass
from typing import Literal

logger = logging.getLogger(__name__)

DocKind = Literal["pdf", "xlsx", "csv", "unknown"]

# Approximate cap so we don't blow up Claude's context with a 500-page PDF.
# Claude can handle plenty, but most useful documents fit well inside this.
_MAX_OUTPUT_CHARS = 60_000


@dataclass
class ExtractedDocument:
    kind: DocKind
    text: str           # human-readable representation
    page_count: int = 0
    truncated: bool = False
    error: str = ""


_PDF_MIMES = {"application/pdf", "application/x-pdf"}
_XLSX_MIMES = {
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel",
    "application/octet-stream",   # WhatsApp sometimes sends generic
}
_CSV_MIMES = {"text/csv", "text/plain", "application/csv"}


def detect_kind(mime: str, filename: str = "") -> DocKind:
    m = (mime or "").lower()
    name = (filename or "").lower()
    if m in _PDF_MIMES or name.endswith(".pdf"):
        return "pdf"
    if (m in _XLSX_MIMES and not name.endswith(".csv")) \
            or name.endswith((".xlsx", ".xls")):
        return "xlsx"
    if m in _CSV_MIMES or name.endswith(".csv"):
        return "csv"
    return "unknown"


# ---------------------------------------------------------------------------
# Per-format extractors
# ---------------------------------------------------------------------------

def _truncate(text: str) -> tuple[str, bool]:
    if len(text) <= _MAX_OUTPUT_CHARS:
        return text, False
    return text[:_MAX_OUTPUT_CHARS] + "\n\n[…truncated]", True


def extract_pdf(body: bytes) -> ExtractedDocument:
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(body))
        chunks: list[str] = []
        for i, page in enumerate(reader.pages, 1):
            try:
                t = page.extract_text() or ""
            except Exception:
                logger.exception("PDF page %d extract failed (non-fatal)", i)
                t = ""
            if t.strip():
                chunks.append(f"--- Page {i} ---\n{t.strip()}")
        text, trunc = _truncate("\n\n".join(chunks) or "[PDF had no extractable text — likely image-only / scanned]")
        return ExtractedDocument(
            kind="pdf", text=text, page_count=len(reader.pages), truncated=trunc,
        )
    except Exception as e:
        logger.exception("PDF extraction failed")
        return ExtractedDocument(kind="pdf", text="", error=str(e))


def extract_xlsx(body: bytes) -> ExtractedDocument:
    try:
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(body), data_only=True, read_only=True)
        chunks: list[str] = []
        total_rows = 0
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            sheet_rows: list[str] = [f"=== Sheet: {sheet_name} ==="]
            for row in ws.iter_rows(values_only=True):
                # Skip fully-empty rows
                if all(v is None or (isinstance(v, str) and not v.strip()) for v in row):
                    continue
                cells = ["" if v is None else str(v) for v in row]
                sheet_rows.append(" | ".join(cells))
                total_rows += 1
                if total_rows > 5000:
                    sheet_rows.append("[…row cap of 5000 reached]")
                    break
            chunks.append("\n".join(sheet_rows))
            if total_rows > 5000:
                break
        text, trunc = _truncate("\n\n".join(chunks))
        return ExtractedDocument(
            kind="xlsx", text=text, page_count=len(wb.sheetnames), truncated=trunc,
        )
    except Exception as e:
        logger.exception("xlsx extraction failed")
        return ExtractedDocument(kind="xlsx", text="", error=str(e))


def extract_csv(body: bytes) -> ExtractedDocument:
    try:
        # Try utf-8 first; fall back to latin-1 (covers bank statement exports)
        try:
            content = body.decode("utf-8")
        except UnicodeDecodeError:
            content = body.decode("latin-1", errors="replace")
        reader = csv.reader(io.StringIO(content))
        rows: list[str] = []
        for i, row in enumerate(reader):
            rows.append(" | ".join(row))
            if i >= 5000:
                rows.append("[…row cap of 5000 reached]")
                break
        text, trunc = _truncate("\n".join(rows))
        return ExtractedDocument(kind="csv", text=text, truncated=trunc)
    except Exception as e:
        logger.exception("CSV extraction failed")
        return ExtractedDocument(kind="csv", text="", error=str(e))


def extract(body: bytes, mime: str, filename: str = "") -> ExtractedDocument:
    kind = detect_kind(mime, filename)
    if kind == "pdf":
        return extract_pdf(body)
    if kind == "xlsx":
        return extract_xlsx(body)
    if kind == "csv":
        return extract_csv(body)
    return ExtractedDocument(
        kind="unknown",
        text="",
        error=f"Unsupported type (mime={mime}, name={filename})",
    )
