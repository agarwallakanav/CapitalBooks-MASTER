"""Incoming document extraction (PDF / xlsx / csv) for WhatsApp attachments."""
