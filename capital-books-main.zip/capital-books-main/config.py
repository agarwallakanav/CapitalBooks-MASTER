from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # App
    app_env: Literal["development", "staging", "production"] = "development"
    log_level: str = "INFO"

    # Supabase
    supabase_url: str
    supabase_key: str

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Claude / Anthropic
    anthropic_api_key: str
    anthropic_model_fast: str = "claude-haiku-4-5-20251001"
    anthropic_model_smart: str = "claude-sonnet-4-6"

    # WhatsApp
    whatsapp_verify_token: str = ""
    whatsapp_access_token: str = ""
    whatsapp_phone_number_id: str = ""

    # Stripe
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""

    # Gmail
    gmail_address: str = ""
    gmail_app_password: str = ""

    # AWS S3
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_region: str = "me-central-1"
    s3_bucket_name: str = ""

    # Zoho Books
    zoho_client_id: str = ""
    zoho_client_secret: str = ""
    zoho_refresh_token: str = ""
    zoho_organization_id: str = ""
    zoho_region: Literal["com", "eu", "in", "com.au"] = "com"

    # Categorizer
    categorizer_interval_minutes: int = Field(default=30, ge=1)

    # Public base URL — used to build clean payment redirect links sent in
    # WhatsApp (e.g. https://capitalbooks.net/pay/INV-202606-0001 → redirects
    # to the full Stripe Checkout URL). Should be the SAME host the public
    # internet reaches the server on (ngrok URL in dev, your domain in prod).
    # Override via PUBLIC_BASE_URL env var.
    public_base_url: str = "https://capitalbooks.app"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
