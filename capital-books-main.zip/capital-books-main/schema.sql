-- CapitalBooks Supabase schema
-- Apply via Supabase SQL editor or psql. Idempotent.

create extension if not exists pgcrypto;

-- =========================================================================
-- clients: per-tenant config + QuickBooks/Stripe credentials
-- =========================================================================
create table if not exists clients (
    id uuid primary key default gen_random_uuid(),
    company_name text not null,
    phone text not null unique,
    email text,
    trn text,
    peppol_id text,

    -- Zoho Books
    zoho_organization_id text,
    zoho_access_token text,
    zoho_refresh_token text,
    zoho_token_expires_at timestamptz,
    -- Per-org Zoho tax_ids: {"standard": "<uuid>", "zero": "<uuid>", "exempt": "<uuid>", "reverse_charge": "<uuid>"}
    zoho_tax_ids jsonb not null default '{}'::jsonb,
    -- Regional Zoho API base (e.g. www.zohoapis.com / .eu / .in / .com.au).
    -- Returned in the OAuth token response — never hardcode.
    api_domain text not null default 'www.zohoapis.com',
    -- Card-last-4 → {account_id, payment_method} for paid_through resolution.
    card_mapping jsonb not null default '{}'::jsonb,
    -- Fallback paid_through_account_id when card_mapping has no match.
    default_payment_account text,
    -- Per-client audit-log Google Sheet (monthly rows appended per transaction).
    google_sheet_id text,

    -- Stripe (per-client connect or direct key)
    stripe_secret_key text,

    -- VAT / accounting config
    vat_basis text not null default 'accrual'
        check (vat_basis in ('accrual', 'realisation')),
    entity_type text,
    supply_mix jsonb not null default '{}'::jsonb,
    foreign_suppliers jsonb not null default '[]'::jsonb,

    -- Invoicing
    invoice_template jsonb not null default '{}'::jsonb,

    -- Routing thresholds
    confidence_threshold int not null default 95
        check (confidence_threshold between 0 and 100),
    approval_amount_limit numeric(15, 2) not null default 5000.00,
    approval_threshold numeric(15, 2) not null default 5000.00,

    is_active boolean not null default true,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create index if not exists clients_phone_active_idx
    on clients (phone) where is_active;

-- =========================================================================
-- transactions: every receipt/invoice processed by the VAT pipeline
-- =========================================================================
create table if not exists transactions (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,

    vendor text,
    description text,
    direction text not null check (direction in ('income', 'expense')),

    -- Amounts (gross is what's on the document; net excludes VAT)
    amount numeric(15, 2) not null,
    net_amount numeric(15, 2),
    vat_amount numeric(15, 2) not null default 0,
    currency text not null default 'AED',
    fx_rate numeric(15, 6) not null default 1.0,
    amount_aed numeric(15, 2),

    -- Categorization
    category text,
    account_code text,
    confidence_score int check (confidence_score between 0 and 100),

    -- VAT
    vat_type text check (vat_type in
        ('standard', 'zero', 'exempt', 'reverse_charge', 'out_of_scope')),
    vat_boxes int[] not null default '{}',
    tax_point_date date,
    is_blocked_vat boolean not null default false,
    blocked_vat_category text,

    -- Routing / status
    status text not null check (status in
        ('auto_posted', 'needs_review', 'hold_until_paid',
         'manually_categorized', 'rejected', 'failed')),
    routing_reason text,

    -- Zoho Books linkage
    zoho_entity_type text,
    zoho_entity_id text,

    -- Source
    source_document_url text,
    raw_payload jsonb not null default '{}'::jsonb,

    -- Soft-delete (set by /edit + /delete WhatsApp flows)
    deleted boolean not null default false,

    created_at timestamptz not null default now()
);

create index if not exists transactions_active_idx
    on transactions (client_id, created_at desc)
    where deleted = false;

create index if not exists transactions_client_created_idx
    on transactions (client_id, created_at desc);

create index if not exists transactions_needs_review_idx
    on transactions (client_id, created_at desc)
    where status in ('needs_review', 'hold_until_paid', 'manually_categorized');

-- =========================================================================
-- categorization_rules: vendor → category mapping learned over time
-- =========================================================================
create table if not exists categorization_rules (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,
    vendor_pattern text not null,
    category text not null,
    account_code text,
    vat_type text check (vat_type in
        ('standard', 'zero', 'exempt', 'reverse_charge', 'out_of_scope')),
    times_used int not null default 0,
    created_at timestamptz not null default now(),
    unique (client_id, vendor_pattern)
);

create index if not exists categorization_rules_client_idx
    on categorization_rules (client_id);

-- =========================================================================
-- invoices: AR invoices created via WhatsApp
-- =========================================================================
create table if not exists invoices (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,

    invoice_number text not null,
    customer_name text not null,
    customer_trn text,
    customer_phone text,
    customer_email text,

    amount numeric(15, 2) not null,
    vat_amount numeric(15, 2) not null default 0,
    total numeric(15, 2) not null,
    currency text not null default 'AED',

    status text not null default 'draft' check (status in
        ('draft', 'sent', 'paid', 'overdue', 'cancelled')),

    pdf_url text,
    zoho_invoice_id text,
    stripe_session_id text,
    stripe_payment_intent text,

    -- Receipt artifacts populated after Stripe payment success
    receipt_number text,
    receipt_url text,

    due_date date,
    paid_date date,
    created_at timestamptz not null default now(),

    unique (client_id, invoice_number),
    unique (client_id, receipt_number)
);

create index if not exists invoices_client_status_idx
    on invoices (client_id, status);

create index if not exists invoices_outstanding_due_idx
    on invoices (due_date)
    where status in ('sent', 'overdue');

-- =========================================================================
-- bills: vendor bills (Accounts Payable)
-- =========================================================================
create table if not exists bills (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,

    vendor text not null,
    vendor_trn text,
    bill_number text,
    description text,

    amount numeric(15, 2) not null,
    net_amount numeric(15, 2),
    vat_amount numeric(15, 2) not null default 0,
    currency text not null default 'AED',
    fx_rate numeric(15, 6) not null default 1.0,

    vat_type text check (vat_type in
        ('standard', 'zero', 'exempt', 'reverse_charge', 'out_of_scope')),
    vat_boxes int[] not null default '{}',
    is_blocked_vat boolean not null default false,

    bill_date date,
    due_date date,
    scheduled_payment_date date,
    paid_date date,

    status text not null check (status in
        ('unpaid', 'scheduled', 'paid', 'overdue', 'needs_approval', 'rejected', 'failed')),
    confidence_score int check (confidence_score between 0 and 100),
    routing_reason text,

    zoho_bill_id text,
    zoho_vendor_id text,
    source_document_url text,
    raw_payload jsonb not null default '{}'::jsonb,

    deleted boolean not null default false,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create index if not exists bills_active_idx
    on bills (client_id, created_at desc) where deleted = false;
create index if not exists bills_due_idx
    on bills (due_date)
    where status in ('unpaid', 'scheduled', 'overdue');
create index if not exists bills_needs_approval_idx
    on bills (client_id, created_at desc)
    where status = 'needs_approval';

-- =========================================================================
-- pending_reviews: items the confidence engine paused before posting to Zoho
-- =========================================================================
create table if not exists pending_reviews (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,

    source_kind text not null check (source_kind in ('text', 'image')),
    source_text text,
    source_document_key text,
    source_document_url text,

    extracted jsonb not null default '{}'::jsonb,
    flags jsonb not null default '[]'::jsonb,
    resolved_fields jsonb not null default '{}'::jsonb,

    action text not null check (action in ('post', 'flag', 'hold', 'block')),
    status text not null default 'awaiting_user' check (status in
        ('awaiting_user', 'resolved', 'discarded')),

    zoho_entity_type text,
    zoho_entity_id text,

    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create index if not exists pending_reviews_open_idx
    on pending_reviews (client_id, created_at desc)
    where status = 'awaiting_user';

-- =========================================================================
-- transaction_events: append-only audit log
-- Only the orchestrator writes here. Records every lifecycle event for any
-- entity (transactions, bills, invoices, payments) + every Zoho API call
-- attempt with success/error attribution. Powers daily-cap monitoring.
-- =========================================================================
create table if not exists transaction_events (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,
    entity_type text check (entity_type in
        ('transaction', 'bill', 'invoice', 'payment', 'receipt')),
    entity_id uuid,
    event_type text not null,
    actor text not null default 'orchestrator',
    payload jsonb not null default '{}'::jsonb,
    zoho_entity_type text,
    zoho_entity_id text,
    api_calls int not null default 0,
    api_domain text,
    error_code text,
    error_message text,
    created_at timestamptz not null default now()
);

create index if not exists txn_events_client_time_idx
    on transaction_events (client_id, created_at desc);
create index if not exists txn_events_entity_idx
    on transaction_events (entity_type, entity_id);
create index if not exists txn_events_api_calls_idx
    on transaction_events (client_id, created_at)
    where api_calls > 0;
