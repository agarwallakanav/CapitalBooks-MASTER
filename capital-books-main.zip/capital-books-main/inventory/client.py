"""Thin Zoho Inventory client — reuses the Books client's auth pipeline.

Same org, same OAuth tokens, same refresh mechanism. Only the base URL
differs (/inventory/v1 instead of /books/v3), so we subclass ZohoClient
and override _base_url. Everything else — auto-401 refresh, rate limiting,
retry backoff — is inherited.
"""
from __future__ import annotations

from orchestrator.zoho_client import ZohoClient


class ZohoInventoryClient(ZohoClient):
    """Same credentials, same refresh, /inventory/v1 base."""

    def _base_url(self) -> str:
        return f"https://{self.creds.api_domain}/inventory/v1"
