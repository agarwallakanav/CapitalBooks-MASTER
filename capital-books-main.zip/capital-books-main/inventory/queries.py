"""Inventory query handlers — the stateless entry points the router calls.

  list_all_stock(input, ctx)      → "show inventory" / "stock levels"
  item_lookup(input, ctx)         → "how much widget A do I have"
  low_stock(input, ctx)           → "low stock" / "what needs reordering"
  inventory_value(input, ctx)     → "inventory value" / "stock value"
  best_selling(input, ctx)        → "best selling products"
  slow_moving(input, ctx)         → "slow moving stock"

All handlers return a ModuleResult. >15 items → xlsx attachment via the
same sentinel pattern used for vendors/customers/audit.
"""
from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, timedelta
from io import BytesIO
from typing import Any, Literal
from uuid import UUID

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from inventory.client import ZohoInventoryClient
from orchestrator.engine import ModuleResult, OrchContext
from orchestrator.zoho_client import ClientCredentials

logger = logging.getLogger(__name__)

_INLINE_CAP = 15
_NAVY = "1A2332"; _ALT = "F4F6F8"; _MINT = "4CAF50"
_AED_FMT = '_-* #,##0.00 [$AED]_-;-* #,##0.00 [$AED]_-'


@dataclass
class InventoryQuery:
    sender: str | None = None


@dataclass
class ItemLookupQuery:
    name: str
    sender: str | None = None


@dataclass
class SlowMovingQuery:
    days: int = 60
    sender: str | None = None


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _inventory_creds(cfg) -> ClientCredentials:
    """Build a ClientCredentials for the same client — subclass will point
    at /inventory/v1 instead of /books/v3."""
    return ClientCredentials(
        client_id=cfg.id, organization_id=cfg.zoho_organization_id,
        api_domain=cfg.api_domain, access_token=cfg.zoho_access_token,
        refresh_token=cfg.zoho_refresh_token,
        token_expires_at=cfg.zoho_token_expires_at,
    )


async def _fetch_items(inv, filter_by: str | None = None) -> list[dict[str, Any]]:
    filters: dict[str, Any] = {"per_page": 200}
    if filter_by:
        filters["filter_by"] = filter_by
    try:
        r = await inv.list_entities("items", filters=filters)
        items = r.get("items") or []
        logger.info(
            "Zoho GET /inventory/v1/items%s → %d items",
            f"?filter_by={filter_by}" if filter_by else "", len(items),
        )
        return items
    except Exception:
        logger.exception("inventory items fetch failed")
        return []


async def _fetch_sales_orders(inv, days: int = 90) -> list[dict[str, Any]]:
    """Recent sales orders. We use the /salesorders list + a date filter to
    keep the payload small — inventory orgs with lots of history otherwise
    thrash the API."""
    since = (date.today() - timedelta(days=days)).isoformat()
    try:
        r = await inv.list_entities("salesorders", filters={
            "per_page": 200, "date_after": since,
        })
        return r.get("salesorders") or []
    except Exception:
        logger.exception("salesorders fetch failed")
        return []


def _sold_qty_by_item(
    sales_orders: list[dict[str, Any]],
) -> tuple[dict[str, float], dict[str, date]]:
    """Returns (item_id → total qty sold, item_id → last-sold date)."""
    qty: dict[str, float] = defaultdict(float)
    last_sold: dict[str, date] = {}
    for so in sales_orders:
        d = so.get("date")
        try:
            when = date.fromisoformat(str(d)[:10]) if d else None
        except ValueError:
            when = None
        for li in so.get("line_items") or []:
            iid = li.get("item_id")
            if not iid:
                continue
            try:
                q = float(li.get("quantity") or 0)
            except (TypeError, ValueError):
                q = 0
            qty[iid] += q
            if when and (iid not in last_sold or when > last_sold[iid]):
                last_sold[iid] = when
    return qty, last_sold


def _fmt_money(amt: float, currency: str = "AED") -> str:
    return f"{currency} {amt:,.2f}"


def _stock_status(item: dict[str, Any]) -> tuple[float, float, float]:
    """Returns (on_hand, reorder_level, unit_rate). Missing → 0."""
    def _f(k: str) -> float:
        v = item.get(k)
        try:
            return float(v) if v is not None else 0.0
        except (TypeError, ValueError):
            return 0.0
    on_hand = _f("stock_on_hand") if "stock_on_hand" in item else _f("actual_available_stock")
    return on_hand, _f("reorder_level"), _f("rate")


# ---------------------------------------------------------------------------
# 1. All-stock listing
# ---------------------------------------------------------------------------

async def list_all_stock(input: InventoryQuery, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    async with ZohoInventoryClient(_inventory_creds(cfg)) as inv:
        items = await _fetch_items(inv)
    if not items:
        return ModuleResult(
            reply_to_user=(
                "No items in your Zoho Inventory. Add products in Zoho or "
                "record a purchase order and I'll start tracking stock."
            ),
        )

    if len(items) <= _INLINE_CAP:
        return ModuleResult(reply_to_user=_format_stock_inline(items, cfg))

    return await _list_as_excel(
        items, ctx, filename_stem="stock_levels", sender_phone=input.sender,
    )


def _format_stock_inline(items: list[dict[str, Any]], cfg) -> str:
    lines = [f"📦 *Inventory — {len(items)} items*", ""]
    total_value = 0.0
    currency = "AED"
    # Sort by name for scannable output
    for it in sorted(items, key=lambda i: (i.get("name") or "").lower()):
        on_hand, reorder, rate = _stock_status(it)
        value = on_hand * rate
        total_value += value
        currency = it.get("currency_code") or currency
        low = " ⚠️ LOW" if reorder > 0 and on_hand <= reorder else ""
        lines.append(
            f"  • {it.get('name') or '(unnamed)'} — "
            f"{on_hand:g} in stock @ {_fmt_money(rate, currency)}"
            f" = {_fmt_money(value, currency)}{low}"
        )
    lines.append("")
    lines.append(f"*Total stock value: {_fmt_money(total_value, currency)}*")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 2. Single-item lookup
# ---------------------------------------------------------------------------

async def item_lookup(input: ItemLookupQuery, ctx: OrchContext) -> ModuleResult:
    needle = (input.name or "").strip().lower()
    if not needle:
        return ModuleResult(reply_to_user="Which product? Say 'how much X do I have'.")
    cfg = ctx.cfg
    async with ZohoInventoryClient(_inventory_creds(cfg)) as inv:
        items = await _fetch_items(inv)
    # Case-insensitive substring match
    hits = [
        it for it in items
        if needle in (it.get("name") or "").lower()
        or needle in (it.get("sku") or "").lower()
    ]
    if not hits:
        return ModuleResult(reply_to_user=f"Couldn't find *{input.name}* in inventory.")
    if len(hits) > 5:
        return ModuleResult(reply_to_user=(
            f"{len(hits)} items match *{input.name}*. Be more specific "
            f"(top matches: {', '.join((h.get('name') or '') for h in hits[:5])})."
        ))
    lines = [f"📦 *{input.name}*", ""]
    for it in hits:
        on_hand, reorder, rate = _stock_status(it)
        currency = it.get("currency_code") or "AED"
        low = " ⚠️ LOW" if reorder > 0 and on_hand <= reorder else ""
        lines.append(
            f"  • {it.get('name')} (SKU {it.get('sku') or '—'})\n"
            f"    Stock: *{on_hand:g}*{low}   Reorder: {reorder:g}\n"
            f"    Unit: {_fmt_money(rate, currency)}   "
            f"Value: {_fmt_money(on_hand * rate, currency)}"
        )
    return ModuleResult(reply_to_user="\n".join(lines))


# ---------------------------------------------------------------------------
# 3. Low stock
# ---------------------------------------------------------------------------

async def low_stock(input: InventoryQuery, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    async with ZohoInventoryClient(_inventory_creds(cfg)) as inv:
        # Zoho supports filter_by=Status.LowStock — cheaper than pulling
        # everything and filtering locally.
        items = await _fetch_items(inv, filter_by="Status.LowStock")
        # Fallback: if Zoho didn't understand the filter (some org versions),
        # pull everything and filter locally.
        if not items:
            all_items = await _fetch_items(inv)
            items = [
                it for it in all_items
                if float(it.get("reorder_level") or 0) > 0
                and float(it.get("stock_on_hand") or 0) <= float(it.get("reorder_level") or 0)
            ]

    if not items:
        return ModuleResult(reply_to_user="✅ Nothing low — all items are above their reorder levels.")

    lines = [f"⚠️ *Low stock — {len(items)} item(s)*", ""]
    for it in sorted(items, key=lambda i: float(i.get("stock_on_hand") or 0)):
        on_hand, reorder, rate = _stock_status(it)
        emoji = "🚨" if on_hand <= 0 else "⚠️"
        note = f"{on_hand:g} left" if on_hand > 0 else "0 in stock!"
        lines.append(f"  {emoji} {it.get('name') or '(unnamed)'} — {note}"
                     f"  (reorder at {reorder:g})")
    lines.append("")
    lines.append("Reply 'create purchase order for X' to reorder any of these.")
    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{"event_type": "inventory_low_stock_queried",
                       "payload": {"count": len(items)}}],
    )


# ---------------------------------------------------------------------------
# 4. Inventory value
# ---------------------------------------------------------------------------

async def inventory_value(input: InventoryQuery, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    async with ZohoInventoryClient(_inventory_creds(cfg)) as inv:
        items = await _fetch_items(inv)
    if not items:
        return ModuleResult(reply_to_user="No items in inventory — nothing to value.")

    total_value = 0.0
    total_units = 0.0
    currency = "AED"
    by_bucket = {"in_stock": 0.0, "low": 0.0, "out": 0.0}
    for it in items:
        on_hand, reorder, rate = _stock_status(it)
        currency = it.get("currency_code") or currency
        value = on_hand * rate
        total_value += value
        total_units += on_hand
        if on_hand <= 0:
            by_bucket["out"] += value
        elif reorder > 0 and on_hand <= reorder:
            by_bucket["low"] += value
        else:
            by_bucket["in_stock"] += value

    lines = [
        f"💰 *Inventory value*",
        "",
        f"Total: *{_fmt_money(total_value, currency)}*  ({len(items)} items, "
        f"{total_units:g} units)",
        "",
        f"  Healthy:   {_fmt_money(by_bucket['in_stock'], currency)}",
        f"  Low stock: {_fmt_money(by_bucket['low'], currency)}",
        f"  Out:       {_fmt_money(by_bucket['out'], currency)}",
    ]
    return ModuleResult(reply_to_user="\n".join(lines))


# ---------------------------------------------------------------------------
# 5. Best selling
# ---------------------------------------------------------------------------

async def best_selling(input: InventoryQuery, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    async with ZohoInventoryClient(_inventory_creds(cfg)) as inv:
        items, sos = await asyncio.gather(
            _fetch_items(inv),
            _fetch_sales_orders(inv, days=90),
        )
    if not items:
        return ModuleResult(reply_to_user="No items in inventory — nothing to rank.")
    if not sos:
        return ModuleResult(reply_to_user="No sales orders in the last 90 days.")

    qty_by_item, _last = _sold_qty_by_item(sos)
    by_id = {it.get("item_id"): it for it in items}
    ranked = [
        (by_id.get(iid), q) for iid, q in qty_by_item.items()
        if by_id.get(iid) is not None
    ]
    ranked.sort(key=lambda p: -p[1])
    top = ranked[:_INLINE_CAP]
    if not top:
        return ModuleResult(reply_to_user="No sales matched any items in inventory.")

    lines = [f"🏆 *Best sellers (last 90 days)*", ""]
    for i, (it, q) in enumerate(top, 1):
        on_hand, _r, rate = _stock_status(it)
        currency = it.get("currency_code") or "AED"
        lines.append(
            f"  {i}. {it.get('name')} — sold {q:g}, {on_hand:g} in stock "
            f"@ {_fmt_money(rate, currency)}"
        )
    return ModuleResult(reply_to_user="\n".join(lines))


# ---------------------------------------------------------------------------
# 6. Slow moving
# ---------------------------------------------------------------------------

async def slow_moving(input: SlowMovingQuery, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    days = max(30, min(input.days or 60, 365))
    async with ZohoInventoryClient(_inventory_creds(cfg)) as inv:
        items, sos = await asyncio.gather(
            _fetch_items(inv),
            _fetch_sales_orders(inv, days=days),
        )
    if not items:
        return ModuleResult(reply_to_user="No items in inventory.")

    _qty, last_sold = _sold_qty_by_item(sos)
    stagnant = [
        it for it in items
        if float(it.get("stock_on_hand") or 0) > 0
        and it.get("item_id") not in last_sold
    ]
    if not stagnant:
        return ModuleResult(
            reply_to_user=f"✅ Nothing slow-moving — everything sold in the last {days} days.",
        )

    lines = [f"🐌 *Slow-moving stock (no sale in {days}d)* — {len(stagnant)} items", ""]
    for it in sorted(stagnant, key=lambda i: -float(i.get("stock_on_hand") or 0))[:_INLINE_CAP]:
        on_hand, _r, rate = _stock_status(it)
        currency = it.get("currency_code") or "AED"
        value = on_hand * rate
        lines.append(
            f"  • {it.get('name')} — {on_hand:g} sitting, tied-up value: "
            f"{_fmt_money(value, currency)}"
        )
    if len(stagnant) > _INLINE_CAP:
        lines.append(f"  … +{len(stagnant) - _INLINE_CAP} more")
    return ModuleResult(reply_to_user="\n".join(lines))


# ---------------------------------------------------------------------------
# Excel export
# ---------------------------------------------------------------------------

def _build_stock_xlsx(items: list[dict[str, Any]], last_sold_by_item: dict[str, date] | None = None) -> bytes:
    wb = Workbook(); ws = wb.active; ws.title = "Inventory"
    headers = ["#", "Item Name", "SKU", "Stock on Hand", "Reorder Level",
               "Unit Price", "Stock Value", "Last Sold"]
    for c, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=_NAVY)

    total_value = 0.0
    for i, it in enumerate(sorted(items, key=lambda x: (x.get("name") or "").lower()), 1):
        r = i + 1
        on_hand, reorder, rate = _stock_status(it)
        value = on_hand * rate
        total_value += value
        last_sold = (last_sold_by_item or {}).get(it.get("item_id"))
        ws.cell(row=r, column=1, value=i)
        ws.cell(row=r, column=2, value=it.get("name") or "")
        ws.cell(row=r, column=3, value=it.get("sku") or "")
        ws.cell(row=r, column=4, value=on_hand)
        ws.cell(row=r, column=5, value=reorder)
        ws.cell(row=r, column=6, value=rate)
        ws.cell(row=r, column=7, value=round(value, 2))
        ws.cell(row=r, column=8, value=last_sold.isoformat() if last_sold else "")
        if r % 2 == 0:
            for c in range(1, len(headers) + 1):
                ws.cell(row=r, column=c).fill = PatternFill("solid", fgColor=_ALT)

    # Totals row
    trow = ws.max_row + 1
    ws.cell(row=trow, column=2, value=f"TOTAL ({len(items)} items)")
    ws.cell(row=trow, column=7, value=round(total_value, 2))
    for c in range(1, len(headers) + 1):
        ws.cell(row=trow, column=c).font = Font(bold=True, color="FFFFFF")
        ws.cell(row=trow, column=c).fill = PatternFill("solid", fgColor=_MINT)

    for col in (6, 7):
        for r in range(2, ws.max_row + 1):
            ws.cell(row=r, column=col).number_format = _AED_FMT
    ws.freeze_panes = "A2"
    for col_idx in range(1, len(headers) + 1):
        col = get_column_letter(col_idx)
        max_len = len(headers[col_idx - 1])
        for r in range(1, ws.max_row + 1):
            v = ws.cell(row=r, column=col_idx).value
            if v is None: continue
            max_len = max(max_len, len(str(v)))
        ws.column_dimensions[col].width = min(max_len + 3, 50)

    buf = BytesIO(); wb.save(buf)
    return buf.getvalue()


async def _list_as_excel(
    items: list[dict[str, Any]], ctx: OrchContext,
    *, filename_stem: str, sender_phone: str | None,
) -> ModuleResult:
    import time as _time
    from ar.storage import upload_bytes
    from whatsapp.sender import send_document
    cfg = ctx.cfg

    last_sold: dict[str, date] = {}
    try:
        async with ZohoInventoryClient(_inventory_creds(cfg)) as inv:
            sos = await _fetch_sales_orders(inv, days=180)
        _q, last_sold = _sold_qty_by_item(sos)
    except Exception:
        logger.exception("last-sold enrichment failed (non-fatal)")

    xlsx = _build_stock_xlsx(items, last_sold_by_item=last_sold)
    key = f"inventory/{cfg.id}/{filename_stem}_{int(_time.time())}.xlsx"
    file_url = await upload_bytes(
        key, xlsx,
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    caption = (
        f"📦 Inventory Report — {cfg.company_name}\n"
        f"{len(items)} items"
    )
    if not sender_phone:
        return ModuleResult(
            reply_to_user=f"📎 {caption}\nDirect link: {file_url}",
        )
    try:
        await send_document(
            to=sender_phone, link=file_url,
            filename=f"{filename_stem}.xlsx", caption=caption,
        )
        return ModuleResult(
            reply_to_user="__SUPPRESS_REPLY__",
            extra_events=[{
                "event_type": "inventory_exported",
                "payload": {"count": len(items)},
            }],
        )
    except Exception as e:
        logger.exception("WhatsApp document send failed for inventory")
        return ModuleResult(
            reply_to_user=f"⚠️ Built the report but couldn't send the attachment: {e}\nDirect link: {file_url}",
        )


async def export_inventory(input: InventoryQuery, ctx: OrchContext) -> ModuleResult:
    """Always send as Excel, regardless of item count."""
    cfg = ctx.cfg
    async with ZohoInventoryClient(_inventory_creds(cfg)) as inv:
        items = await _fetch_items(inv)
    if not items:
        return ModuleResult(reply_to_user="No items in inventory — nothing to export.")
    return await _list_as_excel(
        items, ctx, filename_stem="inventory_full",
        sender_phone=input.sender,
    )
