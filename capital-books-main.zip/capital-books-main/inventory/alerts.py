"""Low-stock section for the daily briefing.

  render_low_stock_section(cfg) → str (empty if nothing to alert on)

Called from reminders/daily_briefing.brief_client. Best-effort: any
failure returns an empty string so briefing rendering is never blocked.
"""
from __future__ import annotations

import logging

from inventory.client import ZohoInventoryClient
from inventory.queries import _fetch_items, _inventory_creds, _stock_status

logger = logging.getLogger(__name__)

_TOP_N = 6


async def render_low_stock_section(cfg) -> str:
    try:
        async with ZohoInventoryClient(_inventory_creds(cfg)) as inv:
            items = await _fetch_items(inv, filter_by="Status.LowStock")
            if not items:
                # Fallback for orgs where the Zoho filter doesn't exist:
                # pull everything + filter locally.
                all_items = await _fetch_items(inv)
                items = [
                    it for it in all_items
                    if float(it.get("reorder_level") or 0) > 0
                    and float(it.get("stock_on_hand") or 0)
                        <= float(it.get("reorder_level") or 0)
                ]
    except Exception:
        logger.exception("low-stock briefing section failed (non-fatal)")
        return ""

    if not items:
        return ""

    items_sorted = sorted(items, key=lambda i: float(i.get("stock_on_hand") or 0))
    lines = ["", f"📦 *Low stock alert — {len(items)} item(s)*"]
    for it in items_sorted[:_TOP_N]:
        on_hand, reorder, _rate = _stock_status(it)
        note = f"{on_hand:g} left (reorder at {reorder:g})" if on_hand > 0 \
            else "0 in stock!"
        lines.append(f"  • {it.get('name') or '(unnamed)'} — {note}")
    if len(items) > _TOP_N:
        lines.append(f"  … +{len(items) - _TOP_N} more")
    lines.append("Reply 'create purchase order for X' to reorder these.")
    return "\n".join(lines)
