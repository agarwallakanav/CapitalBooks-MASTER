"""Zoho Inventory integration — stock queries + low-stock alerts."""
