"""Zoho Books API client (httpx, async).

  - Per-client organization_id + access_token + refresh_token
  - Every request appends ?organization_id=... — Zoho requires it
  - Auth header: Zoho-oauthtoken <token>  (NOT Bearer)
  - On 401 → auto-refresh + retry once
"""
from typing import Any
from uuid import UUID

import httpx

from config import settings
from zoho.auth import persist_refreshed_tokens, refresh_access_token

API_BASE_BY_REGION = {
    "com": "https://www.zohoapis.com/books/v3",
    "eu": "https://www.zohoapis.eu/books/v3",
    "in": "https://www.zohoapis.in/books/v3",
    "com.au": "https://www.zohoapis.com.au/books/v3",
}


class ZohoBooksClient:
    def __init__(
        self,
        organization_id: str,
        access_token: str,
        refresh_token: str,
        client_uuid: UUID,
        region: str | None = None,
    ):
        self.organization_id = organization_id
        self.access_token = access_token
        self.refresh_token = refresh_token
        self.client_uuid = client_uuid
        self.region = region or settings.zoho_region
        self.base_url = API_BASE_BY_REGION[self.region]
        self._http = httpx.AsyncClient(timeout=30.0)

    async def __aenter__(self) -> "ZohoBooksClient":
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.close()

    async def close(self) -> None:
        await self._http.aclose()

    def _url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Zoho-oauthtoken {self.access_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _params(self, extra: dict[str, Any] | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"organization_id": self.organization_id}
        if extra:
            params.update(extra)
        return params

    async def _refresh(self) -> None:
        token = await refresh_access_token(self.refresh_token, region=self.region)
        self.access_token = token["access_token"]
        if token.get("refresh_token"):
            self.refresh_token = token["refresh_token"]
        await persist_refreshed_tokens(self.client_uuid, token)

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        _retried: bool = False,
    ) -> dict[str, Any]:
        import logging
        logger = logging.getLogger(__name__)
        resp = await self._http.request(
            method,
            self._url(path),
            headers=self._headers(),
            params=self._params(params),
            json=json,
        )
        if resp.status_code == 401 and not _retried:
            await self._refresh()
            return await self._request(
                method, path, params=params, json=json, _retried=True
            )
        if resp.status_code >= 400:
            logger.error(
                "Zoho %s %s -> %s body=%s payload=%s",
                method, path, resp.status_code, resp.text[:500], json,
            )
        resp.raise_for_status()
        return resp.json() if resp.content else {}

    async def create_entity(
        self,
        entity: str,
        payload: dict[str, Any],
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """entity is the plural endpoint segment, e.g. 'expenses', 'bills', 'invoices'."""
        return await self._request("POST", entity, params=params, json=payload)

    async def update_entity(
        self, entity: str, entity_id: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return await self._request("PUT", f"{entity}/{entity_id}", json=payload)

    async def get_entity(self, entity: str, entity_id: str) -> dict[str, Any]:
        return await self._request("GET", f"{entity}/{entity_id}")

    async def delete_entity(self, entity: str, entity_id: str) -> dict[str, Any]:
        return await self._request("DELETE", f"{entity}/{entity_id}")

    async def list_entities(
        self, entity: str, filters: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        return await self._request("GET", entity, params=filters)

    async def report(
        self, name: str, filters: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        return await self._request("GET", f"reports/{name}", params=filters)

    async def search_contacts(self, name: str) -> list[dict[str, Any]]:
        resp = await self._request("GET", "contacts", params={"contact_name_contains": name})
        return resp.get("contacts") or []

    async def download_pdf(self, entity: str, entity_id: str, _retried: bool = False) -> bytes:
        """Fetch an entity (invoice/bill/etc.) as a PDF binary.
        Returns raw bytes — caller is responsible for storing/sharing."""
        resp = await self._http.get(
            self._url(f"{entity}/{entity_id}"),
            headers={**self._headers(), "Accept": "application/pdf"},
            params=self._params(),
        )
        if resp.status_code == 401 and not _retried:
            await self._refresh()
            return await self.download_pdf(entity, entity_id, _retried=True)
        resp.raise_for_status()
        return resp.content

    async def create_contact(self, name: str, contact_type: str = "customer") -> dict[str, Any]:
        return await self._request("POST", "contacts", json={
            "contact_name": name,
            "contact_type": contact_type,
        })
