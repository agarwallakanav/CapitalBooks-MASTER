"""Build Zoho Books entity payloads from a TransactionContext.

Zoho entity → endpoint segment:
  Expense          → expenses
  Bill             → bills
  Invoice          → invoices
  BankTransaction  → banktransactions   (deposits, transfers, owner contribs)
  Journal          → journals
  CustomerPayment  → customerpayments

UAE tax handling: Zoho stores per-org tax_ids (UUIDs). We map our logical VAT
names to the IDs the client configured in their `clients.zoho_tax_ids` JSONB:
  {"standard": "<id>", "zero": "<id>", "exempt": "<id>", "reverse_charge": "<id>"}

Vendor / customer / account ID resolution is left to the categorizer or
operator config — payloads here mark those with TODO.
"""
from typing import Any

from transactions.models import TransactionContext

ZOHO_VAT_KEYS: tuple[str, ...] = (
    "standard", "zero", "exempt", "reverse_charge", "out_of_scope",
)

ENDPOINT_BY_ENTITY: dict[str, str] = {
    "Expense": "expenses",
    "Bill": "bills",
    "Invoice": "invoices",
    "BankTransaction": "banktransactions",
    "Journal": "journals",
    "CustomerPayment": "customerpayments",
}


def endpoint_for(entity_type: str) -> str:
    if entity_type not in ENDPOINT_BY_ENTITY:
        raise ValueError(f"Unknown Zoho entity type: {entity_type}")
    return ENDPOINT_BY_ENTITY[entity_type]


def _tax_id(ctx: TransactionContext, tax_ids: dict[str, str]) -> str | None:
    """Resolve logical VAT name → Zoho tax_id from per-client config."""
    if ctx.blocked_vat and ctx.blocked_vat.is_blocked:
        return tax_ids.get("out_of_scope")
    if not ctx.vat_classification:
        return tax_ids.get("out_of_scope")
    return tax_ids.get(ctx.vat_classification.vat_type)


def _txn_date(ctx: TransactionContext) -> str:
    if ctx.tax_point_date:
        return ctx.tax_point_date.isoformat()
    if ctx.input.invoice_date:
        return ctx.input.invoice_date.isoformat()
    return ""


def _line_amount(ctx: TransactionContext) -> float:
    return float(ctx.amounts.net) if ctx.amounts else float(ctx.input.amount)


def _exchange_rate(ctx: TransactionContext) -> float | None:
    if not ctx.amounts:
        return None
    if (ctx.input.currency or "AED").upper() == "AED":
        return None
    return float(ctx.amounts.fx_rate)


def build_expense_payload(ctx: TransactionContext, tax_ids: dict[str, str]) -> dict[str, Any]:
    """An out-of-pocket / cash expense in Zoho Books.

    Requires account_id (which expense account to charge) and paid_through_account_id
    (cash/bank). We read sane defaults from the per-client `zoho_tax_ids` JSONB under
    reserved keys `_default_expense_account_id` + `_default_paid_through_account_id`.
    The categorizer (Module 4) re-classifies into specific expense accounts later.
    """
    payload: dict[str, Any] = {
        "date": _txn_date(ctx),
        "amount": _line_amount(ctx),
        "description": ctx.input.description,
        "is_inclusive_tax": False,
    }
    expense_account = tax_ids.get("_default_expense_account_id")
    paid_through = tax_ids.get("_default_paid_through_account_id")
    if expense_account:
        payload["account_id"] = expense_account
    if paid_through:
        payload["paid_through_account_id"] = paid_through
    tax_id = _tax_id(ctx, tax_ids)
    if tax_id:
        payload["tax_id"] = tax_id
    # UAE edition: required when using free-form vendor_name (no vendor_id).
    tax_treatment = tax_ids.get("_default_tax_treatment")
    place_of_supply = tax_ids.get("_default_place_of_supply")
    if tax_treatment:
        payload["tax_treatment"] = tax_treatment
    if place_of_supply:
        payload["place_of_supply"] = place_of_supply
    rate = _exchange_rate(ctx)
    if rate:
        payload["currency_code"] = ctx.input.currency
        payload["exchange_rate"] = rate
    if ctx.input.vendor:
        payload["vendor_name"] = ctx.input.vendor
    # Note: vendor TRN is recorded in our Supabase transactions.raw_payload; we don't
    # forward it to Zoho because that requires a pre-configured custom field in the
    # Zoho org. Add later via Settings → Custom Fields → Expenses if desired.
    return payload


def build_bill_payload(
    ctx: TransactionContext,
    tax_ids: dict[str, str],
    vendor_id: str | None = None,
) -> dict[str, Any]:
    """A vendor bill in Zoho — supplier invoice you owe. UAE edition requires
    vendor_id (free-text vendor_name is not accepted on bills)."""
    bill_date = _txn_date(ctx)
    due = (
        ctx.input.due_date.isoformat()
        if ctx.input.due_date
        else bill_date
    )
    line: dict[str, Any] = {
        "name": ctx.input.description[:100] or "Bill line",
        "description": ctx.input.description,
        "rate": _line_amount(ctx),
        "quantity": 1,
    }
    # Use the same default expense account as Expenses; categorizer can re-tag.
    account_id = tax_ids.get("_default_expense_account_id")
    if account_id:
        line["account_id"] = account_id
    tax_id = _tax_id(ctx, tax_ids)
    if tax_id:
        line["tax_id"] = tax_id

    payload: dict[str, Any] = {
        "date": bill_date,
        "due_date": due,
        "is_inclusive_tax": False,
        "line_items": [line],
    }
    if ctx.input.bill_number:
        payload["bill_number"] = ctx.input.bill_number
    if vendor_id:
        payload["vendor_id"] = vendor_id

    # UAE edition validators
    tax_treatment = tax_ids.get("_default_tax_treatment")
    place_of_supply = tax_ids.get("_default_place_of_supply")
    if tax_treatment:
        payload["tax_treatment"] = tax_treatment
    if place_of_supply:
        payload["place_of_supply"] = place_of_supply

    rate = _exchange_rate(ctx)
    if rate:
        payload["currency_code"] = ctx.input.currency
        payload["exchange_rate"] = rate
    return payload


def build_invoice_payload(ctx: TransactionContext, tax_ids: dict[str, str]) -> dict[str, Any]:
    """A customer invoice in Zoho — what someone owes you."""
    payload: dict[str, Any] = {
        "date": _txn_date(ctx),
        "is_inclusive_tax": False,
        "line_items": [{
            "name": ctx.input.description[:100] or "Invoice line",
            "description": ctx.input.description,
            "rate": _line_amount(ctx),
            "quantity": 1,
            # TODO: resolve item_id (optional) + account_id
        }],
        # TODO: resolve customer_id from contacts
    }
    tax_id = _tax_id(ctx, tax_ids)
    if tax_id:
        payload["line_items"][0]["tax_id"] = tax_id
    rate = _exchange_rate(ctx)
    if rate:
        payload["currency_code"] = ctx.input.currency
        payload["exchange_rate"] = rate
    return payload


def build_bank_transaction_payload(ctx: TransactionContext, tax_ids: dict[str, str]) -> dict[str, Any]:
    """Standalone deposit / withdrawal / transfer in Zoho banking."""
    txn_type = "deposit" if ctx.input.direction == "income" else "expense"
    payload: dict[str, Any] = {
        "date": _txn_date(ctx),
        "amount": float(ctx.amounts.gross) if ctx.amounts else float(ctx.input.amount),
        "transaction_type": txn_type,
        "description": ctx.input.description,
        # TODO: resolve from_account_id + to_account_id
    }
    tax_id = _tax_id(ctx, tax_ids)
    if tax_id:
        payload["tax_id"] = tax_id
    return payload


def build_journal_payload(ctx: TransactionContext, tax_ids: dict[str, str]) -> dict[str, Any]:
    """Manual journal entry — used when none of the structured types fit."""
    amount = _line_amount(ctx)
    return {
        "journal_date": _txn_date(ctx),
        "reference_number": "",
        "notes": ctx.input.description,
        "line_items": [
            # TODO: resolve account_ids for both legs
            {"description": ctx.input.description, "debit_or_credit": "debit", "amount": amount},
            {"description": ctx.input.description, "debit_or_credit": "credit", "amount": amount},
        ],
    }


_BUILDERS: dict[str, Any] = {
    "Expense": build_expense_payload,
    "Bill": build_bill_payload,
    "Invoice": build_invoice_payload,
    "BankTransaction": build_bank_transaction_payload,
    "Journal": build_journal_payload,
}


def build_entity_payload(ctx: TransactionContext, tax_ids: dict[str, str]) -> dict[str, Any]:
    entity_type = ctx.input.zoho_entity_type
    builder = _BUILDERS.get(entity_type)
    if builder is None:
        raise ValueError(f"No Zoho payload builder for entity type: {entity_type}")
    return builder(ctx, tax_ids)
