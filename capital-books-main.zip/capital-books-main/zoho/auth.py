"""Zoho Books OAuth2 refresh-token flow.

App-level credentials (ZOHO_CLIENT_ID / ZOHO_CLIENT_SECRET) live in env.
Per-client refresh tokens + access tokens live in the Supabase `clients` table.

Notes vs QuickBooks:
  - Zoho refresh tokens DO NOT rotate by default (don't overwrite)
  - Access tokens are short-lived (1 hour)
  - Region-specific token endpoints (.com/.eu/.in/.com.au)
"""
import logging
from datetime import datetime, timedelta, timezone
from typing import Any
from uuid import UUID

import httpx

from config import settings
from database import get_db

logger = logging.getLogger(__name__)

TOKEN_URL_BY_REGION = {
    "com": "https://accounts.zoho.com/oauth/v2/token",
    "eu": "https://accounts.zoho.eu/oauth/v2/token",
    "in": "https://accounts.zoho.in/oauth/v2/token",
    "com.au": "https://accounts.zoho.com.au/oauth/v2/token",
}


def _token_url(region: str | None = None) -> str:
    return TOKEN_URL_BY_REGION[region or settings.zoho_region]


async def refresh_access_token(
    refresh_token: str, region: str | None = None
) -> dict[str, Any]:
    """Exchange a refresh_token for a fresh short-lived access_token."""
    async with httpx.AsyncClient(timeout=20.0) as http:
        resp = await http.post(
            _token_url(region),
            data={
                "refresh_token": refresh_token,
                "client_id": settings.zoho_client_id,
                "client_secret": settings.zoho_client_secret,
                "grant_type": "refresh_token",
            },
        )
        resp.raise_for_status()
        body = resp.json()
        if "access_token" not in body:
            raise RuntimeError(f"Zoho refresh failed: {body}")
        return body


async def persist_refreshed_tokens(
    client_uuid: UUID, token_response: dict[str, Any]
) -> None:
    expires_in = int(token_response.get("expires_in", 3600))
    # 60-second safety margin so concurrent callers don't race past expiry
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in - 60)

    update = {
        "zoho_access_token": token_response["access_token"],
        "zoho_token_expires_at": expires_at.isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    # Zoho refresh tokens don't rotate — but if one is ever returned, keep it.
    new_refresh = token_response.get("refresh_token")
    if new_refresh:
        update["zoho_refresh_token"] = new_refresh

    db = await get_db()
    await db.table("clients").update(update).eq("id", str(client_uuid)).execute()
