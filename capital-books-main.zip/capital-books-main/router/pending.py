"""Redis-backed pending-state store for transactions flagged HUMAN_REVIEW.

When the pipeline returns HUMAN_REVIEW, we serialize the proposed classification
and stash it under `pending:{phone}`. The next message from that phone is
matched against CONFIRM / CORRECT / EDIT / DELETE intents and we resume.

TTL: 1 hour. If they don't reply, the pending entry expires.
"""
import dataclasses
import json
import logging
from datetime import date
from decimal import Decimal
from typing import Any
from uuid import UUID

from redis_client import get_redis
from transactions.models import (
    BlockedVatResult,
    BoxAssignments,
    ReverseChargeResult,
    RoutingDecision,
    TransactionContext,
    TransactionInput,
    TrnValidation,
    VatAmounts,
    VatClassification,
)

logger = logging.getLogger(__name__)

PENDING_TTL_SECONDS = 3600


def _key(phone: str) -> str:
    return f"pending:{phone}"


def _serialize(obj: Any) -> Any:
    if obj is None:
        return None
    if dataclasses.is_dataclass(obj):
        return {k: _serialize(v) for k, v in dataclasses.asdict(obj).items()}
    if isinstance(obj, UUID):
        return str(obj)
    if isinstance(obj, Decimal):
        return str(obj)
    if isinstance(obj, date):
        return obj.isoformat()
    return obj


async def save_pending(phone: str, ctx: TransactionContext) -> None:
    payload = {
        "input": _serialize(ctx.input),
        "vat_classification": _serialize(ctx.vat_classification),
        "reverse_charge": _serialize(ctx.reverse_charge),
        "blocked_vat": _serialize(ctx.blocked_vat),
        "amounts": _serialize(ctx.amounts),
        "boxes": _serialize(ctx.boxes),
        "tax_point_date": _serialize(ctx.tax_point_date),
        "routing": _serialize(ctx.routing),
    }
    redis = await get_redis()
    await redis.set(_key(phone), json.dumps(payload), ex=PENDING_TTL_SECONDS)


def _input_from_dict(d: dict[str, Any]) -> TransactionInput:
    return TransactionInput(
        client_id=d["client_id"],
        direction=d["direction"],
        zoho_entity_type=d["zoho_entity_type"],
        vendor=d["vendor"],
        description=d["description"],
        amount=Decimal(d["amount"]),
        currency=d.get("currency", "AED"),
        invoice_date=date.fromisoformat(d["invoice_date"]) if d.get("invoice_date") else None,
        payment_date=date.fromisoformat(d["payment_date"]) if d.get("payment_date") else None,
        vendor_trn=d.get("vendor_trn"),
        is_tax_invoice=d.get("is_tax_invoice", True),
        is_paid=d.get("is_paid", False),
        source_document_url=d.get("source_document_url"),
        expense_category_hint=d.get("expense_category_hint"),
    )


async def load_pending(phone: str) -> TransactionContext | None:
    redis = await get_redis()
    raw = await redis.get(_key(phone))
    if not raw:
        return None
    try:
        from uuid import UUID
        data = json.loads(raw)
        input_dict = data["input"]
        input_dict["client_id"] = UUID(input_dict["client_id"])
        ctx = TransactionContext(input=_input_from_dict(input_dict))

        if data.get("vat_classification"):
            v = data["vat_classification"]
            ctx.vat_classification = VatClassification(
                vat_type=v["vat_type"],
                confidence=v["confidence"],
                reasoning=v["reasoning"],
                matched_rule=v.get("matched_rule", False),
            )
        if data.get("reverse_charge"):
            r = data["reverse_charge"]
            ctx.reverse_charge = ReverseChargeResult(
                is_reverse_charge=r["is_reverse_charge"], reason=r.get("reason")
            )
        if data.get("blocked_vat"):
            b = data["blocked_vat"]
            ctx.blocked_vat = BlockedVatResult(
                is_blocked=b["is_blocked"],
                reason=b.get("reason"),
                matched_category=b.get("matched_category"),
            )
        if data.get("amounts"):
            a = data["amounts"]
            ctx.amounts = VatAmounts(
                net=Decimal(a["net"]),
                vat=Decimal(a["vat"]),
                gross=Decimal(a["gross"]),
                fx_rate=Decimal(a["fx_rate"]),
                amount_aed=Decimal(a["amount_aed"]),
            )
        if data.get("boxes"):
            ctx.boxes = BoxAssignments(boxes=data["boxes"]["boxes"])
        if data.get("tax_point_date"):
            ctx.tax_point_date = date.fromisoformat(data["tax_point_date"])
        if data.get("routing"):
            r = data["routing"]
            ctx.routing = RoutingDecision(
                action=r["action"], status=r["status"], reason=r["reason"]
            )
        return ctx
    except Exception:
        logger.exception("Failed to deserialize pending state for %s", phone)
        await clear_pending(phone)
        return None


async def clear_pending(phone: str) -> None:
    redis = await get_redis()
    await redis.delete(_key(phone))


async def has_pending(phone: str) -> bool:
    redis = await get_redis()
    return bool(await redis.exists(_key(phone)))


# ---------------------------------------------------------------------------
# Edit & delete pending state (separate Redis keys; 1-hour TTL like reviews)
# ---------------------------------------------------------------------------

def _edit_key(phone: str) -> str:
    return f"edit:{phone}"


def _delete_key(phone: str) -> str:
    return f"delete:{phone}"


async def save_edit_state(phone: str, snapshot: dict[str, Any]) -> None:
    """snapshot carries the txn id + current values so the next message can
    diff against them. Stored as JSON; one key per phone."""
    redis = await get_redis()
    await redis.set(_edit_key(phone), json.dumps(snapshot), ex=PENDING_TTL_SECONDS)


async def load_edit_state(phone: str) -> dict[str, Any] | None:
    redis = await get_redis()
    raw = await redis.get(_edit_key(phone))
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        await redis.delete(_edit_key(phone))
        return None


async def clear_edit_state(phone: str) -> None:
    redis = await get_redis()
    await redis.delete(_edit_key(phone))


async def save_delete_state(phone: str, snapshot: dict[str, Any]) -> None:
    redis = await get_redis()
    await redis.set(_delete_key(phone), json.dumps(snapshot), ex=PENDING_TTL_SECONDS)


async def load_delete_state(phone: str) -> dict[str, Any] | None:
    redis = await get_redis()
    raw = await redis.get(_delete_key(phone))
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        await redis.delete(_delete_key(phone))
        return None


async def clear_delete_state(phone: str) -> None:
    redis = await get_redis()
    await redis.delete(_delete_key(phone))


# ---------------------------------------------------------------------------
# Conversation memory — last N turns per phone so the agent has context
# for short follow-ups like "yes", "more details", "no", "tell me more".
# ---------------------------------------------------------------------------

CONV_TTL_SECONDS = 3600      # 1 hour
CONV_MAX_TURNS = 8           # 4 user + 4 assistant


def _conv_key(phone: str) -> str:
    return f"conv:{phone}"


async def append_conv_turn(phone: str, role: str, content: str) -> None:
    """Append one message to the rolling conversation log. Trims to last
    CONV_MAX_TURNS entries and resets TTL on every write."""
    if not content:
        return
    redis = await get_redis()
    entry = json.dumps({"role": role, "content": content[:2000]})
    try:
        await redis.rpush(_conv_key(phone), entry)
        await redis.ltrim(_conv_key(phone), -CONV_MAX_TURNS, -1)
        await redis.expire(_conv_key(phone), CONV_TTL_SECONDS)
    except Exception:
        logger.exception("Conversation log append failed (non-fatal)")


async def load_recent_history(phone: str) -> list[dict[str, str]]:
    """Return the rolling history as a list of {role, content} dicts.
    Empty list on cache miss or any decode error."""
    redis = await get_redis()
    try:
        raw_entries = await redis.lrange(_conv_key(phone), 0, -1)
    except Exception:
        logger.exception("Conversation log load failed (non-fatal)")
        return []
    out: list[dict[str, str]] = []
    for raw in raw_entries:
        try:
            out.append(json.loads(raw))
        except json.JSONDecodeError:
            continue
    return out


async def clear_conv(phone: str) -> None:
    redis = await get_redis()
    await redis.delete(_conv_key(phone))


# ---------------------------------------------------------------------------
# Bill payment intent (multi-turn: ask for method, then card-last-4 if needed)
# ---------------------------------------------------------------------------

def _payment_key(phone: str) -> str:
    return f"payment_intent:{phone}"


async def save_payment_intent(phone: str, intent: dict[str, Any]) -> None:
    """intent should carry at least: bill_id, vendor, amount, currency, due_date,
    zoho_bill_id, zoho_vendor_id, stage. Stage transitions:
      'awaiting_method' → 'awaiting_card_last4' → (executed)"""
    redis = await get_redis()
    await redis.set(_payment_key(phone), json.dumps(intent), ex=PENDING_TTL_SECONDS)


async def load_payment_intent(phone: str) -> dict[str, Any] | None:
    redis = await get_redis()
    raw = await redis.get(_payment_key(phone))
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        await redis.delete(_payment_key(phone))
        return None


async def clear_payment_intent(phone: str) -> None:
    redis = await get_redis()
    await redis.delete(_payment_key(phone))


# ---------------------------------------------------------------------------
# Invoice email follow-up — after invoice creation, if customer has no email
# on file we ask the user. Their next reply (an address) resumes this intent.
# ---------------------------------------------------------------------------

def _invoice_email_key(phone: str) -> str:
    return f"invoice_email_intent:{phone}"


async def save_invoice_email_intent(phone: str, intent: dict[str, Any]) -> None:
    """intent carries: invoice_id, invoice_number, customer_name, customer_id,
    customer_currency, amount, due_date, description, payment_url, pdf_url."""
    redis = await get_redis()
    await redis.set(_invoice_email_key(phone), json.dumps(intent), ex=PENDING_TTL_SECONDS)


async def load_invoice_email_intent(phone: str) -> dict[str, Any] | None:
    redis = await get_redis()
    raw = await redis.get(_invoice_email_key(phone))
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        await redis.delete(_invoice_email_key(phone))
        return None


async def clear_invoice_email_intent(phone: str) -> None:
    redis = await get_redis()
    await redis.delete(_invoice_email_key(phone))


# ---------------------------------------------------------------------------
# Outbound-message memory for WhatsApp reply-quote handling.
#
# When the user "quotes" (replies to) one of our messages, the webhook only
# gives us the wamid — not the original body. We stash (wamid → body) here
# at send time so the inbound handler can resolve it.
# ---------------------------------------------------------------------------

_WAMID_TTL_SECONDS = 86_400          # 24h — long enough for next-day replies

def _wamid_key(wamid: str) -> str:
    return f"wamid:{wamid}"


async def remember_outbound(wamid: str | None, body: str) -> None:
    if not wamid or not body:
        return
    redis = await get_redis()
    try:
        await redis.set(_wamid_key(wamid), body[:4000], ex=_WAMID_TTL_SECONDS)
    except Exception:
        logger.exception("wamid cache write failed (non-fatal)")


async def lookup_outbound(wamid: str) -> str | None:
    if not wamid:
        return None
    redis = await get_redis()
    try:
        v = await redis.get(_wamid_key(wamid))
        return v if isinstance(v, str) else (v.decode() if v else None)
    except Exception:
        logger.exception("wamid cache read failed (non-fatal)")
        return None
