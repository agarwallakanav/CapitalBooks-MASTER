"""Dispatch incoming WhatsApp messages to the conversational agent.

Text messages → router.agent.run_agent (Claude tool-use loop)
Image messages → fast-path: extract receipt → pipeline → reply
"""
import logging
from typing import Any
from uuid import UUID

from database import get_db
from router.agent import run_agent
from transactions.extractor import extract_from_image
from transactions.models import TransactionInput
from transactions.pipeline import run_pipeline
from whatsapp.media import fetch_media
from whatsapp.sender import send_text

logger = logging.getLogger(__name__)


async def _lookup_client_by_phone(phone: str) -> dict[str, Any] | None:
    db = await get_db()
    res = (
        await db.table("clients")
        .select("id, company_name")
        .eq("phone", phone)
        .eq("is_active", True)
        .maybe_single()
        .execute()
    )
    return res.data


async def _resolve_quoted_context(message: dict[str, Any]) -> str:
    """If the inbound message is a reply-quote of one of our earlier
    messages, return a short context block to prepend to the user's text.
    Empty string when no quote / quoted body can't be found.

    The webhook only includes the quoted wamid — we resolve the body via
    the Redis (wamid → body) cache populated when we sent each message.
    """
    ctx = message.get("context") or {}
    quoted_id = ctx.get("id")
    if not quoted_id:
        return ""
    try:
        from router.pending import lookup_outbound
        body = await lookup_outbound(quoted_id)
    except Exception:
        logger.exception("lookup_outbound failed (non-fatal)")
        body = None
    if not body:
        # Quote points to a message older than our 24h cache or one we don't
        # have in the index. Still surface the fact of the quote so Claude
        # knows the user is referring back to something.
        return "[The user is replying to one of your earlier messages, but the original text isn't in cache.]\n\n"
    # Cap to keep prompt size reasonable
    snippet = body if len(body) <= 800 else body[:800] + "…[truncated]"
    return (
        f"[The user is replying to this earlier message of yours:]\n"
        f'"""\n{snippet}\n"""\n\n'
    )


async def handle_incoming_message(message: dict[str, Any]) -> None:
    sender = message.get("from")
    msg_type = message.get("type")
    text = (message.get("text") or "").strip()

    if not sender:
        logger.warning("WhatsApp message missing 'from': %r", message)
        return

    try:
        client = await _lookup_client_by_phone(sender)
        if not client:
            await send_text(
                sender,
                "We don't have your number on file. Please contact support to onboard.",
            )
            return

        client_id = UUID(client["id"])

        if msg_type == "image":
            await _handle_image(sender, client_id, message)
            return

        if msg_type == "document":
            await _handle_document(sender, client_id, message)
            return

        if msg_type != "text" or not text:
            await send_text(
                sender,
                "Send me a text question or instruction, a photo of a receipt, "
                "or attach a PDF / Excel / CSV file.",
            )
            return

        # If the message is a reply-quote, prepend the quoted body so the
        # agent has context for "explain this" / "edit this" / "pay this".
        quote_prefix = await _resolve_quoted_context(message)
        effective_text = (quote_prefix + text) if quote_prefix else text

        # All text goes through the conversational agent
        reply = await run_agent(effective_text, client_id, sender)
        # Tools that ship their own WhatsApp attachment (audit workbook,
        # transaction export) return a sentinel so we skip the duplicate
        # text bubble.
        if reply and reply.strip() != "__SUPPRESS_REPLY__":
            await send_text(sender, reply)

    except Exception:
        logger.exception("handle_incoming_message failed for %s", sender)
        try:
            await send_text(sender, "Sorry, something went wrong. Please try again shortly.")
        except Exception:
            logger.exception("Error reply also failed for %s", sender)


async def _handle_image(sender: str, client_id: UUID, message: dict[str, Any]) -> None:
    image_obj = message.get("image") or {}
    media_id = image_obj.get("id")
    caption = image_obj.get("caption")
    if not media_id:
        await send_text(sender, "I couldn't read that image. Try sending it again.")
        return

    await send_text(sender, "📷 Reading your receipt…")

    try:
        img_bytes, mime = await fetch_media(media_id)
    except Exception:
        logger.exception("Failed to fetch WhatsApp media %s", media_id)
        await send_text(sender, "Couldn't download the image from WhatsApp. Try again.")
        return

    # Phase: route image receipts through the new Transactions Bot
    from orchestrator.engine import process
    from transactions.pipeline_v2 import CaptureImageInput, capture_image
    try:
        result = await process(
            client_id,
            capture_image,
            CaptureImageInput(img_bytes, mime, caption=caption, sender=sender),
        )
    except Exception:
        logger.exception("Image capture failed for %s", sender)
        await send_text(
            sender,
            "I couldn't read that receipt. Try a clearer photo or describe it in text.",
        )
        return
    await send_text(sender, result.reply_to_user)


async def _handle_document(
    sender: str, client_id: UUID, message: dict[str, Any],
) -> None:
    """Download a WhatsApp document, store it, extract text, and pass the
    content plus the user's caption to the conversational agent.

    The agent decides what to do — log_expense for receipts, summarize for
    statements, etc. — using the extracted text as if it were a long user
    message.
    """
    doc = message.get("document") or {}
    media_id = doc.get("id")
    filename = (doc.get("filename") or "").strip()
    mime = (doc.get("mime_type") or "").lower()
    caption = (doc.get("caption") or "").strip()
    if not media_id:
        await send_text(sender, "I couldn't read that attachment. Try sending it again.")
        return

    from documents.extractor import detect_kind, extract
    kind = detect_kind(mime, filename)
    if kind == "unknown":
        await send_text(
            sender,
            "I can read Excel (.xlsx), PDF, and CSV files. "
            f"This one looks like *{mime or 'unknown type'}* — could you send it "
            "in one of those formats?",
        )
        return

    await send_text(sender, f"📎 Reading your {kind.upper()} attachment…")

    try:
        body, fetched_mime = await fetch_media(media_id)
    except Exception:
        logger.exception("Failed to fetch WhatsApp document %s", media_id)
        await send_text(sender, "Couldn't download the file from WhatsApp. Try again.")
        return

    # Persist the raw bytes to Supabase Storage so it's auditable. Errors
    # here are non-fatal — extraction can still run on the bytes we have.
    try:
        from orchestrator.audit import store_document
        await store_document(
            client_id=client_id,
            entity_type="incoming_doc",
            body=body,
            filename=filename or f"attachment_{media_id}",
            mime_type=fetched_mime or mime,
        )
    except Exception:
        logger.exception("store_document failed for %s (non-fatal)", media_id)

    extracted = extract(body, fetched_mime or mime, filename)
    if extracted.error or not extracted.text.strip():
        await send_text(
            sender,
            f"I couldn't read the {kind.upper()} content. "
            f"({extracted.error or 'no text found'}) "
            "If it's a scanned image, try sending it as a photo instead.",
        )
        return

    # Compose a synthesized user message for the agent. The agent's existing
    # tools (log_expense, list_transactions, etc.) operate on text, so we
    # hand it the extracted content plus the user's caption.
    name_clause = f" ({filename})" if filename else ""
    page_clause = f", {extracted.page_count} page(s)" if extracted.page_count else ""
    trunc_clause = " [content was truncated]" if extracted.truncated else ""
    caption_clause = (
        f"\n\nMy message: \"{caption}\""
        if caption else
        "\n\nI didn't add a caption — figure out what to do from the content."
    )
    synthesized = (
        f"I attached a {kind.upper()}{name_clause}{page_clause}{trunc_clause}."
        f"{caption_clause}\n\n"
        f"=== {kind.upper()} CONTENT ===\n{extracted.text}\n=== END ==="
    )

    try:
        reply = await run_agent(synthesized, client_id, sender)
    except Exception:
        logger.exception("Document agent loop failed for %s", sender)
        await send_text(
            sender,
            "I read the file but hit an error analysing it. Try a smaller "
            "section or a more specific question.",
        )
        return
    await send_text(sender, reply)


async def _run_pipeline_and_reply(
    sender: str,
    tx_input: TransactionInput,
    require_confirmation: bool = False,
) -> None:
    from router.pending import save_pending
    ctx = await run_pipeline(tx_input, require_confirmation=require_confirmation)
    routing = ctx.routing
    amounts = ctx.amounts
    vat_type = ctx.vat_classification.vat_type if ctx.vat_classification else "unknown"
    confidence = ctx.vat_classification.confidence if ctx.vat_classification else 0

    if routing.action == "AUTO_POST":
        body = (
            "✅ Posted to Zoho Books\n"
            f"Vendor: {tx_input.vendor}\n"
            f"Net: {amounts.net} {tx_input.currency} | VAT: {amounts.vat} | Gross: {amounts.gross}\n"
            f"VAT type: {vat_type}, boxes: {ctx.boxes.boxes}"
        )
    elif routing.action == "HUMAN_REVIEW":
        await save_pending(sender, ctx)
        body = (
            "⚠️ Needs your review\n"
            f"Vendor: {tx_input.vendor} — {amounts.gross} {tx_input.currency}\n"
            f"My guess: {vat_type} ({confidence}%)\n"
            f"Reason: {routing.reason}\n"
            "Reply 'confirm' to approve, or correct it (e.g. 'no, that's office supplies')."
        )
    elif routing.action == "HOLD_UNTIL_PAID":
        body = (
            "📌 On hold until paid (realisation basis).\n"
            f"Vendor: {tx_input.vendor}, {amounts.gross} {tx_input.currency}"
        )
    else:  # MANUAL
        await save_pending(sender, ctx)
        body = (
            f"❓ Not confident on this one ({confidence}%). Tell me the category — "
            f"e.g. 'office supplies, standard VAT'."
        )

    await send_text(sender, body)
