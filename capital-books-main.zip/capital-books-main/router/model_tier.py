"""Two-tier model selection.

Default posture: Haiku. Escalate to Sonnet only when the task genuinely
needs it — image OCR with confidence scoring, complex multi-tool agent
queries, VAT ambiguity, analytical reasoning.

Callers use `pick_agent_model(user_message)` to decide the agent's model
per turn. Image-path callers hardcode Sonnet (image OCR always benefits).
"""
from __future__ import annotations

import re
import time
from contextlib import contextmanager
from typing import Iterator

from config import settings


# Phrases that flag genuinely complex agent-turns worth Sonnet's better
# planning. Kept intentionally narrow — Haiku handles most bookkeeping
# CRUD fine.
_SMART_PATTERNS: tuple[re.Pattern[str], ...] = (
    # Multi-report / comparison / analysis
    re.compile(r"\b(compare|comparison|versus|vs\.?)\b", re.I),
    re.compile(r"\b(trend|trending|over time|month over month|yoy|year over year)\b", re.I),
    re.compile(r"\b(what'?s? eating|breakdown of|analyze|analysis|deep dive)\b", re.I),
    re.compile(r"\b(everything|all my|all of my|full picture)\b", re.I),
    re.compile(r"\b(why|how come|explain|explanation)\b", re.I),
    # Bare financial-narrative words when combined with change/direction cues
    re.compile(r"\b(profit|revenue|expense|loss|margin|cash)\w*\b.*\b(shrink|grow|drop|fall|rise|jump|spike|declin|down|up|change)\w*\b", re.I),
    # Audit / consolidated exports (multi-tool)
    re.compile(r"\baudit\s+(workbook|file|pack|report)\b", re.I),
    # Cash-flow / forecast / prediction
    re.compile(r"\b(cash\s*flow|forecast|projection|predict|expected)\b", re.I),
    # Financial narrative
    re.compile(r"\b(runway|burn\s*rate|working capital|margins?)\b", re.I),
)


def pick_agent_model(user_message: str) -> tuple[str, str]:
    """Returns (model_id, tier). tier is 'fast' or 'smart'."""
    if not user_message:
        return settings.anthropic_model_fast, "fast"
    for pattern in _SMART_PATTERNS:
        if pattern.search(user_message):
            return settings.anthropic_model_smart, "smart"
    return settings.anthropic_model_fast, "fast"


@contextmanager
def timed(logger, label: str, *, model: str, tier: str, **extra) -> Iterator[dict]:
    """Times a block and logs one INFO line at exit. `extra` fields land in
    the log line for structured querying later.

      with timed(logger, 'agent turn', model=model, tier=tier) as t:
          resp = await client.messages.create(...)

    On completion emits:
      INFO router.agent | agent turn | tier=fast model=claude-haiku-4-5-...
           elapsed_ms=812 tokens_in=1204 tokens_out=87
    """
    t0 = time.perf_counter()
    stats: dict = {"model": model, "tier": tier, **extra}
    try:
        yield stats
    finally:
        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        stats["elapsed_ms"] = elapsed_ms
        parts = " ".join(f"{k}={v}" for k, v in stats.items() if v is not None)
        logger.info("%s | %s", label, parts)
