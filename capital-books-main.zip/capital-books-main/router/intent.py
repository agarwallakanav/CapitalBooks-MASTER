"""Classify a WhatsApp message into one of the bot's intents using Claude (fast model)."""
import json
import logging
from dataclasses import dataclass
from typing import Literal

from anthropic import AsyncAnthropic

from config import settings

logger = logging.getLogger(__name__)

Intent = Literal[
    "TRANSACTION", "CONFIRM", "CORRECT", "EDIT", "DELETE",
    "INVOICE", "REPORT", "OVERDUE", "AGING", "GREETING",
    "BILL", "PAY_BILL", "AP_AGING", "AP_OVERDUE", "APPROVE", "REJECT",
    "UNKNOWN",
]

_VALID_INTENTS: set[str] = {
    "TRANSACTION", "CONFIRM", "CORRECT", "EDIT", "DELETE",
    "INVOICE", "REPORT", "OVERDUE", "AGING", "GREETING",
    "BILL", "PAY_BILL", "AP_AGING", "AP_OVERDUE", "APPROVE", "REJECT",
}


@dataclass
class IntentClassification:
    intent: Intent
    confidence: int
    reasoning: str


_anthropic: AsyncAnthropic | None = None


def _client() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


_SYSTEM_PROMPT = """You classify WhatsApp messages from UAE small-business owners using their bookkeeping bot.

Choose exactly one intent:
- TRANSACTION: logging a paid expense / receipt ("spent AED 500 at Carrefour", "here's a receipt")
- BILL: recording a vendor bill they owe but haven't paid ("bill from XYZ for 8400 due in 14 days", "received invoice from supplier", "bill 2500 AED from Etisalat due Friday")
- PAY_BILL: paying or scheduling a previously-recorded bill ("pay bill to ACME", "schedule payment to XYZ for Thursday", "settle Etisalat bill")
- APPROVE: approving a pending action ("approve", "approve the bill", "okay post it")
- REJECT: rejecting a pending action ("reject", "discard that bill", "don't post it")
- CONFIRM: confirms a pending action ("yes", "confirm", "looks good") — applies to expense reviews
- CORRECT: corrects a prior categorization ("no, that's office supplies")
- EDIT: modify a posted transaction ("edit last entry", "change amount to 300")
- DELETE: remove a transaction ("delete that", "remove last receipt")
- INVOICE: create an invoice for a customer ("invoice ABC Corp 5000 AED for consulting")
- REPORT: financial report ("show P&L", "balance sheet last month", "VAT summary")
- OVERDUE: AR overdue receivables ("show overdue invoices", "who owes us")
- AGING: AR aging report ("aging report", "AR aging")
- AP_OVERDUE: AP overdue bills ("overdue bills", "what bills are overdue", "what do we owe past due")
- AP_AGING: AP aging report ("AP aging", "bills aging", "what do we owe by age")
- GREETING: small talk ("hi", "hello")

KEY DISTINCTION (TRANSACTION vs BILL):
- TRANSACTION: already paid out-of-pocket / on card / in cash. Past tense, present.
- BILL: vendor sent an invoice, payment not yet made. Has a due date or "owes".
When the message mentions a future "due date" or says "received", lean BILL.

Respond with JSON ONLY, no prose:
{"intent": "<one of the above>", "confidence": <0-100>, "reasoning": "<one short sentence>"}"""


def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return text.strip()


async def classify_intent(message_text: str) -> IntentClassification:
    if not message_text or not message_text.strip():
        return IntentClassification("UNKNOWN", 0, "Empty message")

    resp = await _client().messages.create(
        model=settings.anthropic_model_fast,
        max_tokens=200,
        system=_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": message_text}],
    )
    raw = "".join(
        block.text for block in resp.content if getattr(block, "type", None) == "text"
    )
    raw = _strip_fences(raw)

    try:
        data = json.loads(raw)
        intent = data["intent"]
        if intent not in _VALID_INTENTS:
            raise ValueError(f"Invalid intent: {intent}")
        return IntentClassification(
            intent=intent,
            confidence=max(0, min(100, int(data.get("confidence", 0)))),
            reasoning=str(data.get("reasoning", "")),
        )
    except (json.JSONDecodeError, KeyError, ValueError) as e:
        logger.warning("Intent parse failed: %s | raw=%r", e, raw[:200])
        return IntentClassification("UNKNOWN", 0, f"Parser failed: {e}")
