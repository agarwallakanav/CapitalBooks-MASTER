"""Tool definitions + handlers for the conversational agent.

Each tool is exposed to Claude with a JSON schema. Tool handlers are thin
wrappers over the existing modules (ap/, ar/, transactions/, reports/, etc.).
They return strings (or JSON-serializable dicts) that Claude reads and uses
to compose its final reply.

Convention: handlers take (client_id, sender, **input_args) and return a
str — the textual result Claude sees, NOT what the user sees. Claude
synthesizes the user-facing reply from these results.
"""
import json
import logging
from datetime import date
from typing import Any, Awaitable, Callable
from uuid import UUID

logger = logging.getLogger(__name__)


# ============================================================================
# Tool schemas (sent to Claude on every turn)
# ============================================================================

TOOL_SCHEMAS: list[dict[str, Any]] = [
    # ---- Expenses ----
    {
        "name": "log_expense",
        "description": (
            "Log a paid expense from text. Use for messages like "
            "'spent AED 500 at Carrefour on groceries' — a paid receipt or "
            "out-of-pocket expense. Runs the full VAT pipeline and posts to "
            "Zoho Books on high confidence; otherwise saves for review."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "The full expense description from the user.",
                }
            },
            "required": ["text"],
        },
    },
    {
        "name": "confirm_pending_expense",
        "description": (
            "Confirm a pending expense review (one previously flagged as "
            "HUMAN_REVIEW). Loads the saved pipeline state and posts to Zoho."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "confirm_pending_review",
        "description": (
            "Confirm a transaction held by the confidence engine. The hold can "
            "be for one of three reasons (look at the pending state):\n"
            "  • needs category — user must say what the expense was for\n"
            "  • needs payment method — user must say cash / card / bank etc\n"
            "  • needs card digits — user said 'card' but no last-4\n"
            "Pass whichever fields the user's reply provided. The tool resolves "
            "the card via the client_cards registry; unknown cards trigger a "
            "follow-up 'what to call this card?' (then use register_card)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "description": "Category (e.g. 'lunch', 'office supplies', 'fuel', 'utilities').",
                },
                "payment_method": {
                    "type": "string",
                    "enum": ["cash", "card", "bank_transfer", "online", "cheque"],
                    "description": "How it was paid. For 'visa'/'amex'/'mastercard' use 'card'.",
                },
                "card_last_4": {
                    "type": "string",
                    "pattern": "^[0-9]{4}$",
                    "description": (
                        "EXACTLY 4 digits (e.g. '4521'). ONLY pass when the user "
                        "literally typed 4 digits — never invent, never use placeholders "
                        "like 'unknown' / 'tbd' / '0000'. If the user mentioned a card "
                        "by label only (e.g. 'Company Visa', 'my Visa'), omit this field "
                        "and pass payment_method='card' — the tool will auto-match the "
                        "single card on file, OR re-prompt for digits."
                    ),
                },
            },
        },
    },
    {
        "name": "register_card",
        "description": (
            "User just told us what to call a previously-unknown card. The "
            "pending_review carries the digits already (payment_pending_last_four). "
            "Use this when the bot's last prompt was 'what would you like to call "
            "this card?' and the user replied with a label like 'Company Visa', "
            "'Neil personal Mastercard', etc."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "label": {
                    "type": "string",
                    "description": "User's chosen card label (e.g. 'Company Visa').",
                },
                "last_four": {
                    "type": "string",
                    "description": "Optional override if user re-stated the digits.",
                },
            },
            "required": ["label"],
        },
    },
    {
        "name": "cancel_pending_review",
        "description": (
            "Discard a transaction held by the confidence engine (user said "
            "'cancel' / 'discard' / 'never mind' after a held expense was shown)."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "correct_pending_expense",
        "description": (
            "User is correcting a pending expense review with new category "
            "or VAT info (e.g. 'no, that's office supplies')."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "correction_text": {
                    "type": "string",
                    "description": "The user's correction message.",
                }
            },
            "required": ["correction_text"],
        },
    },
    # ---- Bills (AP) ----
    {
        "name": "record_bill",
        "description": (
            "Record a vendor bill the user OWES but hasn't paid yet "
            "(e.g. 'bill from XYZ Trading 8400 AED due in 14 days'). NOT for "
            "already-paid expenses — use log_expense for those."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "The bill description from the user."}
            },
            "required": ["text"],
        },
    },
    {
        "name": "approve_pending_bill",
        "description": "Approve the most recent bill flagged for approval. Posts it to Zoho.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "reject_pending_bill",
        "description": "Reject the most recent bill flagged for approval. Discards it.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "pay_bill",
        "description": (
            "FIRST TURN: User said something like 'pay bill to X' or 'settle Etisalat'. "
            "This initiates a multi-turn payment flow: it finds the bill, saves it as "
            "a payment intent, and asks the user how it was paid. It does NOT yet post "
            "anything to Zoho. The user's next reply will name the payment method and "
            "should be passed to confirm_payment_method."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "The user's payment instruction.",
                }
            },
            "required": ["text"],
        },
    },
    {
        "name": "confirm_payment_method",
        "description": (
            "SECOND TURN: User has named a payment method in reply to a pay_bill "
            "initiation. Posts the VendorPayment to Zoho using the resolved account. "
            "Accepted methods: bank_transfer, cash, card, not_yet/cancel. "
            "If method=card, card_last_4 must be supplied (or omit it and the user "
            "will be re-prompted)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "method": {
                    "type": "string",
                    "enum": ["bank_transfer", "cash", "card", "not_yet", "cancel"],
                },
                "card_last_4": {
                    "type": "string",
                    "description": "4-digit string. Required iff method=card.",
                },
                "scheduled_date": {
                    "type": "string",
                    "description": "YYYY-MM-DD if user wants to schedule rather than pay now.",
                },
            },
            "required": ["method"],
        },
    },
    # ---- Invoices (AR) ----
    {
        "name": "create_invoice",
        "description": (
            "Create a NEW unpaid customer invoice in Zoho Books and a Stripe "
            "payment link. Use when the user is about to BILL a customer who "
            "hasn't paid yet ('invoice ABC Corp 5000 AED for consulting', "
            "'bill XYZ 3000 net 30'). If the bot previously blocked the same "
            "request as a possible duplicate AND the user says 'create anyway' / "
            "'do it anyway' / 'yes proceed', pass force=true.\n\n"
            "If the user's message also includes an email address (e.g. "
            "'invoice ABC Corp 5000 AED for consulting, email to billing@abccorp.com'), "
            "pass customer_email — the invoice will be emailed to that address AND "
            "the Zoho contact record will be updated."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "Full invoice request (customer + amount + description + optional due). Leave email out of this field — pass it separately via customer_email.",
                },
                "force": {
                    "type": "boolean",
                    "description": "Set true to bypass the duplicate-detection soft block.",
                },
                "customer_email": {
                    "type": "string",
                    "description": "Optional explicit email override (e.g. 'billing@abccorp.com').",
                },
            },
            "required": ["text"],
        },
    },
    {
        "name": "provide_invoice_email",
        "description": (
            "User just replied with a customer email after the bot asked "
            "'I don't have an email for X — what address should I use?' "
            "Triggers the actual email send (PDF attached, payment link, "
            "BCC to owner) and updates the Zoho contact."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "email": {"type": "string", "description": "The customer's email address."},
            },
            "required": ["email"],
        },
    },
    {
        "name": "skip_invoice_email",
        "description": (
            "User said 'skip' / 'no email' / 'just whatsapp' after the bot "
            "asked for the customer's email. Discards the pending intent."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "record_completed_sale",
        "description": (
            "Issue a Tax Invoice for a sale that's already been paid (customer "
            "paid out-of-band, client just wants the receipt). Searches Zoho "
            "for a matching existing invoice first; if not found, creates + "
            "marks PAID + returns PDF in one shot. Use when the user says "
            "'got AED 5000 from ABC Corp today for consulting' / 'received "
            "payment from XYZ' / 'invoice for the project we just finished'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "Customer name + amount + description + optional date.",
                }
            },
            "required": ["text"],
        },
    },
    {
        "name": "total_owed",
        "description": (
            "Single-number summary of how much you owe vendors. Use for "
            "'how much do I owe?', 'total outstanding bills', 'what's my AP balance'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "review_vat_return",
        "description": (
            "Pull the current draft VAT 201 return from Zoho and run CB "
            "validation: cross-checks output VAT against invoices, input "
            "VAT against bills, flags variances and voluntary-disclosure "
            "situations. Use for 'review VAT', 'check the VAT return', "
            "'VAT 201 review', 'show me the VAT draft'. After the user sees "
            "the summary they can authorize with 'FILE'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "period": {
                    "type": "string",
                    "description": "Optional period override (e.g. '2026-Q2'). Omit for current draft.",
                },
            },
        },
    },
    {
        "name": "authorize_vat_filing",
        "description": (
            "Authorize Zoho to push the previously-reviewed VAT return to "
            "EmaraTax. ONLY call this when the user has just reviewed a "
            "return AND replies with 'FILE' or 'FILE ANYWAY'. CB does not "
            "submit to FTA — Zoho does, as the FTA-recognised Digital Tax "
            "Integrator. This tool logs the authorization and returns a "
            "Zoho deep link."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "override": {
                    "type": "boolean",
                    "description": "True when user typed 'FILE ANYWAY' to override warning flags.",
                },
            },
        },
    },
    {
        "name": "check_voluntary_disclosures",
        "description": (
            "Scan filed VAT returns for transactions posted after filing "
            "that may trigger a Voluntary Disclosure (Form 211). Use for "
            "'any voluntary disclosures?', 'check Form 211', 'corrections "
            "to prior VAT returns'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "mark_bill_paid_simple",
        "description": (
            "Quick mark-paid toggle for the most recent open bill from a "
            "vendor. Use when the user says 'mark the Etisalat bill paid' / "
            "'log payment to ACME' AND doesn't specify a payment method. "
            "Falls back to the client's default payment account. For a full "
            "method-cascade (card/cash/transfer with last-4 lookup), use pay_bill instead."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "vendor_name": {"type": "string"},
            },
            "required": ["vendor_name"],
        },
    },
    {
        "name": "add_teammate",
        "description": (
            "Owner-only. Register a new phone under the same Zoho org as the "
            "owner + assign a role. Use when the owner says 'add teammate X 971..', "
            "'invite my accountant', 'add Sarah as employee', etc.\n\n"
            "Roles:\n"
            "  owner    — everything\n"
            "  finance  — everything except managing teammates\n"
            "  employee — log expenses/bills + create invoices only. No reports, "
            "no customer/vendor lists, no payment execution.\n\n"
            "After adding, remind the owner to allow-list the number in Meta's "
            "WhatsApp dashboard before it can receive/send messages."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "phone": {"type": "string", "description": "Phone with country code, e.g. 971558653850."},
                "name": {"type": "string", "description": "Display name for the teammate."},
                "role": {
                    "type": "string",
                    "enum": ["owner", "finance", "employee"],
                    "description": "Permission level.",
                },
            },
            "required": ["phone", "name", "role"],
        },
    },
    {
        "name": "run_daily_briefing",
        "description": (
            "Run the daily briefing on-demand for the caller's account: sends "
            "the owner a summary of unpaid bills + invoices AND sends payment "
            "follow-ups to customers with overdue or nearly-due invoices. Use "
            "for 'daily summary', 'today's briefing', 'run my morning summary', "
            "'send reminders now', 'chase my overdue invoices'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "list_teammates",
        "description": (
            "Owner-only. Show everyone on the team with their role. Use when the "
            "owner says 'who's on my team', 'list teammates', 'show my staff'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "list_all_stock",
        "description": (
            "Show current stock levels from Zoho Inventory (GET /inventory/v1/items). "
            "Use for 'show inventory', 'stock levels', 'what's in stock'. Top 15 "
            "inline; >15 → Excel attachment."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "item_lookup",
        "description": (
            "Look up a specific product's stock, reorder level, and value. Use for "
            "'how much X do I have', 'is X in stock', 'stock for X'. Pass the "
            "product name or SKU."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Product name or SKU substring."},
            },
            "required": ["name"],
        },
    },
    {
        "name": "low_stock",
        "description": (
            "List items at or below their reorder level. Use for 'low stock', "
            "'what needs reordering', 'reorder alerts'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "inventory_value",
        "description": (
            "Total value of stock on hand + healthy/low/out breakdown. Use for "
            "'inventory value', 'stock value', 'how much is my inventory worth'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "best_selling",
        "description": (
            "Top-selling items in the last 90 days from sales orders. Use for "
            "'best sellers', 'top products', 'best selling items'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "slow_moving",
        "description": (
            "Items with stock on hand but no sales in the last N days (default 60). "
            "Use for 'slow moving stock', 'dead stock', 'what isn't selling'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "days": {
                    "type": "integer",
                    "description": "Window in days (default 60). Also accepts 30, 90, 180.",
                },
            },
        },
    },
    {
        "name": "export_inventory",
        "description": (
            "Build a full inventory Excel file (item name, SKU, stock, reorder, "
            "unit price, value, last-sold date) and send as a WhatsApp document. "
            "Use for 'export inventory', 'inventory report', 'download stock list'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "list_customers",
        "description": (
            "List the client's customers from Zoho Books (GET /contacts?"
            "contact_type=customer&status=active), enriched with outstanding "
            "balance + invoice count. Returns ALL active customers, not just "
            "those with receivables. Top 15 inline; >15 → Excel attachment.\n\n"
            "Pick filter from user wording:\n"
            "  - 'show me my customers' / 'list customers' / 'who are my clients' "
            "→ filter='default'\n"
            "  - 'customers who owe me' / 'open receivables by customer' "
            "→ filter='owed'\n"
            "  - 'customers who paid this month' / 'who paid me recently' "
            "→ filter='paid_this_month'\n"
            "  - 'inactive customers' / 'dormant clients' "
            "→ filter='inactive'"
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "filter": {
                    "type": "string",
                    "enum": ["default", "owed", "paid_this_month", "inactive"],
                    "description": "Which slice of customers to show.",
                },
            },
        },
    },
    {
        "name": "list_vendors",
        "description": (
            "List the client's vendors from Zoho Books, enriched with last-bill "
            "amount + activity count from CB's records. Top 15 inline; if more "
            "exist, sends an Excel attachment.\n\n"
            "Pick the filter from the user's wording:\n"
            "  - 'show me my vendors' / 'list vendors' / 'who are my suppliers' "
            "→ filter='default'\n"
            "  - 'vendors I owe money to' / 'who do I owe' / 'open bills' "
            "→ filter='owed'\n"
            "  - 'vendors I paid this month' / 'who did I pay recently' "
            "→ filter='paid_this_month'\n"
            "  - 'inactive vendors' / 'vendors I haven\\'t used' / 'dormant suppliers' "
            "→ filter='inactive'"
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "filter": {
                    "type": "string",
                    "enum": ["default", "owed", "paid_this_month", "inactive"],
                    "description": "Which slice of vendors to show.",
                },
            },
        },
    },
    {
        "name": "vendor_payment_status",
        "description": (
            "Look up a vendor's bill status in Zoho. Use for "
            "'did I pay Etisalat?', 'what do I owe XYZ?', 'has the ACME bill cleared?'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "vendor_name": {
                    "type": "string",
                    "description": "Vendor/supplier name to look up in Zoho.",
                },
            },
            "required": ["vendor_name"],
        },
    },
    {
        "name": "customer_payment_status",
        "description": (
            "Look up a customer's invoice status in Zoho. Use for "
            "'did ABC Corp pay?', 'has XYZ settled?', 'what's outstanding "
            "from CustomerName'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "customer_name": {
                    "type": "string",
                    "description": "Customer/contact name to look up in Zoho.",
                },
            },
            "required": ["customer_name"],
        },
    },
    # ---- Queries (read-only, used to compose conversational answers) ----
    {
        "name": "get_latest_transaction",
        "description": (
            "Return details (vendor, amount, VAT split, date, status) of the "
            "user's most recent non-deleted expense / bill. Use for questions "
            "like 'when is this due', 'what was the last thing I logged'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "generate_audit_workbook",
        "description": (
            "Build an 8-sheet audit workbook (Trial Balance, P&L, Balance Sheet, "
            "VAT Summary, AR Aging, AP Aging, Transaction Log, Bank Reconciliation) "
            "and send it as a WhatsApp document. Use for any audit-related request:\n"
            "  - 'audit workbook' / 'audit file' / 'audit pack' / 'FTA workbook'\n"
            "  - 'audit workbook for Q1' / 'for 2026' / 'for January to March'\n"
            "Pass `period` as one of:\n"
            "  - 'YYYY-Qn' (e.g. '2026-Q1')\n"
            "  - 'YYYY' for full year (e.g. '2025')\n"
            "  - 'YYYY-MM' for a month\n"
            "  - omit for the current quarter to date"
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "period": {
                    "type": "string",
                    "description": "Optional. '2026-Q1' / '2025' / '2026-03' — omit for current quarter.",
                },
            },
        },
    },
    {
        "name": "export_transactions",
        "description": (
            "Generate an Excel file of transactions over a date range and "
            "send it as a WhatsApp document. Use this for ANY date-range "
            "transaction request that's likely to return more than 5 rows:\n"
            "  - 'expenses for May' / 'transactions for this month'\n"
            "  - 'export everything from Carrefour' (vendor filter)\n"
            "  - 'all cash payments this month' (payment-method filter)\n"
            "  - 'export for my accountant' (no filters — full month)\n"
            "If the resulting row count is ≤5, the tool falls back to an "
            "inline text list (no attachment). For explicit small-list "
            "requests like 'show me my last 3 expenses', use list_transactions instead."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "start_date": {
                    "type": "string",
                    "description": "YYYY-MM-DD inclusive. Defaults to first of current month.",
                },
                "end_date": {
                    "type": "string",
                    "description": "YYYY-MM-DD inclusive. Defaults to today.",
                },
                "vendor_contains": {
                    "type": "string",
                    "description": "Optional vendor substring filter.",
                },
                "payment_method_contains": {
                    "type": "string",
                    "description": "Optional payment account substring (e.g. 'cash', 'visa', 'transfer').",
                },
                "period_label": {
                    "type": "string",
                    "description": "Human label for the caption ('May 2026', 'last week', etc.).",
                },
            },
        },
    },
    {
        "name": "list_transactions",
        "description": (
            "List the user's logged expenses (transactions) with optional "
            "date range and vendor filters. Use for questions like "
            "'what did I log yesterday', 'expenses this week', "
            "'show transactions at Carrefour last month'. "
            "Dates accept YYYY-MM-DD; if omitted, defaults to last 30 days."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "start_date": {
                    "type": "string",
                    "description": "YYYY-MM-DD (inclusive). Defaults to 30 days ago.",
                },
                "end_date": {
                    "type": "string",
                    "description": "YYYY-MM-DD (inclusive). Defaults to today.",
                },
                "vendor_contains": {
                    "type": "string",
                    "description": "Substring match on vendor name (case-insensitive).",
                },
                "limit": {"type": "integer", "default": 25},
            },
        },
    },
    {
        "name": "get_latest_bill",
        "description": "Most recent non-deleted bill (any status).",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_latest_invoice",
        "description": "Most recent invoice issued (any status).",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "list_bills",
        "description": (
            "List recent bills with optional status filter. "
            "Statuses: 'all', 'unpaid', 'paid', 'overdue', 'needs_approval', 'scheduled'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "description": "Status filter; default 'unpaid'.",
                    "enum": ["all", "unpaid", "paid", "overdue", "needs_approval", "scheduled"],
                },
                "limit": {"type": "integer", "default": 10},
            },
        },
    },
    {
        "name": "list_invoices",
        "description": "List recent invoices with optional status filter.",
        "input_schema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["all", "draft", "sent", "paid", "overdue", "cancelled"],
                },
                "limit": {"type": "integer", "default": 10},
            },
        },
    },
    # ---- Reports ----
    {
        "name": "get_pl_report",
        "description": (
            "Generate a Profit & Loss report for a time period via Zoho. "
            "Period is parsed from natural language (today, this week, this "
            "month, last month, this quarter, last 7 days, etc.)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "period": {"type": "string", "description": "Time-range phrase."}
            },
            "required": ["period"],
        },
    },
    {
        "name": "get_vat_summary",
        "description": "VAT 201 box totals + net VAT payable for a period (from Supabase).",
        "input_schema": {
            "type": "object",
            "properties": {
                "period": {"type": "string", "description": "Time-range phrase."}
            },
            "required": ["period"],
        },
    },
    {
        "name": "get_cash_balance",
        "description": (
            "Current cash + bank balances pulled from Zoho's bank accounts. "
            "Use for 'how much cash do I have', 'what's my bank balance', "
            "'cash on hand', 'money in account'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_expense_breakdown",
        "description": (
            "Expense breakdown grouped by category/account for a period. "
            "Use for 'expense breakdown this month', 'where is my money going', "
            "'expense by category'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"period": {"type": "string"}},
            "required": ["period"],
        },
    },
    {
        "name": "get_vendor_spend",
        "description": (
            "How much was spent at a specific vendor over a period. Use for "
            "'how much did I spend at Carrefour', 'spend at Talabat last month'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "vendor": {"type": "string"},
                "period": {"type": "string"},
            },
            "required": ["vendor", "period"],
        },
    },
    {
        "name": "get_balance_sheet",
        "description": "Zoho balance sheet as of the end of a period.",
        "input_schema": {
            "type": "object",
            "properties": {
                "period": {"type": "string", "description": "Time-range phrase."}
            },
            "required": ["period"],
        },
    },
    {
        "name": "get_ar_aging",
        "description": "AR aging summary (current / 1-30 / 31-60 / 61-90 / 90+).",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_ap_aging",
        "description": "AP aging summary (current / 1-30 / 31-60 / 61-90 / 90+).",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_ar_overdue",
        "description": "AR overdue or due-soon invoices.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_ap_overdue",
        "description": "AP overdue or due-soon bills.",
        "input_schema": {"type": "object", "properties": {}},
    },
    # ---- Modifications ----
    {
        "name": "edit_latest_transaction",
        "description": (
            "Edit the most recent non-deleted expense. Pass a free-form text "
            "instruction (e.g. 'change vendor to Spinneys')."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "instruction": {"type": "string"}
            },
            "required": ["instruction"],
        },
    },
    {
        "name": "delete_latest_transaction",
        "description": "Soft-delete the most recent non-deleted expense + hard-delete in Zoho.",
        "input_schema": {"type": "object", "properties": {}},
    },
]


# ============================================================================
# Tool handlers — thin wrappers over existing modules
# ============================================================================

async def _log_expense(client_id: UUID, sender: str, text: str) -> str:
    """Phase B + Transactions Bot rebuild: routes through the orchestrator,
    using the new per-field-confidence extractor + payment cascade."""
    from orchestrator.engine import process
    from transactions.pipeline_v2 import CaptureTextInput, capture_text

    result = await process(client_id, capture_text, CaptureTextInput(text, sender))
    logger.info(
        "log_expense returning reply (len=%d): %r",
        len(result.reply_to_user or ""), result.reply_to_user[:300],
    )
    return result.reply_to_user


async def _confirm_pending_expense(client_id: UUID, sender: str) -> str:
    from router.pending import clear_pending, load_pending
    from transactions.pipeline import load_client_config, log_transaction
    from zoho.client import ZohoBooksClient
    from zoho.entities import build_entity_payload, endpoint_for

    ctx = await load_pending(sender)
    if ctx is None:
        return "No pending expense to confirm."

    client = await load_client_config(client_id)
    ctx.client = client
    if not ctx.zoho_entity_id and client.zoho_organization_id and client.zoho_access_token:
        payload = build_entity_payload(ctx, client.zoho_tax_ids)
        endpoint = endpoint_for(ctx.input.zoho_entity_type)
        async with ZohoBooksClient(
            organization_id=client.zoho_organization_id,
            access_token=client.zoho_access_token,
            refresh_token=client.zoho_refresh_token,
            client_uuid=client.id,
        ) as zoho:
            resp = await zoho.create_entity(endpoint, payload)
        singular = endpoint.rstrip("s")
        entity = resp.get(singular) or {}
        ctx.zoho_entity_id = str(entity.get(f"{singular}_id") or entity.get("id") or "") or None

    if ctx.routing:
        ctx.routing.status = "auto_posted"
        ctx.routing.reason = "User-confirmed after review"
    await log_transaction(ctx)
    await clear_pending(sender)
    return f"POSTED. zoho_id={ctx.zoho_entity_id}"


async def _confirm_pending_review(
    client_id: UUID, sender: str,
    category: str | None = None,
    payment_method: str | None = None,
    card_last_4: str | None = None,
) -> str:
    from orchestrator.engine import process
    from transactions.pending_reviews_actions import (
        PendingReviewAction, confirm_pending_review,
    )
    # Defensive: drop anything that isn't exactly 4 digits. The LLM has been
    # caught passing 'unknown' / 'tbd' / '****' here, which causes the
    # cascade to re-park as needs_card_label with garbage.
    cleaned_digits: str | None = None
    if card_last_4 and len(card_last_4) == 4 and card_last_4.isdigit():
        cleaned_digits = card_last_4
    result = await process(
        client_id, confirm_pending_review,
        PendingReviewAction(
            sender, category=category,
            payment_method=payment_method, card_last_4=cleaned_digits,
        ),
    )
    return result.reply_to_user


async def _register_card(
    client_id: UUID, sender: str, label: str, last_four: str | None = None,
) -> str:
    from orchestrator.engine import process
    from transactions.pending_reviews_actions import (
        RegisterCardAction, register_card_and_post,
    )
    result = await process(
        client_id, register_card_and_post,
        RegisterCardAction(label=label, sender=sender, last_four=last_four),
    )
    return result.reply_to_user


async def _cancel_pending_review(client_id: UUID, sender: str) -> str:
    from orchestrator.engine import process
    from transactions.pending_reviews_actions import (
        PendingReviewAction, cancel_pending_review,
    )
    result = await process(client_id, cancel_pending_review, PendingReviewAction(sender))
    return result.reply_to_user


async def _correct_pending_expense(
    client_id: UUID, sender: str, correction_text: str
) -> str:
    from categorizer.rules_engine import save_rule_from_correction
    from router.pending import clear_pending, load_pending
    from transactions.extractor import extract_transaction
    from transactions.pipeline import run_pipeline

    ctx = await load_pending(sender)
    if ctx is None:
        return "No pending expense to correct. Ask user to send the expense again."

    try:
        await save_rule_from_correction(client_id, ctx.input.vendor, correction_text)
    except Exception:
        logger.exception("Rule save failed (non-fatal)")

    merged_text = f"{ctx.input.description}. Correction: {correction_text}"
    new_input = await extract_transaction(merged_text, client_id)
    new_input.amount = ctx.input.amount
    new_input.vendor = ctx.input.vendor
    new_ctx = await run_pipeline(new_input)
    await clear_pending(sender)
    return (
        f"REAPPLIED. New vat_type={new_ctx.vat_classification.vat_type}, "
        f"vat_amount={new_ctx.amounts.vat} {new_input.currency}, "
        f"zoho_id={new_ctx.zoho_entity_id}"
    )


async def _record_bill(client_id: UUID, sender: str, text: str) -> str:
    """Phase C: routes through the orchestrator."""
    from ap.bills_stateless import BillInput, classify_and_record_bill
    from orchestrator.engine import process
    from transactions.extractor import extract_bill

    try:
        tx_input = await extract_bill(text, client_id)
    except Exception as e:
        return f"Couldn't parse the bill: {e}"
    result = await process(client_id, classify_and_record_bill, BillInput(tx_input, sender))
    return result.reply_to_user


async def _approve_pending_bill(client_id: UUID, sender: str) -> str:
    from ap.bills_stateless import BillDecisionInput, approve_or_reject_pending_bill
    from orchestrator.engine import process
    result = await process(
        client_id, approve_or_reject_pending_bill,
        BillDecisionInput("approve", sender),
    )
    return result.reply_to_user


async def _reject_pending_bill(client_id: UUID, sender: str) -> str:
    from ap.bills_stateless import BillDecisionInput, approve_or_reject_pending_bill
    from orchestrator.engine import process
    result = await process(
        client_id, approve_or_reject_pending_bill,
        BillDecisionInput("reject", sender),
    )
    return result.reply_to_user


async def _pay_bill(client_id: UUID, sender: str, text: str) -> str:
    """Multi-turn initiation: find bill + ask for method."""
    from ap.payments_stateless import InitiatePaymentInput, initiate_payment
    from orchestrator.engine import process
    result = await process(client_id, initiate_payment, InitiatePaymentInput(text, sender))
    return result.reply_to_user


async def _confirm_payment_method(
    client_id: UUID, sender: str,
    method: str,
    card_last_4: str | None = None,
    scheduled_date: str | None = None,
) -> str:
    from ap.payments_stateless import ConfirmPaymentInput, confirm_payment
    from orchestrator.engine import process
    result = await process(
        client_id, confirm_payment,
        ConfirmPaymentInput(method, sender, card_last_4, scheduled_date),
    )
    return result.reply_to_user


async def _record_completed_sale(client_id: UUID, sender: str, text: str) -> str:
    from ar.sales_stateless import SaleInput, attach_signed_url_to_invoice, record_completed_sale
    from orchestrator.engine import process
    from whatsapp.sender import send_document

    result = await process(client_id, record_completed_sale, SaleInput(text, sender))
    # Attach signed URL on the invoice row AND send the PDF to the user as
    # a WhatsApp document — that's a much cleaner UX than a wall-of-text URL.
    if result.documents:
        for doc in result.documents:
            if doc.signed_url:
                if result.entity_id:
                    try:
                        await attach_signed_url_to_invoice(str(result.entity_id), doc.signed_url)
                    except Exception:
                        logger.exception("Failed to attach sale invoice URL")
                try:
                    await send_document(
                        sender,
                        doc.signed_url,
                        doc.filename,
                        "Tax invoice",
                    )
                except Exception:
                    logger.exception("Failed to send invoice document via WhatsApp")
                break
    return result.reply_to_user


async def _customer_payment_status(
    client_id: UUID, sender: str, customer_name: str
) -> str:
    from ar.queries_stateless import CustomerPaymentQuery, query_customer_payment_status
    from orchestrator.engine import process
    result = await process(
        client_id, query_customer_payment_status,
        CustomerPaymentQuery(customer_name, sender),
    )
    return result.reply_to_user


async def _list_vendors(
    client_id: UUID, sender: str, filter: str = "default",
) -> str:
    from ap.vendors_stateless import ListVendorsQuery, list_vendors
    from orchestrator.engine import process
    valid = {"default", "owed", "paid_this_month", "inactive"}
    fk = filter if filter in valid else "default"
    result = await process(
        client_id, list_vendors,
        ListVendorsQuery(sender=sender, filter_kind=fk),
    )
    return result.reply_to_user


async def _add_teammate(
    client_id: UUID, sender: str, phone: str, name: str, role: str,
) -> str:
    from teams.tools import add_teammate
    return await add_teammate(client_id, phone=phone, name=name, role=role)


async def _list_teammates(client_id: UUID, sender: str) -> str:
    from teams.tools import list_teammates
    return await list_teammates(client_id)


async def _run_daily_briefing(client_id: UUID, sender: str) -> str:
    from reminders.daily_briefing import brief_client
    client_row = {"id": client_id}
    summary = await brief_client(client_row)
    if summary.get("skipped"):
        return f"⚠️ Skipped — {summary['skipped']}"
    if summary.get("error"):
        return f"⚠️ Briefing failed: {summary['error']}"
    # The briefing message is already sent as a separate WhatsApp text by
    # brief_client; suppress the agent's echo so the user sees it once.
    return "__SUPPRESS_REPLY__"


async def _list_all_stock(client_id: UUID, sender: str) -> str:
    from inventory.queries import InventoryQuery, list_all_stock
    from orchestrator.engine import process
    r = await process(client_id, list_all_stock, InventoryQuery(sender=sender))
    return r.reply_to_user


async def _item_lookup(client_id: UUID, sender: str, name: str) -> str:
    from inventory.queries import ItemLookupQuery, item_lookup
    from orchestrator.engine import process
    r = await process(client_id, item_lookup, ItemLookupQuery(name=name, sender=sender))
    return r.reply_to_user


async def _low_stock(client_id: UUID, sender: str) -> str:
    from inventory.queries import InventoryQuery, low_stock
    from orchestrator.engine import process
    r = await process(client_id, low_stock, InventoryQuery(sender=sender))
    return r.reply_to_user


async def _inventory_value(client_id: UUID, sender: str) -> str:
    from inventory.queries import InventoryQuery, inventory_value
    from orchestrator.engine import process
    r = await process(client_id, inventory_value, InventoryQuery(sender=sender))
    return r.reply_to_user


async def _best_selling(client_id: UUID, sender: str) -> str:
    from inventory.queries import InventoryQuery, best_selling
    from orchestrator.engine import process
    r = await process(client_id, best_selling, InventoryQuery(sender=sender))
    return r.reply_to_user


async def _slow_moving(client_id: UUID, sender: str, days: int = 60) -> str:
    from inventory.queries import SlowMovingQuery, slow_moving
    from orchestrator.engine import process
    r = await process(client_id, slow_moving, SlowMovingQuery(days=days, sender=sender))
    return r.reply_to_user


async def _export_inventory(client_id: UUID, sender: str) -> str:
    from inventory.queries import InventoryQuery, export_inventory
    from orchestrator.engine import process
    r = await process(client_id, export_inventory, InventoryQuery(sender=sender))
    return r.reply_to_user


async def _list_customers(
    client_id: UUID, sender: str, filter: str = "default",
) -> str:
    from ar.customers_stateless import ListCustomersQuery, list_customers
    from orchestrator.engine import process
    valid = {"default", "owed", "paid_this_month", "inactive"}
    fk = filter if filter in valid else "default"
    result = await process(
        client_id, list_customers,
        ListCustomersQuery(sender=sender, filter_kind=fk),
    )
    return result.reply_to_user


async def _vendor_payment_status(
    client_id: UUID, sender: str, vendor_name: str
) -> str:
    from ap.queries_stateless import VendorPaymentQuery, query_vendor_payment_status
    from orchestrator.engine import process
    result = await process(
        client_id, query_vendor_payment_status,
        VendorPaymentQuery(vendor_name, sender),
    )
    return result.reply_to_user


async def _total_owed(client_id: UUID, sender: str) -> str:
    from ap.queries_stateless import _Empty, query_total_owed
    from orchestrator.engine import process
    result = await process(client_id, query_total_owed, _Empty(sender))
    return result.reply_to_user


async def _review_vat_return(
    client_id: UUID, sender: str, period: str | None = None
) -> str:
    from orchestrator.engine import process
    from vat.review import ReviewRequest, review_current_return
    result = await process(
        client_id, review_current_return,
        ReviewRequest(period=period, sender=sender),
    )
    return result.reply_to_user


async def _authorize_vat_filing(
    client_id: UUID, sender: str, override: bool = False
) -> str:
    from orchestrator.engine import process
    from vat.filing import FilingAuthorization, authorize_filing
    result = await process(
        client_id, authorize_filing,
        FilingAuthorization(sender=sender, override=bool(override)),
    )
    return result.reply_to_user


async def _check_voluntary_disclosures(client_id: UUID, sender: str) -> str:
    from orchestrator.engine import process
    from vat.disclosures import DisclosureRequest, detect_voluntary_disclosures
    result = await process(
        client_id, detect_voluntary_disclosures,
        DisclosureRequest(sender=sender),
    )
    return result.reply_to_user


async def _mark_bill_paid_simple(client_id: UUID, sender: str, vendor_name: str) -> str:
    from ap.queries_stateless import MarkPaidQuery, mark_bill_paid_simple
    from orchestrator.engine import process
    result = await process(
        client_id, mark_bill_paid_simple,
        MarkPaidQuery(vendor_name, sender),
    )
    return result.reply_to_user


async def _provide_invoice_email(client_id: UUID, sender: str, email: str) -> str:
    from ar.email_followup import ProvideEmailInput, provide_invoice_email
    from orchestrator.engine import process
    result = await process(
        client_id, provide_invoice_email,
        ProvideEmailInput(email=email, sender=sender),
    )
    return result.reply_to_user


async def _skip_invoice_email(client_id: UUID, sender: str) -> str:
    from ar.email_followup import SkipEmailInput, skip_invoice_email
    from orchestrator.engine import process
    result = await process(
        client_id, skip_invoice_email,
        SkipEmailInput(sender=sender),
    )
    return result.reply_to_user


async def _create_invoice(
    client_id: UUID, sender: str, text: str,
    force: bool = False, customer_email: str | None = None,
) -> str:
    """Phase C: routes through the orchestrator."""
    from ar.invoice_stateless import InvoiceInput, create_invoice, update_invoice_pdf_url
    from orchestrator.engine import process

    result = await process(
        client_id, create_invoice,
        InvoiceInput(text, sender, force=force, customer_email=customer_email),
    )
    # If the engine uploaded a PDF, patch its signed URL back onto the invoice row.
    if result.entity_id and result.documents:
        for doc in result.documents:
            if doc.signed_url:
                try:
                    await update_invoice_pdf_url(str(result.entity_id), doc.signed_url)
                    result.reply_to_user += f"\nInvoice: {doc.signed_url}"
                except Exception:
                    logger.exception("Failed to patch invoice pdf_url")
                break
    return result.reply_to_user


# ---- Queries ----

async def _get_latest_transaction(client_id: UUID, sender: str) -> str:
    from database import get_db
    db = await get_db()
    res = (
        await db.table("transactions")
        .select(
            "vendor, description, amount, net_amount, vat_amount, currency, vat_type, "
            "vat_boxes, tax_point_date, status, zoho_entity_id, created_at"
        )
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .order("created_at", desc=True)
        .limit(1)
        .execute()
    )
    if not res.data:
        return "No transactions on record."
    return json.dumps(res.data[0], default=str)


async def _generate_audit_workbook(
    client_id: UUID, sender: str, period: str | None = None,
) -> str:
    import time as _time
    from ar.storage import upload_bytes
    from orchestrator.engine import (
        ClientCredentials, ZohoClient, ZohoResolver,
        load_client_config,
    )
    from reports.audit_workbook import build_audit_workbook, parse_audit_period
    from whatsapp.sender import send_document

    cfg = await load_client_config(client_id)
    if not cfg.zoho_organization_id or not cfg.zoho_refresh_token:
        return "Zoho isn't connected — can't build the audit workbook."

    from_date, to_date, label = parse_audit_period(period)

    creds = ClientCredentials(
        client_id=cfg.id, organization_id=cfg.zoho_organization_id,
        api_domain=cfg.api_domain, access_token=cfg.zoho_access_token,
        refresh_token=cfg.zoho_refresh_token,
        token_expires_at=cfg.zoho_token_expires_at,
    )
    # Stand up a minimal OrchContext (cfg + resolver) — same shape modules expect.
    class _Ctx:
        pass
    ctx = _Ctx()
    ctx.cfg = cfg
    async with ZohoClient(creds) as z:
        ctx.resolver = ZohoResolver(None, cfg, z)
        try:
            xlsx, filename = await build_audit_workbook(ctx, from_date, to_date, label)
        except Exception as e:
            logger.exception("audit workbook build failed")
            return f"⚠️ Couldn't build the workbook: {e}"

    key = f"audit/{client_id}/{filename.rsplit('.', 1)[0]}_{int(_time.time())}.xlsx"
    file_url = await upload_bytes(
        key, xlsx,
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    caption = (
        f"📒 Audit Workbook — {cfg.company_name}\n"
        f"Period: {label}  ({from_date.isoformat()} → {to_date.isoformat()})"
    )
    try:
        await send_document(to=sender, link=file_url, filename=filename, caption=caption)
        # The document + caption are already in the WhatsApp thread; signal
        # the agent loop to skip the follow-up text bubble.
        return "__SUPPRESS_REPLY__"
    except Exception as e:
        logger.exception("WhatsApp document send failed for audit workbook")
        return f"⚠️ Built the workbook but couldn't send the attachment: {e}\nDirect link: {file_url}"


async def _export_transactions(
    client_id: UUID,
    sender: str,
    start_date: str | None = None,
    end_date: str | None = None,
    vendor_contains: str | None = None,
    payment_method_contains: str | None = None,
    period_label: str | None = None,
) -> str:
    from datetime import date, timedelta

    from ar.storage import upload_bytes
    from database import get_db
    from transactions.export import build_workbook
    from whatsapp.sender import send_document

    today = date.today()
    # Default to current calendar month (handy for "expenses for May" — Claude
    # resolves the month; for naked "export", we hand back the month-to-date).
    start = start_date or today.replace(day=1).isoformat()
    end = end_date or today.isoformat()
    label = period_label or (
        f"{start} → {end}" if start != today.replace(day=1).isoformat()
        else today.strftime("%B %Y")
    )

    db = await get_db()
    q = (
        db.table("transactions")
        .select("*")
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .gte("tax_point_date", start)
        .lte("tax_point_date", end)
        .order("tax_point_date", desc=True)
        .order("created_at", desc=True)
    )
    if vendor_contains:
        q = q.ilike("vendor", f"%{vendor_contains}%")
    res = await q.execute()
    rows = res.data or []

    # Payment-method filter happens locally (the value lives inside
    # raw_payload.payment_resolution, not on a queryable column).
    if payment_method_contains:
        needle = payment_method_contains.lower()
        def _pay(t):
            return ((t.get("raw_payload") or {}).get("payment_resolution") or {}).get("account_name") or ""
        rows = [t for t in rows if needle in _pay(t).lower()]

    total_gross = sum(float(t.get("amount") or 0) for t in rows)
    filter_bits = []
    if vendor_contains:
        filter_bits.append(f"vendor like '{vendor_contains}'")
    if payment_method_contains:
        filter_bits.append(f"paid via '{payment_method_contains}'")
    filter_desc = ", ".join(filter_bits)

    # ≤5 rows: inline reply, no attachment
    if len(rows) == 0:
        suffix = f" matching {filter_desc}" if filter_desc else ""
        return f"No transactions found for {label}{suffix}."
    if len(rows) <= 5:
        lines = [f"📋 {len(rows)} transactions for {label}"
                 + (f" ({filter_desc})" if filter_desc else "") + ":"]
        for t in rows:
            cat = ((t.get("raw_payload") or {}).get("resolved") or {}).get("category_account_name") or "Uncategorized"
            lines.append(
                f"  • {t.get('tax_point_date')} — {t.get('vendor')} — "
                f"AED {float(t.get('amount') or 0):,.2f} ({cat})"
            )
        lines.append(f"\nTotal: AED {total_gross:,.2f}")
        return "\n".join(lines)

    # >5 rows: build xlsx, upload, send as WhatsApp document.
    xlsx = build_workbook(rows, period_label=label, filter_desc=filter_desc)
    safe_label = label.replace(" ", "_").replace("/", "-")
    key = f"exports/{client_id}/{safe_label}_{int(__import__('time').time())}.xlsx"
    file_url = await upload_bytes(
        key, xlsx,
        content_type=(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        ),
    )

    caption = (
        f"📊 Expense report for {label}"
        + (f" ({filter_desc})" if filter_desc else "")
        + f" — {len(rows)} transactions totaling AED {total_gross:,.2f}."
    )
    try:
        await send_document(
            to=sender,
            link=file_url,
            filename=f"transactions_{safe_label}.xlsx",
            caption=caption,
        )
        return "__SUPPRESS_REPLY__"
    except Exception as e:
        logger.exception("WhatsApp document send failed")
        return f"⚠️ Built the report but couldn't send the attachment: {e}\nDirect link: {file_url}"


async def _list_transactions(
    client_id: UUID,
    sender: str,
    start_date: str | None = None,
    end_date: str | None = None,
    vendor_contains: str | None = None,
    limit: int = 25,
) -> str:
    from database import get_db
    from datetime import date, timedelta
    today = date.today()
    start = start_date or (today - timedelta(days=30)).isoformat()
    end = end_date or today.isoformat()

    db = await get_db()
    q = (
        db.table("transactions")
        .select(
            "vendor, description, amount, net_amount, vat_amount, currency, "
            "vat_type, status, tax_point_date, created_at"
        )
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .gte("tax_point_date", start)
        .lte("tax_point_date", end)
        .order("tax_point_date", desc=True)
        .order("created_at", desc=True)
        .limit(limit)
    )
    if vendor_contains:
        q = q.ilike("vendor", f"%{vendor_contains}%")
    res = await q.execute()
    return json.dumps({
        "start_date": start,
        "end_date": end,
        "vendor_filter": vendor_contains,
        "count": len(res.data or []),
        "transactions": res.data or [],
    }, default=str)


async def _get_latest_bill(client_id: UUID, sender: str) -> str:
    from database import get_db
    db = await get_db()
    res = (
        await db.table("bills")
        .select(
            "vendor, amount, currency, due_date, status, bill_date, "
            "vat_amount, scheduled_payment_date, paid_date, zoho_bill_id, created_at"
        )
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .order("created_at", desc=True)
        .limit(1)
        .execute()
    )
    if not res.data:
        return "No bills on record."
    return json.dumps(res.data[0], default=str)


async def _get_latest_invoice(client_id: UUID, sender: str) -> str:
    from database import get_db
    db = await get_db()
    res = (
        await db.table("invoices")
        .select("*")
        .eq("client_id", str(client_id))
        .order("created_at", desc=True)
        .limit(1)
        .execute()
    )
    if not res.data:
        return "No invoices on record."
    return json.dumps(res.data[0], default=str)


async def _list_bills(
    client_id: UUID, sender: str, status: str = "unpaid", limit: int = 10
) -> str:
    from database import get_db
    db = await get_db()
    q = (
        db.table("bills")
        .select(
            "vendor, amount, currency, due_date, status, scheduled_payment_date"
        )
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .order("due_date", desc=False)
        .limit(limit)
    )
    if status != "all":
        q = q.eq("status", status)
    res = await q.execute()
    return json.dumps(res.data or [], default=str)


async def _list_invoices(
    client_id: UUID, sender: str, status: str = "all", limit: int = 10
) -> str:
    from database import get_db
    db = await get_db()
    q = (
        db.table("invoices")
        .select("invoice_number, customer_name, total, currency, status, due_date, paid_date")
        .eq("client_id", str(client_id))
        .order("created_at", desc=True)
        .limit(limit)
    )
    if status != "all":
        q = q.eq("status", status)
    res = await q.execute()
    return json.dumps(res.data or [], default=str)


# ---- Reports ----

async def _run_report_query(client_id: UUID, sender: str, query: str) -> str:
    """Reports Bot: natural-language query → ReportSpec → Zoho → formatted reply."""
    from orchestrator.engine import process
    from reports.generator_stateless import ReportQueryInput, run_query
    result = await process(client_id, run_query, ReportQueryInput(query, sender))
    return result.reply_to_user


async def _get_pl_report(client_id: UUID, sender: str, period: str) -> str:
    return await _run_report_query(client_id, sender, f"P&L {period}")


async def _get_vat_summary(client_id: UUID, sender: str, period: str) -> str:
    return await _run_report_query(client_id, sender, f"VAT summary {period}")


async def _get_balance_sheet(client_id: UUID, sender: str, period: str) -> str:
    return await _run_report_query(client_id, sender, f"balance sheet {period}")


async def _get_cash_balance(client_id: UUID, sender: str) -> str:
    return await _run_report_query(client_id, sender, "cash balance")


async def _get_expense_breakdown(client_id: UUID, sender: str, period: str) -> str:
    return await _run_report_query(client_id, sender, f"expense breakdown {period}")


async def _get_vendor_spend(client_id: UUID, sender: str, vendor: str, period: str) -> str:
    return await _run_report_query(client_id, sender, f"how much did I spend at {vendor} {period}")


async def _get_ar_aging(client_id: UUID, sender: str) -> str:
    """AR Bot rebuild: queries Zoho directly via the orchestrator."""
    from ar.queries_stateless import _Empty, query_aging_report
    from orchestrator.engine import process
    result = await process(client_id, query_aging_report, _Empty(sender))
    return result.reply_to_user


async def _get_ap_aging(client_id: UUID, sender: str) -> str:
    """AP Bot rebuild: queries Zoho directly via the orchestrator."""
    from ap.queries_stateless import _Empty, query_ap_aging
    from orchestrator.engine import process
    result = await process(client_id, query_ap_aging, _Empty(sender))
    return result.reply_to_user


async def _get_ar_overdue(client_id: UUID, sender: str) -> str:
    """AR Bot rebuild: queries Zoho directly via the orchestrator."""
    from ar.queries_stateless import _Empty, query_overdue_invoices
    from orchestrator.engine import process
    result = await process(client_id, query_overdue_invoices, _Empty(sender))
    return result.reply_to_user


async def _get_ap_overdue(client_id: UUID, sender: str) -> str:
    """AP Bot rebuild: queries Zoho directly via the orchestrator."""
    from ap.queries_stateless import _Empty, query_overdue_bills
    from orchestrator.engine import process
    result = await process(client_id, query_overdue_bills, _Empty(sender))
    return result.reply_to_user


# ---- Modifications ----

async def _edit_latest_transaction(
    client_id: UUID, sender: str, instruction: str
) -> str:
    """Phase C-final: routes through the orchestrator."""
    from orchestrator.engine import process
    from transactions.modify_stateless import EditInput, edit_latest
    result = await process(client_id, edit_latest, EditInput(instruction, sender))
    return result.reply_to_user


async def _delete_latest_transaction(client_id: UUID, sender: str) -> str:
    """Phase C-final: routes through the orchestrator."""
    from orchestrator.engine import process
    from transactions.modify_stateless import DeleteInput, delete_latest
    result = await process(client_id, delete_latest, DeleteInput(sender))
    return result.reply_to_user


# ============================================================================
# Tool dispatch
# ============================================================================

TOOL_HANDLERS: dict[str, Callable[..., Awaitable[str]]] = {
    "log_expense": _log_expense,
    "confirm_pending_expense": _confirm_pending_expense,
    "confirm_pending_review": _confirm_pending_review,
    "cancel_pending_review": _cancel_pending_review,
    "register_card": _register_card,
    "correct_pending_expense": _correct_pending_expense,
    "record_bill": _record_bill,
    "approve_pending_bill": _approve_pending_bill,
    "reject_pending_bill": _reject_pending_bill,
    "pay_bill": _pay_bill,
    "confirm_payment_method": _confirm_payment_method,
    "create_invoice": _create_invoice,
    "provide_invoice_email": _provide_invoice_email,
    "skip_invoice_email": _skip_invoice_email,
    "record_completed_sale": _record_completed_sale,
    "customer_payment_status": _customer_payment_status,
    "vendor_payment_status": _vendor_payment_status,
    "list_vendors": _list_vendors,
    "list_customers": _list_customers,
    "list_all_stock": _list_all_stock,
    "item_lookup": _item_lookup,
    "low_stock": _low_stock,
    "inventory_value": _inventory_value,
    "best_selling": _best_selling,
    "slow_moving": _slow_moving,
    "export_inventory": _export_inventory,
    "add_teammate": _add_teammate,
    "list_teammates": _list_teammates,
    "run_daily_briefing": _run_daily_briefing,
    "total_owed": _total_owed,
    "mark_bill_paid_simple": _mark_bill_paid_simple,
    "review_vat_return": _review_vat_return,
    "authorize_vat_filing": _authorize_vat_filing,
    "check_voluntary_disclosures": _check_voluntary_disclosures,
    "get_latest_transaction": _get_latest_transaction,
    "list_transactions": _list_transactions,
    "export_transactions": _export_transactions,
    "generate_audit_workbook": _generate_audit_workbook,
    "get_latest_bill": _get_latest_bill,
    "get_latest_invoice": _get_latest_invoice,
    "list_bills": _list_bills,
    "list_invoices": _list_invoices,
    "get_pl_report": _get_pl_report,
    "get_vat_summary": _get_vat_summary,
    "get_balance_sheet": _get_balance_sheet,
    "get_cash_balance": _get_cash_balance,
    "get_expense_breakdown": _get_expense_breakdown,
    "get_vendor_spend": _get_vendor_spend,
    "get_ar_aging": _get_ar_aging,
    "get_ap_aging": _get_ap_aging,
    "get_ar_overdue": _get_ar_overdue,
    "get_ap_overdue": _get_ap_overdue,
    "edit_latest_transaction": _edit_latest_transaction,
    "delete_latest_transaction": _delete_latest_transaction,
}


async def execute_tool(
    name: str, input_args: dict[str, Any], client_id: UUID, sender: str
) -> str:
    from teams.notifications import notify_after_tool
    from teams.permissions import check_tool_permission
    from teams.membership import get_role

    handler = TOOL_HANDLERS.get(name)
    if not handler:
        return f"ERROR: unknown tool '{name}'"

    # Permission gate — deny before any side effects if role isn't allowed.
    role = await get_role(client_id)
    allowed, deny_msg = check_tool_permission(name, role)
    if not allowed:
        logger.info("Tool %s DENIED for role=%s client=%s", name, role, client_id)
        return deny_msg

    try:
        result = await handler(client_id, sender, **input_args)
    except TypeError as e:
        return f"ERROR: bad args for {name}: {e}"
    except Exception as e:
        logger.exception("Tool %s failed", name)
        return f"ERROR running {name}: {e}"

    # Post-execution broadcast (fire-and-forget; never blocks the caller)
    try:
        await notify_after_tool(name, input_args, result, client_id)
    except Exception:
        logger.exception("Team broadcast for %s failed (non-fatal)", name)
    return result
