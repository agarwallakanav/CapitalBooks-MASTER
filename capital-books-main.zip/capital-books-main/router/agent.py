"""Tool-use orchestration loop. Claude reads the user's message, decides which
tool(s) to call, executes them, and composes a natural-language reply.

Each WhatsApp message is a fresh one-shot conversation — no message history
is carried over. Per-user state (HUMAN_REVIEW pending, needs_approval bills,
soft-deleted txns) lives in Redis/Supabase and tools read/write it as needed.
"""
import logging
from typing import Any
from uuid import UUID

from anthropic import AsyncAnthropic

from config import settings
from router.tools import TOOL_SCHEMAS, execute_tool

logger = logging.getLogger(__name__)

MAX_TOOL_ITERATIONS = 6  # safety bound: model can call tools at most this many turns

_anthropic: AsyncAnthropic | None = None


def _client() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


SYSTEM_PROMPT = """You are CapitalBooks, a professional bookkeeping service for UAE businesses.

IDENTITY — CRITICAL
You ARE the client's bookkeeper and accountant. CapitalBooks is their accounting
service. Never refer the client to an external accountant, never say "ask your
accountant", "your accountant will handle this", "talk to a qualified
accountant", "consult an accountant", or suggest they hire one. Bookkeeping,
VAT, reporting, P&L, balance sheets, AR/AP, reconciliation, FTA filings,
audit-prep workbooks — ALL of these are your job, and you handle them.

Genuinely out-of-scope items: legal opinions, signed audit attestations, formal
tax advice. For those, the right phrasing is: "That's outside our scope, but
I can prepare everything your auditor or lawyer will need on their side."
Never deflect bookkeeping/VAT/reporting itself.

ROLE
You handle: expense logging, vendor-bill recording, invoice creation, payment
tracking, financial reports, audit workbooks, VAT 201 review, and ad-hoc
questions about the user's books. Always go through tools for any factual
answer about their records — never invent numbers.

WHEN TO USE WHICH TOOL
- "spent X at Y" / paid receipt / receipt photo / cash purchase → log_expense
- "bill from X for Y due Z" / supplier invoice received → record_bill
- "pay bill to X" / "settle X" → pay_bill
- "schedule payment to X for <date>" → schedule_payment
- "invoice ABC for X for Y" → create_invoice
- "yes/confirm" right after a NEEDS_REVIEW expense → confirm_pending_expense
- "approve/approve the bill" right after a needs-approval bill → approve_pending_bill
- "reject/discard" → reject_pending_bill
- "no, that's X" / corrections on a pending expense → correct_pending_expense
- Questions like "when is this due", "what's my last expense", "show me my bills" → use get_latest_* / list_* tools
- Reports ("P&L this month", "VAT summary") → get_pl_report / get_vat_summary / etc.
- AR ("aging", "overdue invoices") → get_ar_aging / get_ar_overdue
- AP ("AP aging", "overdue bills") → get_ap_aging / get_ap_overdue

KEY DISTINCTION
- log_expense = ALREADY PAID. Money has left.
- record_bill = OWED, NOT YET PAID. Has a due date.
If the message mentions a due date or says "received bill", lean record_bill.

RESPONSE STYLE
- Concise. WhatsApp message, not an essay.
- Use AED + amount format (e.g. "AED 3,500").
- 1-2 emojis only when they add meaning (✅ for success, ⚠️ for problems, 📅 for dates).
- When a tool returns "NEEDS_REVIEW" or "needs your approval", repeat the key facts
  to the user and tell them how to confirm/reject. Do NOT silently complete.
- When showing dates, prefer "Friday 12 Jun 2026" format rather than ISO when speaking
  conversationally, but exact ISO when it's already in a list/table.
- For greetings ("hi", "hello") just reply warmly with a hint of capabilities; no tool call.
- Don't quote raw JSON to the user. Summarize.
- IMPORTANT: when a tool returns a reply that contains a URL (PDF link, Stripe
  Checkout URL, signed download, anything starting with https://), the URL is
  user-facing and must appear verbatim in your final reply. Don't summarize
  "Pay: https://checkout.stripe.com/..." away into "Payment link ready" — the
  user needs the actual link to click.

CRITICAL: Every user message describing a NEW expense, bill, invoice, or
payment is a NEW action that requires a tool call. NEVER reuse a prior
response from conversation history as your reply — even if the user's
message text is identical to one they sent earlier. Each message must
trigger the appropriate tool (log_expense / record_bill / pay_bill /
create_invoice / confirm_pending_review / etc.) so the action actually
executes. If you skip the tool call, NOTHING happens in the books.

SILENT TOOLS — DO NOT FOLLOW UP
Some tools (generate_audit_workbook, export_transactions) deliver their
output directly to WhatsApp as an attachment WITH A CAPTION. When such a
tool returns the literal string `__SUPPRESS_REPLY__`, return that string
VERBATIM as your final reply — do not add a summary, do not re-list the
sheet contents, do not say "here you go" or "check your messages". The
user already sees the attachment and caption.

CARD LAST-4 RULE
The card_last_4 field on confirm_pending_review is EXACTLY 4 digits the user
typed. Never invent values:
  - User says "Company Visa" / "my Visa" / "the company card" → omit card_last_4
    and pass payment_method='card'. The tool auto-matches a single card on file
    or re-prompts for digits.
  - User says "card 4521" / "ending 4521" / "4521" → card_last_4='4521'.
  - Never pass 'unknown' / 'tbd' / '****' / a placeholder — schema requires
    4 digits and the tool will reject anything else.

DELETIONS — YOU CAN DELETE POSTED TRANSACTIONS
If the user wants to remove an expense that was already posted (e.g. "discard
the previous one", "delete that last AWS one", "I made a duplicate, remove it"),
call delete_latest_transaction. It deletes BOTH from Zoho Books AND from CB's
records. Never tell the user "I can't discard from here" — that's false.

ERRORS — HARD RULE
If a tool's reply starts with "⚠️" / "❌" / "Couldn't" / "Failed" / "Error" / "Sorry" /
"Zoho" / "Stripe" / contains "PGRST" or any stack-trace fragment, return it
VERBATIM. Do NOT rephrase the error into a different request from the user
(e.g. "save_card failed: table missing" must NOT become "I need a more
specific label"). The user must see the real error so they can fix the
real problem.

FAITHFULNESS TO TOOL OUTPUT — PRESERVE VERBATIM
Tool replies are USER-FACING text, already WhatsApp-formatted. Return them
VERBATIM as your final reply. Do not rephrase, reorder, compress, prefix,
or summarize.

Specifically:
  - "🧾 Invoice INV-X created" stays "🧾 Invoice INV-X created" — do NOT
    rewrite as "✅ Invoice INV-X created" or "Second invoice created".
  - All lines the tool emitted stay in order. Don't drop the Customer line.
    Don't reorder Amount/Due/Pay.
  - "📧 Emailed to ..." / "📧 No email on file ..." / "📅 When's this due?"
    headers stay exactly as written.
  - "🏷️ Category: <name>" stays — never replace with "default" / "uncategorized".
  - "Needs your attention: ..." stays — never soften to "all set".
  - URLs stay verbatim (already enforced above).
  - No "here you go" / "all set" / "Got it" prefixes or suffixes added.

You may add a short reply ONLY when the tool returned plain status text
without WhatsApp formatting (no emoji headers, no labelled fields). In any
case, never invent facts not present in the tool output. A real business
will reconcile every line to Zoho — rephrasing creates false discrepancies."""


async def _has_pending_review(client_id_str: str | None) -> dict | None:
    """Latest awaiting_user pending review — but only if it's fresh. A stale
    pending from 3 days ago should NOT lock the user into an expense-confirm
    flow when they send a totally new message. 24-hour window is enough for
    same-session + next-day follow-ups."""
    if not client_id_str:
        return None
    try:
        from datetime import datetime, timedelta, timezone
        from database import get_db
        db = await get_db()
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
        res = (
            await db.table("pending_reviews")
            .select("id, action, extracted, resolved_fields, flags, created_at")
            .eq("client_id", client_id_str)
            .eq("status", "awaiting_user")
            .gte("created_at", cutoff)
            .order("created_at", desc=True)
            .limit(1)
            .execute()
        )
        return (res.data or [None])[0]
    except Exception:
        logger.exception("pending_reviews lookup failed (non-fatal)")
        return None


async def _build_state_context(sender: str, client_id_str: str | None = None) -> str:
    """Build a small, conversational context block for any active multi-turn
    flow. Trust Claude to interpret naturally — we just say what's pending.

    Tolerant of Redis blips: returns empty string if state can't be loaded so
    a transient cache outage doesn't crash the user-facing flow."""
    parts: list[str] = []
    from router.pending import load_invoice_email_intent, load_payment_intent
    try:
        intent = await load_payment_intent(sender)
        invoice_email_intent = await load_invoice_email_intent(sender)
    except Exception:
        logger.exception("State load failed (non-fatal) — proceeding without context")
        return ""

    # ORDER MATTERS. When multiple flows are alive we must pick ONE and
    # suppress the others in the prompt — otherwise Claude sees ambiguous
    # routing and picks the wrong tool. Priority:
    #   1. pending_reviews (holding on category/payment/card)
    #   2. invoice_email_intent
    #   3. payment_intent (bill payment)
    # This mirrors "the flow the user is currently in the middle of."

    pr = await _has_pending_review(client_id_str)
    active_flow: str | None = None
    if pr:
        active_flow = "expense_confirmation"
    elif invoice_email_intent:
        active_flow = "invoice_email"
    elif intent:
        active_flow = "bill_payment"

    if pr and active_flow == "expense_confirmation":
        # skip the other blocks entirely — this flow owns the reply
        invoice_email_intent = None
        intent = None

    if invoice_email_intent:
        parts.append(
            f"ACTIVE FLOW = invoice_email\n\n"
            f"You just asked the user for the customer's email to send invoice "
            f"{invoice_email_intent.get('invoice_number')} to "
            f"{invoice_email_intent.get('customer_name')}.\n\n"
            "MANDATORY ROUTING for the next reply:\n"
            "  - an email address (e.g. 'billing@x.com') → call provide_invoice_email(email=<that>)\n"
            "  - 'skip' / 'no email' / 'just whatsapp'   → call skip_invoice_email\n"
            "MUST call a tool — do not reply with text only."
        )

    if pr:
        rf = pr.get("resolved_fields") or {}
        vendor = rf.get("vendor") or "an expense"
        amount = rf.get("amount") or "?"
        currency = rf.get("currency") or "AED"
        flags = pr.get("flags") or []
        needs_category = any(
            f.get("field") == "category" for f in flags
        ) and not rf.get("category_account_id")
        payment_state = rf.get("payment_state")
        pending_last_four = rf.get("payment_pending_last_four")

        category_clause = ""
        if needs_category:
            category_clause = (
                "  - a category word (lunch, office, meals, fuel, etc.) "
                "→ confirm_pending_review(category=<word>)\n"
            )

        payment_clause = ""
        if payment_state == "needs_method":
            payment_clause = (
                "  - 'cash'/'card'/'visa'/'transfer'/'bank'/'online' "
                "→ confirm_pending_review(payment_method=<one of cash/card/bank_transfer/online/cheque>)\n"
            )
        elif payment_state == "needs_card_digits":
            payment_clause = (
                "  - a 4-digit string like '4521' (the card last-4) "
                "→ confirm_pending_review(card_last_4='4521')\n"
            )
        elif payment_state == "needs_card_label":
            payment_clause = (
                f"  - any label like 'Company Visa', 'Neil personal MC', etc. "
                f"→ register_card(label=<that label>) "
                f"(the digits {pending_last_four} are already on file)\n"
            )

        what_was_asked = []
        if needs_category:
            what_was_asked.append("what the expense was for (category)")
        if payment_state == "needs_method":
            what_was_asked.append("how it was paid")
        elif payment_state == "needs_card_digits":
            what_was_asked.append("the card's last 4 digits")
        elif payment_state == "needs_card_label":
            what_was_asked.append(f"a label for the new card ending {pending_last_four}")
        asked_clause = (
            " (specifically: " + " AND ".join(what_was_asked) + ")"
            if what_was_asked else ""
        )

        parts.append(
            f"ACTIVE FLOW = expense_confirmation\n\n"
            f"You are in the middle of confirming a held EXPENSE (receipt): "
            f"{vendor} for {currency} {amount}. You already asked the user how "
            f"to proceed{asked_clause}.\n\n"
            "The user's NEXT reply is a response to YOUR question about THIS "
            "expense. Any mention of a payment method (cash / card / credit "
            "card / visa / mastercard / amex / bank transfer / wire / online) "
            "refers to how THIS EXPENSE was paid — NOT a bill or invoice.\n\n"
            "MANDATORY ROUTING:\n"
            + category_clause
            + payment_clause
            + "  - confirm / yes / post / go ahead / ok    → confirm_pending_review (no args)\n"
            + "  - cancel / no / discard / never mind     → cancel_pending_review (no args)\n"
            + "  - edit / change <field> / not quite      → ask what to change (no tool yet)\n\n"
            + "Payment-method wording mapping (all → confirm_pending_review, "
            + "NEVER pay_bill / mark_bill_paid_simple / customer_payment_status):\n"
            + "  'cash' / 'paid in cash' / 'petty cash'\n"
            + "      → confirm_pending_review(payment_method='cash')\n"
            + "  'card' / 'credit card' / 'debit card' / 'visa' / 'mastercard' / 'amex' /\n"
            + "  'paid with card' / 'it was paid using credit card' / 'on my card'\n"
            + "      → confirm_pending_review(payment_method='card')\n"
            + "  'card 4521' / 'visa ending 4521' / 'my 4521 card'\n"
            + "      → confirm_pending_review(payment_method='card', card_last_4='4521')\n"
            + "  'bank transfer' / 'wire' / 'online' / 'stc pay'\n"
            + "      → confirm_pending_review(payment_method='bank_transfer')\n"
            + "  a bare 4-digit number in response to 'what are the last 4?'\n"
            + "      → confirm_pending_review(card_last_4=<digits>)\n\n"
            + "If the reply combines multiple things (e.g. 'lunch, card 4521'), "
            + "pass them in the same confirm_pending_review call.\n\n"
            + "HARD BAN — while this flow is active, do NOT call:\n"
            + "  - log_expense (would duplicate)\n"
            + "  - pay_bill / mark_bill_paid_simple / confirm_payment_method\n"
            + "    (those are for VENDOR BILLS — the user isn't paying a bill)\n"
            + "  - customer_payment_status / list_invoices / get_ar_overdue\n"
            + "    (those are AR — the user isn't asking about invoices)\n\n"
            + "MUST call a tool — do not reply with text only."
        )
    if intent:
        v = f"{intent['vendor']} ({intent['currency']} {intent['amount']:,.2f})"
        stage = intent.get("stage")
        if stage == "awaiting_card_last4":
            parts.append(
                f"You're mid-flow: paying the bill to {v} by card. You just asked the "
                "user for the last 4 digits. Their next reply is those digits — call "
                "confirm_payment_method with method='card' and card_last_4 set."
            )
        else:
            parts.append(
                f"You're mid-flow: the user is paying the bill to {v}. You just asked "
                "how it was paid (bank transfer / cash / card / not yet). Their next "
                "reply is the answer — call confirm_payment_method.\n"
                "Notes: bare 4-digit replies are almost always a card's last 4 (use "
                "method='card', card_last_4=<digits>). 'no', 'cancel', 'not yet' mean "
                "method='not_yet'."
            )
    if not parts:
        return ""
    return "\n\n" + "\n".join(parts)


_ACTION_KEYWORDS = (
    # expense / payment-out
    " spent ", " paid ", " bought ", " purchased ", " expensed ",
    # sale / payment-in
    " got ", " received ", "payment from ", "paid by ", " collected ",
    # bills / invoicing
    "bill from ", "received bill", "owe ", " invoice ", " billing ",
    "tax invoice", "receipt for",
    # pay / schedule
    "pay bill", "settle ", "schedule payment",
)


def _cacheable_tools(tool_schemas: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return a copy of the tool schemas with cache_control on the LAST
    entry. Anthropic caches every content block from the start of the
    request up to and including a cache_control marker. Marking the tail
    of the tools array caches the whole array."""
    if not tool_schemas:
        return tool_schemas
    out = [dict(t) for t in tool_schemas]
    out[-1] = {**out[-1], "cache_control": {"type": "ephemeral"}}
    return out


def _looks_like_action(message: str) -> bool:
    """When True, force the agent to call a tool — prevents hallucinated
    'I posted that for you' replies based on similar prior conversations."""
    m = f" {message.lower().strip()} "
    return any(k in m for k in _ACTION_KEYWORDS)


async def run_agent(
    user_message: str,
    client_id: UUID,
    sender: str,
) -> str:
    """Run a one-shot tool-use loop. Returns the final natural-language reply
    that should be sent to the user via WhatsApp."""
    from datetime import date
    from router.pending import append_conv_turn, load_recent_history

    # Load rolling conversation history so the agent has context for short
    # contextual replies ("yes", "more details", "tell me more about X").
    try:
        history = await load_recent_history(sender)
    except Exception:
        logger.exception("History load failed (non-fatal)")
        history = []

    messages: list[dict[str, Any]] = []
    for turn in history:
        # Strip any tool-result blocks; we only replay clean text exchanges
        messages.append({"role": turn["role"], "content": turn["content"]})
    messages.append({"role": "user", "content": user_message})

    state_ctx = await _build_state_context(sender, str(client_id))
    # If we injected a state-routing block, the next reply MUST go through a
    # tool — the routing rules in state_ctx say which one. Otherwise the LLM
    # will happily fabricate a "✅ done" reply with no tool call (especially
    # for short replies like an email address that don't look action-y).
    has_active_intent = bool(state_ctx)
    today = date.today()
    date_ctx = (
        f"\n\nTODAY'S DATE: {today.isoformat()} "
        f"({today.strftime('%A, %d %B %Y')}). "
        "Resolve relative dates (yesterday, this week, last month, 'Tuesday') "
        "from this absolute date."
    )
    effective_system = SYSTEM_PROMPT + date_ctx + state_ctx

    # Persist the user message right away so subsequent turns see it even if
    # the agent crashes mid-loop.
    await append_conv_turn(sender, "user", user_message)

    # Force a tool call on the first turn whenever (a) the user's message
    # looks like an action OR (b) there's an active multi-turn intent
    # waiting for resolution. Without (b), short non-action replies like an
    # email address slip past auto-mode and the LLM fabricates success.
    force_tools = _looks_like_action(user_message) or has_active_intent
    first_turn_tool_choice = {"type": "any"} if force_tools else {"type": "auto"}

    # Pick the model tier for THIS message. Complex analytical / multi-tool
    # asks (comparisons, trends, audit-workbook, cash flow) escalate to
    # Sonnet; everything else stays on Haiku for latency.
    from router.model_tier import pick_agent_model, timed
    model_id, tier = pick_agent_model(user_message)
    logger.info(
        "agent.model_choice client=%s tier=%s model=%s message=%r",
        client_id, tier, model_id, user_message[:80],
    )

    # Prompt caching — flag the (large, near-invariant) system prompt +
    # tool schemas so the second+ turn within 5 min pays a fraction of
    # input cost + latency. Anthropic will silently no-op if caching isn't
    # available for the model/region; reply behaviour is unchanged.
    cached_system = [
        {"type": "text", "text": effective_system,
         "cache_control": {"type": "ephemeral"}},
    ]
    cached_tools = _cacheable_tools(TOOL_SCHEMAS)

    for iteration in range(MAX_TOOL_ITERATIONS):
        kwargs: dict[str, Any] = {
            "model": model_id,
            "max_tokens": 1500,
            "system": cached_system,
            "tools": cached_tools,
            "messages": messages,
        }
        if iteration == 0 and force_tools:
            kwargs["tool_choice"] = first_turn_tool_choice
        with timed(
            logger, "agent.turn",
            model=model_id, tier=tier, iter=iteration,
        ) as stats:
            resp = await _client().messages.create(**kwargs)
            usage = getattr(resp, "usage", None)
            if usage:
                stats["tokens_in"] = getattr(usage, "input_tokens", None)
                stats["tokens_out"] = getattr(usage, "output_tokens", None)
                # Cache hit stats — only present when caching is active. A
                # non-zero cache_read_input_tokens on turn 1+ proves it's
                # working; if it stays 0, cache isn't being hit.
                cread = getattr(usage, "cache_read_input_tokens", None)
                cwrite = getattr(usage, "cache_creation_input_tokens", None)
                if cread is not None:
                    stats["cache_read"] = cread
                if cwrite is not None:
                    stats["cache_write"] = cwrite
            stats["stop"] = resp.stop_reason

        if resp.stop_reason != "tool_use":
            text_parts = [
                b.text for b in resp.content if getattr(b, "type", None) == "text"
            ]
            final = "\n".join(text_parts).strip() or (
                "I'm not sure how to handle that — try rephrasing."
            )
            # Persist the assistant turn so the next message has context
            await append_conv_turn(sender, "assistant", final)
            return final

        # Otherwise, execute every tool_use block in this turn
        tool_results: list[dict[str, Any]] = []
        for block in resp.content:
            if getattr(block, "type", None) != "tool_use":
                continue
            logger.info(
                "agent.tool client=%s tool=%s input=%s",
                client_id, block.name, block.input,
            )
            result = await execute_tool(block.name, block.input, client_id, sender)
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": block.id,
                "content": result,
            })

        # Feed tool results back into the conversation
        messages.append({"role": "assistant", "content": resp.content})
        messages.append({"role": "user", "content": tool_results})

    logger.warning(
        "agent.max_iterations_reached client=%s — returning fallback",
        client_id,
    )
    return "Sorry, that's taking longer than expected. Try a simpler request."
