"""Financial report generators.

P&L, Balance Sheet, Trial Balance, Cash Summary → QB Reports API (direct httpx).
VAT Summary → Supabase transactions table (we own the box mapping).

Multiple QB queries fire in parallel via asyncio.gather. Results cached in Redis
with a 5-minute TTL keyed by (client_id, report_type, period).
"""
import asyncio
import logging
from dataclasses import dataclass
from typing import Any
from uuid import UUID

from database import get_db
from reports.cache import get_cached, set_cached
from reports.time_filter import DateRange
from transactions.models import ClientConfig
from zoho.client import ZohoBooksClient

logger = logging.getLogger(__name__)


@dataclass
class ReportResult:
    report_type: str
    period: str
    data: dict[str, Any]
    cached: bool = False


async def _load_client(client_id: UUID) -> ClientConfig:
    from transactions.pipeline import load_client_config
    return await load_client_config(client_id)


async def _with_zoho(client: ClientConfig):
    if not (client.zoho_organization_id and client.zoho_access_token and client.zoho_refresh_token):
        raise ValueError(f"Client {client.id} has no Zoho Books credentials configured")
    return ZohoBooksClient(
        organization_id=client.zoho_organization_id,
        access_token=client.zoho_access_token,
        refresh_token=client.zoho_refresh_token,
        client_uuid=client.id,
    )


# --------------------------- Zoho-sourced reports ---------------------------

async def generate_profit_loss(client: ClientConfig, period: DateRange) -> dict[str, Any]:
    params = {"from_date": period.start.isoformat(), "to_date": period.end.isoformat()}
    async with await _with_zoho(client) as zoho:
        return await zoho.report("profitandloss", params)


async def generate_balance_sheet(client: ClientConfig, period: DateRange) -> dict[str, Any]:
    params = {"to_date": period.end.isoformat()}
    async with await _with_zoho(client) as zoho:
        return await zoho.report("balancesheet", params)


async def generate_trial_balance(client: ClientConfig, period: DateRange) -> dict[str, Any]:
    params = {"from_date": period.start.isoformat(), "to_date": period.end.isoformat()}
    async with await _with_zoho(client) as zoho:
        return await zoho.report("trialbalance", params)


async def generate_cash_summary(client: ClientConfig, period: DateRange) -> dict[str, Any]:
    params = {"from_date": period.start.isoformat(), "to_date": period.end.isoformat()}
    async with await _with_zoho(client) as zoho:
        return await zoho.report("cashflow", params)


# --------------------------- Supabase-sourced VAT summary ---------------------------

async def generate_vat_summary(client: ClientConfig, period: DateRange) -> dict[str, Any]:
    """Aggregate VAT 201 box totals from our own transactions table.

    Output VAT (Box 1) - Input VAT (Box 9) = Net VAT payable.
    Box 11 (reverse charge) goes both ways and is self-cancelling.
    """
    db = await get_db()
    res = (
        await db.table("transactions")
        .select("direction, vat_type, vat_amount, vat_boxes, is_blocked_vat, amount_aed")
        .eq("client_id", str(client.id))
        .gte("tax_point_date", period.start.isoformat())
        .lte("tax_point_date", period.end.isoformat())
        .in_("status", ["auto_posted", "manually_categorized"])
        .execute()
    )
    rows = res.data or []

    box_totals: dict[int, float] = {1: 0, 3: 0, 4: 0, 9: 0, 10: 0, 11: 0}
    output_vat = 0.0
    input_vat = 0.0

    for row in rows:
        boxes = row.get("vat_boxes") or []
        vat = float(row.get("vat_amount") or 0)
        amount = float(row.get("amount_aed") or 0)
        for b in boxes:
            box_totals[b] = box_totals.get(b, 0) + amount
        if row.get("direction") == "income" and not row.get("is_blocked_vat"):
            output_vat += vat
        elif row.get("direction") == "expense" and not row.get("is_blocked_vat"):
            input_vat += vat

    return {
        "period": {"start": period.start.isoformat(), "end": period.end.isoformat()},
        "boxes": box_totals,
        "output_vat": round(output_vat, 2),
        "input_vat": round(input_vat, 2),
        "net_vat_payable": round(output_vat - input_vat, 2),
        "transaction_count": len(rows),
    }


# --------------------------- Dispatcher ---------------------------

_GENERATORS = {
    "pnl": generate_profit_loss,
    "balance_sheet": generate_balance_sheet,
    "trial_balance": generate_trial_balance,
    "cash_summary": generate_cash_summary,
    "vat_summary": generate_vat_summary,
}


def resolve_report_type(text: str) -> str:
    t = (text or "").lower()
    if "balance" in t:
        return "balance_sheet"
    if "trial" in t:
        return "trial_balance"
    if "cash" in t:
        return "cash_summary"
    if "vat" in t or "201" in t:
        return "vat_summary"
    return "pnl"


async def generate_report(client_id: UUID, report_type: str, period: DateRange) -> ReportResult:
    generator = _GENERATORS.get(report_type)
    if generator is None:
        raise ValueError(f"Unknown report type: {report_type}")

    cached = await get_cached(client_id, report_type, period.cache_key())
    if cached is not None:
        return ReportResult(report_type=report_type, period=period.label, data=cached, cached=True)

    client = await _load_client(client_id)
    data = await generator(client, period)
    await set_cached(client_id, report_type, period.cache_key(), data)
    return ReportResult(report_type=report_type, period=period.label, data=data, cached=False)


async def generate_reports_batch(
    client_id: UUID, report_types: list[str], period: DateRange
) -> list[ReportResult]:
    """Fire multiple reports in parallel — useful when a user asks for a dashboard view."""
    return await asyncio.gather(
        *(generate_report(client_id, rt, period) for rt in report_types)
    )
