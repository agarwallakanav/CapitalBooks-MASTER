"""Parse natural-language time references into (start, end) date tuples."""
import re
from dataclasses import dataclass
from datetime import date, timedelta


@dataclass(frozen=True)
class DateRange:
    start: date
    end: date
    label: str

    def cache_key(self) -> str:
        return f"{self.start.isoformat()}_{self.end.isoformat()}"


def _start_of_week(d: date) -> date:
    return d - timedelta(days=d.weekday())


def _start_of_month(d: date) -> date:
    return d.replace(day=1)


def _end_of_month(d: date) -> date:
    if d.month == 12:
        return d.replace(day=31)
    next_month_first = d.replace(month=d.month + 1, day=1)
    return next_month_first - timedelta(days=1)


def parse_time_filter(text: str, today: date | None = None) -> DateRange:
    """Map free-form text to a date range. Defaults to current month if nothing recognized."""
    t = (text or "").lower().strip()
    today = today or date.today()

    if "today" in t:
        return DateRange(today, today, "today")
    if "yesterday" in t:
        y = today - timedelta(days=1)
        return DateRange(y, y, "yesterday")
    if "this week" in t:
        start = _start_of_week(today)
        return DateRange(start, today, "this week")
    if "last week" in t:
        this_start = _start_of_week(today)
        end = this_start - timedelta(days=1)
        start = end - timedelta(days=6)
        return DateRange(start, end, "last week")
    if "this month" in t:
        return DateRange(_start_of_month(today), today, "this month")
    if "last month" in t:
        last_month_end = _start_of_month(today) - timedelta(days=1)
        last_month_start = _start_of_month(last_month_end)
        return DateRange(last_month_start, last_month_end, "last month")
    if "this quarter" in t or "qtd" in t:
        q_start_month = ((today.month - 1) // 3) * 3 + 1
        start = today.replace(month=q_start_month, day=1)
        return DateRange(start, today, "this quarter")
    if "this year" in t or "ytd" in t:
        return DateRange(today.replace(month=1, day=1), today, "this year")
    if "last year" in t:
        ly = today.year - 1
        return DateRange(date(ly, 1, 1), date(ly, 12, 31), "last year")

    m = re.search(r"last (\d+) days?", t)
    if m:
        n = int(m.group(1))
        start = today - timedelta(days=n)
        return DateRange(start, today, f"last {n} days")

    return DateRange(_start_of_month(today), today, "this month")
