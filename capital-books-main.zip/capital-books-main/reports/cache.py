"""Redis-backed JSON cache for QB report responses. 5-minute TTL per CLAUDE.md."""
import json
import logging
from typing import Any
from uuid import UUID

from redis_client import get_redis

logger = logging.getLogger(__name__)

DEFAULT_TTL_SECONDS = 300


def _key(client_id: UUID, report_type: str, period: str) -> str:
    return f"report:{client_id}:{report_type}:{period}"


async def get_cached(client_id: UUID, report_type: str, period: str) -> dict[str, Any] | None:
    redis = await get_redis()
    raw = await redis.get(_key(client_id, report_type, period))
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("Corrupt cache entry for %s/%s/%s — discarding", client_id, report_type, period)
        await redis.delete(_key(client_id, report_type, period))
        return None


async def set_cached(
    client_id: UUID,
    report_type: str,
    period: str,
    data: dict[str, Any],
    ttl: int = DEFAULT_TTL_SECONDS,
) -> None:
    redis = await get_redis()
    await redis.set(_key(client_id, report_type, period), json.dumps(data, default=str), ex=ttl)


async def invalidate(client_id: UUID, report_type: str | None = None) -> None:
    """Drop all cached reports for a client (or a single report type)."""
    redis = await get_redis()
    pattern = f"report:{client_id}:{report_type or '*'}:*"
    async for key in redis.scan_iter(match=pattern):
        await redis.delete(key)
