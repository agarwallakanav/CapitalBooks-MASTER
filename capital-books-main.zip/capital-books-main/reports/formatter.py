"""Format a report into a concise WhatsApp message via Claude (fast model)."""
import json
import logging

from anthropic import AsyncAnthropic

from config import settings
from reports.generator import ReportResult

logger = logging.getLogger(__name__)

_anthropic: AsyncAnthropic | None = None


def _client() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


_SYSTEM_PROMPT = """Format the JSON financial report for WhatsApp:

  - Keep under 1200 characters
  - Use bullets and 1-2 emojis (📊 💰 ⚠️) tastefully
  - Round to whole AED, no decimals
  - Highlight: total revenue, total expenses, net profit/loss for P&L;
    total assets/liabilities/equity for balance sheet; net VAT payable for VAT summary
  - No markdown headers (#), no code fences

ABSOLUTE RULES — this is a financial tool used by real businesses:
  - NEVER invent numbers, counts, dates, vendors, transactions, or facts not
    present in the input JSON. No "X more receipts waiting", no "this seems
    high compared to last month" unless the data shows last month.
  - You MAY add a short closing observation, but ONLY if it's strictly
    derivable from the JSON. Example: if net is negative, you can say
    "expenses exceed revenue this period" because the numbers prove it.
    Do not speculate about causes ("perhaps unrecorded sales") or what's
    missing — say nothing rather than guess.
  - If the data is empty or zero, say so plainly. Don't pad with "want to
    log one?" prompts unless the user asked for help logging.

Plain text, mobile-friendly, scannable in 5 seconds, factually verifiable."""


async def format_for_whatsapp(result: ReportResult) -> str:
    user_msg = (
        f"Report type: {result.report_type}\n"
        f"Period: {result.period}\n"
        f"Data: {json.dumps(result.data, default=str)[:6000]}"
    )
    try:
        resp = await _client().messages.create(
            model=settings.anthropic_model_fast,
            max_tokens=600,
            system=_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
        )
        return "".join(
            b.text for b in resp.content if getattr(b, "type", None) == "text"
        ).strip()
    except Exception as e:
        logger.exception("Report formatting failed")
        return _fallback_format(result, error=str(e))


def _fallback_format(result: ReportResult, error: str) -> str:
    """Plain dump if Claude is unavailable — better than nothing."""
    head = f"📊 {result.report_type.replace('_', ' ').title()} ({result.period})"
    if result.report_type == "vat_summary":
        d = result.data
        return (
            f"{head}\n"
            f"Output VAT: AED {d.get('output_vat', 0):,.0f}\n"
            f"Input VAT:  AED {d.get('input_vat', 0):,.0f}\n"
            f"Net payable: AED {d.get('net_vat_payable', 0):,.0f}\n"
            f"({d.get('transaction_count', 0)} transactions)"
        )
    return f"{head}\n(Couldn't format — {error[:80]}. Raw data available on request.)"
