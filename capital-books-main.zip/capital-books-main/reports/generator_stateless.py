"""Stateless reports — Reports Bot rebuild.

  run_query(input, ctx) → ModuleResult

The user's natural-language query is parsed by reports.mapper into a
ReportSpec, which is then executed against Zoho. The 5-minute Redis cache
is consulted before any Zoho call.

VAT summary is computed from our own Supabase transactions table.
"""
import logging
from collections import defaultdict
from decimal import Decimal
from typing import Any

from orchestrator.engine import ModuleResult, OrchContext
from reports.cache import get_cached, set_cached
from reports.formatter import format_for_whatsapp
from reports.generator import ReportResult, generate_vat_summary
from reports.mapper import ReportSpec, map_query_to_report

logger = logging.getLogger(__name__)


class ReportQueryInput:
    """The raw NL query plus an optional sender (for context)."""

    def __init__(self, query: str, sender: str | None = None):
        self.query = query
        self.sender = sender


# ---------------------------------------------------------------------------
# Specialty handlers for the new report types
# ---------------------------------------------------------------------------

async def _fetch_cash_balance(ctx: OrchContext) -> dict[str, Any]:
    resp = await ctx.resolver._zoho.list_entities("bankaccounts", filters={})
    accounts = resp.get("bankaccounts") or []
    total = 0.0
    rows = []
    currency = "AED"
    for acct in accounts:
        bal = float(acct.get("balance") or 0)
        currency = acct.get("currency_code", currency)
        rows.append({
            "name": acct.get("account_name"),
            "type": acct.get("account_type"),
            "balance": bal,
        })
        total += bal
    return {"total": total, "currency": currency, "accounts": rows}


async def _fetch_expense_by_vendor(ctx: OrchContext, spec: ReportSpec) -> dict[str, Any]:
    # Zoho's /expenses list doesn't accept a vendor_name_contains filter —
    # strip it and filter locally on the returned vendor_name field. Also
    # walk paginated responses if the result set is large.
    api_params = {k: v for k, v in spec.zoho_params.items() if k != "vendor_name_contains"}
    api_params.setdefault("per_page", 200)
    needle = (spec.vendor_filter or "").lower().strip()

    resp = await ctx.resolver._zoho.list_entities("expenses", filters=api_params)
    expenses = resp.get("expenses") or []
    # Zoho UAE silently drops vendor_name on free-form expense entries — the
    # vendor info ends up in `description` instead. Match against both.
    def _haystack(e: dict[str, Any]) -> str:
        return f"{e.get('vendor_name') or ''} {e.get('description') or ''}".lower()
    matched = [e for e in expenses if needle and needle in _haystack(e)]

    total = 0.0
    by_date: dict[str, float] = {}
    currency = "AED"
    for e in matched:
        amt = float(e.get("total") or e.get("amount") or 0)
        total += amt
        d = e.get("date") or "?"
        by_date[d] = by_date.get(d, 0.0) + amt
        currency = e.get("currency_code", currency)

    return {
        "vendor": spec.vendor_filter,
        "period": {"start": spec.period.start.isoformat(),
                   "end": spec.period.end.isoformat()},
        "total": total,
        "currency": currency,
        "transaction_count": len(matched),
        "by_date": [{"date": d, "amount": v} for d, v in sorted(by_date.items())],
    }


async def _fetch_expense_breakdown(ctx: OrchContext, spec: ReportSpec) -> dict[str, Any]:
    resp = await ctx.resolver._zoho.list_entities("expenses", filters=spec.zoho_params)
    expenses = resp.get("expenses") or []
    by_account: dict[str, float] = defaultdict(float)
    currency = "AED"
    total = 0.0
    for e in expenses:
        amt = float(e.get("total") or e.get("amount") or 0)
        total += amt
        acct = e.get("account_name") or "Uncategorized"
        by_account[acct] += amt
        currency = e.get("currency_code", currency)
    breakdown = sorted(
        ({"category": c, "amount": a} for c, a in by_account.items()),
        key=lambda x: -x["amount"],
    )
    return {
        "period": {"start": spec.period.start.isoformat(),
                   "end": spec.period.end.isoformat()},
        "total": total,
        "currency": currency,
        "count": len(expenses),
        "breakdown": breakdown,
    }


# ---------------------------------------------------------------------------
# Main entry
# ---------------------------------------------------------------------------

async def run_query(input: ReportQueryInput, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    spec = map_query_to_report(input.query)

    # Routing guard — bounce AR/AP queries back to the right tool
    if spec.routing != "reports":
        return ModuleResult(
            reply_to_user=spec.hint or "That's not a reports question.",
            extra_events=[{
                "event_type": "report_query_routed_away",
                "payload": {"routing": spec.routing, "query": input.query[:200]},
            }],
        )

    report_type = spec.report_type
    period = spec.period

    # Cache check (period key for time-bound; for cash_balance use 'current').
    # IMPORTANT: include the vendor filter in the key so distinct vendors
    # don't collide on the same cache entry.
    cache_period_key = period.cache_key() if period else "current"
    if spec.vendor_filter:
        cache_period_key = f"{cache_period_key}__{spec.vendor_filter.lower()}"
    cached = await get_cached(cfg.id, report_type, cache_period_key)
    if cached is not None:
        result = ReportResult(report_type=report_type,
                              period=(period.label if period else "now"),
                              data=cached, cached=True)
        reply = await format_for_whatsapp(result)
        return ModuleResult(
            reply_to_user=reply,
            extra_events=[{
                "event_type": "report_served_from_cache",
                "payload": {"report_type": report_type, "period": cache_period_key},
            }],
        )

    # Execute
    if ctx.resolver is None and report_type != "vat_summary":
        return ModuleResult(reply_to_user="Zoho isn't connected — can't pull that report.")

    try:
        if report_type == "vat_summary":
            from transactions.models import ClientConfig as PipelineClientConfig
            pipeline_cfg = PipelineClientConfig(
                id=cfg.id, company_name=cfg.company_name, vat_basis=cfg.vat_basis,
                entity_type=None, foreign_suppliers=cfg.foreign_suppliers,
                confidence_threshold=cfg.confidence_threshold,
                approval_amount_limit=Decimal(str(cfg.approval_amount_limit)),
                zoho_organization_id=cfg.zoho_organization_id,
                zoho_access_token=cfg.zoho_access_token,
                zoho_refresh_token=cfg.zoho_refresh_token,
                zoho_tax_ids=cfg.zoho_tax_ids,
            )
            data = await generate_vat_summary(pipeline_cfg, period)
        elif report_type == "cash_balance":
            data = await _fetch_cash_balance(ctx)
        elif report_type == "expense_by_vendor":
            data = await _fetch_expense_by_vendor(ctx, spec)
        elif report_type == "expense_breakdown":
            data = await _fetch_expense_breakdown(ctx, spec)
        else:
            # pnl / balance_sheet / trial_balance / cash_flow → /reports/<x>
            endpoint = spec.zoho_endpoint.replace("reports/", "")
            data = await ctx.resolver._zoho.report(endpoint, spec.zoho_params)
    except Exception as exc:
        logger.exception("Report generation failed")
        return ModuleResult(
            reply_to_user=f"Couldn't generate that report: {exc}",
            extra_events=[{
                "event_type": "report_failed",
                "payload": {"report_type": report_type, "error": str(exc)[:300]},
            }],
        )

    await set_cached(cfg.id, report_type, cache_period_key, data)
    result = ReportResult(
        report_type=report_type,
        period=(period.label if period else "now"),
        data=data,
        cached=False,
    )
    reply = await format_for_whatsapp(result)
    return ModuleResult(
        reply_to_user=reply,
        extra_events=[{
            "event_type": "report_generated",
            "payload": {"report_type": report_type, "period": cache_period_key,
                        "vendor_filter": spec.vendor_filter},
        }],
    )


# Backwards-compat shim for the old report-type-specific entry points
class ReportInput:
    def __init__(self, report_type: str, period):
        self.report_type = report_type
        self.period = period


async def generate_report(input: ReportInput, ctx: OrchContext) -> ModuleResult:
    """Legacy entry kept so reports/generator-direct callers keep working.
    New code should call run_query with a natural-language query instead."""
    query_input = ReportQueryInput(
        query=f"{input.report_type} {input.period.label}",
        sender=None,
    )
    return await run_query(query_input, ctx)
