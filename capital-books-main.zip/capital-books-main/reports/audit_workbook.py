"""Audit workbook builder — 8-sheet xlsx for handing to an auditor.

  build_audit_workbook(ctx, start_date, end_date, period_label) → (bytes, filename)

Sheets:
  1. Trial Balance    — Zoho /reports/trialbalance, flattened account tree
  2. Profit & Loss    — Zoho /reports/profitandloss, current vs prior period
  3. Balance Sheet    — Zoho /reports/balancesheet, balance check
  4. VAT Summary      — Supabase transactions grouped by VAT 201 box
  5. AR Aging         — Zoho /invoices bucketed (current / 1-30 / ... / 90+)
  6. AP Aging         — Zoho /bills, same buckets
  7. Transaction Log  — Supabase transactions for the period
  8. Bank Recon Summary — Zoho /bankaccounts + unreconciled count

All Zoho/Supabase fetches happen in parallel (asyncio.gather) so worst-case
build time is ~one Zoho RTT.
"""
from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from datetime import date, timedelta
from io import BytesIO
from typing import Any
from uuid import UUID

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from database import get_db

logger = logging.getLogger(__name__)

# ---- styling --------------------------------------------------------------

_NAVY = "1A2332"
_GREEN = "4CAF50"
_LIGHT_GRAY = "F4F6F8"
_AED_FMT = '_-* #,##0.00 [$AED]_-;-* #,##0.00 [$AED]_-'


def _header_font() -> Font:
    return Font(bold=True, color="FFFFFF", size=11)


def _header_fill() -> PatternFill:
    return PatternFill("solid", fgColor=_NAVY)


def _section_font() -> Font:
    return Font(bold=True, size=12, color=_NAVY)


def _total_font() -> Font:
    return Font(bold=True, color="FFFFFF")


def _total_fill() -> PatternFill:
    return PatternFill("solid", fgColor=_GREEN)


def _alt_fill() -> PatternFill:
    return PatternFill("solid", fgColor=_LIGHT_GRAY)


def _autosize(ws) -> None:
    for col_idx in range(1, ws.max_column + 1):
        col = get_column_letter(col_idx)
        max_len = 8
        for row in range(1, ws.max_row + 1):
            v = ws.cell(row=row, column=col_idx).value
            if v is None:
                continue
            max_len = max(max_len, len(str(v)))
        ws.column_dimensions[col].width = min(max_len + 3, 60)


def _aed_columns(ws, header_row: int, cols: tuple[int, ...]) -> None:
    """Apply AED number format to the given column indices for every data row."""
    for r in range(header_row + 1, ws.max_row + 1):
        for c in cols:
            ws.cell(row=r, column=c).number_format = _AED_FMT


def _stripe_rows(ws, header_row: int) -> None:
    fill = _alt_fill()
    for r in range(header_row + 1, ws.max_row + 1):
        if r % 2 == 0:
            for c in range(1, ws.max_column + 1):
                ws.cell(row=r, column=c).fill = fill


# ---- Zoho report flattening ----------------------------------------------

def _walk_zoho_accounts(node: Any, depth: int = 0) -> list[dict[str, Any]]:
    """Recursively flatten Zoho's report tree. Zoho is inconsistent about
    shape — at any level a node can be a dict, a list of dicts, or even a
    nested list. Accept all three."""
    out: list[dict[str, Any]] = []
    # Case 1: a list at this position → iterate as children at same depth
    if isinstance(node, list):
        for child in node:
            out.extend(_walk_zoho_accounts(child, depth))
        return out
    # Case 2: not a dict (string, number, None) → no rows
    if not isinstance(node, dict):
        return out

    # Zoho uses `name` for leaves, `total_label` for aggregator rows
    # ("Total Operating Income", "TOTAL ASSETS", etc.).
    name = (node.get("name") or node.get("account_name")
            or node.get("total_label") or "")
    children_raw = (node.get("account_transactions")
                    or node.get("accounts")
                    or node.get("account_list")
                    or node.get("sections")
                    or node.get("sub_accounts")
                    or [])
    children: list[Any] = (children_raw if isinstance(children_raw, list)
                           else [children_raw])

    # Trial-balance leaves carry net_debit_total/net_credit_total at the top
    # level AND/OR inside values[0]. Fall back through both.
    def _money(*keys: str) -> float:
        for k in keys:
            v = node.get(k)
            if v not in (None, "", []):
                try:
                    return float(v)
                except (TypeError, ValueError):
                    continue
        vals = node.get("values") or []
        if vals and isinstance(vals, list) and isinstance(vals[0], dict):
            for k in keys:
                v = vals[0].get(k)
                if v not in (None, "", []):
                    try:
                        return float(v)
                    except (TypeError, ValueError):
                        continue
        return 0.0

    debit = _money("debit", "net_debit_total")
    credit = _money("credit", "net_credit_total")
    amount = _money("total", "amount", "net_amount")

    if name and not children:
        out.append({
            "depth": depth,
            "name": name,
            "code": node.get("account_code") or "",
            "debit": debit,
            "credit": credit,
            "amount": amount,
        })
    if name and children:
        out.append({"depth": depth, "name": name, "code": "",
                    "debit": debit, "credit": credit, "amount": amount,
                    "is_section": True})
    for child in children:
        out.extend(_walk_zoho_accounts(child, depth + 1))
    return out


def _unwrap_report_root(resp: dict[str, Any], *keys: str) -> Any:
    """Find the report's root node in the Zoho response. The wrapper key
    varies by org/region/version (e.g. 'trial_balance' vs 'trialbalance')
    AND its value may be a dict OR a list."""
    for k in keys:
        if k in resp:
            return resp[k]
    # Some reports return the whole response as the root (no wrapper key)
    if "code" in resp and resp.get("code") == 0:
        # Skip Zoho metadata, look for the first dict-or-list value
        for k, v in resp.items():
            if k in ("code", "message", "page_context"):
                continue
            return v
    return resp


# ---- Data fetchers --------------------------------------------------------

def _log_zoho_shape(label: str, resp: Any) -> None:
    """Log the top-level shape of a Zoho response so we can see what we got
    when parsing breaks. Truncated to ~500 chars."""
    import json as _json
    try:
        if isinstance(resp, dict):
            keys_info = {
                k: (type(resp[k]).__name__,
                    (len(resp[k]) if hasattr(resp[k], "__len__") else None))
                for k in list(resp.keys())[:15]
            }
            logger.info("ZOHO %s: type=dict top_keys=%s body=%s",
                        label, keys_info, _json.dumps(resp, default=str)[:500])
        elif isinstance(resp, list):
            logger.info("ZOHO %s: type=list len=%d body=%s",
                        label, len(resp), _json.dumps(resp, default=str)[:500])
        else:
            logger.info("ZOHO %s: type=%s value=%r",
                        label, type(resp).__name__, str(resp)[:300])
    except Exception:
        logger.exception("logging Zoho shape failed")


async def _fetch_trial_balance(zoho, from_date: date, to_date: date) -> dict[str, Any]:
    try:
        resp = await zoho.report("trialbalance", {
            "from_date": from_date.isoformat(),
            "to_date": to_date.isoformat(),
        })
        _log_zoho_shape("trialbalance", resp)
        return resp
    except Exception as e:
        logger.exception("trial balance fetch failed")
        return {"error": str(e)}


async def _fetch_pnl(zoho, from_date: date, to_date: date) -> dict[str, Any]:
    try:
        resp = await zoho.report("profitandloss", {
            "from_date": from_date.isoformat(),
            "to_date": to_date.isoformat(),
        })
        _log_zoho_shape("profitandloss", resp)
        return resp
    except Exception as e:
        logger.exception("p&l fetch failed")
        return {"error": str(e)}


async def _fetch_balance_sheet(zoho, to_date: date) -> dict[str, Any]:
    try:
        resp = await zoho.report("balancesheet", {"to_date": to_date.isoformat()})
        _log_zoho_shape("balancesheet", resp)
        return resp
    except Exception as e:
        logger.exception("balance sheet fetch failed")
        return {"error": str(e)}


async def _fetch_transactions(client_id: UUID, from_date: date, to_date: date) -> list[dict[str, Any]]:
    db = await get_db()
    try:
        res = await (
            db.table("transactions")
            .select("*")
            .eq("client_id", str(client_id))
            .eq("deleted", False)
            .gte("tax_point_date", from_date.isoformat())
            .lte("tax_point_date", to_date.isoformat())
            .order("tax_point_date", desc=False)
            .execute()
        )
        return res.data or []
    except Exception:
        logger.exception("transactions fetch failed")
        return []


async def _fetch_invoices(zoho) -> list[dict[str, Any]]:
    try:
        rows: list[dict[str, Any]] = []
        for status in ("sent", "overdue", "paid", "partially_paid"):
            r = await zoho.list_entities("invoices", filters={"status": status, "per_page": 200})
            rows.extend(r.get("invoices") or [])
        return rows
    except Exception:
        logger.exception("invoices fetch failed")
        return []


async def _fetch_bills(zoho) -> list[dict[str, Any]]:
    try:
        rows: list[dict[str, Any]] = []
        for status in ("open", "overdue", "paid", "partially_paid"):
            r = await zoho.list_entities("bills", filters={"status": status, "per_page": 200})
            rows.extend(r.get("bills") or [])
        return rows
    except Exception:
        logger.exception("bills fetch failed")
        return []


async def _fetch_bank_accounts(zoho) -> list[dict[str, Any]]:
    try:
        r = await zoho.list_entities("bankaccounts", filters={})
        return r.get("bankaccounts") or []
    except Exception:
        logger.exception("bankaccounts fetch failed")
        return []


# ---- Sheet builders -------------------------------------------------------

def _write_header_block(ws, company: str, sheet_title: str, period: str) -> int:
    ws.cell(row=1, column=1, value=company).font = Font(bold=True, size=14, color=_NAVY)
    ws.cell(row=2, column=1, value=sheet_title).font = _section_font()
    ws.cell(row=3, column=1, value=f"Period: {period}").font = Font(italic=True)
    return 5   # next-usable row


def _write_headers(ws, row: int, headers: list[str]) -> int:
    for c, h in enumerate(headers, 1):
        cell = ws.cell(row=row, column=c, value=h)
        cell.font = _header_font()
        cell.fill = _header_fill()
        cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    return row + 1


def _build_trial_balance(wb: Workbook, tb_resp: dict, company: str, period: str) -> None:
    ws = wb.create_sheet("Trial Balance")
    next_row = _write_header_block(ws, company, "Trial Balance", period)
    header_row = _write_headers(ws, next_row, ["Code", "Account", "Debit (AED)", "Credit (AED)"])
    if tb_resp.get("error"):
        ws.cell(row=header_row, column=1, value=f"⚠️ {tb_resp['error']}")
        _autosize(ws); return

    tb = _unwrap_report_root(tb_resp, "trial_balance", "trialbalance",
                              "account_transactions", "accounts")
    rows = _walk_zoho_accounts(tb)
    total_dr = total_cr = 0.0
    for row in rows:
        if row.get("is_section"):
            cell = ws.cell(row=ws.max_row + 1, column=1, value=row["name"])
            cell.font = Font(bold=True)
            continue
        r = ws.max_row + 1
        ws.cell(row=r, column=1, value=row["code"])
        ws.cell(row=r, column=2, value=("  " * row["depth"]) + row["name"])
        ws.cell(row=r, column=3, value=row["debit"])
        ws.cell(row=r, column=4, value=row["credit"])
        total_dr += row["debit"]; total_cr += row["credit"]

    r = ws.max_row + 1
    ws.cell(row=r, column=2, value="TOTAL").font = _total_font()
    ws.cell(row=r, column=3, value=total_dr)
    ws.cell(row=r, column=4, value=total_cr)
    for c in range(1, 5):
        ws.cell(row=r, column=c).font = _total_font()
        ws.cell(row=r, column=c).fill = _total_fill()

    _aed_columns(ws, header_row - 1, (3, 4))
    _stripe_rows(ws, header_row - 1)
    _autosize(ws)


def _build_pnl(wb: Workbook, pnl_resp: dict, company: str, period: str) -> None:
    ws = wb.create_sheet("Profit & Loss")
    next_row = _write_header_block(ws, company, "Profit & Loss Statement", period)
    header_row = _write_headers(ws, next_row, ["Account", "Amount (AED)"])
    if pnl_resp.get("error"):
        ws.cell(row=header_row, column=1, value=f"⚠️ {pnl_resp['error']}")
        _autosize(ws); return

    pnl = _unwrap_report_root(pnl_resp, "profit_and_loss", "profitandloss",
                               "profit_loss", "report")
    rows = _walk_zoho_accounts(pnl)
    for row in rows:
        r = ws.max_row + 1
        label = ("  " * row["depth"]) + row["name"]
        if row.get("is_section"):
            cell = ws.cell(row=r, column=1, value=label); cell.font = _section_font()
            # Section rows carry their own total at depth>0 — show it
            if row["amount"]:
                ws.cell(row=r, column=2, value=row["amount"])
            continue
        ws.cell(row=r, column=1, value=label)
        ws.cell(row=r, column=2, value=row["amount"])

    # Net profit/loss — derive from the walked rows. The Zoho PnL tree puts
    # "Net Profit/Loss" as a top-level row with total_label set, so it's
    # already rendered above. If we can identify it explicitly, highlight.
    for row in rows:
        if "net profit" in row["name"].lower() or "net loss" in row["name"].lower():
            # Re-emit a highlighted summary row
            r = ws.max_row + 2
            ws.cell(row=r, column=1, value="NET PROFIT / (LOSS)")
            ws.cell(row=r, column=2, value=row["amount"])
            for c in (1, 2):
                ws.cell(row=r, column=c).font = _total_font()
                ws.cell(row=r, column=c).fill = _total_fill()
            break

    _aed_columns(ws, header_row - 1, (2,))
    _stripe_rows(ws, header_row - 1)
    _autosize(ws)


def _build_balance_sheet(wb: Workbook, bs_resp: dict, company: str, period: str) -> None:
    ws = wb.create_sheet("Balance Sheet")
    next_row = _write_header_block(ws, company, "Balance Sheet", period)
    header_row = _write_headers(ws, next_row, ["Account", "Amount (AED)"])
    if bs_resp.get("error"):
        ws.cell(row=header_row, column=1, value=f"⚠️ {bs_resp['error']}")
        _autosize(ws); return

    bs = _unwrap_report_root(bs_resp, "balance_sheet", "balancesheet", "report")
    rows = _walk_zoho_accounts(bs)
    for row in rows:
        r = ws.max_row + 1
        label = ("  " * row["depth"]) + row["name"]
        if row.get("is_section"):
            cell = ws.cell(row=r, column=1, value=label); cell.font = _section_font()
            if row["amount"]:
                ws.cell(row=r, column=2, value=row["amount"])
            continue
        ws.cell(row=r, column=1, value=label)
        ws.cell(row=r, column=2, value=row["amount"])

    # Balance check — derive from walked rows by matching the canonical
    # "TOTAL ASSETS" / "TOTAL LIABILITIES & EQUITIES" labels in the tree.
    assets = None; liab_eq = None
    for row in rows:
        n = row["name"].lower()
        if assets is None and "total assets" in n:
            assets = row["amount"]
        if liab_eq is None and (
            "total liabilities and equit" in n or "total liabilit" in n and "equit" in n
        ):
            liab_eq = row["amount"]
    if assets is not None and liab_eq is not None:
        r = ws.max_row + 2
        ws.cell(row=r, column=1, value="Total Assets")
        ws.cell(row=r, column=2, value=float(assets))
        ws.cell(row=r + 1, column=1, value="Total Liabilities + Equity")
        ws.cell(row=r + 1, column=2, value=float(liab_eq))
        delta = float(assets) - float(liab_eq)
        ws.cell(row=r + 2, column=1,
                value=f"Difference {'(balanced)' if abs(delta) < 0.01 else '⚠ unbalanced'}")
        ws.cell(row=r + 2, column=2, value=delta)
        for rr in range(r, r + 3):
            for c in (1, 2):
                ws.cell(row=rr, column=c).font = _total_font()
                ws.cell(row=rr, column=c).fill = _total_fill()

    _aed_columns(ws, header_row - 1, (2,))
    _stripe_rows(ws, header_row - 1)
    _autosize(ws)


_VAT_BOX_LABELS: dict[int, str] = {
    1: "Standard rated supplies (output VAT)",
    2: "Tax refunds for tourists",
    3: "Zero-rated supplies",
    4: "Exempt supplies",
    9: "Standard rated expenses (input VAT)",
    10: "Expenses related to exempt/non-taxable supplies",
    11: "Reverse charge (also Box 4)",
}


def _build_vat_summary(wb: Workbook, txns: list[dict], company: str, period: str) -> None:
    ws = wb.create_sheet("VAT Summary")
    next_row = _write_header_block(ws, company, "VAT 201 Summary", period)
    header_row = _write_headers(ws, next_row,
                                 ["Box", "Description", "Taxable (AED)", "VAT (AED)"])
    box_totals: dict[int, dict[str, float]] = defaultdict(
        lambda: {"taxable": 0.0, "vat": 0.0}
    )
    for t in txns:
        boxes = t.get("vat_boxes") or []
        taxable = float(t.get("net_amount") or t.get("amount_aed") or 0)
        vat = float(t.get("vat_amount") or 0)
        for b in boxes:
            try:
                bn = int(b)
            except (TypeError, ValueError):
                continue
            box_totals[bn]["taxable"] += taxable
            box_totals[bn]["vat"] += vat

    for bn in sorted(_VAT_BOX_LABELS.keys()):
        r = ws.max_row + 1
        totals = box_totals.get(bn) or {"taxable": 0.0, "vat": 0.0}
        ws.cell(row=r, column=1, value=f"Box {bn}")
        ws.cell(row=r, column=2, value=_VAT_BOX_LABELS[bn])
        ws.cell(row=r, column=3, value=round(totals["taxable"], 2))
        ws.cell(row=r, column=4, value=round(totals["vat"], 2))

    # Net VAT payable / refundable
    output_vat = sum(box_totals[b]["vat"] for b in (1, 11))
    input_vat = sum(box_totals[b]["vat"] for b in (9, 11))
    net = output_vat - input_vat
    r = ws.max_row + 2
    ws.cell(row=r, column=2, value="Output VAT (Boxes 1 + 11)")
    ws.cell(row=r, column=4, value=round(output_vat, 2))
    ws.cell(row=r + 1, column=2, value="Input VAT (Boxes 9 + 11)")
    ws.cell(row=r + 1, column=4, value=round(input_vat, 2))
    ws.cell(row=r + 2, column=2,
            value="Net VAT Payable" if net >= 0 else "Net VAT Refundable")
    ws.cell(row=r + 2, column=4, value=round(abs(net), 2))
    for rr in range(r, r + 3):
        for c in (2, 3, 4):
            ws.cell(row=rr, column=c).font = _total_font()
            ws.cell(row=rr, column=c).fill = _total_fill()

    _aed_columns(ws, header_row - 1, (3, 4))
    _stripe_rows(ws, header_row - 1)
    _autosize(ws)


def _age_bucket(days_overdue: int) -> str:
    if days_overdue <= 0: return "Current"
    if days_overdue <= 30: return "1-30"
    if days_overdue <= 60: return "31-60"
    if days_overdue <= 90: return "61-90"
    return "90+"


def _build_aging(
    wb: Workbook, title: str, sheet_name: str, rows: list[dict],
    *, ident_field: str, party_field: str, balance_field: str,
    company: str, period: str,
) -> None:
    ws = wb.create_sheet(sheet_name)
    next_row = _write_header_block(ws, company, title, period)
    header_row = _write_headers(ws, next_row, [
        f"{title.split()[0]} #", "Party", "Date", "Due Date",
        "Amount (AED)", "Balance (AED)", "Status", "Days Overdue", "Bucket",
    ])
    today = date.today()
    bucket_totals: dict[str, float] = defaultdict(float)
    for row in rows:
        r = ws.max_row + 1
        due_str = row.get("due_date") or row.get("date") or ""
        days_overdue = 0
        if due_str:
            try:
                d = date.fromisoformat(str(due_str)[:10])
                days_overdue = max(0, (today - d).days)
            except ValueError:
                pass
        balance = float(row.get(balance_field) or 0)
        bucket = _age_bucket(days_overdue)
        bucket_totals[bucket] += balance
        ws.cell(row=r, column=1, value=row.get(ident_field) or "")
        ws.cell(row=r, column=2, value=row.get(party_field) or "")
        ws.cell(row=r, column=3, value=row.get("date") or "")
        ws.cell(row=r, column=4, value=row.get("due_date") or "")
        ws.cell(row=r, column=5, value=float(row.get("total") or 0))
        ws.cell(row=r, column=6, value=balance)
        ws.cell(row=r, column=7, value=row.get("status") or "")
        ws.cell(row=r, column=8, value=days_overdue)
        ws.cell(row=r, column=9, value=bucket)

    # Bucket summary
    if bucket_totals:
        r = ws.max_row + 2
        ws.cell(row=r, column=1, value="Bucket totals (AED)").font = _section_font()
        for i, bucket in enumerate(("Current", "1-30", "31-60", "61-90", "90+"), 1):
            ws.cell(row=r + i, column=1, value=bucket)
            ws.cell(row=r + i, column=2, value=round(bucket_totals.get(bucket, 0), 2))
        for rr in range(r + 1, r + 6):
            ws.cell(row=rr, column=2).number_format = _AED_FMT

    _aed_columns(ws, header_row - 1, (5, 6))
    _stripe_rows(ws, header_row - 1)
    _autosize(ws)


def _build_transaction_log(
    wb: Workbook, txns: list[dict], company: str, period: str,
) -> None:
    ws = wb.create_sheet("Transaction Log")
    next_row = _write_header_block(ws, company, "Transaction Log", period)
    header_row = _write_headers(ws, next_row, [
        "Date", "Reference", "Vendor", "Description", "Amount (AED)",
        "VAT (AED)", "Gross (AED)", "Category", "Payment Method",
        "VAT Type", "Box", "Confidence", "Status",
    ])
    for t in sorted(txns, key=lambda r: (r.get("tax_point_date") or "", r.get("created_at") or "")):
        raw = t.get("raw_payload") or {}
        resolved = raw.get("resolved") or {}
        pay = raw.get("payment_resolution") or {}
        boxes = t.get("vat_boxes") or []
        r = ws.max_row + 1
        ws.cell(row=r, column=1, value=t.get("tax_point_date") or "")
        ws.cell(row=r, column=2, value=(t.get("zoho_entity_id") or str(t.get("id") or ""))[:24])
        ws.cell(row=r, column=3, value=t.get("vendor") or "")
        ws.cell(row=r, column=4, value=t.get("description") or "")
        ws.cell(row=r, column=5, value=float(t.get("net_amount") or 0))
        ws.cell(row=r, column=6, value=float(t.get("vat_amount") or 0))
        ws.cell(row=r, column=7, value=float(t.get("amount") or 0))
        ws.cell(row=r, column=8, value=resolved.get("category_account_name") or "Uncategorized")
        ws.cell(row=r, column=9, value=pay.get("account_name") or "—")
        ws.cell(row=r, column=10, value=t.get("vat_type") or "")
        ws.cell(row=r, column=11, value=", ".join(str(b) for b in boxes))
        ws.cell(row=r, column=12, value=t.get("confidence_score") or "")
        ws.cell(row=r, column=13, value=t.get("status") or "")

    _aed_columns(ws, header_row - 1, (5, 6, 7))
    _stripe_rows(ws, header_row - 1)
    _autosize(ws)


def _build_bank_recon(
    wb: Workbook, bank_accounts: list[dict], company: str, period: str,
) -> None:
    ws = wb.create_sheet("Bank Reconciliation")
    next_row = _write_header_block(ws, company, "Bank Reconciliation Summary", period)
    header_row = _write_headers(ws, next_row, [
        "Account", "Type", "Book Balance (AED)", "Bank Balance (AED)",
        "Unreconciled Items",
    ])
    for a in bank_accounts:
        r = ws.max_row + 1
        book = float(a.get("balance") or 0)
        # Zoho usually doesn't expose the external bank-side balance unless
        # the feed is connected; surface book balance in both cols and let
        # the auditor reconcile manually if no feed.
        ws.cell(row=r, column=1, value=a.get("account_name") or "")
        ws.cell(row=r, column=2, value=a.get("account_type") or "")
        ws.cell(row=r, column=3, value=book)
        ws.cell(row=r, column=4, value=a.get("bank_balance") or book)
        ws.cell(row=r, column=5, value=a.get("uncategorized_transactions") or "—")
    _aed_columns(ws, header_row - 1, (3, 4))
    _stripe_rows(ws, header_row - 1)
    _autosize(ws)


# ---- Top-level orchestration ---------------------------------------------

async def build_audit_workbook(
    ctx, from_date: date, to_date: date, period_label: str,
) -> tuple[bytes, str]:
    cfg = ctx.cfg
    if ctx.resolver is None:
        raise RuntimeError("Zoho isn't connected — can't pull report data.")

    zoho = ctx.resolver._zoho

    # Parallel fetches — saves several Zoho RTTs of latency.
    (tb, pnl, bs, txns, invoices, bills, banks) = await asyncio.gather(
        _fetch_trial_balance(zoho, from_date, to_date),
        _fetch_pnl(zoho, from_date, to_date),
        _fetch_balance_sheet(zoho, to_date),
        _fetch_transactions(cfg.id, from_date, to_date),
        _fetch_invoices(zoho),
        _fetch_bills(zoho),
        _fetch_bank_accounts(zoho),
    )

    wb = Workbook()
    # Drop the default blank sheet — every section gets its own
    default = wb.active
    wb.remove(default)

    _build_trial_balance(wb, tb, cfg.company_name, period_label)
    _build_pnl(wb, pnl, cfg.company_name, period_label)
    _build_balance_sheet(wb, bs, cfg.company_name, period_label)
    _build_vat_summary(wb, txns, cfg.company_name, period_label)
    _build_aging(
        wb, "AR Aging", "AR Aging", invoices,
        ident_field="invoice_number", party_field="customer_name",
        balance_field="balance",
        company=cfg.company_name, period=period_label,
    )
    _build_aging(
        wb, "AP Aging", "AP Aging", bills,
        ident_field="bill_number", party_field="vendor_name",
        balance_field="balance",
        company=cfg.company_name, period=period_label,
    )
    _build_transaction_log(wb, txns, cfg.company_name, period_label)
    _build_bank_recon(wb, banks, cfg.company_name, period_label)

    buf = BytesIO(); wb.save(buf)

    safe_company = (cfg.company_name or "company").replace(" ", "_").replace("/", "-")
    safe_period = period_label.replace(" ", "_").replace("/", "-")
    filename = f"{safe_company}_Audit_Workbook_{safe_period}.xlsx"
    return buf.getvalue(), filename


# ---- Period parsing — quarter / year / month / range --------------------

_QUARTER_RE = __import__("re").compile(r"^(\d{4})[-\s]?Q([1-4])$", __import__("re").IGNORECASE)
_YEAR_RE    = __import__("re").compile(r"^(\d{4})$")
_MONTH_RE   = __import__("re").compile(r"^(\d{4})-(\d{2})$")


def parse_audit_period(spec: str | None) -> tuple[date, date, str]:
    """Returns (from, to, label). Defaults to current calendar quarter."""
    from datetime import date as date_t
    today = date_t.today()
    s = (spec or "").strip()

    m = _QUARTER_RE.match(s)
    if m:
        year, q = int(m.group(1)), int(m.group(2))
        start_month = (q - 1) * 3 + 1
        start = date_t(year, start_month, 1)
        end_month = start_month + 2
        end_next = date_t(year + (1 if end_month == 12 else 0),
                          1 if end_month == 12 else end_month + 1, 1)
        return start, end_next - timedelta(days=1), f"{year}-Q{q}"

    m = _YEAR_RE.match(s)
    if m:
        year = int(m.group(1))
        return date_t(year, 1, 1), date_t(year, 12, 31), str(year)

    m = _MONTH_RE.match(s)
    if m:
        year, mo = int(m.group(1)), int(m.group(2))
        next_month = date_t(year + (1 if mo == 12 else 0),
                            1 if mo == 12 else mo + 1, 1)
        return (date_t(year, mo, 1), next_month - timedelta(days=1),
                date_t(year, mo, 1).strftime("%B %Y"))

    # Default: current quarter to date
    q = (today.month - 1) // 3 + 1
    start_month = (q - 1) * 3 + 1
    start = date_t(today.year, start_month, 1)
    return start, today, f"{today.year}-Q{q} (to date)"
