"""Natural-language query → Zoho report endpoint mapping.

Parses a user message into a structured ReportSpec the orchestrator can
execute. Includes a routing guard that flags AR/AP-style questions so the
Reports Bot can hand them off to the AR/AP queries module instead of
guessing a Zoho reports endpoint that doesn't fit.
"""
import re
from dataclasses import dataclass, field
from typing import Any, Literal

from reports.time_filter import DateRange, parse_time_filter

ReportType = Literal[
    "pnl",
    "balance_sheet",
    "trial_balance",
    "cash_flow",
    "cash_balance",
    "expense_by_vendor",
    "expense_breakdown",
    "vat_summary",
]

RoutingHint = Literal["reports", "ar", "ap", "out_of_scope"]


@dataclass
class ReportSpec:
    routing: RoutingHint
    report_type: ReportType | None = None
    period: DateRange | None = None
    zoho_endpoint: str | None = None
    zoho_params: dict[str, Any] = field(default_factory=dict)
    # Used by vendor-specific queries
    vendor_filter: str | None = None
    # If routing != "reports", a friendly hint to give the agent / user
    hint: str = ""


# ---------------------------------------------------------------------------
# Routing guard
# ---------------------------------------------------------------------------

_AR_PHRASES = (
    "who owes",
    "who owe me",
    "paid me",
    "customer paid",
    "did the customer",
    "did my customer",
    "overdue invoice",
    "overdue invoices",
    "ar aging",
    "what is owed to me",
    "who hasn't paid",
)

_AP_PHRASES = (
    "did i pay",
    "do i owe",
    "what do i owe",
    "overdue bill",
    "overdue bills",
    "ap aging",
    "what's overdue",
)


def _routing_for(text: str) -> tuple[RoutingHint, str]:
    t = text.lower().strip()
    for phrase in _AP_PHRASES:
        if phrase in t:
            return "ap", (
                "That looks like an AP/vendor question — use vendor_payment_status, "
                "get_ap_overdue, or get_ap_aging instead of a Reports tool."
            )
    for phrase in _AR_PHRASES:
        if phrase in t:
            return "ar", (
                "That looks like an AR/customer question — use customer_payment_status, "
                "get_ar_overdue, or get_ar_aging instead."
            )
    return "reports", ""


# ---------------------------------------------------------------------------
# Report-type detection
# ---------------------------------------------------------------------------

_CASH_BALANCE_HINTS = ("cash balance", "bank balance", "how much cash",
                       "how much in the bank", "what's my cash", "money in account")
_BALANCE_SHEET_HINTS = ("balance sheet", "balance-sheet", "assets and liabilities")
_TRIAL_BALANCE_HINTS = ("trial balance", "tb ")
_CASH_FLOW_HINTS = ("cash flow", "cash-flow", "cashflow", "cash summary")
_VAT_HINTS = ("vat summary", "vat report", "vat 201", "tax summary", "tax 201")
_EXPENSE_BREAKDOWN_HINTS = ("expense breakdown", "spend breakdown",
                            "where is my money going", "expense by category",
                            "spending by category", "categorise expenses",
                            "categorize expenses")
# "how much did I spend at <vendor>" / "spend with <vendor>" / etc.
_VENDOR_SPEND_PATTERN = re.compile(
    r"(?:spend|spent|spending|paid|expense[d]?|expenses?)\s+(?:at|to|with|on|for)\s+([A-Za-z][\w &'\-]+?)(?:\s+(?:this|last|in|today|yesterday|month|week|quarter|year)\b|$|\?)",
    re.IGNORECASE,
)


def _extract_vendor_filter(text: str) -> str | None:
    m = _VENDOR_SPEND_PATTERN.search(text)
    if m:
        return m.group(1).strip().rstrip(".,?!")
    return None


def _detect_report_type(text: str) -> tuple[ReportType, str | None]:
    """Returns (report_type, vendor_filter) — vendor_filter is set for the
    'spent at X' family of queries."""
    t = text.lower()

    if any(h in t for h in _CASH_BALANCE_HINTS):
        return "cash_balance", None
    if any(h in t for h in _BALANCE_SHEET_HINTS):
        return "balance_sheet", None
    if any(h in t for h in _TRIAL_BALANCE_HINTS):
        return "trial_balance", None
    if any(h in t for h in _CASH_FLOW_HINTS):
        return "cash_flow", None
    if any(h in t for h in _VAT_HINTS):
        return "vat_summary", None
    if any(h in t for h in _EXPENSE_BREAKDOWN_HINTS):
        return "expense_breakdown", None

    vendor = _extract_vendor_filter(text)
    if vendor:
        return "expense_by_vendor", vendor

    # Default: P&L
    return "pnl", None


# ---------------------------------------------------------------------------
# Endpoint mapping
# ---------------------------------------------------------------------------

def _zoho_endpoint_for(
    report_type: ReportType, period: DateRange, vendor: str | None
) -> tuple[str, dict[str, Any]]:
    if report_type == "pnl":
        return "reports/profitandloss", {
            "from_date": period.start.isoformat(),
            "to_date": period.end.isoformat(),
        }
    if report_type == "balance_sheet":
        return "reports/balancesheet", {"to_date": period.end.isoformat()}
    if report_type == "trial_balance":
        return "reports/trialbalance", {
            "from_date": period.start.isoformat(),
            "to_date": period.end.isoformat(),
        }
    if report_type == "cash_flow":
        return "reports/cashflow", {
            "from_date": period.start.isoformat(),
            "to_date": period.end.isoformat(),
        }
    if report_type == "cash_balance":
        # GET /bankaccounts returns all bank/cash accounts with current balances
        return "bankaccounts", {}
    if report_type == "expense_by_vendor":
        # List expenses with vendor name filter
        params: dict[str, Any] = {
            "date_after": period.start.isoformat(),
            "date_before": period.end.isoformat(),
            "per_page": 200,
        }
        if vendor:
            params["vendor_name_contains"] = vendor
        return "expenses", params
    if report_type == "expense_breakdown":
        # Pull all expenses for period; downstream groups by account_name
        return "expenses", {
            "date_after": period.start.isoformat(),
            "date_before": period.end.isoformat(),
            "per_page": 500,
        }
    # vat_summary is computed locally from transactions, not Zoho
    return "", {}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def map_query_to_report(text: str, today=None) -> ReportSpec:
    routing, hint = _routing_for(text)
    if routing != "reports":
        return ReportSpec(routing=routing, hint=hint)

    period = parse_time_filter(text, today=today)
    report_type, vendor = _detect_report_type(text)
    endpoint, params = _zoho_endpoint_for(report_type, period, vendor)

    return ReportSpec(
        routing="reports",
        report_type=report_type,
        period=period,
        zoho_endpoint=endpoint,
        zoho_params=params,
        vendor_filter=vendor,
    )
