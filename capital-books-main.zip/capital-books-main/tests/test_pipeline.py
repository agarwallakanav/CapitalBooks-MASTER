"""Sanity tests for the VAT pipeline.

Pure-logic tests run the step functions directly with fabricated contexts.
The two e2e tests monkeypatch the network-touching boundaries
(load_client_config, classify_vat, post_to_zoho, log_transaction)
so they stay offline.
"""
from datetime import date
from decimal import Decimal
from uuid import uuid4

from transactions.blocked_vat import check_blocked_vat
from transactions.box_mapping import map_vat_boxes
from transactions.models import (
    BlockedVatResult,
    ClientConfig,
    ReverseChargeResult,
    TransactionContext,
    TransactionInput,
    VatClassification,
)
from transactions.routing_decision import decide_routing
from transactions.tax_point import determine_tax_point
from transactions.trn_validation import validate_trn
from transactions.vat_arithmetic import compute_vat_amounts


def _input(**overrides) -> TransactionInput:
    base = dict(
        client_id=uuid4(),
        direction="expense",
        zoho_entity_type="Expense",
        vendor="Office Plus LLC",
        description="A4 paper, pens, stapler",
        amount=Decimal("105.00"),
        currency="AED",
        invoice_date=date(2026, 6, 1),
        payment_date=date(2026, 6, 1),
        vendor_trn="100123456789012",
        is_tax_invoice=True,
        is_paid=True,
    )
    base.update(overrides)
    return TransactionInput(**base)


def _client(**overrides) -> ClientConfig:
    base = dict(
        id=uuid4(),
        company_name="ACME LLC",
        vat_basis="accrual",
        entity_type="SME",
        foreign_suppliers=[],
        confidence_threshold=95,
        approval_amount_limit=Decimal("5000"),
        zoho_organization_id=None,
        zoho_access_token=None,
        zoho_refresh_token=None,
    )
    base.update(overrides)
    return ClientConfig(**base)


# --------------------------------------------------------------- TRN

async def test_trn_valid():
    ctx = TransactionContext(input=_input(vendor_trn="100123456789012"))
    res = await validate_trn(ctx)
    assert res.is_valid


async def test_trn_missing():
    ctx = TransactionContext(input=_input(vendor_trn=None))
    res = await validate_trn(ctx)
    assert not res.present and not res.is_valid


async def test_trn_wrong_length():
    ctx = TransactionContext(input=_input(vendor_trn="100123"))
    res = await validate_trn(ctx)
    assert res.present and not res.format_valid


async def test_trn_wrong_prefix():
    ctx = TransactionContext(input=_input(vendor_trn="200123456789012"))
    res = await validate_trn(ctx)
    assert res.format_valid and not res.starts_with_100


# --------------------------------------------------------------- Blocked VAT

async def test_blocked_entertainment():
    ctx = TransactionContext(input=_input(description="client dinner at Atlantis"))
    res = await check_blocked_vat(ctx)
    assert res.is_blocked and res.matched_category == "entertainment"


async def test_not_blocked_normal_expense():
    ctx = TransactionContext(input=_input(description="A4 paper and pens"))
    res = await check_blocked_vat(ctx)
    assert not res.is_blocked


async def test_blocked_skipped_for_income():
    ctx = TransactionContext(
        input=_input(direction="income", description="client dinner")
    )
    res = await check_blocked_vat(ctx)
    assert not res.is_blocked


# --------------------------------------------------------------- VAT arithmetic

async def test_arithmetic_standard_5pct():
    ctx = TransactionContext(
        input=_input(amount=Decimal("105.00")),
        vat_classification=VatClassification("standard", 95, ""),
        reverse_charge=ReverseChargeResult(False),
    )
    a = await compute_vat_amounts(ctx)
    assert a.net == Decimal("100.00")
    assert a.vat == Decimal("5.00")
    assert a.gross == Decimal("105.00")


async def test_arithmetic_reverse_charge_self_account():
    ctx = TransactionContext(
        input=_input(amount=Decimal("1000.00")),
        vat_classification=VatClassification("reverse_charge", 90, ""),
        reverse_charge=ReverseChargeResult(True),
    )
    a = await compute_vat_amounts(ctx)
    assert a.net == Decimal("1000.00")
    assert a.vat == Decimal("50.00")


async def test_arithmetic_zero_rated_no_vat():
    ctx = TransactionContext(
        input=_input(amount=Decimal("100.00")),
        vat_classification=VatClassification("zero", 95, ""),
        reverse_charge=ReverseChargeResult(False),
    )
    a = await compute_vat_amounts(ctx)
    assert a.vat == Decimal("0.00")


# --------------------------------------------------------------- Box mapping

async def test_boxes_income_standard_box1():
    ctx = TransactionContext(
        input=_input(direction="income"),
        vat_classification=VatClassification("standard", 95, ""),
        reverse_charge=ReverseChargeResult(False),
        blocked_vat=BlockedVatResult(False),
    )
    assert (await map_vat_boxes(ctx)).boxes == [1]


async def test_boxes_expense_standard_claimable_box9():
    ctx = TransactionContext(
        input=_input(),
        vat_classification=VatClassification("standard", 95, ""),
        reverse_charge=ReverseChargeResult(False),
        blocked_vat=BlockedVatResult(False),
    )
    assert (await map_vat_boxes(ctx)).boxes == [9]


async def test_boxes_expense_standard_blocked_box10():
    ctx = TransactionContext(
        input=_input(),
        vat_classification=VatClassification("standard", 95, ""),
        reverse_charge=ReverseChargeResult(False),
        blocked_vat=BlockedVatResult(True, matched_category="entertainment"),
    )
    assert (await map_vat_boxes(ctx)).boxes == [10]


async def test_boxes_reverse_charge_box4_and_11():
    ctx = TransactionContext(
        input=_input(),
        vat_classification=VatClassification("reverse_charge", 95, ""),
        reverse_charge=ReverseChargeResult(True),
        blocked_vat=BlockedVatResult(False),
    )
    assert (await map_vat_boxes(ctx)).boxes == [4, 11]


# --------------------------------------------------------------- Tax point

async def test_tax_point_accrual_takes_earlier_date():
    ctx = TransactionContext(
        input=_input(invoice_date=date(2026, 6, 1), payment_date=date(2026, 5, 28)),
        client=_client(vat_basis="accrual"),
    )
    assert await determine_tax_point(ctx) == date(2026, 5, 28)


async def test_tax_point_realisation_unpaid_returns_none():
    ctx = TransactionContext(
        input=_input(payment_date=None, is_paid=False),
        client=_client(vat_basis="realisation"),
    )
    assert await determine_tax_point(ctx) is None


# --------------------------------------------------------------- Routing

async def test_routing_auto_post_high_confidence():
    ctx = TransactionContext(
        input=_input(amount=Decimal("100")),
        client=_client(confidence_threshold=95),
        vat_classification=VatClassification("standard", 98, ""),
    )
    d = await decide_routing(ctx)
    assert d.action == "AUTO_POST"


async def test_routing_human_review_when_below_threshold():
    ctx = TransactionContext(
        input=_input(amount=Decimal("100")),
        client=_client(confidence_threshold=95),
        vat_classification=VatClassification("standard", 80, ""),
    )
    assert (await decide_routing(ctx)).action == "HUMAN_REVIEW"


async def test_routing_manual_when_very_low_confidence():
    ctx = TransactionContext(
        input=_input(amount=Decimal("100")),
        client=_client(),
        vat_classification=VatClassification("standard", 50, ""),
    )
    assert (await decide_routing(ctx)).action == "MANUAL"


async def test_routing_hold_until_paid_realisation_basis():
    ctx = TransactionContext(
        input=_input(is_paid=False),
        client=_client(vat_basis="realisation"),
        vat_classification=VatClassification("standard", 98, ""),
    )
    assert (await decide_routing(ctx)).action == "HOLD_UNTIL_PAID"


async def test_routing_human_review_when_amount_exceeds_limit():
    ctx = TransactionContext(
        input=_input(amount=Decimal("10000")),
        client=_client(approval_amount_limit=Decimal("5000")),
        vat_classification=VatClassification("standard", 98, ""),
    )
    assert (await decide_routing(ctx)).action == "HUMAN_REVIEW"


# --------------------------------------------------------------- E2E orchestrator

async def test_pipeline_e2e_auto_post(monkeypatch):
    from transactions import pipeline

    fake_client_id = uuid4()
    fake_client = _client(id=fake_client_id)

    async def fake_load_client_config(_client_id):
        return fake_client

    async def fake_classify_vat(_ctx):
        return VatClassification("standard", 97, "A4 paper is standard rated")

    async def fake_post_to_zoho(_ctx):
        return "ZB-12345"

    async def fake_log_transaction(_ctx):
        return uuid4()

    monkeypatch.setattr(pipeline, "load_client_config", fake_load_client_config)
    monkeypatch.setattr(pipeline, "classify_vat", fake_classify_vat)
    monkeypatch.setattr(pipeline, "post_to_zoho", fake_post_to_zoho)
    monkeypatch.setattr(pipeline, "log_transaction", fake_log_transaction)

    ctx = await pipeline.run_pipeline(_input(client_id=fake_client_id))

    assert ctx.routing.action == "AUTO_POST"
    assert ctx.amounts.net == Decimal("100.00")
    assert ctx.amounts.vat == Decimal("5.00")
    assert ctx.boxes.boxes == [9]
    assert ctx.zoho_entity_id == "ZB-12345"
    assert ctx.transaction_id is not None


async def test_pipeline_e2e_foreign_supplier_becomes_reverse_charge(monkeypatch):
    """Vendor on foreign_suppliers list → step 4 flips vat_type to reverse_charge,
    which routes box mapping to [4,11] and computes self-account VAT."""
    from transactions import pipeline

    fake_client = _client(foreign_suppliers=["Microsoft Ireland"])

    async def fake_load_client_config(_client_id):
        return fake_client

    async def fake_classify_vat(_ctx):
        # AI guesses 'standard' but the foreign-supplier rule should override
        return VatClassification("standard", 85, "")

    async def fake_log_transaction(_ctx):
        return uuid4()

    monkeypatch.setattr(pipeline, "load_client_config", fake_load_client_config)
    monkeypatch.setattr(pipeline, "classify_vat", fake_classify_vat)
    monkeypatch.setattr(pipeline, "log_transaction", fake_log_transaction)

    ctx = await pipeline.run_pipeline(
        _input(vendor="Microsoft Ireland Operations Ltd", amount=Decimal("1000.00"))
    )

    assert ctx.reverse_charge.is_reverse_charge
    assert ctx.vat_classification.vat_type == "reverse_charge"
    assert ctx.boxes.boxes == [4, 11]
    assert ctx.amounts.vat == Decimal("50.00")
