"""Smoke tests for reports/categorizer/AR — pure-logic only, no network."""
from datetime import date
from decimal import Decimal

from ar.aging import _bucket_for
from ar.templates.invoice_pdf import InvoiceData, LineItem, render_invoice_pdf
from ar.templates.receipt_pdf import ReceiptData, render_receipt_pdf
from ar.templates.styles import shape_arabic
from categorizer.rules_engine import Rule, _category_from_text, _vat_type_from_text, match_rule
from reports.time_filter import parse_time_filter


# ---- time filter

def test_parse_today():
    r = parse_time_filter("show P&L today", today=date(2026, 6, 2))
    assert r.start == r.end == date(2026, 6, 2)
    assert r.label == "today"


def test_parse_this_month():
    r = parse_time_filter("balance sheet this month", today=date(2026, 6, 2))
    assert r.start == date(2026, 6, 1)
    assert r.end == date(2026, 6, 2)


def test_parse_last_month():
    r = parse_time_filter("VAT summary last month", today=date(2026, 6, 2))
    assert r.start == date(2026, 5, 1)
    assert r.end == date(2026, 5, 31)


def test_parse_last_n_days():
    r = parse_time_filter("show last 7 days", today=date(2026, 6, 8))
    assert r.start == date(2026, 6, 1)
    assert r.end == date(2026, 6, 8)
    assert "7 days" in r.label


def test_parse_defaults_to_this_month():
    r = parse_time_filter("just show me numbers", today=date(2026, 6, 2))
    assert r.start == date(2026, 6, 1)
    assert r.label == "this month"


def test_parse_this_quarter():
    r = parse_time_filter("this quarter", today=date(2026, 5, 15))
    assert r.start == date(2026, 4, 1)


# ---- rules engine

def test_match_rule_longest_pattern_wins():
    rules = [
        Rule(id="1", vendor_pattern="amazon", category="software", account_code=None, vat_type="standard", times_used=5),
        Rule(id="2", vendor_pattern="amazon web services", category="cloud hosting", account_code=None, vat_type="standard", times_used=10),
    ]
    matched = match_rule("Amazon Web Services UAE", rules)
    assert matched is not None
    assert matched.category == "cloud hosting"


def test_match_rule_no_match():
    rules = [Rule(id="1", vendor_pattern="amazon", category="software", account_code=None, vat_type="standard", times_used=1)]
    assert match_rule("Carrefour Mall of Emirates", rules) is None


def test_category_from_correction_text():
    assert _category_from_text("no, that's office supplies") == "office supplies"
    assert _category_from_text("category: marketing") == "marketing"
    assert _category_from_text("no idea what this is") is None


def test_vat_type_from_text():
    assert _vat_type_from_text("it's zero-rated") == "zero"
    assert _vat_type_from_text("standard 5% VAT") == "standard"
    assert _vat_type_from_text("reverse charge applies") == "reverse_charge"


# ---- aging buckets

def test_aging_bucket_for_days():
    assert _bucket_for(-5) == "current"
    assert _bucket_for(0) == "current"
    assert _bucket_for(15) == "days_1_30"
    assert _bucket_for(45) == "days_31_60"
    assert _bucket_for(75) == "days_61_90"
    assert _bucket_for(120) == "days_over_90"


# ---- PDFs (render without raising; check it's a real PDF)

def test_invoice_pdf_renders():
    pdf = render_invoice_pdf(InvoiceData(
        invoice_number="INV-202606-0001",
        issue_date=date(2026, 6, 2),
        due_date=date(2026, 6, 16),
        company_name="ACME LLC",
        company_trn="100123456789012",
        company_address="Office 101, Sheikh Zayed Rd, Dubai",
        bank_name="Emirates NBD",
        iban="AE07 0331 2345 6789 0123 456",
        customer_name="ABC Corp",
        customer_trn="100987654321012",
        customer_address="Business Bay, Dubai",
        line_items=[
            LineItem(description="Consulting Q2 2026", quantity=1, unit_price=Decimal("5000")),
            LineItem(description="Workshop facilitation", quantity=2, unit_price=Decimal("1500")),
        ],
        currency="AED",
        ai_confidence=97,
        arabic_notes="شكراً لتعاملكم معنا",
    ))
    assert pdf.startswith(b"%PDF-")
    assert len(pdf) > 1000  # sanity: not an empty page


def test_receipt_pdf_renders():
    pdf = render_receipt_pdf(ReceiptData(
        receipt_number="REC-202606-0001",
        invoice_number="INV-202606-0001",
        payment_date=date(2026, 6, 5),
        company_name="ACME LLC",
        company_trn="100123456789012",
        customer_name="ABC Corp",
        customer_trn="100987654321012",
        amount_paid=Decimal("8400"),
        vat_amount=Decimal("400"),
        currency="AED",
        stripe_payment_intent="pi_test_123",
    ))
    assert pdf.startswith(b"%PDF-")


def test_shape_arabic_returns_string():
    out = shape_arabic("فاتورة ضريبية")
    assert isinstance(out, str)
    assert len(out) > 0
