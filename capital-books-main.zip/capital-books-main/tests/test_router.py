"""Router + WhatsApp tests.

Anthropic is monkeypatched at the module level (the lazily-cached `_anthropic`
field on each module), so no network calls are made.
"""
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from uuid import uuid4

from fastapi.testclient import TestClient

from router import intent as intent_module
from transactions import extractor as extractor_module
from whatsapp.webhook import iter_messages


# ---------- Anthropic SDK fake ----------

@dataclass
class _TextBlock:
    text: str
    type: str = "text"


@dataclass
class _MessageResp:
    content: list


class _FakeMessages:
    def __init__(self, reply: str):
        self.reply = reply
        self.calls: list[dict] = []

    async def create(self, **kwargs):
        self.calls.append(kwargs)
        return _MessageResp(content=[_TextBlock(text=self.reply)])


class _FakeAnthropic:
    def __init__(self, reply: str):
        self.messages = _FakeMessages(reply)


# ---------- iter_messages ----------

def test_iter_messages_extracts_text():
    payload = {
        "entry": [{
            "changes": [{
                "value": {
                    "messages": [{
                        "from": "971501234567",
                        "type": "text",
                        "text": {"body": "spent AED 500 at Carrefour"},
                        "id": "wamid.abc",
                        "timestamp": "1717000000",
                    }]
                }
            }]
        }]
    }
    messages = list(iter_messages(payload))
    assert len(messages) == 1
    assert messages[0]["from"] == "971501234567"
    assert messages[0]["type"] == "text"
    assert messages[0]["text"] == "spent AED 500 at Carrefour"


def test_iter_messages_skips_statuses_only_payload():
    """Delivery/read receipts arrive in 'statuses', never 'messages'."""
    payload = {
        "entry": [{
            "changes": [{
                "value": {
                    "statuses": [{"id": "wamid.xyz", "status": "delivered"}]
                }
            }]
        }]
    }
    assert list(iter_messages(payload)) == []


def test_iter_messages_empty_payload():
    assert list(iter_messages({})) == []


# ---------- Intent classifier ----------

async def test_intent_classifier_parses_transaction(monkeypatch):
    fake = _FakeAnthropic(
        '{"intent": "TRANSACTION", "confidence": 92, "reasoning": "expense logged"}'
    )
    monkeypatch.setattr(intent_module, "_anthropic", fake)

    result = await intent_module.classify_intent("spent 500 AED on office paper")
    assert result.intent == "TRANSACTION"
    assert result.confidence == 92


async def test_intent_classifier_strips_code_fences(monkeypatch):
    fake = _FakeAnthropic(
        '```json\n{"intent": "GREETING", "confidence": 99, "reasoning": "hi"}\n```'
    )
    monkeypatch.setattr(intent_module, "_anthropic", fake)

    result = await intent_module.classify_intent("hello")
    assert result.intent == "GREETING"


async def test_intent_classifier_handles_bad_json(monkeypatch):
    fake = _FakeAnthropic("totally not json")
    monkeypatch.setattr(intent_module, "_anthropic", fake)

    result = await intent_module.classify_intent("anything")
    assert result.intent == "UNKNOWN"
    assert result.confidence == 0


async def test_intent_classifier_rejects_unknown_intent(monkeypatch):
    fake = _FakeAnthropic('{"intent": "FOO_BAR", "confidence": 80, "reasoning": ""}')
    monkeypatch.setattr(intent_module, "_anthropic", fake)

    result = await intent_module.classify_intent("x")
    assert result.intent == "UNKNOWN"


async def test_intent_classifier_empty_message():
    result = await intent_module.classify_intent("")
    assert result.intent == "UNKNOWN"


# ---------- Transaction extractor ----------

async def test_extractor_parses_full_transaction(monkeypatch):
    fake = _FakeAnthropic(
        '{"direction": "expense", "vendor": "Carrefour", '
        '"description": "groceries", "amount": 500.50, "currency": "AED", '
        '"vendor_trn": "100123456789012", "invoice_date": "2026-06-01", "is_paid": true}'
    )
    monkeypatch.setattr(extractor_module, "_anthropic", fake)

    client_id = uuid4()
    tx = await extractor_module.extract_transaction(
        "spent AED 500.50 at Carrefour on groceries", client_id, today=date(2026, 6, 5)
    )
    assert tx.client_id == client_id
    assert tx.direction == "expense"
    assert tx.zoho_entity_type == "Expense"
    assert tx.vendor == "Carrefour"
    assert tx.amount == Decimal("500.50")
    assert tx.currency == "AED"
    assert tx.vendor_trn == "100123456789012"
    assert tx.invoice_date == date(2026, 6, 1)
    assert tx.payment_date == date(2026, 6, 5)
    assert tx.is_paid is True


async def test_extractor_defaults_for_unpaid_invoice(monkeypatch):
    fake = _FakeAnthropic(
        '{"direction": "income", "vendor": "ABC Corp", '
        '"description": "consulting Q2", "amount": 5000, "currency": "AED", '
        '"vendor_trn": null, "invoice_date": null, "is_paid": false}'
    )
    monkeypatch.setattr(extractor_module, "_anthropic", fake)

    tx = await extractor_module.extract_transaction(
        "invoice ABC Corp 5000 AED for Q2 consulting", uuid4(), today=date(2026, 6, 5)
    )
    assert tx.direction == "income"
    assert tx.zoho_entity_type == "Invoice"
    assert tx.is_paid is False
    assert tx.payment_date is None
    assert tx.invoice_date == date(2026, 6, 5)


# ---------- Webhook verification endpoint ----------

def test_webhook_verify_accepts_correct_token(monkeypatch):
    from config import settings
    monkeypatch.setattr(settings, "whatsapp_verify_token", "secret123")
    from main import app

    client = TestClient(app)
    r = client.get(
        "/webhook/whatsapp",
        params={
            "hub.mode": "subscribe",
            "hub.verify_token": "secret123",
            "hub.challenge": "echo-me-back",
        },
    )
    assert r.status_code == 200
    assert r.text == "echo-me-back"


def test_webhook_verify_rejects_wrong_token(monkeypatch):
    from config import settings
    monkeypatch.setattr(settings, "whatsapp_verify_token", "secret123")
    from main import app

    client = TestClient(app)
    r = client.get(
        "/webhook/whatsapp",
        params={
            "hub.mode": "subscribe",
            "hub.verify_token": "wrong",
            "hub.challenge": "anything",
        },
    )
    assert r.status_code == 403
