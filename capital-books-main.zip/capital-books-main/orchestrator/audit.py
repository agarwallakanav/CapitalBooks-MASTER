"""Four-layer audit trail.

Layer 1 — Supabase Storage: immutable source documents (receipts, invoice PDFs,
          receipt PDFs, supplier docs). Already exists at ar/storage.py — we
          reuse it. Key convention: docs/{client_id}/{entity_type}/{yyyymm}/{filename}.

Layer 2 — transaction_events: append-only log of every state change. The
          orchestrator is the ONLY writer. record_event() is the single entry
          point.

Layer 3 — Zoho linkage: bidirectional id mapping (CB ↔ Zoho). Stored on the
          entity row (transactions.zoho_entity_id, bills.zoho_bill_id,
          invoices.zoho_invoice_id) AND on the corresponding transaction_event.
          link_zoho_entity() updates both atomically.

Layer 4 — Google Sheets: monthly per-client audit log. append_to_sheet() is
          a best-effort write; logs a warning and continues if Google Sheets
          isn't configured (no GOOGLE_* env vars or no client.google_sheet_id).
"""
import json
import logging
from datetime import date
from typing import Any
from uuid import UUID

from ar.storage import upload_pdf as _upload_pdf
from database import get_db

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Layer 2: transaction_events
# ---------------------------------------------------------------------------

async def record_event(
    client_id: UUID,
    event_type: str,
    *,
    entity_type: str | None = None,
    entity_id: UUID | str | None = None,
    actor: str = "orchestrator",
    payload: dict[str, Any] | None = None,
    zoho_entity_type: str | None = None,
    zoho_entity_id: str | None = None,
    api_calls: int = 0,
    api_domain: str | None = None,
    error_code: str | None = None,
    error_message: str | None = None,
) -> dict[str, Any]:
    """Append a single event. Returns the inserted row."""
    row = {
        "client_id": str(client_id),
        "event_type": event_type,
        "actor": actor,
        "payload": payload or {},
        "api_calls": api_calls,
    }
    if entity_type:
        row["entity_type"] = entity_type
    if entity_id:
        row["entity_id"] = str(entity_id)
    if zoho_entity_type:
        row["zoho_entity_type"] = zoho_entity_type
    if zoho_entity_id:
        row["zoho_entity_id"] = zoho_entity_id
    if api_domain:
        row["api_domain"] = api_domain
    if error_code:
        row["error_code"] = error_code
    if error_message:
        row["error_message"] = error_message[:2000]   # avoid runaway bodies

    db = await get_db()
    try:
        res = await db.table("transaction_events").insert(row).execute()
        return res.data[0] if res.data else row
    except Exception:
        # Never block business logic if the audit log itself fails.
        logger.exception(
            "transaction_events insert failed (client=%s event=%s) — continuing",
            client_id, event_type,
        )
        return row


async def daily_api_call_count(client_id: UUID, on_day: date | None = None) -> int:
    """Sum api_calls across events for one client on one calendar day.
    Used by the engine to enforce daily caps (1k free / 10k premium)."""
    on_day = on_day or date.today()
    start = f"{on_day.isoformat()}T00:00:00+00:00"
    end = f"{on_day.isoformat()}T23:59:59+00:00"
    db = await get_db()
    res = (
        await db.table("transaction_events")
        .select("api_calls")
        .eq("client_id", str(client_id))
        .gte("created_at", start)
        .lte("created_at", end)
        .execute()
    )
    return sum((r.get("api_calls") or 0) for r in (res.data or []))


# ---------------------------------------------------------------------------
# Layer 1: Source documents
# ---------------------------------------------------------------------------

def _doc_key(
    client_id: UUID, entity_type: str, filename: str, today: date | None = None
) -> str:
    today = today or date.today()
    return f"docs/{client_id}/{entity_type}/{today:%Y%m}/{filename}"


async def store_document(
    client_id: UUID,
    entity_type: str,
    body: bytes,
    filename: str,
    *,
    entity_id: UUID | str | None = None,
    mime_type: str = "application/pdf",
) -> str:
    """Upload an immutable source document to Supabase Storage; record an
    event so the audit log knows where it lives. Returns the signed URL."""
    key = _doc_key(client_id, entity_type, filename)
    url = await _upload_pdf(key, body)   # _upload_pdf accepts any bytes, content-type fixed
    await record_event(
        client_id,
        event_type="document_stored",
        entity_type=entity_type if entity_type in {
            "transaction", "bill", "invoice", "payment", "receipt"
        } else None,
        entity_id=entity_id,
        payload={"key": key, "mime_type": mime_type, "filename": filename},
    )
    return url


# ---------------------------------------------------------------------------
# Layer 3: Zoho linkage
# ---------------------------------------------------------------------------

# Table for each CB entity → the column that holds the Zoho id.
_ZOHO_ID_COLUMN: dict[str, tuple[str, str]] = {
    "transaction": ("transactions", "zoho_entity_id"),
    "bill": ("bills", "zoho_bill_id"),
    "invoice": ("invoices", "zoho_invoice_id"),
}


async def link_zoho_entity(
    client_id: UUID,
    entity_type: str,
    entity_id: UUID | str,
    zoho_entity_type: str,
    zoho_entity_id: str,
) -> None:
    """Store the CB ↔ Zoho id linkage on the CB entity row, and record an
    event so the audit log captures the moment of binding."""
    pair = _ZOHO_ID_COLUMN.get(entity_type)
    if pair:
        table, column = pair
        db = await get_db()
        try:
            await db.table(table).update({column: zoho_entity_id}).eq(
                "id", str(entity_id)
            ).execute()
        except Exception:
            logger.exception(
                "Failed to set %s.%s for %s — event still recorded",
                table, column, entity_id,
            )

    await record_event(
        client_id,
        event_type="zoho_linked",
        entity_type=entity_type,
        entity_id=entity_id,
        zoho_entity_type=zoho_entity_type,
        zoho_entity_id=zoho_entity_id,
    )


# ---------------------------------------------------------------------------
# Layer 4: Google Sheets per-client audit log
# ---------------------------------------------------------------------------

async def append_to_sheet(
    client_id: UUID,
    sheet_id: str | None,
    row: dict[str, Any],
) -> None:
    """Append one row to a per-client Google Sheet. Best-effort: no-op if
    sheet_id is missing or Google API isn't wired up yet."""
    if not sheet_id:
        return
    try:
        # Deferred: real Google Sheets writes require service-account creds + the
        # google-api-python-client install. Stub for now — log to a sentinel event
        # so it's auditable that we *tried* and config is missing.
        await record_event(
            client_id,
            event_type="sheet_append_skipped",
            payload={"reason": "google_creds_not_configured", "sheet_id": sheet_id, "row": row},
        )
        logger.info(
            "Google Sheets append skipped — sheet=%s payload=%s",
            sheet_id, json.dumps(row, default=str)[:300],
        )
    except Exception:
        logger.exception("Sheets append failed for client %s", client_id)
