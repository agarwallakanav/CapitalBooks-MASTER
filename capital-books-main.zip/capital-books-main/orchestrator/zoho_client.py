"""Centralized Zoho Books client.

This is the ONLY module that talks to Zoho. The orchestrator owns its lifecycle.
No other module imports this directly — they go through orchestrator.engine.

Responsibilities:
  - Per-client OAuth lifecycle: proactive refresh before 1h expiry, persist new
    tokens via audit layer. Refresh tokens don't expire but each user has a
    20-token cap — never request more refresh tokens than needed (we keep one
    per client and reuse).
  - Per-client api_domain — Zoho returns one of 8 regional API hosts in the
    token response. Persisted on the clients row. NEVER hardcode.
  - Rate limit handling: 100 req/min per user. In-process bucket per client_id;
    when the bucket is exhausted, callers wait for the window to refill. No
    Retry-After header in 429 responses — exponential backoff with jitter.
  - Daily cap awareness: free 1k/org/day, premium 10k/org/day. Each successful
    call is logged via orchestrator.audit.record_event(api_calls=1); the audit
    log answers "did we exceed the cap today" queries.
  - All errors flow back to the orchestrator with structured info so the audit
    layer can record event_type='api_error' or 'rate_limited' with details.
"""
import asyncio
import logging
import random
import time
from datetime import datetime, timedelta, timezone
from typing import Any
from uuid import UUID

import httpx

from config import settings

logger = logging.getLogger(__name__)

# Regional Zoho accounts/token endpoints. The OAuth flow tells us which API
# domain to use afterward; persist it on the clients row.
ACCOUNTS_HOST_BY_API_DOMAIN: dict[str, str] = {
    "www.zohoapis.com": "accounts.zoho.com",
    "www.zohoapis.eu": "accounts.zoho.eu",
    "www.zohoapis.in": "accounts.zoho.in",
    "www.zohoapis.com.au": "accounts.zoho.com.au",
    "www.zohoapis.jp": "accounts.zoho.jp",
    "www.zohoapis.com.cn": "accounts.zoho.com.cn",
    "www.zohoapis.sa": "accounts.zoho.sa",
    "www.zohoapis.uk": "accounts.zoho.uk",
}

RATE_LIMIT_REQS_PER_WINDOW = 100
RATE_LIMIT_WINDOW_SECONDS = 60
MAX_BACKOFF_SECONDS = 32


class ZohoError(Exception):
    """Structured Zoho API error — orchestrator catches and logs to audit."""

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        code: int | str | None = None,
        body: str | None = None,
        api_domain: str | None = None,
    ):
        super().__init__(message)
        self.status = status
        self.code = code
        self.body = body
        self.api_domain = api_domain


class _ClientRateBucket:
    """Per-client sliding-window counter. Cheap, in-process. If we scale to
    multiple workers, replace with Redis ZADD/ZREMRANGEBYSCORE."""

    def __init__(self) -> None:
        self._timestamps: list[float] = []
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        async with self._lock:
            now = time.monotonic()
            cutoff = now - RATE_LIMIT_WINDOW_SECONDS
            self._timestamps = [t for t in self._timestamps if t > cutoff]
            if len(self._timestamps) >= RATE_LIMIT_REQS_PER_WINDOW:
                wait = RATE_LIMIT_WINDOW_SECONDS - (now - self._timestamps[0])
                if wait > 0:
                    logger.info(
                        "Zoho rate-limit local wait: %.2fs (bucket full at %d)",
                        wait, len(self._timestamps),
                    )
                    await asyncio.sleep(wait)
                # Re-trim after the sleep
                now = time.monotonic()
                cutoff = now - RATE_LIMIT_WINDOW_SECONDS
                self._timestamps = [t for t in self._timestamps if t > cutoff]
            self._timestamps.append(now)


# One bucket per client (lives for the process lifetime; fine for dev).
_buckets: dict[str, _ClientRateBucket] = {}


def _bucket_for(client_id: UUID) -> _ClientRateBucket:
    key = str(client_id)
    if key not in _buckets:
        _buckets[key] = _ClientRateBucket()
    return _buckets[key]


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

async def refresh_access_token(
    refresh_token: str, api_domain: str
) -> dict[str, Any]:
    """Exchange a refresh_token for a fresh short-lived access_token. Returns
    the raw Zoho response (caller persists tokens via audit/engine)."""
    accounts_host = ACCOUNTS_HOST_BY_API_DOMAIN.get(
        api_domain, "accounts.zoho.com"
    )
    async with httpx.AsyncClient(timeout=20.0) as http:
        resp = await http.post(
            f"https://{accounts_host}/oauth/v2/token",
            data={
                "refresh_token": refresh_token,
                "client_id": settings.zoho_client_id,
                "client_secret": settings.zoho_client_secret,
                "grant_type": "refresh_token",
            },
        )
        body = resp.json() if resp.content else {}
        if resp.status_code >= 400 or "access_token" not in body:
            raise ZohoError(
                f"Zoho refresh failed: {body}",
                status=resp.status_code,
                body=resp.text,
                api_domain=api_domain,
            )
        return body


# ---------------------------------------------------------------------------
# ClientCredentials: what the orchestrator hands the client per request
# ---------------------------------------------------------------------------

class ClientCredentials:
    """Snapshot of a client's Zoho auth state for one request batch.

    The orchestrator (engine.py) holds the canonical state in Supabase and
    builds this object before each module call. After the call returns, the
    orchestrator persists any token updates back to Supabase via audit.
    """

    __slots__ = (
        "client_id",
        "organization_id",
        "api_domain",
        "access_token",
        "refresh_token",
        "token_expires_at",
        "refreshed",
    )

    def __init__(
        self,
        client_id: UUID,
        organization_id: str,
        api_domain: str,
        access_token: str,
        refresh_token: str,
        token_expires_at: datetime | None = None,
    ):
        self.client_id = client_id
        self.organization_id = organization_id
        self.api_domain = api_domain
        self.access_token = access_token
        self.refresh_token = refresh_token
        self.token_expires_at = token_expires_at
        # Set when this request batch triggered a refresh — engine persists.
        self.refreshed = False


# ---------------------------------------------------------------------------
# The actual API client (used by the orchestrator)
# ---------------------------------------------------------------------------

class ZohoClient:
    """Stateless-ish per-call wrapper. The orchestrator instantiates this once
    per request batch, hands it ClientCredentials, and calls methods.

    Refresh policy: if the credentials' token expires within the next 60s
    (proactive) or we receive a 401, refresh once and retry.
    """

    def __init__(self, creds: ClientCredentials, http: httpx.AsyncClient | None = None):
        self.creds = creds
        # Caller may pass a shared httpx client; otherwise we own one.
        self._http = http or httpx.AsyncClient(timeout=30.0)
        self._owns_http = http is None
        # Per-call accounting for the orchestrator's audit log
        self.api_call_count = 0

    async def __aenter__(self) -> "ZohoClient":
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.close()

    async def close(self) -> None:
        if self._owns_http:
            await self._http.aclose()

    # ---- low-level transport ----

    def _base_url(self) -> str:
        return f"https://{self.creds.api_domain}/books/v3"

    def _url(self, path: str) -> str:
        return f"{self._base_url()}/{path.lstrip('/')}"

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Zoho-oauthtoken {self.creds.access_token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def _params(self, extra: dict[str, Any] | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"organization_id": self.creds.organization_id}
        if extra:
            params.update(extra)
        return params

    def _needs_proactive_refresh(self) -> bool:
        if not self.creds.token_expires_at:
            return False
        return self.creds.token_expires_at - datetime.now(timezone.utc) < timedelta(seconds=60)

    async def _refresh(self) -> None:
        token = await refresh_access_token(
            self.creds.refresh_token, self.creds.api_domain
        )
        self.creds.access_token = token["access_token"]
        # Zoho rotates refresh_token only when the old one is near limit; respect it
        if token.get("refresh_token"):
            self.creds.refresh_token = token["refresh_token"]
        # Token response includes api_domain — but it may have a protocol prefix
        # like "https://www.zohoapis.com". Strip that so our URL construction
        # f"https://{api_domain}/..." doesn't produce "https://https://...".
        new_api_domain = token.get("api_domain")
        if new_api_domain:
            new_api_domain = new_api_domain.replace("https://", "").replace("http://", "").rstrip("/")
        if new_api_domain and new_api_domain != self.creds.api_domain:
            logger.info(
                "Zoho api_domain changed for client %s: %s -> %s",
                self.creds.client_id, self.creds.api_domain, new_api_domain,
            )
            self.creds.api_domain = new_api_domain
        expires_in = int(token.get("expires_in", 3600))
        self.creds.token_expires_at = datetime.now(timezone.utc) + timedelta(
            seconds=expires_in - 60
        )
        self.creds.refreshed = True

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        _retry_after_refresh: bool = False,
        _backoff_attempt: int = 0,
        _connect_retry: int = 0,
    ) -> dict[str, Any]:
        if self._needs_proactive_refresh() and not _retry_after_refresh:
            await self._refresh()

        await _bucket_for(self.creds.client_id).acquire()

        url = self._url(path)
        try:
            logger.debug("Zoho request %s %s (api_domain=%s)", method, url, self.creds.api_domain)
            resp = await self._http.request(
                method,
                url,
                headers=self._headers(),
                params=self._params(params),
                json=json,
            )
        except (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError) as exc:
            # Transient resolver / connection blips — retry once with backoff.
            # macOS in particular sometimes fails the first lookup after the
            # process has been idle. Don't bury this on the second try.
            if _connect_retry == 0:
                logger.warning(
                    "Zoho transient connect error (%s) for %s %s — retrying once",
                    type(exc).__name__, method, path,
                )
                await asyncio.sleep(1.0)
                return await self._request(
                    method, path,
                    params=params, json=json,
                    _retry_after_refresh=_retry_after_refresh,
                    _backoff_attempt=_backoff_attempt,
                    _connect_retry=1,
                )
            raise ZohoError(
                f"Zoho transport failure for {method} {path}: {exc}",
                status=None,
                api_domain=self.creds.api_domain,
            ) from exc
        self.api_call_count += 1

        # 401: stale token, refresh + retry once
        if resp.status_code == 401 and not _retry_after_refresh:
            await self._refresh()
            return await self._request(
                method, path, params=params, json=json, _retry_after_refresh=True
            )

        # 429: rate-limited by Zoho. No Retry-After — exponential backoff with jitter.
        if resp.status_code == 429 and _backoff_attempt < 5:
            wait = min(MAX_BACKOFF_SECONDS, (2 ** _backoff_attempt)) + random.uniform(0, 1)
            logger.warning(
                "Zoho 429 backoff for client %s: sleeping %.2fs (attempt %d)",
                self.creds.client_id, wait, _backoff_attempt,
            )
            await asyncio.sleep(wait)
            return await self._request(
                method, path, params=params, json=json,
                _retry_after_refresh=_retry_after_refresh,
                _backoff_attempt=_backoff_attempt + 1,
            )

        if resp.status_code >= 400:
            body = resp.text
            try:
                code = (resp.json() or {}).get("code")
            except Exception:
                code = None
            raise ZohoError(
                f"Zoho {method} {path} -> {resp.status_code} body={body[:500]}",
                status=resp.status_code,
                code=code,
                body=body,
                api_domain=self.creds.api_domain,
            )

        return resp.json() if resp.content else {}

    # ---- high-level convenience methods ----

    async def create_entity(
        self,
        entity: str,
        payload: dict[str, Any],
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return await self._request("POST", entity, params=params, json=payload)

    async def update_entity(
        self,
        entity: str,
        entity_id: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        return await self._request("PUT", f"{entity}/{entity_id}", json=payload)

    async def get_entity(self, entity: str, entity_id: str) -> dict[str, Any]:
        return await self._request("GET", f"{entity}/{entity_id}")

    async def list_entities(
        self,
        entity: str,
        filters: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", entity, params=filters)

    async def delete_entity(self, entity: str, entity_id: str) -> dict[str, Any]:
        return await self._request("DELETE", f"{entity}/{entity_id}")

    async def report(
        self,
        name: str,
        filters: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", f"reports/{name}", params=filters)

    async def search_contacts(self, name: str) -> list[dict[str, Any]]:
        resp = await self._request(
            "GET", "contacts", params={"contact_name_contains": name}
        )
        return resp.get("contacts") or []

    async def download_pdf(self, entity: str, entity_id: str) -> bytes:
        """Fetch entity as PDF bytes (used for invoices/bills)."""
        if self._needs_proactive_refresh():
            await self._refresh()
        await _bucket_for(self.creds.client_id).acquire()
        resp = await self._http.get(
            self._url(f"{entity}/{entity_id}"),
            headers={**self._headers(), "Accept": "application/pdf"},
            params=self._params(),
        )
        self.api_call_count += 1
        if resp.status_code == 401:
            await self._refresh()
            await _bucket_for(self.creds.client_id).acquire()
            resp = await self._http.get(
                self._url(f"{entity}/{entity_id}"),
                headers={**self._headers(), "Accept": "application/pdf"},
                params=self._params(),
            )
            self.api_call_count += 1
        if resp.status_code >= 400:
            raise ZohoError(
                f"Zoho PDF download {entity}/{entity_id} -> {resp.status_code}",
                status=resp.status_code,
                body=resp.text,
                api_domain=self.creds.api_domain,
            )
        return resp.content
