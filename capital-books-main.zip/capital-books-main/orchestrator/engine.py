"""The orchestration engine.

Single entry point for all business operations. The WhatsApp router (and any
future input — email, scheduled jobs, manual API calls) gets the right
behavior by calling engine.process(...).

Architectural rules enforced here:
  1. Modules NEVER call Zoho directly. They return structured intent (a
     ModuleResult). The engine executes the Zoho writes via
     orchestrator.zoho_client.ZohoClient and persists the result.
  2. All transaction_events writes go through orchestrator.audit. No module
     writes events.
  3. Token refresh is automatic. After every batch, if creds.refreshed is
     True, the engine persists the new access_token/expires_at/api_domain
     back to Supabase.
  4. Source documents (PDFs) are stored via orchestrator.audit.store_document
     before any Zoho write — Layer 1 of the audit trail always precedes
     Layer 2/3.

Module contract (modules implement this so the engine can drive them):

    @dataclass
    class ModuleResult:
        # What the engine should do next.
        zoho_writes: list[ZohoWrite]      # API calls to perform
        events: list[dict]                # extra audit events to log
        documents: list[Document]         # source docs to upload
        reply_to_user: str                # what to send back over WhatsApp
        entity_kind: Literal[...]         # transaction / bill / invoice / payment

The engine executes zoho_writes in order, threads new Zoho ids back into the
events/documents, persists, and returns reply_to_user.

Phase A scope: the engine class + ClientConfig loader + the helper that
acquires ZohoClient/creds. Module migration happens in Phase B+.
"""
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal
from uuid import UUID

from database import get_db
from orchestrator.audit import (
    daily_api_call_count,
    link_zoho_entity,
    record_event,
    store_document,
)
from orchestrator.zoho_client import ClientCredentials, ZohoClient, ZohoError

logger = logging.getLogger(__name__)

# Conservative cap — bumped per-plan via env var later (free=1k, premium=10k).
DAILY_API_CAP_DEFAULT = 1000


# ---------------------------------------------------------------------------
# ClientConfig — the engine's per-request snapshot
# ---------------------------------------------------------------------------

@dataclass
class ClientConfig:
    """Materialized client config the engine hands modules. Read-only view —
    modules must NOT mutate. Engine writes back to Supabase as needed."""
    id: UUID
    company_name: str
    phone: str
    trn: str | None
    vat_basis: str
    foreign_suppliers: list[str]
    confidence_threshold: int
    approval_amount_limit: float
    approval_threshold: float

    # Zoho
    zoho_organization_id: str | None
    api_domain: str
    zoho_access_token: str | None
    zoho_refresh_token: str | None
    zoho_token_expires_at: datetime | None
    zoho_tax_ids: dict[str, Any]

    # AP/AR helpers
    card_mapping: dict[str, Any]
    default_payment_account: str | None
    google_sheet_id: str | None


async def load_client_config(client_id: UUID) -> ClientConfig:
    db = await get_db()
    res = (
        await db.table("clients")
        .select(
            "id, company_name, phone, trn, vat_basis, foreign_suppliers, "
            "confidence_threshold, approval_amount_limit, approval_threshold, "
            "zoho_organization_id, api_domain, "
            "zoho_access_token, zoho_refresh_token, zoho_token_expires_at, "
            "zoho_tax_ids, card_mapping, default_payment_account, google_sheet_id"
        )
        .eq("id", str(client_id))
        .single()
        .execute()
    )
    row = res.data
    if not row:
        raise ValueError(f"Client not found: {client_id}")
    expires_at = row.get("zoho_token_expires_at")
    return ClientConfig(
        id=UUID(row["id"]),
        company_name=row["company_name"],
        phone=row["phone"],
        trn=row.get("trn"),
        vat_basis=row.get("vat_basis") or "accrual",
        foreign_suppliers=row.get("foreign_suppliers") or [],
        confidence_threshold=int(row.get("confidence_threshold") or 95),
        approval_amount_limit=float(row.get("approval_amount_limit") or 5000),
        approval_threshold=float(row.get("approval_threshold") or 5000),
        zoho_organization_id=row.get("zoho_organization_id"),
        api_domain=row.get("api_domain") or "www.zohoapis.com",
        zoho_access_token=row.get("zoho_access_token"),
        zoho_refresh_token=row.get("zoho_refresh_token"),
        zoho_token_expires_at=(
            datetime.fromisoformat(expires_at) if expires_at else None
        ),
        zoho_tax_ids=row.get("zoho_tax_ids") or {},
        card_mapping=row.get("card_mapping") or {},
        default_payment_account=row.get("default_payment_account"),
        google_sheet_id=row.get("google_sheet_id"),
    )


# ---------------------------------------------------------------------------
# ZohoWrite — modules return these; engine executes them
# ---------------------------------------------------------------------------

@dataclass
class ZohoWrite:
    """One Zoho API call the engine should perform on behalf of a module."""
    method: Literal["GET", "POST", "PUT", "DELETE"]
    endpoint: str                       # e.g. "expenses", "bills/123", "reports/pnl"
    payload: dict[str, Any] | None = None
    params: dict[str, Any] | None = None
    # Slot to bind the Zoho-returned id back into the entity (for layer 3).
    bind_to_entity: tuple[str, UUID] | None = None  # ("bill", entity_id)
    # The engine sets this after executing; modules read it in subsequent writes.
    response: dict[str, Any] | None = None


@dataclass
class Document:
    """A source document the engine should upload to Storage."""
    entity_type: str                    # "receipt", "invoice", "bill"
    body: bytes
    filename: str
    mime_type: str = "application/pdf"
    entity_id: UUID | str | None = None
    # Engine sets after upload — modules can include this in their reply if needed.
    signed_url: str | None = None


@dataclass
class ModuleResult:
    """What every stateless module returns to the engine."""
    reply_to_user: str
    zoho_writes: list[ZohoWrite] = field(default_factory=list)
    documents: list[Document] = field(default_factory=list)
    extra_events: list[dict[str, Any]] = field(default_factory=list)
    entity_kind: str | None = None      # "transaction", "bill", "invoice", "payment"
    entity_id: UUID | str | None = None


# ---------------------------------------------------------------------------
# ZohoResolver — engine-provided helper for multi-step Zoho operations
# (lookups + create-if-missing for contacts) that can't be expressed as a
# single declarative ZohoWrite. The resolver shares the request's ZohoClient.
# ---------------------------------------------------------------------------

class ZohoResolver:
    def __init__(self, engine: "Engine", cfg: "ClientConfig", zoho_client: "ZohoClient"):
        self._engine = engine
        self._cfg = cfg
        self._zoho = zoho_client

    async def resolve_vendor(self, name: str, trn: str | None = None) -> str | None:
        """Find an existing VENDOR-typed contact in Zoho or create one.
        Returns the Zoho contact_id or None on failure."""
        try:
            matches = await self._zoho.search_contacts(name)
            vendors = [c for c in matches if c.get("contact_type") == "vendor"]
            # Prefer an exact name match
            for c in vendors:
                if (c.get("contact_name") or "").lower() == name.lower():
                    await record_event(
                        self._cfg.id,
                        event_type="vendor_resolved",
                        payload={"name": name, "method": "exact_match"},
                        api_calls=1,
                        api_domain=self._cfg.api_domain,
                    )
                    return c.get("contact_id")
            if vendors:
                await record_event(
                    self._cfg.id,
                    event_type="vendor_resolved",
                    payload={"name": name, "method": "fuzzy_match"},
                    api_calls=1,
                    api_domain=self._cfg.api_domain,
                )
                return vendors[0].get("contact_id")
            # Create fresh
            payload = {
                "contact_name": name,
                "company_name": name,
                "contact_type": "vendor",
                "currency_code": "AED",
            }
            if trn:
                payload["tax_reg_no"] = trn
            resp = await self._zoho.create_entity("contacts", payload)
            contact_id = (resp.get("contact") or {}).get("contact_id")
            await record_event(
                self._cfg.id,
                event_type="vendor_created",
                payload={"name": name, "trn": trn, "contact_id": contact_id},
                api_calls=2,                # search + create
                api_domain=self._cfg.api_domain,
            )
            return contact_id
        except Exception as exc:
            await record_event(
                self._cfg.id,
                event_type="vendor_resolve_failed",
                payload={"name": name, "error": str(exc)[:500]},
                api_calls=1,
                api_domain=self._cfg.api_domain,
            )
            raise

    async def mark_invoice_sent(self, invoice_id: str) -> None:
        """Transition a draft invoice → sent. Required before its customer-facing
        invoice_url + downloadable PDF become accessible."""
        try:
            await self._zoho._request("POST", f"invoices/{invoice_id}/status/sent")
            await record_event(
                self._cfg.id,
                event_type="invoice_marked_sent",
                payload={"zoho_invoice_id": invoice_id},
                api_calls=1, api_domain=self._cfg.api_domain,
            )
        except Exception as exc:
            await record_event(
                self._cfg.id,
                event_type="invoice_mark_sent_failed",
                payload={"zoho_invoice_id": invoice_id, "error": str(exc)[:500]},
                api_calls=1, api_domain=self._cfg.api_domain,
            )
            raise

    async def download_entity_pdf(self, entity: str, entity_id: str) -> bytes:
        """Fetch a Zoho-rendered PDF (invoice / bill / etc.) as bytes. Records
        the API call for daily-cap accounting."""
        try:
            pdf = await self._zoho.download_pdf(entity, entity_id)
            await record_event(
                self._cfg.id,
                event_type="pdf_downloaded",
                payload={"entity": entity, "entity_id": entity_id, "bytes": len(pdf)},
                api_calls=1, api_domain=self._cfg.api_domain,
            )
            return pdf
        except Exception as exc:
            await record_event(
                self._cfg.id,
                event_type="pdf_download_failed",
                payload={"entity": entity, "entity_id": entity_id, "error": str(exc)[:500]},
                api_calls=1, api_domain=self._cfg.api_domain,
            )
            raise

    async def resolve_customer(self, name: str) -> str | None:
        """Find an existing CUSTOMER-typed contact or create one. Returns contact_id."""
        try:
            matches = await self._zoho.search_contacts(name)
            customers = [c for c in matches if c.get("contact_type") != "vendor"]
            for c in customers:
                if (c.get("contact_name") or "").lower() == name.lower():
                    await record_event(
                        self._cfg.id,
                        event_type="customer_resolved",
                        payload={"name": name, "method": "exact_match"},
                        api_calls=1, api_domain=self._cfg.api_domain,
                    )
                    return c.get("contact_id")
            if customers:
                await record_event(
                    self._cfg.id,
                    event_type="customer_resolved",
                    payload={"name": name, "method": "fuzzy_match"},
                    api_calls=1, api_domain=self._cfg.api_domain,
                )
                return customers[0].get("contact_id")
            resp = await self._zoho.create_entity(
                "contacts", {"contact_name": name, "contact_type": "customer"}
            )
            contact_id = (resp.get("contact") or {}).get("contact_id")
            await record_event(
                self._cfg.id,
                event_type="customer_created",
                payload={"name": name, "contact_id": contact_id},
                api_calls=2, api_domain=self._cfg.api_domain,
            )
            return contact_id
        except Exception as exc:
            await record_event(
                self._cfg.id,
                event_type="customer_resolve_failed",
                payload={"name": name, "error": str(exc)[:500]},
                api_calls=1, api_domain=self._cfg.api_domain,
            )
            raise


@dataclass
class OrchContext:
    """What the engine passes to modules. cfg is read-only client state;
    resolver is None when no Zoho credentials are configured."""
    cfg: "ClientConfig"
    resolver: ZohoResolver | None


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class Engine:
    """The orchestration entry point.

    Lifecycle of one request:
      1. load_client_config(client_id)
      2. Check daily API cap → reject early if exceeded
      3. Call the module function (passed in) with (input, config)
      4. Execute ModuleResult.zoho_writes one by one via ZohoClient,
         binding ids back to entities + recording audit events
      5. Upload Documents to Storage
      6. Append a row to the per-client Google Sheet (best-effort)
      7. Persist refreshed tokens if creds.refreshed
      8. Return reply_to_user to the caller (router)
    """

    def __init__(self) -> None:
        pass

    async def _credentials_from(self, cfg: ClientConfig) -> ClientCredentials | None:
        if not (cfg.zoho_organization_id and cfg.zoho_access_token and cfg.zoho_refresh_token):
            return None
        return ClientCredentials(
            client_id=cfg.id,
            organization_id=cfg.zoho_organization_id,
            api_domain=cfg.api_domain,
            access_token=cfg.zoho_access_token,
            refresh_token=cfg.zoho_refresh_token,
            token_expires_at=cfg.zoho_token_expires_at,
        )

    async def _persist_refreshed_tokens(self, creds: ClientCredentials) -> None:
        if not creds.refreshed:
            return
        db = await get_db()
        update: dict[str, Any] = {
            "zoho_access_token": creds.access_token,
            "zoho_refresh_token": creds.refresh_token,
            "api_domain": creds.api_domain,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        if creds.token_expires_at:
            update["zoho_token_expires_at"] = creds.token_expires_at.isoformat()
        await (
            db.table("clients").update(update).eq("id", str(creds.client_id)).execute()
        )
        await record_event(
            creds.client_id,
            event_type="zoho_token_refreshed",
            api_calls=1,           # the refresh call itself
            api_domain=creds.api_domain,
        )

    async def _check_daily_cap(self, cfg: ClientConfig) -> bool:
        used = await daily_api_call_count(cfg.id)
        cap = DAILY_API_CAP_DEFAULT
        if used >= cap:
            await record_event(
                cfg.id,
                event_type="daily_cap_reached",
                payload={"used": used, "cap": cap},
            )
            return False
        return True

    async def execute(
        self,
        result: ModuleResult,
        cfg: ClientConfig,
        _existing_zoho: "ZohoClient | None" = None,
    ) -> ModuleResult:
        """Run a ModuleResult: zoho writes + document uploads + audit + sheet.

        Modules construct the ModuleResult purely from input + config; this
        method is the only place the rest of the world is touched. Returns
        the same result with response/signed_url fields populated."""
        # 1) Documents first (Layer 1)
        for doc in result.documents:
            try:
                doc.signed_url = await store_document(
                    cfg.id,
                    doc.entity_type,
                    doc.body,
                    doc.filename,
                    entity_id=doc.entity_id,
                    mime_type=doc.mime_type,
                )
            except Exception as e:
                logger.exception("Document upload failed: %s", doc.filename)
                await record_event(
                    cfg.id,
                    event_type="document_store_failed",
                    payload={"filename": doc.filename, "error": str(e)},
                )

        # 2) Extra events — record FIRST so classification/routing decisions
        # are always captured, even if Zoho is down or rate-limited.
        for ev in result.extra_events:
            payload = {**ev, "entity_id": result.entity_id}
            payload.setdefault("entity_type", result.entity_kind)
            await record_event(cfg.id, **payload)

        # 3) Zoho writes (Layer 2 + 3)
        if result.zoho_writes:
            # Reuse the request's existing client if process() created one.
            zoho_ctx_manager = None
            if _existing_zoho is not None:
                zoho = _existing_zoho
                creds = zoho.creds
            else:
                creds = await self._credentials_from(cfg)
                if creds is None:
                    await record_event(
                        cfg.id,
                        event_type="zoho_skipped_no_credentials",
                        payload={"writes_skipped": len(result.zoho_writes)},
                    )
                    creds = None
            if creds is None:
                # nothing to do
                pass
            else:
                if not await self._check_daily_cap(cfg):
                    result.reply_to_user = (
                        "⚠️ Your Zoho daily API limit is reached. "
                        "Your records are saved — they'll sync once the cap resets at midnight."
                    )
                    return result

                # Acquire client if not already provided
                if _existing_zoho is None:
                    zoho = ZohoClient(creds)
                    await zoho.__aenter__()
                try:
                    for w in result.zoho_writes:
                        try:
                            # Debug log the exact payload going to Zoho — lets us
                            # diagnose RCM/currency/account_id mismatches without
                            # round-tripping through the WhatsApp surface.
                            import json as _json
                            logger.info(
                                "ZOHO %s /%s payload=%s params=%s",
                                w.method, w.endpoint,
                                _json.dumps(w.payload or {}, default=str),
                                _json.dumps(w.params or {}),
                            )
                            if w.method == "GET":
                                w.response = await zoho._request(
                                    "GET", w.endpoint, params=w.params
                                )
                            elif w.method == "POST":
                                w.response = await zoho.create_entity(
                                    w.endpoint, w.payload or {}, params=w.params
                                )
                            elif w.method == "PUT":
                                head, _, ident = w.endpoint.partition("/")
                                w.response = await zoho.update_entity(
                                    head, ident, w.payload or {}
                                )
                            elif w.method == "DELETE":
                                head, _, ident = w.endpoint.partition("/")
                                w.response = await zoho.delete_entity(head, ident)
                            await record_event(
                                cfg.id,
                                event_type="zoho_write_succeeded",
                                payload={"endpoint": w.endpoint, "method": w.method},
                                api_calls=1,
                                api_domain=creds.api_domain,
                            )
                            if w.bind_to_entity and w.response:
                                ent_kind, ent_id = w.bind_to_entity
                                head, _, _ = w.endpoint.partition("/")
                                singular = head.rstrip("s")
                                inner = w.response.get(singular) or {}
                                zoho_id = (
                                    inner.get(f"{singular}_id")
                                    or inner.get("id")
                                    or ""
                                )
                                if zoho_id:
                                    await link_zoho_entity(
                                        cfg.id, ent_kind, ent_id, singular, str(zoho_id),
                                    )
                        except ZohoError as ze:
                            await record_event(
                                cfg.id,
                                event_type="api_error",
                                payload={"endpoint": w.endpoint, "method": w.method},
                                error_code=str(ze.code or ze.status or ""),
                                error_message=ze.body or str(ze),
                                api_calls=1,
                                api_domain=ze.api_domain,
                            )
                            logger.warning(
                                "Zoho write failed (will continue): %s %s — %s",
                                w.method, w.endpoint, ze,
                            )
                            result.reply_to_user += (
                                f"\n⚠️ Zoho post failed: {ze.code or ze.status} — saved locally for retry."
                            )
                        except Exception as exc:
                            # DNS / connection / timeout — log + continue, don't
                            # crash the agent flow. The local entity is already
                            # written; the categorizer or a manual retry can sync.
                            await record_event(
                                cfg.id,
                                event_type="api_error",
                                payload={"endpoint": w.endpoint, "method": w.method,
                                         "kind": type(exc).__name__},
                                error_message=str(exc)[:1500],
                                api_calls=0,
                                api_domain=creds.api_domain,
                            )
                            logger.exception(
                                "Non-Zoho exception during write: %s %s",
                                w.method, w.endpoint,
                            )
                            result.reply_to_user += (
                                "\n⚠️ Couldn't reach Zoho right now — saved locally; "
                                "the next sync will pick it up."
                            )
                finally:
                    if _existing_zoho is None:
                        await zoho.__aexit__(None, None, None)
                        await self._persist_refreshed_tokens(creds)

        # 4) Google Sheets row (Layer 4)
        if cfg.google_sheet_id and result.entity_kind:
            from orchestrator.audit import append_to_sheet
            await append_to_sheet(
                cfg.id,
                cfg.google_sheet_id,
                {
                    "entity_kind": result.entity_kind,
                    "entity_id": str(result.entity_id) if result.entity_id else None,
                    "reply": result.reply_to_user[:200],
                    "at": datetime.now(timezone.utc).isoformat(),
                },
            )

        return result


# Singleton — cheap, no state of its own.
engine = Engine()


# ---------------------------------------------------------------------------
# Convenience: thin pass-through process() the router can call
# ---------------------------------------------------------------------------

async def process(
    client_id: UUID,
    handler,            # async fn(input, ctx_or_cfg) -> ModuleResult
    handler_input: Any,
) -> ModuleResult:
    """Run a handler through the orchestration pipeline.

    Handler may have either signature:
      async def handler(input, cfg)        — legacy
      async def handler(input, ctx)        — preferred (ctx has .cfg + .resolver)
    """
    import inspect

    cfg = await load_client_config(client_id)
    creds = await engine._credentials_from(cfg)

    # Create a single ZohoClient for the whole request (if creds exist) so
    # resolvers and declarative writes share one connection + token state.
    zoho_client = None
    resolver = None
    if creds:
        zoho_client = ZohoClient(creds)
        await zoho_client.__aenter__()
        resolver = ZohoResolver(engine, cfg, zoho_client)

    try:
        ctx = OrchContext(cfg=cfg, resolver=resolver)
        # Dispatch on signature: legacy handlers take cfg, new ones take ctx.
        sig = inspect.signature(handler)
        if "ctx" in sig.parameters or len(sig.parameters) >= 2 and "cfg" not in sig.parameters:
            result = await handler(handler_input, ctx)
        else:
            result = await handler(handler_input, cfg)
        return await engine.execute(result, cfg, _existing_zoho=zoho_client)
    finally:
        if zoho_client:
            await zoho_client.__aexit__(None, None, None)
            if creds and creds.refreshed:
                await engine._persist_refreshed_tokens(creds)
