-- Migration 0006: vat_filings — CB's record of authorized VAT 201 filings.
--
-- Zoho is the system of record for the actual EmaraTax push. CB is the
-- system of record for *what the user consented to and when*. The
-- disclosures detector uses this table to find post-filing corrections.

create table if not exists vat_filings (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,

    period_label text,                       -- e.g. "2026-Q1", "2026-04"
    from_date date not null,
    to_date date not null,

    -- Snapshot of the totals the user reviewed and authorized.
    -- Shape: {output_vat, input_vat, adjustments, net_payable, net_refundable}
    totals jsonb not null default '{}'::jsonb,

    -- True when user typed "FILE ANYWAY" to bypass CB warnings.
    override_used boolean not null default false,

    -- Deep link to the Zoho UI page where the actual EmaraTax push happens.
    zoho_deep_link text,

    -- Zoho's vat_return_id, if/when Zoho exposes a programmatic submit API
    -- and we can capture it. Optional today.
    zoho_vat_return_id text,

    filed_at timestamptz not null default now(),
    created_at timestamptz not null default now()
);

create index if not exists vat_filings_client_period_idx
    on vat_filings (client_id, to_date desc);
