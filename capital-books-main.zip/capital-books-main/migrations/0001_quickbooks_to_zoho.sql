-- One-time migration: rename QuickBooks columns → Zoho Books equivalents.
-- Safe to run on the empty Supabase you just created. Idempotent guards included.

-- clients
alter table clients rename column qb_realm_id to zoho_organization_id;
alter table clients rename column qb_access_token to zoho_access_token;
alter table clients rename column qb_refresh_token to zoho_refresh_token;
alter table clients rename column qb_token_expires_at to zoho_token_expires_at;
alter table clients add column if not exists zoho_tax_ids jsonb not null default '{}'::jsonb;

-- transactions
alter table transactions rename column qb_entity_type to zoho_entity_type;
alter table transactions rename column qb_entity_id to zoho_entity_id;
alter table transactions drop column if exists qb_sync_token;

-- invoices
alter table invoices rename column qb_invoice_id to zoho_invoice_id;
