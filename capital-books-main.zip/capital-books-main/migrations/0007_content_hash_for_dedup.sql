-- Migration 0007: content_hash for duplicate detection.
--
-- SHA-256 hex of the source bytes for receipts/bills/invoices. Lets us
-- catch resends of the same image; the value-tuple (vendor, amount, date)
-- check in transactions/dedup.py covers the text-claim case.

alter table transactions add column if not exists content_hash text;
alter table bills        add column if not exists content_hash text;
alter table invoices     add column if not exists content_hash text;

create index if not exists transactions_dedup_idx
    on transactions (client_id, content_hash)
    where content_hash is not null;

create index if not exists bills_dedup_idx
    on bills (client_id, content_hash)
    where content_hash is not null;

create index if not exists invoices_dedup_idx
    on invoices (client_id, content_hash)
    where content_hash is not null;
