-- Migration 0008: client_cards — per-card payment-method registry.
--
-- Replaces the clients.card_mapping JSONB over time. We keep reading the
-- JSONB as a fallback so existing data keeps working; new cards land in
-- this table, with one row per (client_id, last_four).

create table if not exists client_cards (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,

    last_four text not null check (length(last_four) = 4),
    label text not null,                       -- e.g. "Company Visa", "Neil personal Mastercard"
    zoho_account_id text,                      -- Zoho paid_through_account_id
    brand text,                                -- optional: visa / mastercard / amex / etc

    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),

    unique (client_id, last_four)
);

create index if not exists client_cards_client_idx on client_cards (client_id);
