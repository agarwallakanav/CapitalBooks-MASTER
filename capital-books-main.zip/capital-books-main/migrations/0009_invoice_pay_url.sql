-- Migration 0009: store the full Stripe checkout URL on the invoice row so the
-- short /pay/<invoice_number> redirect endpoint can resolve it without a Stripe API call.

alter table invoices add column if not exists stripe_checkout_url text;

create index if not exists invoices_pay_lookup_idx
    on invoices (client_id, invoice_number)
    where stripe_checkout_url is not null;
