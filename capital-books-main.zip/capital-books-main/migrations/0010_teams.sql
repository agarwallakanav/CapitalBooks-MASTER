-- Migration 0010: teams + roles + real-time activity notifications.

create table if not exists teams (
    id uuid primary key default gen_random_uuid(),
    name text not null,
    created_at timestamptz not null default now()
);

create table if not exists team_members (
    id uuid primary key default gen_random_uuid(),
    team_id uuid not null references teams (id) on delete cascade,
    client_id uuid not null references clients (id) on delete cascade,
    role text not null check (role in ('owner', 'finance', 'employee')),
    created_at timestamptz not null default now(),
    unique (team_id, client_id)
);

alter table clients add column if not exists team_id uuid references teams (id);
create index if not exists clients_team_idx on clients (team_id);
create index if not exists team_members_team_role_idx on team_members (team_id, role);
