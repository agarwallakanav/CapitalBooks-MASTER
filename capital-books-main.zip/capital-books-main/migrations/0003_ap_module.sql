-- Migration 0003: Accounts Payable module.

-- Per-client AP approval gate (separate from the AR approval_amount_limit so
-- you can be stricter on outgoing money than on logging incoming work).
alter table clients
    add column if not exists approval_threshold numeric(15, 2) not null default 5000.00;

-- Vendor bills. Mirrors the transactions table for VAT but adds AP-specific
-- fields: due_date, scheduled_payment_date, and a richer status enum.
create table if not exists bills (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,

    vendor text not null,
    vendor_trn text,
    bill_number text,            -- the supplier's invoice number
    description text,

    -- Amounts (gross is what's on the bill; net excludes VAT)
    amount numeric(15, 2) not null,
    net_amount numeric(15, 2),
    vat_amount numeric(15, 2) not null default 0,
    currency text not null default 'AED',
    fx_rate numeric(15, 6) not null default 1.0,

    -- VAT
    vat_type text check (vat_type in
        ('standard', 'zero', 'exempt', 'reverse_charge', 'out_of_scope')),
    vat_boxes int[] not null default '{}',
    is_blocked_vat boolean not null default false,

    -- AP dates
    bill_date date,
    due_date date,
    scheduled_payment_date date,
    paid_date date,

    -- Status / routing
    status text not null check (status in
        ('unpaid', 'scheduled', 'paid', 'overdue', 'needs_approval', 'rejected', 'failed')),
    confidence_score int check (confidence_score between 0 and 100),
    routing_reason text,

    -- External linkage
    zoho_bill_id text,
    zoho_vendor_id text,         -- resolved at create time
    source_document_url text,
    raw_payload jsonb not null default '{}'::jsonb,

    deleted boolean not null default false,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create index if not exists bills_active_idx
    on bills (client_id, created_at desc) where deleted = false;

create index if not exists bills_due_idx
    on bills (due_date)
    where status in ('unpaid', 'scheduled', 'overdue');

create index if not exists bills_needs_approval_idx
    on bills (client_id, created_at desc)
    where status = 'needs_approval';
