-- Migration 0002: support EDIT/DELETE on transactions + receipt PDFs after payment.

-- Soft-delete flag on transactions
alter table transactions
    add column if not exists deleted boolean not null default false;

create index if not exists transactions_active_idx
    on transactions (client_id, created_at desc)
    where deleted = false;

-- Receipt artifacts on invoices
alter table invoices
    add column if not exists receipt_number text;
alter table invoices
    add column if not exists receipt_url text;

-- One receipt per client/number
do $$
begin
    if not exists (
        select 1 from pg_constraint where conname = 'invoices_client_receipt_unique'
    ) then
        alter table invoices
            add constraint invoices_client_receipt_unique
            unique (client_id, receipt_number);
    end if;
end$$;
