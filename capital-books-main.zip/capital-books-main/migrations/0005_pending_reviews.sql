-- Migration 0005: pending_reviews table for the hold / block confidence actions.

create table if not exists pending_reviews (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,

    -- Source: the extracted JSON + (if image) reference to the stored document
    source_kind text not null check (source_kind in ('text', 'image')),
    source_text text,
    source_document_key text,
    source_document_url text,

    -- Extraction output (the per-field {value, confidence} payload)
    extracted jsonb not null default '{}'::jsonb,

    -- Confidence + payment-cascade outcomes
    flags jsonb not null default '[]'::jsonb,
    resolved_fields jsonb not null default '{}'::jsonb,

    -- Workflow
    action text not null check (action in ('post', 'flag', 'hold', 'block')),
    status text not null default 'awaiting_user' check (status in
        ('awaiting_user', 'resolved', 'discarded')),

    -- Zoho linkage when resolved
    zoho_entity_type text,
    zoho_entity_id text,

    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create index if not exists pending_reviews_open_idx
    on pending_reviews (client_id, created_at desc)
    where status = 'awaiting_user';
