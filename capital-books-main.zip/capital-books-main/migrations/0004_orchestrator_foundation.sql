-- Migration 0004: orchestrator foundation.
-- Adds:
--   1. transaction_events  — append-only audit log; only the orchestrator writes here.
--   2. clients.api_domain  — per-client Zoho regional API base (returned in token response).
--   3. clients.card_mapping — JSONB map from card-last-4 → expense account/method.
--   4. clients.google_sheet_id — per-client audit-log Sheet.
--   5. clients.default_payment_account — fallback paid_through when card_mapping miss.

alter table clients
    add column if not exists api_domain text not null default 'www.zohoapis.com';
alter table clients
    add column if not exists card_mapping jsonb not null default '{}'::jsonb;
alter table clients
    add column if not exists google_sheet_id text;
alter table clients
    add column if not exists default_payment_account text;

-- =========================================================================
-- transaction_events: every state change a transaction/bill/invoice goes through
-- =========================================================================
create table if not exists transaction_events (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references clients (id) on delete cascade,

    -- The CB id of the entity being tracked (transactions.id / bills.id / invoices.id).
    -- Nullable: pre-creation events ("ocr_failed") have no entity yet.
    entity_type text check (entity_type in
        ('transaction', 'bill', 'invoice', 'payment', 'receipt')),
    entity_id uuid,

    -- Lifecycle event:
    --   extracted, classified, flagged_for_review, posted_to_zoho, post_failed,
    --   user_confirmed, user_rejected, user_edited, user_deleted, payment_recorded,
    --   receipt_issued, rule_promoted, api_error, rate_limited
    event_type text not null,

    actor text not null default 'orchestrator',     -- 'orchestrator', 'user', 'categorizer', 'scheduler'
    payload jsonb not null default '{}'::jsonb,     -- arbitrary structured detail

    -- Zoho linkage (Layer 3 of the audit trail)
    zoho_entity_type text,
    zoho_entity_id text,

    -- API-call accounting
    api_calls int not null default 0,                -- Zoho calls this event consumed
    api_domain text,                                 -- which regional Zoho host

    -- Error details when event_type = api_error / post_failed
    error_code text,
    error_message text,

    created_at timestamptz not null default now()
);

create index if not exists txn_events_client_time_idx
    on transaction_events (client_id, created_at desc);
create index if not exists txn_events_entity_idx
    on transaction_events (entity_type, entity_id);
create index if not exists txn_events_api_calls_idx
    on transaction_events (client_id, created_at)
    where api_calls > 0;
