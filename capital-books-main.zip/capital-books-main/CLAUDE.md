# CapitalBooks — AI-Powered Bookkeeping Automation for UAE SMEs

## What this project is
A Python FastAPI application that automates bookkeeping for UAE small businesses via WhatsApp. It sits on top of Zoho Books and handles transaction capture, VAT compliance, categorization, invoicing, and financial reporting — all through WhatsApp messages.

## Architecture overview
Single Python app (FastAPI) replacing 5 separate CodeWords bots. Multi-tenant: one app serves all clients, with per-client config stored in Supabase (PostgreSQL). Deployed on Railway.

### Tech stack
- **Framework:** FastAPI (Python)
- **Database:** Supabase (PostgreSQL) — client configs, transactions, rules, invoices
- **Cache:** Redis (Upstash) — report caching, temporary state
- **Accounting:** Zoho Books API (direct via httpx). Per-client OAuth tokens stored in Supabase; app-level OAuth client credentials in env. Region-aware base URL (`zohoapis.com` / `.eu` / `.in` / `.com.au`).
- **AI:** Anthropic Claude API (intent classification, transaction categorization, VAT classification)
- **WhatsApp:** WhatsApp Business API (webhook receiver + message sender)
- **Payments:** Stripe (invoice payment links, webhooks)
- **PDF generation:** ReportLab + arabic_reshaper + python-bidi (bilingual Arabic/English)
- **Email:** Gmail SMTP
- **File storage:** AWS S3 or CodeWords S3 (receipts, invoice PDFs, receipt PDFs)
- **Deployment:** Railway

## Project structure
```
capitalbooks/
├── main.py                  # FastAPI app entry point
├── config.py                # Environment variables and settings
├── database.py              # Supabase/PostgreSQL connection
├── redis_client.py          # Redis connection for caching
├── router/
│   ├── __init__.py
│   ├── intent.py            # AI intent classification
│   └── handler.py           # WhatsApp webhook + routing logic
├── transactions/
│   ├── __init__.py
│   ├── pipeline.py          # Main 12-step transaction pipeline
│   ├── trn_validation.py    # TRN format validation
│   ├── vat_classifier.py    # AI VAT classification (standard/zero/exempt/RC)
│   ├── reverse_charge.py    # Foreign supplier detection → Box 4+11
│   ├── blocked_vat.py       # Entertainment, motor, residential blocking
│   ├── vat_arithmetic.py    # Net/VAT/gross, FX conversion, banker rounding
│   ├── box_mapping.py       # VAT 201 box assignment (1-4, 9-11)
│   ├── tax_point.py         # Accrual vs realisation basis
│   └── routing_decision.py  # AUTO_POST / HUMAN_REVIEW / HOLD_UNTIL_PAID
├── categorizer/
│   ├── __init__.py
│   ├── scheduler.py         # APScheduler: runs every 30 min
│   ├── classifier.py        # Batch AI classification
│   └── rules_engine.py      # Per-client vendor → category rules
├── reports/
│   ├── __init__.py
│   ├── generator.py         # P&L, balance sheet, trial balance, VAT summary
│   └── cache.py             # Redis caching with 5-min TTL
├── ap/
│   ├── __init__.py
│   ├── bills.py             # Vendor bill ingestion (text + image) + approval workflow
│   ├── payments.py          # Pay or schedule a vendor bill (Zoho VendorPayment)
│   ├── reminders.py         # Daily APScheduler sweep: upcoming + overdue bill alerts
│   └── aging.py             # AP aging report (current / 1-30 / 31-60 / 61-90 / 90+)
├── ar/
│   ├── __init__.py
│   ├── invoice.py           # Create Zoho invoice + generate PDF + Stripe link
│   ├── receipt.py           # Generate receipt PDF after payment
│   ├── overdue.py           # Check overdue invoices (due within 3 days)
│   ├── aging.py             # AR aging report (current, 1-30, 31-60, 61-90, 90+)
│   ├── webhook.py           # Stripe payment webhook handler
│   └── templates/           # Invoice + receipt PDF templates
├── zoho/
│   ├── __init__.py
│   ├── auth.py              # Zoho OAuth refresh-token flow + persist tokens
│   ├── client.py            # ZohoBooksClient (httpx) with per-client org_id + auto-retry on 401
│   └── entities.py          # Expense, Bill, Invoice, BankTransaction, Journal payload builders
├── whatsapp/
│   ├── __init__.py
│   ├── webhook.py           # Receive incoming messages
│   └── sender.py            # Send replies, PDFs, payment links
├── requirements.txt
├── .env                     # Environment variables (never commit)
└── CLAUDE.md                # This file
```

## Module 1: Router (WhatsApp + Intent Classification)

### How it works
1. WhatsApp Business API sends incoming messages to POST /webhook/whatsapp
2. App extracts sender phone number and message content
3. Phone number is looked up in Supabase `clients` table to identify the client
4. Claude API classifies the intent using a fast model
5. Message is routed to the correct module

### Intent categories
- TRANSACTION — paid receipt photo or description ("here's a receipt for AED 500")
- BILL — vendor bill not yet paid ("bill from XYZ 8400 AED due in 14 days")
- PAY_BILL — pay or schedule a previously-recorded bill ("pay bill to Etisalat", "schedule payment to XYZ Thursday")
- APPROVE / REJECT — approve or reject a pending bill flagged for human review
- CONFIRM — user confirms a pending transaction ("yes", "correct")
- CORRECT — user corrects a categorization ("no, that's office supplies")
- EDIT — modify a posted transaction ("edit that last entry")
- DELETE — remove a transaction ("delete that")
- INVOICE — create an invoice ("invoice ABC Corp for AED 5000 for consulting")
- REPORT — financial report request ("show P&L for this month", "balance sheet")
- OVERDUE — AR: check overdue invoices ("show overdue invoices", "who owes us")
- AGING — AR aging report ("aging report")
- AP_OVERDUE — bills past due ("overdue bills", "what bills are overdue")
- AP_AGING — AP aging report ("AP aging", "bills aging")
- GREETING — general chat ("hi", "hello")

## Module 2: Transactions / VAT Engine (PRIORITY — build first)

### The 12-step pipeline
This is the core of the system. Each step is a Python function. Steps that don't depend on each other run in parallel using asyncio.gather().

1. **Load client config** — Pull from Supabase: vat_basis, entity_type, supply_mix, foreign_suppliers list
2. **TRN validation** — Check vendor TRN: must be 15 digits, must start with "100", presence check on document
3. **VAT classification** — Claude AI classifies: standard (5%), zero-rated, exempt, or reverse charge. Use fast model.
4. **Reverse charge detection** — If vendor is in foreign_suppliers list or AI detects foreign supplier → map to VAT 201 Box 4 + Box 11
5. **Blocked input VAT** — Check if expense category is non-claimable per UAE FTA rules:
   - Entertainment expenses → VAT blocked
   - Motor vehicle expenses → VAT blocked  
   - Personal/residential expenses → VAT blocked
6. **VAT arithmetic** — Calculate net/VAT/gross amounts. Handle FX conversion for foreign currency invoices. Use banker's rounding (round half to even).
7. **Box mapping** — Assign to correct VAT 201 return boxes:
   - Box 1: Standard rated supplies (output VAT)
   - Box 2: Tax refunds for tourists
   - Box 3: Zero-rated supplies
   - Box 4: Exempt supplies
   - Box 9: Standard rated expenses (input VAT)
   - Box 10: Expenses related to exempt/non-taxable supplies
   - Box 11: Reverse charge (also in Box 4)
   - Auto-sum boxes
8. **Tax point** — Determine tax point date based on client's VAT basis:
   - Accrual basis: earlier of invoice date or payment date
   - Realisation basis: payment date only
9. **Routing decision** — Based on confidence score:
   - 95-100%: AUTO_POST (post directly to Zoho Books)
   - 70-94%: HUMAN_REVIEW (flag for review, send WhatsApp asking for confirmation)
   - Below 70%: require manual categorization
   - Also HOLD_UNTIL_PAID for realisation basis clients
10. **Zoho Books post** — Create entry via direct API (httpx) using per-client `zoho_tax_ids` (UAE VAT tax IDs configured in the client's Zoho org for standard / zero / exempt / reverse_charge). Auth header is `Zoho-oauthtoken <access_token>` and every request requires `?organization_id=...`.
11. **Supabase log** — Save transaction record with all VAT details, confidence score, box mapping, and source document reference.

### Parallel execution opportunities
- Steps 2 (TRN validation) and 3 (VAT classification) can run in parallel — TRN is a format check, doesn't depend on VAT type
- Steps 4 (reverse charge) and 5 (blocked VAT) can run in parallel after step 3
- Steps 7 (box mapping) and 8 (tax point) can run in parallel after step 6

### Confidence scoring
- Exact vendor match in rules table: 95-100%
- AI classification with high certainty: 80-94%
- AI classification with low certainty or unknown vendor: below 70%
- When human corrects, save the correction as a new rule in the rules table

## Module 3: Reports

### How it works
1. Parse time filter from natural language ("today", "this week", "this month", "last month")
2. Check Redis cache (5-minute TTL, keyed by client_id + report_type + time_period)
3. If cache miss: query Zoho Books `/reports/{name}` directly via httpx. Fire multiple Zoho queries in parallel using asyncio.gather()
4. Process and format the response
5. Cache the results in Redis
6. Use Claude API (fast model) to format into a WhatsApp-friendly message
7. Return formatted text to the router

### Report types
- P&L (Profit & Loss) statement
- Balance sheet
- Trial balance
- VAT summary (input VAT, output VAT, net payable)
- Cash summary

## Module 4: Categorizer

### How it works
1. APScheduler runs every 30 minutes
2. Pull list of all active clients from Supabase
3. For each client: load their Zoho credentials and categorization rules
4. Query uncategorized entries from their Zoho Books (Expense, Bill, Invoice, BankTransaction) — filtered locally for missing `account_id`
5. Batch classify: send 10-20 transactions in ONE Claude API prompt (not one-by-one)
6. Update Zoho Books with categories via PUT (Zoho doesn't use SyncToken — full or partial replace)
7. Save results to Supabase transactions table
8. Update rules table with any new patterns learned

## Module 5: Accounts Receivable

### Invoice creation flow
1. Fuzzy-match customer name in Zoho Books contacts (or auto-create if no match)
2. Pull customer phone/email from the Zoho contact
3. Create invoice in Zoho Books via direct API
4. Generate bilingual PDF (Arabic/English) using ReportLab + arabic_reshaper + python-bidi
   - Colors: navy (#1a2332), green (#4CAF50), gold/amber highlights
   - Template includes: company header, BILL TO section, line items, VAT calculation, bank details, TRN validation box, AI confidence badge
5. Upload PDF to S3
6. Create Stripe Checkout Session (AED currency, invoice metadata)
7. Return: PDF URL + payment link + WhatsApp message

### Payment confirmation flow (Stripe webhook)
1. POST /webhook/stripe receives checkout.session.completed event
2. Mark invoice as paid in Zoho Books by creating a `CustomerPayment` linked to the invoice
3. Generate receipt PDF (matching receipt template, bilingual)
4. Upload receipt to S3
5. Send WhatsApp notification + email with receipt link

### Other endpoints
- POST /check-overdue — invoices due within 3 days or overdue
- POST /aging-report — group by: current, 1-30, 31-60, 61-90, 90+ days

## Database schema (Supabase)

### clients table
- id, company_name, phone, email, trn, peppol_id
- zoho_organization_id, zoho_access_token, zoho_refresh_token, zoho_token_expires_at
- zoho_tax_ids (JSONB: {"standard": "<uuid>", "zero": "<uuid>", "exempt": "<uuid>", "reverse_charge": "<uuid>"})
- stripe_secret_key
- vat_basis (accrual/realisation), entity_type
- foreign_suppliers (JSON array)
- invoice_template (JSON: logo_url, bank_name, iban, default_payment_terms)
- confidence_threshold (default 95)
- approval_amount_limit (default 5000 AED)
- created_at, updated_at, is_active

### transactions table
- id, client_id (FK), vendor, description, amount, vat_amount, currency
- category, account_code, confidence_score
- vat_type (standard/zero/exempt/reverse_charge)
- vat_box (which VAT 201 box)
- tax_point_date, is_blocked_vat
- status (auto_posted/needs_review/hold_until_paid/manually_categorized)
- zoho_entity_type, zoho_entity_id
- source_document_url
- created_at

### categorization_rules table
- id, client_id (FK), vendor_pattern, category, account_code, times_used, created_at

### invoices table
- id, client_id (FK), invoice_number, customer_name, customer_trn
- amount, vat_amount, total
- status (draft/sent/paid/overdue/cancelled)
- pdf_url, stripe_session_id, stripe_payment_intent
- due_date, paid_date
- created_at

## Zoho Books integration details
- Direct API via httpx
- OAuth2 refresh-token flow with automatic retry on 401
- App-level credentials in env: `ZOHO_CLIENT_ID`, `ZOHO_CLIENT_SECRET`, `ZOHO_REFRESH_TOKEN`, `ZOHO_ORGANIZATION_ID`, `ZOHO_REGION` (com/eu/in/com.au)
- Per-client credentials in Supabase `clients` table: `zoho_organization_id`, `zoho_access_token`, `zoho_refresh_token`, `zoho_token_expires_at`, `zoho_tax_ids`
- Auth header: `Authorization: Zoho-oauthtoken <access_token>` (NOT `Bearer`)
- Every request appends `?organization_id=<id>`
- Base URL: `https://www.zohoapis.com/books/v3/` (and `.eu` / `.in` / `.com.au` variants)
- UAE VAT is configured per-org in Zoho — we resolve logical names (standard / zero / exempt / reverse_charge) → Zoho `tax_id` via `clients.zoho_tax_ids` JSONB
- No SyncToken concept — updates are PUT requests, full or partial body accepted
- Entity types we use: Expense, Bill, Invoice, BankTransaction, Journal, CustomerPayment

## Environment variables needed
```
# Supabase
SUPABASE_URL=
SUPABASE_KEY=

# Redis
REDIS_URL=

# Claude API
ANTHROPIC_API_KEY=

# WhatsApp
WHATSAPP_VERIFY_TOKEN=
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=

# Zoho Books
ZOHO_CLIENT_ID=
ZOHO_CLIENT_SECRET=
ZOHO_REFRESH_TOKEN=
ZOHO_ORGANIZATION_ID=
ZOHO_REGION=com

# Stripe
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=

# Gmail
GMAIL_ADDRESS=
GMAIL_APP_PASSWORD=

# AWS S3
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
S3_BUCKET_NAME=
```

## Important UAE-specific rules
- VAT rate: 5% standard
- TRN format: 15 digits starting with "100"
- Blocked input VAT: entertainment, motor vehicles, personal/residential
- Reverse charge: applies to services from foreign suppliers
- VAT 201 return: boxes 1-4 (output), 9-11 (input)
- Tax invoices require both supplier and customer TRN
- Simplified tax invoices: B2C transactions under AED 10,000
- Document retention: 5 years for VAT, 7 years for corporate tax
- E-invoicing (PINT AE format) mandatory by July 2027 for SMEs

## Module 6: Accounts Payable (AP)

### How it works
1. **Bill ingestion** — user sends a text ("bill from XYZ Trading 8400 AED due in 14 days") or a photo of a supplier invoice. Same Claude OCR/extractor used for expenses; output is a `TransactionInput` with `zoho_entity_type="Bill"` + `due_date`.
2. **VAT pipeline** — bills go through the same 12-step VAT pipeline as expenses (TRN validation, classification, arithmetic, box mapping, tax point, routing).
3. **Approval gate** — if amount > `clients.approval_threshold` (default AED 5000) OR confidence < `confidence_threshold`, the bill is saved with status=`needs_approval` and the user is prompted: "Reply 'approve' to post it to Zoho, or 'reject' to discard."
4. **Zoho post** — on auto-post or approval, we lookup-or-create a Zoho vendor contact (UAE Bills require `vendor_id`, free-text vendor_name is rejected), then create the Bill via `POST /bills` with `tax_treatment` + `place_of_supply` + the resolved `tax_id`.
5. **Payment tracking** — user can later say "pay bill to XYZ" → fuzzy-find the matching unpaid bill → post a `VendorPayment` to Zoho linked to the bill → mark `status=paid`. Or "schedule payment to XYZ for Thursday" → set `scheduled_payment_date`, status=`scheduled` (no Zoho call yet).
6. **Reminders** — daily APScheduler job at 08:00 UAE: sweeps bills due ≤3 days (sends a "upcoming" summary) and bills past due_date (promotes to status=`overdue` + sends an alert).
7. **AP aging** — same bucket structure as AR (current / 1-30 / 31-60 / 61-90 / 90+) with top-3 vendors by exposure.

### Database table
```
bills (
  id uuid, client_id uuid,
  vendor text, vendor_trn text, bill_number text, description text,
  amount numeric, net_amount numeric, vat_amount numeric, currency text, fx_rate numeric,
  vat_type text, vat_boxes int[], is_blocked_vat boolean,
  bill_date date, due_date date, scheduled_payment_date date, paid_date date,
  status text (unpaid/scheduled/paid/overdue/needs_approval/rejected/failed),
  confidence_score int, routing_reason text,
  zoho_bill_id text, zoho_vendor_id text,
  source_document_url text, raw_payload jsonb,
  deleted boolean, created_at, updated_at
)
```

`clients.approval_threshold` (numeric default 5000) controls the auto-post-vs-needs-approval gate for bills.

## Current build priority
Building the Transactions/VAT module first (Module 2). This is the 12-step pipeline that processes receipts and posts to Zoho Books with correct VAT treatment. Need foundation (FastAPI + Supabase + Redis) set up first, then the pipeline.

