import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI

from ar.aging import aging_summary
from ar.overdue import overdue_summary
from ar.webhook import router as stripe_router
from categorizer.scheduler import start_scheduler, stop_scheduler
from config import settings
from database import close_db, get_db
from redis_client import close_redis, get_redis
from whatsapp.webhook import router as whatsapp_router

logging.basicConfig(level=settings.log_level)
logger = logging.getLogger("capitalbooks")


@asynccontextmanager
async def lifespan(app: FastAPI):
    await get_db()
    redis = await get_redis()
    await redis.ping()
    start_scheduler()
    logger.info("CapitalBooks started (env=%s)", settings.app_env)
    try:
        yield
    finally:
        stop_scheduler()
        await close_redis()
        await close_db()
        logger.info("CapitalBooks shutdown complete")


app = FastAPI(
    title="CapitalBooks",
    description="AI-powered bookkeeping automation for UAE SMEs",
    version="0.1.0",
    lifespan=lifespan,
)

app.include_router(whatsapp_router)
app.include_router(stripe_router)

from ar.pay_redirect import router as pay_redirect_router  # noqa: E402
app.include_router(pay_redirect_router)


@app.post("/check-overdue")
async def check_overdue(client_id: str) -> dict:
    from uuid import UUID
    return {"summary": await overdue_summary(UUID(client_id))}


@app.post("/aging-report")
async def aging_report(client_id: str) -> dict:
    from uuid import UUID
    return {"summary": await aging_summary(UUID(client_id))}


@app.get("/")
async def root() -> dict[str, str]:
    return {"service": "capitalbooks", "status": "ok"}


@app.get("/health")
async def health() -> dict[str, str]:
    redis = await get_redis()
    await redis.ping()
    await get_db()
    return {"status": "healthy", "redis": "ok", "supabase": "ok"}
