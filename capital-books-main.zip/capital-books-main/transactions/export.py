"""Excel export for transaction history.

build_workbook(rows, period_label, filter_desc) → bytes

Builds an xlsx with two sheets:
  - Transactions: row-per-txn, totals row, formatting (bold headers, AED
    number format, alternating rows, frozen header, auto-width).
  - Summary: totals + breakdowns by category and payment method.

Returns the workbook as bytes so the caller can upload directly without
touching the filesystem.
"""
from __future__ import annotations

from collections import defaultdict
from io import BytesIO
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

_HEADERS = [
    "Date", "Reference", "Vendor", "Description",
    "Amount (AED)", "VAT", "Gross",
    "Category", "Payment Method", "VAT Type", "Box", "Status",
]

# Colors
_NAVY = "1A2332"
_MINT = "4CAF50"
_ALT_ROW = "F4F6F8"
_AED_FMT = '_-* #,##0.00 [$AED]_-;-* #,##0.00 [$AED]_-'


def _row_from_txn(t: dict[str, Any]) -> list[Any]:
    raw = t.get("raw_payload") or {}
    resolved = raw.get("resolved") or {}
    pay = raw.get("payment_resolution") or {}
    boxes = t.get("vat_boxes") or []
    return [
        t.get("tax_point_date") or "",
        (t.get("zoho_entity_id") or str(t.get("id") or ""))[:24],
        t.get("vendor") or "",
        t.get("description") or "",
        float(t.get("net_amount") or 0),
        float(t.get("vat_amount") or 0),
        float(t.get("amount") or 0),
        resolved.get("category_account_name") or "Uncategorized",
        pay.get("account_name") or "—",
        t.get("vat_type") or "",
        ", ".join(str(b) for b in boxes) if boxes else "",
        t.get("status") or "",
    ]


def _style_transactions_sheet(ws, n_rows: int) -> None:
    # Bold headers + navy bg + white text
    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill("solid", fgColor=_NAVY)
    for col_idx, _ in enumerate(_HEADERS, 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center")

    # AED format for amount columns (E, F, G — indices 5, 6, 7)
    for r in range(2, 2 + n_rows + 1):    # +1 for totals row at the bottom
        for c in (5, 6, 7):
            ws.cell(row=r, column=c).number_format = _AED_FMT

    # Alternating row colors on data rows
    alt_fill = PatternFill("solid", fgColor=_ALT_ROW)
    for r in range(2, 2 + n_rows):
        if r % 2 == 0:
            for c in range(1, len(_HEADERS) + 1):
                ws.cell(row=r, column=c).fill = alt_fill

    # Freeze header
    ws.freeze_panes = "A2"

    # Auto-width — openpyxl doesn't do it natively, so compute from cell text.
    for col_idx in range(1, len(_HEADERS) + 1):
        col_letter = get_column_letter(col_idx)
        max_len = len(_HEADERS[col_idx - 1])
        for r in range(2, 2 + n_rows + 1):
            v = ws.cell(row=r, column=col_idx).value
            if v is None:
                continue
            max_len = max(max_len, len(str(v)))
        ws.column_dimensions[col_letter].width = min(max_len + 3, 50)


def _write_totals_row(ws, row_idx: int, totals: dict[str, float]) -> None:
    total_font = Font(bold=True, color="FFFFFF")
    total_fill = PatternFill("solid", fgColor=_MINT)
    ws.cell(row=row_idx, column=1, value=f"Total ({int(totals['count'])} txns)")
    ws.cell(row=row_idx, column=5, value=totals["net"])
    ws.cell(row=row_idx, column=6, value=totals["vat"])
    ws.cell(row=row_idx, column=7, value=totals["gross"])
    for c in range(1, len(_HEADERS) + 1):
        cell = ws.cell(row=row_idx, column=c)
        cell.font = total_font
        cell.fill = total_fill
    for c in (5, 6, 7):
        ws.cell(row=row_idx, column=c).number_format = _AED_FMT


def _build_summary_sheet(ws, txns: list[dict[str, Any]], totals: dict[str, float]) -> None:
    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill("solid", fgColor=_NAVY)
    section_font = Font(bold=True, size=12, color=_NAVY)

    ws["A1"] = "Summary"
    ws["A1"].font = Font(bold=True, size=14, color=_NAVY)

    ws["A3"] = "Total transactions"
    ws["B3"] = int(totals["count"])
    ws["A4"] = "Total net (AED)"
    ws["B4"] = totals["net"]
    ws["B4"].number_format = _AED_FMT
    ws["A5"] = "Total VAT (AED)"
    ws["B5"] = totals["vat"]
    ws["B5"].number_format = _AED_FMT
    ws["A6"] = "Total gross (AED)"
    ws["B6"] = totals["gross"]
    ws["B6"].number_format = _AED_FMT
    for r in range(3, 7):
        ws.cell(row=r, column=1).font = Font(bold=True)

    # Breakdown by category
    by_category: dict[str, float] = defaultdict(float)
    by_payment: dict[str, float] = defaultdict(float)
    for t in txns:
        raw = t.get("raw_payload") or {}
        cat = (raw.get("resolved") or {}).get("category_account_name") or "Uncategorized"
        pay = (raw.get("payment_resolution") or {}).get("account_name") or "Unspecified"
        by_category[cat] += float(t.get("amount") or 0)
        by_payment[pay] += float(t.get("amount") or 0)

    row = 8
    ws.cell(row=row, column=1, value="By category").font = section_font
    row += 1
    ws.cell(row=row, column=1, value="Category").font = header_font
    ws.cell(row=row, column=1).fill = header_fill
    ws.cell(row=row, column=2, value="Total (AED)").font = header_font
    ws.cell(row=row, column=2).fill = header_fill
    row += 1
    for cat, amt in sorted(by_category.items(), key=lambda kv: -kv[1]):
        ws.cell(row=row, column=1, value=cat)
        c = ws.cell(row=row, column=2, value=amt)
        c.number_format = _AED_FMT
        row += 1

    row += 2
    ws.cell(row=row, column=1, value="By payment method").font = section_font
    row += 1
    ws.cell(row=row, column=1, value="Account").font = header_font
    ws.cell(row=row, column=1).fill = header_fill
    ws.cell(row=row, column=2, value="Total (AED)").font = header_font
    ws.cell(row=row, column=2).fill = header_fill
    row += 1
    for pay, amt in sorted(by_payment.items(), key=lambda kv: -kv[1]):
        ws.cell(row=row, column=1, value=pay)
        c = ws.cell(row=row, column=2, value=amt)
        c.number_format = _AED_FMT
        row += 1

    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 18


def build_workbook(
    txns: list[dict[str, Any]],
    period_label: str,
    filter_desc: str = "",
) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Transactions"

    # Headers row
    ws.append(_HEADERS)
    # Data rows
    for t in txns:
        ws.append(_row_from_txn(t))
    # Totals
    totals = {
        "count": float(len(txns)),
        "net": sum(float(t.get("net_amount") or 0) for t in txns),
        "vat": sum(float(t.get("vat_amount") or 0) for t in txns),
        "gross": sum(float(t.get("amount") or 0) for t in txns),
    }
    _write_totals_row(ws, row_idx=len(txns) + 2, totals=totals)
    _style_transactions_sheet(ws, n_rows=len(txns))

    # Summary sheet
    summary = wb.create_sheet("Summary")
    _build_summary_sheet(summary, txns, totals)

    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()
