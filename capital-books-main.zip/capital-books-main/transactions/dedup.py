"""Duplicate detection for expenses / bills / invoices.

Two signals:
  1. content_hash — SHA-256 of source image/PDF bytes. Catches the
     "user resent the same photo" case decisively. Optional (text-only
     entries have no hash).
  2. value tuple — (vendor, amount, date) match within a sliding window
     (7 days). Catches "log a 500 AED Carrefour expense" sent twice
     with different wording but the same underlying claim.

Behavior is soft-block: detection only — the caller decides what to do.
The capture pipelines route a detected dup through the existing
pending_reviews "hold" flow so the user can confirm with "yes" or
discard. For invoices we surface the prior invoice number and refuse
to post until the user explicitly says "create anyway".
"""
from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Literal
from uuid import UUID

from database import get_db

logger = logging.getLogger(__name__)

# Match window for value-tuple checks. Same-day catches the obvious resend;
# 7 days catches "I forgot if I logged this" mid-week re-entries.
_VALUE_WINDOW_DAYS = 7

EntityKind = Literal["transaction", "bill", "invoice"]


@dataclass
class DuplicateMatch:
    kind: EntityKind
    entity_id: str            # CB-side id (transactions.id / bills.id / invoices.id)
    signal: Literal["content_hash", "value_tuple"]
    vendor: str | None
    amount: float | None
    when: str | None          # ISO date string from the prior entry
    extra: dict[str, Any]     # entity-specific extras (e.g. invoice_number)


def sha256_hex(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


_TABLE_BY_KIND: dict[EntityKind, str] = {
    "transaction": "transactions",
    "bill": "bills",
    "invoice": "invoices",
}

_VENDOR_COLUMN: dict[EntityKind, str] = {
    "transaction": "vendor",
    "bill": "vendor",
    "invoice": "customer_name",
}

_DATE_COLUMN: dict[EntityKind, str] = {
    "transaction": "tax_point_date",
    "bill": "bill_date",
    "invoice": "created_at",
}

# Which column holds the GROSS / user-stated amount. Invoices put net in
# `amount` and gross in `total`; transactions/bills put gross in `amount`.
_AMOUNT_COLUMN: dict[EntityKind, str] = {
    "transaction": "amount",
    "bill": "amount",
    "invoice": "total",
}


async def find_recent_duplicate(
    client_id: UUID,
    kind: EntityKind,
    *,
    content_hash: str | None = None,
    vendor: str | None = None,
    amount: Decimal | float | None = None,
    when: date | None = None,
) -> DuplicateMatch | None:
    """Look up a prior entry that matches by content hash OR value tuple.
    content_hash beats value_tuple — if both are present and only one
    matches, we still return that one (with the matching signal labeled)."""
    table = _TABLE_BY_KIND[kind]
    db = await get_db()

    # 1) Exact content-hash match wins — strongest signal.
    if content_hash:
        try:
            q = (
                db.table(table)
                .select("*")
                .eq("client_id", str(client_id))
                .eq("content_hash", content_hash)
                .order("created_at", desc=True)
                .limit(1)
            )
            # Bills + transactions can be soft-deleted; exclude.
            if table in {"bills", "transactions"}:
                q = q.eq("deleted", False) if table == "bills" else q
            res = await q.execute()
            if res.data:
                row = res.data[0]
                return _build_match(kind, row, signal="content_hash")
        except Exception:
            logger.exception("Content-hash dedup query failed (non-fatal)")

    # 2) Value-tuple match — vendor + amount within ±7 days.
    if vendor and amount is not None:
        try:
            amt = float(amount)
            # `when` may arrive as a date (from bills) or a string (from the
            # extractor's resolved_fields). Normalize.
            anchor: date
            if when is None:
                anchor = date.today()
            elif isinstance(when, date):
                anchor = when
            else:
                try:
                    anchor = date.fromisoformat(str(when)[:10])
                except ValueError:
                    anchor = date.today()
            window_start = (anchor - timedelta(days=_VALUE_WINDOW_DAYS)).isoformat()
            window_end = (anchor + timedelta(days=_VALUE_WINDOW_DAYS)).isoformat()
            date_col = _DATE_COLUMN[kind]
            vendor_col = _VENDOR_COLUMN[kind]
            amount_col = _AMOUNT_COLUMN[kind]

            # ilike for case-insensitive vendor match; use ±0.01 amount tolerance
            q = (
                db.table(table)
                .select("*")
                .eq("client_id", str(client_id))
                .ilike(vendor_col, vendor.strip())
                .gte(amount_col, amt - 0.01)
                .lte(amount_col, amt + 0.01)
                .gte(date_col, window_start)
                .lte(date_col, window_end)
                .order("created_at", desc=True)
                .limit(1)
            )
            if table == "bills":
                q = q.eq("deleted", False)
            res = await q.execute()
            if res.data:
                row = res.data[0]
                return _build_match(kind, row, signal="value_tuple")
        except Exception:
            logger.exception("Value-tuple dedup query failed (non-fatal)")

    return None


def _build_match(
    kind: EntityKind, row: dict[str, Any], *, signal: str,
) -> DuplicateMatch:
    vendor = row.get("vendor") or row.get("customer_name")
    when = (row.get("tax_point_date") or row.get("bill_date")
            or row.get("created_at") or "")
    if isinstance(when, str) and "T" in when:
        when = when.split("T", 1)[0]
    extra: dict[str, Any] = {}
    if kind == "invoice":
        extra["invoice_number"] = row.get("invoice_number")
        extra["status"] = row.get("status")
    elif kind == "bill":
        extra["bill_number"] = row.get("bill_number")
        extra["status"] = row.get("status")
    # Invoices store net in `amount` and gross in `total` — surface the
    # gross figure so the soft-block message matches what the user typed.
    amount_col = _AMOUNT_COLUMN[kind]
    return DuplicateMatch(
        kind=kind,
        entity_id=str(row.get("id") or ""),
        signal=signal,    # type: ignore[arg-type]
        vendor=vendor,
        amount=float(row.get(amount_col) or 0),
        when=str(when) if when else None,
        extra=extra,
    )


def format_for_user(match: DuplicateMatch) -> str:
    """Short human-readable line for soft-block messages."""
    signal_label = "exact resend" if match.signal == "content_hash" else "matching amount + vendor"
    bits = [f"⚠️ Possible duplicate ({signal_label})"]
    if match.vendor:
        bits.append(f"Vendor: *{match.vendor}*")
    if match.amount is not None:
        bits.append(f"Amount: AED {match.amount:,.2f}")
    if match.when:
        bits.append(f"Logged: {match.when}")
    if match.kind == "invoice" and match.extra.get("invoice_number"):
        bits.append(f"Prior invoice: {match.extra['invoice_number']}")
    if match.kind == "bill" and match.extra.get("bill_number"):
        bits.append(f"Prior bill: {match.extra['bill_number']}")
    return "\n".join(bits)
