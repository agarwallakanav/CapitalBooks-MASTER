"""Step 9: Decide how the transaction proceeds.

Precedence:
  1. Realisation basis + unpaid  → HOLD_UNTIL_PAID
  2. Confidence < 70            → MANUAL (require human categorization)
  3. Confidence < client threshold OR amount > approval_amount_limit → HUMAN_REVIEW
  4. Otherwise                   → AUTO_POST
"""
from decimal import Decimal

from transactions.models import RoutingDecision, TransactionContext


async def decide_routing(ctx: TransactionContext) -> RoutingDecision:
    client = ctx.client
    confidence = ctx.vat_classification.confidence if ctx.vat_classification else 0
    amount = Decimal(ctx.input.amount)

    if client and client.vat_basis == "realisation" and not ctx.input.is_paid:
        return RoutingDecision(
            action="HOLD_UNTIL_PAID",
            status="hold_until_paid",
            reason="Realisation basis: tax point unset until payment received",
        )

    threshold = client.confidence_threshold if client else 95
    limit = client.approval_amount_limit if client else Decimal("5000")

    if confidence < 70:
        return RoutingDecision(
            action="MANUAL",
            status="manually_categorized",
            reason=f"Low confidence ({confidence}%) — manual categorization required",
        )

    if confidence < threshold:
        return RoutingDecision(
            action="HUMAN_REVIEW",
            status="needs_review",
            reason=f"Confidence {confidence}% below threshold {threshold}%",
        )

    if amount > limit:
        return RoutingDecision(
            action="HUMAN_REVIEW",
            status="needs_review",
            reason=f"Amount {amount} {ctx.input.currency} exceeds approval limit {limit}",
        )

    return RoutingDecision(
        action="AUTO_POST",
        status="auto_posted",
        reason=f"Confidence {confidence}% ≥ threshold {threshold}% — auto-posted",
    )
