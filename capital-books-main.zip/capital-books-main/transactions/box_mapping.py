"""Step 7: Assign VAT 201 return boxes.

  Output (income):
    Box 1 = standard rated supplies
    Box 3 = zero-rated supplies
    Box 4 = exempt supplies
  Input (expense):
    Box 9  = standard rated expenses (claimable input VAT)
    Box 10 = blocked / non-recoverable input VAT
    Box 4 + Box 11 = reverse charge on imported services
"""
from transactions.models import BoxAssignments, TransactionContext


async def map_vat_boxes(ctx: TransactionContext) -> BoxAssignments:
    direction = ctx.input.direction
    vat_type = ctx.vat_classification.vat_type if ctx.vat_classification else "out_of_scope"
    is_blocked = ctx.blocked_vat.is_blocked if ctx.blocked_vat else False
    is_rc = ctx.reverse_charge.is_reverse_charge if ctx.reverse_charge else False

    boxes: list[int] = []

    if direction == "income":
        if vat_type == "standard":
            boxes.append(1)
        elif vat_type == "zero":
            boxes.append(3)
        elif vat_type == "exempt":
            boxes.append(4)
    else:
        if is_rc:
            boxes.extend([4, 11])
        elif vat_type == "standard":
            boxes.append(10 if is_blocked else 9)

    return BoxAssignments(boxes=boxes)
