"""Production-ready transactions extractor with per-field confidence.

Two entry points:
  - extract_from_text(text, cfg, today=None)
  - extract_from_image(image_bytes, mime, cfg, caption=None, today=None)

Both return ExtractedTransaction — a dataclass where every field is a
FieldValue carrying both the value and a 'high'|'low' confidence label.
Downstream logic in confidence.py decides whether to post, flag, hold, or block.

The Claude system prompt is dynamically injected with the client's TRN, the
last-4 digits we know cards for, and the top vendors we've already seen.
"""
import base64
import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any, Literal
from uuid import UUID

from anthropic import AsyncAnthropic

from config import settings
from database import get_db

logger = logging.getLogger(__name__)

Confidence = Literal["high", "low"]

_anthropic: AsyncAnthropic | None = None


def _client() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


# ---------------------------------------------------------------------------
# Output shape
# ---------------------------------------------------------------------------

@dataclass
class FieldValue:
    value: Any = None
    confidence: Confidence = "low"


@dataclass
class LineItem:
    description: str = ""
    quantity: float | None = None
    unit_price: float | None = None
    amount: float | None = None


@dataclass
class ExtractedTransaction:
    vendor: FieldValue = field(default_factory=FieldValue)
    date: FieldValue = field(default_factory=FieldValue)
    amount: FieldValue = field(default_factory=FieldValue)          # gross
    vat_amount: FieldValue = field(default_factory=FieldValue)
    currency: FieldValue = field(default_factory=FieldValue)
    payment_method_hint: FieldValue = field(default_factory=FieldValue)
    # Free-form category if the user STATED what the expense was for
    # ("lunch", "office supplies", "fuel"). high confidence ONLY when the
    # message explicitly says so. Vendor alone is not enough — Carrefour
    # can be groceries, office supplies, snacks, etc.
    category_hint: FieldValue = field(default_factory=FieldValue)
    line_items: FieldValue = field(default_factory=FieldValue)      # value: list[LineItem]
    vendor_trn: FieldValue = field(default_factory=FieldValue)
    raw_response: str = ""                                          # for audit

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Known-vendor lookup (used to bias high-confidence on seen vendors)
# ---------------------------------------------------------------------------

async def _top_known_vendors(client_id: UUID, limit: int = 25) -> list[str]:
    db = await get_db()
    res = (
        await db.table("transactions")
        .select("vendor")
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .order("created_at", desc=True)
        .limit(200)
        .execute()
    )
    seen: dict[str, int] = {}
    for r in res.data or []:
        v = (r.get("vendor") or "").strip()
        if v:
            seen[v] = seen.get(v, 0) + 1
    top = sorted(seen.items(), key=lambda kv: -kv[1])[:limit]
    return [v for v, _ in top]


# ---------------------------------------------------------------------------
# Prompt construction
# ---------------------------------------------------------------------------

_BASE_RULES = """You extract UAE bookkeeping transaction data with PER-FIELD
confidence. Every field has a confidence flag of "high" or "low".

Use "high" only when the field is explicitly visible / clearly stated. Use
"low" when you inferred it, guessed defaults, or couldn't read it clearly.

Special UAE-specific guidance:
- UAE VAT is 5%. If you see "VAT", "ضريبة القيمة المضافة", or a 5% addition,
  the amount field should be GROSS and vat_amount should be that 5% line.
- TRN is a 15-digit number starting with "100". If you see it, return it.
- Currency: detect from symbols / words and return the ISO 4217 code.
  Symbols: $→USD, €→EUR, £→GBP, ¥→JPY, ₹→INR, ₨→PKR
  Words: "dollar/dollars/USD" → USD, "euro" → EUR, "pound/pounds/GBP" → GBP,
    "dirham/dirhams/dhs/AED" → AED, "riyal/saudi riyal/SAR/SR" → SAR,
    "rupee/rupees/INR/Rs" → INR, "yen/JPY" → JPY, "yuan/RMB" → CNY
  "Dirham" without qualifier ALWAYS means AED (the UAE Dirham) — never
    Moroccan Dirham, even though the word is ambiguous.
  Default to AED with confidence "low" if no currency signal is present.
- payment_method_hint: detect cues like "PAID BY CARD VISA ****1234", "CASH",
  "BANK TRANSFER", "STC PAY", etc. Return the most specific hint you see.
- category_hint: ONLY set when the user EXPLICITLY named a PURPOSE WORD
  (what the spending was FOR). Vendor name is NEVER a category signal,
  even when it seems obvious.
    HIGH confidence — purpose word present:
      "lunch at X"         → "meals"
      "office supplies at X" → "office supplies"
      "fuel/petrol/gas"    → "fuel"
      "snacks at X"        → "snacks"
      "internet bill"      → "utilities"
      "flight/hotel/ride"  → "travel"
    LOW / leave null — no purpose word, ONLY a vendor:
      "spent 150 at Carrefour"  → Carrefour could be groceries, office,
                                   snacks, lunch — DO NOT GUESS.
      "150 at Careem"           → Careem could be rides, food delivery,
                                   shipping — DO NOT GUESS.
      "120 at Etisalat"         → Could be phone, internet, mobile data
                                   — DO NOT GUESS.
  Rule: if the user did not write a purpose word, set confidence "low"
  and leave value null. The bot will ask them what it was for.

Reply with JSON ONLY, no prose:
{
  "vendor":             {"value": "<name>",   "confidence": "high"|"low"},
  "date":               {"value": "YYYY-MM-DD","confidence": "high"|"low"},
  "amount":             {"value": <gross>,    "confidence": "high"|"low"},
  "vat_amount":         {"value": <vat>,      "confidence": "high"|"low"},
  "currency":           {"value": "AED|USD|…","confidence": "high"|"low"},
  "payment_method_hint":{"value": "<raw hint>","confidence": "high"|"low"},
  "category_hint":      {"value": "<short category like 'meals'/'office supplies'>","confidence": "high"|"low"},
  "vendor_trn":         {"value": "<15-digit>","confidence": "high"|"low"},
  "line_items": {
    "value": [
      {"description": "...", "quantity": 1, "unit_price": 10.0, "amount": 10.0}
    ],
    "confidence": "high"|"low"
  }
}"""


def _build_system_prompt(
    today: date,
    company_trn: str | None,
    card_mapping: dict[str, Any] | None,
    known_vendors: list[str],
) -> str:
    pieces = [_BASE_RULES, f"\nTODAY'S DATE: {today.isoformat()}"]
    if company_trn:
        pieces.append(f"\nThis client's own TRN: {company_trn}")
    if card_mapping:
        cards = list(card_mapping.keys())
        if cards:
            pieces.append(
                "\nThis client has cards on file ending: "
                + ", ".join(cards)
                + ". If you see any of these last-4s, set payment_method_hint with high confidence."
            )
    if known_vendors:
        pieces.append(
            "\nVendors this client has used recently: "
            + ", ".join(known_vendors[:15])
            + ". Match leniently and use high confidence when the vendor matches."
        )
    return "\n".join(pieces)


def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return text.strip()


def _parse(raw_json: str) -> ExtractedTransaction:
    data = json.loads(raw_json)
    out = ExtractedTransaction()

    def fv(name: str) -> FieldValue:
        node = data.get(name) or {}
        return FieldValue(value=node.get("value"), confidence=node.get("confidence", "low"))

    out.vendor = fv("vendor")
    out.date = fv("date")
    out.amount = fv("amount")
    out.vat_amount = fv("vat_amount")
    out.currency = fv("currency")
    out.payment_method_hint = fv("payment_method_hint")
    out.category_hint = fv("category_hint")
    out.vendor_trn = fv("vendor_trn")

    li_node = data.get("line_items") or {}
    li_raw = li_node.get("value") or []
    items = []
    for item in li_raw:
        items.append(LineItem(
            description=item.get("description", ""),
            quantity=item.get("quantity"),
            unit_price=item.get("unit_price"),
            amount=item.get("amount"),
        ))
    out.line_items = FieldValue(value=items, confidence=li_node.get("confidence", "low"))
    out.raw_response = raw_json
    return out


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------

async def _extract(
    cfg,
    user_content: list[dict[str, Any]],
    today: date | None = None,
    *,
    tier: str = "fast",
) -> ExtractedTransaction:
    today = today or date.today()
    known_vendors = await _top_known_vendors(cfg.id)
    system = _build_system_prompt(
        today=today,
        company_trn=getattr(cfg, "trn", None),
        card_mapping=getattr(cfg, "card_mapping", None) or {},
        known_vendors=known_vendors,
    )
    from router.model_tier import timed
    model_id = (settings.anthropic_model_smart if tier == "smart"
                else settings.anthropic_model_fast)
    with timed(
        logger, "extractor.call",
        model=model_id, tier=tier, source_kind=("image" if any(
            (isinstance(b, dict) and b.get("type") == "image") for b in user_content
        ) else "text"),
    ) as stats:
        resp = await _client().messages.create(
            model=model_id,
            max_tokens=1500,
            system=system,
            messages=[{"role": "user", "content": user_content}],
        )
        usage = getattr(resp, "usage", None)
        if usage:
            stats["tokens_in"] = getattr(usage, "input_tokens", None)
            stats["tokens_out"] = getattr(usage, "output_tokens", None)
    raw = _strip_fences(
        "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    )
    return _parse(raw)


async def extract_from_text(
    text: str, cfg, today: date | None = None
) -> ExtractedTransaction:
    return await _extract(cfg, [{"type": "text", "text": text}], today=today)


async def extract_from_image(
    image_bytes: bytes,
    mime: str,
    cfg,
    caption: str | None = None,
    today: date | None = None,
) -> ExtractedTransaction:
    if mime not in ("image/jpeg", "image/png", "image/gif", "image/webp"):
        logger.warning("Unsupported mime %s — coercing to image/jpeg", mime)
        mime = "image/jpeg"
    b64 = base64.standard_b64encode(image_bytes).decode("ascii")
    content: list[dict[str, Any]] = [
        {"type": "image",
         "source": {"type": "base64", "media_type": mime, "data": b64}},
    ]
    if caption:
        content.append({"type": "text", "text": f"User caption: {caption}"})
    else:
        content.append({"type": "text", "text": "Extract this UAE receipt."})
    # Image OCR + per-field confidence is exactly where Sonnet earns its
    # keep — sharper vision, better confidence calibration on ambiguous
    # receipts. Text extraction stays on Haiku.
    return await _extract(cfg, content, today=today, tier="smart")
