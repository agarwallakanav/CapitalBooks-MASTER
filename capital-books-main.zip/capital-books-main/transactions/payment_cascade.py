"""Payment method resolution.

Returns one of four states the caller can act on:

  resolved              — account_id present, post normally
  needs_method          — no payment mention at all → ask "how was this paid?"
  needs_card_digits     — said "card" / "visa" / etc with no last-4 → ask digits
  needs_card_label      — gave digits but card unknown → ask "what to call it?"

Cards are looked up in the `client_cards` table (with the legacy
`clients.card_mapping` JSONB as a fallback). Cash / bank-transfer / cheque
resolve from the per-client tax_ids / default_payment_account config.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal
from uuid import UUID

from transactions.cards import CardRecord, list_cards

ResolutionState = Literal[
    "resolved",
    "needs_method",
    "needs_card_digits",
    "needs_card_label",
]
ResolutionMethod = Literal["card_match", "keyword", "default", "manual"]


@dataclass
class ResolutionResult:
    state: ResolutionState
    account_name: str
    zoho_account_id: str | None
    resolution_method: ResolutionMethod
    detail: str = ""
    # When state == needs_card_label, the digits the user gave (so the
    # caller can pass them through to the follow-up "name this card" tool).
    pending_last_four: str | None = None
    # Cards on file — surfaced to the caller for "auto-match single card"
    # logic and "your cards on file: ..." prompts.
    known_cards: list[CardRecord] = field(default_factory=list)

    @property
    def needs_user_input(self) -> bool:
        return self.state != "resolved"


_FOUR_DIGITS = re.compile(r"\b(\d{4})\b")

_KEYWORDS: dict[str, str] = {
    "cash":              "cash",
    "petty cash":        "cash",
    "card":              "card",
    "visa":              "card",
    "mastercard":        "card",
    "credit card":       "card",
    "debit card":        "card",
    "amex":              "card",
    "american express":  "card",
    "bank transfer":     "bank_transfer",
    "wire":              "bank_transfer",
    "wire transfer":     "bank_transfer",
    "transfer":          "bank_transfer",
    "bank":              "bank_transfer",
    "online":            "bank_transfer",
    "stc pay":           "bank_transfer",
    "cheque":            "cheque",
    "check":             "cheque",
}


def _extract_card_last_4(text: str) -> str | None:
    if not text:
        return None
    for m in _FOUR_DIGITS.finditer(text):
        start = max(0, m.start() - 30)
        ctx = text[start:m.start()].lower()
        if any(k in ctx for k in ("card", "visa", "mastercard", "amex",
                                   "ending", "****", "••")):
            return m.group(1)
    m = _FOUR_DIGITS.search(text)
    return m.group(1) if m else None


def _keyword_method(text: str) -> str | None:
    t = (text or "").lower()
    for token, method in _KEYWORDS.items():
        if token in t:
            return method
    return None


async def resolve(
    message: str,
    payment_method_hint: str | None,
    cfg,
) -> ResolutionResult:
    """Async resolution — queries client_cards. Inspects both the user's
    message and the extractor's payment_method_hint (often a snippet from
    the receipt itself)."""
    client_id: UUID = cfg.id
    known_cards = await list_cards(client_id)
    cards_by_last4 = {c.last_four: c for c in known_cards}
    tax_ids = (cfg.zoho_tax_ids or {})

    combined = f"{payment_method_hint or ''} {message or ''}".strip()
    method = _keyword_method(combined)

    # Card last-4 mentioned anywhere?
    last_4: str | None = None
    for src in (payment_method_hint or "", message or ""):
        digits = _extract_card_last_4(src)
        if digits:
            last_4 = digits
            break

    # Case: digits provided
    if last_4:
        match = cards_by_last4.get(last_4)
        if match and match.zoho_account_id:
            return ResolutionResult(
                state="resolved",
                account_name=f"{match.label} ••{last_4}",
                zoho_account_id=match.zoho_account_id,
                resolution_method="card_match",
                detail=f"card ending {last_4}",
                known_cards=known_cards,
            )
        # Digits given but unknown — ask user to name the card
        return ResolutionResult(
            state="needs_card_label",
            account_name=f"Card ••{last_4} (new)",
            zoho_account_id=None,
            resolution_method="manual",
            detail=f"unknown card ending {last_4}",
            pending_last_four=last_4,
            known_cards=known_cards,
        )

    # Case: "card" keyword without digits
    if method == "card":
        # Auto-match if the client has exactly one card on file
        if len(known_cards) == 1 and known_cards[0].zoho_account_id:
            c = known_cards[0]
            return ResolutionResult(
                state="resolved",
                account_name=f"{c.label} ••{c.last_four}",
                zoho_account_id=c.zoho_account_id,
                resolution_method="card_match",
                detail=f"auto-matched single card on file ({c.last_four})",
                known_cards=known_cards,
            )
        return ResolutionResult(
            state="needs_card_digits",
            account_name="(card — need last 4 digits)",
            zoho_account_id=None,
            resolution_method="manual",
            detail="card mentioned without last-4",
            known_cards=known_cards,
        )

    # Case: cash → cash account
    if method == "cash":
        acct = tax_ids.get("_default_paid_through_account_id")
        if acct:
            return ResolutionResult(
                state="resolved",
                account_name="Petty Cash",
                zoho_account_id=acct,
                resolution_method="keyword",
                detail="cash",
                known_cards=known_cards,
            )

    # Case: bank transfer → default bank
    if method == "bank_transfer" and cfg.default_payment_account:
        return ResolutionResult(
            state="resolved",
            account_name="Bank (default)",
            zoho_account_id=cfg.default_payment_account,
            resolution_method="keyword",
            detail="bank transfer",
            known_cards=known_cards,
        )

    # No payment signal at all → ASK (don't silently default to a bank account)
    return ResolutionResult(
        state="needs_method",
        account_name="(unspecified)",
        zoho_account_id=None,
        resolution_method="manual",
        detail="no payment method stated",
        known_cards=known_cards,
    )
