"""The 12-step VAT pipeline.

Step 1  — load_client_config          (sequential, blocks everything below)
Steps 2 + 3 — validate_trn || classify_vat                       (asyncio.gather)
Steps 4 + 5 — detect_reverse_charge || check_blocked_vat         (asyncio.gather)
Step 6  — compute_vat_amounts         (sequential, needs 3 + 4)
Steps 7 + 8 — map_vat_boxes || determine_tax_point               (asyncio.gather)
Step 9  — decide_routing
Step 10 — post_to_zoho                (only when AUTO_POST)
Step 11 — log_transaction             (always, even on failure)
"""
import asyncio
import dataclasses
import logging
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any
from uuid import UUID

from database import get_db
from transactions.blocked_vat import check_blocked_vat
from zoho.client import ZohoBooksClient
from zoho.entities import build_entity_payload, endpoint_for
from transactions.box_mapping import map_vat_boxes
from transactions.models import (
    ClientConfig,
    RoutingDecision,
    TransactionContext,
    TransactionInput,
)
from transactions.reverse_charge import detect_reverse_charge
from transactions.routing_decision import decide_routing
from transactions.tax_point import determine_tax_point
from transactions.trn_validation import validate_trn
from transactions.vat_arithmetic import compute_vat_amounts
from transactions.vat_classifier import classify_vat

logger = logging.getLogger(__name__)


# -------- Step 1: client config --------

async def load_client_config(client_id: UUID) -> ClientConfig:
    db = await get_db()
    res = (
        await db.table("clients")
        .select(
            "id, company_name, vat_basis, entity_type, foreign_suppliers, "
            "confidence_threshold, approval_amount_limit, "
            "zoho_organization_id, zoho_access_token, zoho_refresh_token, zoho_tax_ids"
        )
        .eq("id", str(client_id))
        .single()
        .execute()
    )
    row = res.data
    if not row:
        raise ValueError(f"Client not found: {client_id}")
    return ClientConfig(
        id=UUID(row["id"]),
        company_name=row["company_name"],
        vat_basis=row.get("vat_basis") or "accrual",
        entity_type=row.get("entity_type"),
        foreign_suppliers=row.get("foreign_suppliers") or [],
        confidence_threshold=int(row.get("confidence_threshold") or 95),
        approval_amount_limit=Decimal(str(row.get("approval_amount_limit") or 5000)),
        zoho_organization_id=row.get("zoho_organization_id"),
        zoho_access_token=row.get("zoho_access_token"),
        zoho_refresh_token=row.get("zoho_refresh_token"),
        zoho_tax_ids=row.get("zoho_tax_ids") or {},
    )


# -------- Step 10: Zoho Books post --------

async def post_to_zoho(ctx: TransactionContext) -> str | None:
    client = ctx.client
    if not (
        client
        and client.zoho_organization_id
        and client.zoho_access_token
        and client.zoho_refresh_token
    ):
        logger.warning(
            "Client %s has no Zoho credentials — skipping Zoho post",
            client.id if client else "?",
        )
        return None

    payload = build_entity_payload(ctx, client.zoho_tax_ids)
    endpoint = endpoint_for(ctx.input.zoho_entity_type)
    async with ZohoBooksClient(
        organization_id=client.zoho_organization_id,
        access_token=client.zoho_access_token,
        refresh_token=client.zoho_refresh_token,
        client_uuid=client.id,
    ) as zoho:
        resp = await zoho.create_entity(endpoint, payload)
    # Zoho responses wrap the entity in a singular key (expense, bill, invoice, etc.)
    singular = endpoint.rstrip("s")
    entity = resp.get(singular) or resp.get(endpoint) or {}
    return str(entity.get(f"{singular}_id") or entity.get("id") or "") or None


# -------- Step 11: Supabase log --------

def _serialize(obj: Any) -> Any:
    if obj is None:
        return None
    if dataclasses.is_dataclass(obj):
        return {k: _serialize(v) for k, v in dataclasses.asdict(obj).items()}
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, (datetime,)):
        return obj.isoformat()
    return obj


async def log_transaction(ctx: TransactionContext) -> UUID:
    db = await get_db()
    amounts = ctx.amounts
    routing = ctx.routing or RoutingDecision(
        action="MANUAL", status="failed", reason="Pipeline did not reach routing decision"
    )

    row: dict[str, Any] = {
        "client_id": str(ctx.input.client_id),
        "vendor": ctx.input.vendor,
        "description": ctx.input.description,
        "direction": ctx.input.direction,
        "amount": float(amounts.gross) if amounts else float(ctx.input.amount),
        "net_amount": float(amounts.net) if amounts else None,
        "vat_amount": float(amounts.vat) if amounts else 0.0,
        "currency": ctx.input.currency,
        "fx_rate": float(amounts.fx_rate) if amounts else 1.0,
        "amount_aed": float(amounts.amount_aed) if amounts else None,
        "confidence_score": ctx.vat_classification.confidence if ctx.vat_classification else 0,
        "vat_type": ctx.vat_classification.vat_type if ctx.vat_classification else "out_of_scope",
        "vat_boxes": ctx.boxes.boxes if ctx.boxes else [],
        "tax_point_date": ctx.tax_point_date.isoformat() if ctx.tax_point_date else None,
        "is_blocked_vat": ctx.blocked_vat.is_blocked if ctx.blocked_vat else False,
        "blocked_vat_category": ctx.blocked_vat.matched_category if ctx.blocked_vat else None,
        "status": routing.status,
        "routing_reason": routing.reason,
        "zoho_entity_type": ctx.input.zoho_entity_type,
        "zoho_entity_id": ctx.zoho_entity_id,
        "source_document_url": ctx.input.source_document_url,
        "raw_payload": {
            "trn_validation": _serialize(ctx.trn),
            "vat_classification": _serialize(ctx.vat_classification),
            "reverse_charge": _serialize(ctx.reverse_charge),
            "blocked_vat": _serialize(ctx.blocked_vat),
            "amounts": _serialize(ctx.amounts),
            "errors": ctx.errors,
        },
    }
    res = await db.table("transactions").insert(row).execute()
    return UUID(res.data[0]["id"])


# -------- Orchestrator --------

async def run_pipeline(
    transaction: TransactionInput,
    require_confirmation: bool = False,
    skip_transaction_log: bool = False,
) -> TransactionContext:
    """When require_confirmation=True (e.g. image-extracted receipts), the pipeline
    runs steps 1-9 normally but forces routing to HUMAN_REVIEW even on high
    confidence, so the user can verify amounts before we POST to Zoho."""
    ctx = TransactionContext(input=transaction)

    # Step 1
    ctx.client = await load_client_config(transaction.client_id)

    # Steps 2 + 3 in parallel
    ctx.trn, ctx.vat_classification = await asyncio.gather(
        validate_trn(ctx),
        classify_vat(ctx),
    )

    # Steps 4 + 5 in parallel (both consume vat_classification from step 3)
    ctx.reverse_charge, ctx.blocked_vat = await asyncio.gather(
        detect_reverse_charge(ctx),
        check_blocked_vat(ctx),
    )

    # If reverse_charge was decided by foreign-supplier match but the AI didn't
    # flag it, normalize vat_classification so downstream tax codes are correct.
    if (
        ctx.reverse_charge.is_reverse_charge
        and ctx.vat_classification
        and ctx.vat_classification.vat_type != "reverse_charge"
    ):
        ctx.vat_classification.vat_type = "reverse_charge"

    # Step 6
    ctx.amounts = await compute_vat_amounts(ctx)

    # Steps 7 + 8 in parallel
    ctx.boxes, ctx.tax_point_date = await asyncio.gather(
        map_vat_boxes(ctx),
        determine_tax_point(ctx),
    )

    # Step 9
    ctx.routing = await decide_routing(ctx)

    # Override AUTO_POST when the caller asked for explicit confirmation
    # (e.g. image-extracted transactions — OCR can misread amounts).
    if require_confirmation and ctx.routing.action == "AUTO_POST":
        ctx.routing = RoutingDecision(
            action="HUMAN_REVIEW",
            status="needs_review",
            reason="Receipt image — please verify the values before I post",
        )

    # Step 10
    if ctx.routing.action == "AUTO_POST":
        try:
            ctx.zoho_entity_id = await post_to_zoho(ctx)
        except Exception as exc:
            logger.exception("Zoho post failed for client=%s vendor=%s", ctx.client.id, ctx.input.vendor)
            ctx.errors.append(f"Zoho post failed: {exc}")
            ctx.routing = RoutingDecision(
                action="HUMAN_REVIEW",
                status="needs_review",
                reason=f"Zoho post failed: {exc}",
            )

    # Step 11 — log to transactions table, UNLESS the caller is an AP/AR module
    # that owns its own source-of-truth table (bills/invoices). Without this
    # guard, every Bill processed through the pipeline produced a stale
    # transactions row that polluted the "what did I log" query.
    if not skip_transaction_log:
        try:
            ctx.transaction_id = await log_transaction(ctx)
        except Exception as exc:
            logger.exception("Supabase log failed for client=%s", ctx.client.id if ctx.client else "?")
            ctx.errors.append(f"Supabase log failed: {exc}")
            raise

    return ctx
