"""Edit and delete operations on already-posted transactions.

Edit allowed fields: vendor, amount (recomputes net/VAT), description.
Category change requires Zoho account-id resolution — deferred to the categorizer.
Delete: hard-delete in Zoho, soft-delete (deleted=true) in Supabase.
"""
import json
import logging
from decimal import ROUND_HALF_EVEN, Decimal
from typing import Any

from anthropic import AsyncAnthropic

from config import settings
from database import get_db
from transactions.models import ClientConfig
from zoho.client import ZohoBooksClient
from zoho.entities import endpoint_for

logger = logging.getLogger(__name__)

VAT_RATE = Decimal("0.05")
ONE_PLUS_RATE = Decimal("1.05")
TWO_PLACES = Decimal("0.01")

_anthropic: AsyncAnthropic | None = None


def _claude() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


_EDIT_PROMPT = """The user wants to edit a transaction. Their current values:
{current}

Their edit request: "{instruction}"

Extract ONLY the fields they want to change. Return JSON like:
{{"vendor": "<new>" or null, "amount": <number> or null, "description": "<new>" or null}}

Use null for fields they didn't mention. Don't guess. Reply with JSON only, no prose."""


def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return text.strip()


async def parse_edit_instructions(
    instruction: str, current_state: dict[str, Any]
) -> dict[str, Any]:
    """Use Claude to figure out which fields to change. Returns only non-null fields."""
    current = (
        f"  vendor: {current_state.get('vendor')}\n"
        f"  amount: {current_state.get('amount')} {current_state.get('currency')}\n"
        f"  description: {current_state.get('description')}"
    )
    resp = await _claude().messages.create(
        model=settings.anthropic_model_fast,
        max_tokens=300,
        messages=[{
            "role": "user",
            "content": _EDIT_PROMPT.format(current=current, instruction=instruction),
        }],
    )
    raw = _strip_fences(
        "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    )
    data = json.loads(raw)
    changes: dict[str, Any] = {}
    if data.get("vendor"):
        changes["vendor"] = str(data["vendor"]).strip()
    if data.get("amount") is not None:
        try:
            changes["amount"] = Decimal(str(data["amount"]))
        except Exception:
            pass
    if data.get("description"):
        changes["description"] = str(data["description"]).strip()
    return changes


def _recompute_vat(gross: Decimal, vat_type: str | None) -> tuple[Decimal, Decimal]:
    if vat_type == "standard":
        net = (gross / ONE_PLUS_RATE).quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)
        vat = (gross - net).quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)
        return net, vat
    return gross.quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN), Decimal("0.00")


async def apply_edit_to_zoho_and_supabase(
    client: ClientConfig, snapshot: dict[str, Any], changes: dict[str, Any]
) -> dict[str, Any]:
    """Apply the parsed changes to both Zoho (PUT) and Supabase. Returns the
    fields that actually changed (post-recompute) for the WhatsApp reply."""
    if not (client.zoho_organization_id and client.zoho_access_token):
        raise RuntimeError("No Zoho credentials configured for this client")

    entity_type = snapshot["zoho_entity_type"]
    entity_id = snapshot["zoho_entity_id"]
    endpoint = endpoint_for(entity_type)

    zoho_payload: dict[str, Any] = {}
    supabase_payload: dict[str, Any] = {}
    summary: dict[str, Any] = {}

    if "vendor" in changes:
        zoho_payload["vendor_name"] = changes["vendor"]
        supabase_payload["vendor"] = changes["vendor"]
        summary["vendor"] = changes["vendor"]
    if "description" in changes:
        # Zoho's expense field is "description"; invoices/bills use "notes" + line_items.
        if entity_type == "Expense":
            zoho_payload["description"] = changes["description"]
        else:
            zoho_payload["notes"] = changes["description"]
        supabase_payload["description"] = changes["description"]
        summary["description"] = changes["description"]
    if "amount" in changes:
        gross = Decimal(changes["amount"])
        net, vat = _recompute_vat(gross, snapshot.get("vat_type"))
        # Zoho Expense uses 'amount' as gross with is_inclusive_tax=False meaning
        # the amount is NET. We posted with is_inclusive_tax=False so we send net.
        if entity_type == "Expense":
            zoho_payload["amount"] = float(net)
        else:
            # invoices/bills track per-line rates; updating gross requires line_items
            # rewrite which is out of scope here. Surface as a TODO.
            raise NotImplementedError(
                "Amount edits on invoices/bills require line_items rewrite — not yet supported."
            )
        supabase_payload["amount"] = float(gross)
        supabase_payload["net_amount"] = float(net)
        supabase_payload["vat_amount"] = float(vat)
        summary["amount"] = f"{gross} (net {net}, vat {vat})"

    if not zoho_payload and not supabase_payload:
        return summary

    if entity_id and zoho_payload:
        # Zoho UAE silently drops vendor_name on PUT unless tax_treatment +
        # place_of_supply are echoed back. Pull defaults from client config.
        tax_treatment = (client.zoho_tax_ids or {}).get("_default_tax_treatment")
        place_of_supply = (client.zoho_tax_ids or {}).get("_default_place_of_supply")
        if tax_treatment:
            zoho_payload["tax_treatment"] = tax_treatment
        if place_of_supply:
            zoho_payload["place_of_supply"] = place_of_supply

        async with ZohoBooksClient(
            organization_id=client.zoho_organization_id,
            access_token=client.zoho_access_token,
            refresh_token=client.zoho_refresh_token or "",
            client_uuid=client.id,
        ) as zoho:
            await zoho.update_entity(endpoint, entity_id, zoho_payload)

    if supabase_payload:
        db = await get_db()
        await (
            db.table("transactions")
            .update(supabase_payload)
            .eq("id", snapshot["txn_id"])
            .execute()
        )

    return summary


async def soft_delete_transaction(
    client: ClientConfig, snapshot: dict[str, Any]
) -> None:
    """Hard-delete in Zoho; soft-delete (deleted=true) in Supabase.
    The soft delete preserves the row for audit + VAT-history continuity."""
    entity_type = snapshot["zoho_entity_type"]
    entity_id = snapshot["zoho_entity_id"]

    if (
        entity_id
        and client.zoho_organization_id
        and client.zoho_access_token
    ):
        endpoint = endpoint_for(entity_type)
        try:
            async with ZohoBooksClient(
                organization_id=client.zoho_organization_id,
                access_token=client.zoho_access_token,
                refresh_token=client.zoho_refresh_token or "",
                client_uuid=client.id,
            ) as zoho:
                await zoho.delete_entity(endpoint, entity_id)
        except Exception:
            # Zoho refuses to delete entries with linked payments etc. Log and
            # continue — Supabase soft-delete still happens so the user sees it
            # removed from their lists. Real cleanup in Zoho can be manual.
            logger.exception(
                "Zoho delete failed for %s/%s — soft-deleting in Supabase anyway",
                entity_type, entity_id,
            )

    db = await get_db()
    await (
        db.table("transactions")
        .update({"deleted": True})
        .eq("id", snapshot["txn_id"])
        .execute()
    )
