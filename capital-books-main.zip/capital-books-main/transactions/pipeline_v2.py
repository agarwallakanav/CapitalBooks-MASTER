"""Production transactions pipeline — wires together the new extractor,
confidence scoring, payment cascade, RCM detection, and orchestrator-flavor
ModuleResult emission.

Two entry points, both stateless:
  capture_text(text, ctx)
  capture_image(image_bytes, mime, caption, ctx)

Both flow through the orchestrator. The orchestrator owns Zoho writes,
Storage uploads (Layer 1), transaction_events (Layer 2), and
the CB↔Zoho linkage (Layer 3).
"""
import logging
from dataclasses import asdict
from datetime import date as date_t
from decimal import ROUND_HALF_EVEN, Decimal
from typing import Any
from uuid import UUID

from database import get_db
from orchestrator.engine import Document, ModuleResult, OrchContext, ZohoWrite
from categorizer.coa import (
    get_expense_accounts,
    match_category,
    suggest_categories,
)
from transactions.confidence import ConfidenceDecision, FieldFlag, evaluate
from transactions.dedup import (
    DuplicateMatch,
    find_recent_duplicate,
    format_for_user,
    sha256_hex,
)
from transactions.extractor_v2 import (
    ExtractedTransaction,
    extract_from_image,
    extract_from_text,
)
from transactions.payment_cascade import ResolutionResult, resolve

logger = logging.getLogger(__name__)

VAT_RATE = Decimal("0.05")
ONE_PLUS_RATE = Decimal("1.05")
TWO_PLACES = Decimal("0.01")


# ---------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------

class CaptureTextInput:
    def __init__(self, text: str, sender: str | None = None):
        self.text = text
        self.sender = sender


class CaptureImageInput:
    def __init__(
        self,
        image_bytes: bytes,
        mime: str,
        caption: str | None = None,
        sender: str | None = None,
    ):
        self.image_bytes = image_bytes
        self.mime = mime
        self.caption = caption
        self.sender = sender


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_BUILTIN_FOREIGN_VENDORS: tuple[str, ...] = (
    # Cloud / SaaS — service imports → UAE reverse charge applies
    "aws", "amazon web services", "google cloud", "microsoft", "azure",
    "anthropic", "openai", "github", "gitlab", "cloudflare", "vercel",
    "netlify", "digitalocean", "linode", "heroku", "atlassian", "jira",
    "slack", "notion", "figma", "stripe", "paypal", "twilio", "sendgrid",
    "zoom", "dropbox", "datadog", "sentry", "linear", "intercom",
    "mailchimp", "hubspot", "salesforce", "shopify", "zapier", "calendly",
    "supabase", "vercel", "fly.io", "render",
)


def _is_foreign_vendor(vendor: str, cfg) -> bool:
    """True if vendor matches the per-client foreign_suppliers list OR a
    built-in well-known foreign service provider (covers the case where
    the client hasn't manually maintained their list)."""
    if not vendor:
        return False
    v = vendor.lower()
    if any(f.lower() in v for f in (cfg.foreign_suppliers or [])):
        return True
    return any(b in v for b in _BUILTIN_FOREIGN_VENDORS)


def _split_vat(gross: Decimal, is_rcm: bool) -> tuple[Decimal, Decimal]:
    if is_rcm:
        return gross.quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN), (gross * VAT_RATE).quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)
    net = (gross / ONE_PLUS_RATE).quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)
    vat = (gross - net).quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)
    return net, vat


def _format_confirmation_card(
    extracted: ExtractedTransaction,
    decision: ConfidenceDecision,
    resolution: ResolutionResult,
    is_rcm: bool,
    net: Decimal,
    vat: Decimal,
    gross: Decimal,
    currency: str,
    action_label: str,
    *,
    gross_aed: Decimal | None = None,
    fx_rate: Decimal | None = None,
) -> str:
    """Build the rich WhatsApp confirmation card showing all extracted fields
    plus flags and resolved payment account."""
    def cf(v) -> str:
        return "✅" if v == "high" else "⚠️"

    lines: list[str] = []
    lines.append(action_label)
    lines.append("")
    lines.append(f"{cf(extracted.vendor.confidence)} *Vendor:* {extracted.vendor.value or '—'}")
    lines.append(f"{cf(extracted.date.confidence)} *Date:* {extracted.date.value or 'today'}")
    lines.append(
        f"{cf(extracted.amount.confidence)} *Amount:* "
        f"{currency} {gross:,.2f}  (net {net:,.2f}, VAT {vat:,.2f})"
    )
    if (currency.upper() != "AED" and gross_aed is not None
            and fx_rate is not None and fx_rate != Decimal("1")):
        lines.append(
            f"💱 *AED equivalent:* AED {gross_aed:,.2f} @ {fx_rate:.4f}"
        )
    if extracted.vendor_trn.value:
        lines.append(f"📄 *Vendor TRN:* {extracted.vendor_trn.value}")
    if is_rcm:
        lines.append("🔁 *Reverse Charge:* yes (UAE imports/foreign supplier)")
    pmh = extracted.payment_method_hint.value
    if pmh:
        lines.append(f"{cf(extracted.payment_method_hint.confidence)} *Payment hint:* {pmh}")
    lines.append(
        f"💳 *Paid from:* {resolution.account_name} "
        f"({resolution.resolution_method.replace('_', ' ')})"
    )
    cat_name = decision.resolved_fields.get("category_account_name")
    if cat_name:
        lines.append(f"🏷️ *Category:* {cat_name}")
    elif extracted.category_hint.value:
        lines.append(
            f"🏷️ *Category:* {extracted.category_hint.value} "
            "(couldn't match to a Zoho account — will use default)"
        )

    if extracted.line_items.value:
        n = len(extracted.line_items.value)
        lines.append(f"📋 *Line items:* {n} {cf(extracted.line_items.confidence)}")

    if decision.flags:
        lines.append("")
        lines.append("*Needs your attention:*")
        for f in decision.flags:
            icon = "⛔️" if f.severity == "block" else ("⚠️" if f.severity == "warn" else "ℹ️")
            lines.append(f"  {icon} {f.reason}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# pending_reviews persistence
# ---------------------------------------------------------------------------

async def _save_pending_review(
    client_id: UUID,
    *,
    source_kind: str,
    source_text: str | None,
    extracted: ExtractedTransaction,
    decision: ConfidenceDecision,
    action: str,
    resolution: ResolutionResult | None,
    content_hash: str | None = None,
    is_rcm: bool = False,
) -> dict[str, Any]:
    db = await get_db()
    row = {
        "client_id": str(client_id),
        "source_kind": source_kind,
        "source_text": source_text,
        "extracted": _serialize_extracted(extracted),
        "flags": [asdict(f) for f in decision.flags],
        "resolved_fields": {
            **_json_safe_resolved(decision.resolved_fields),
            "payment_account_name": resolution.account_name if resolution else None,
            "payment_zoho_account_id": resolution.zoho_account_id if resolution else None,
            "payment_resolution_method": resolution.resolution_method if resolution else None,
            "payment_state": resolution.state if resolution else None,
            "payment_pending_last_four": resolution.pending_last_four if resolution else None,
            # Carry RCM + currency + FX so confirm_pending_review posts with
            # the same VAT treatment + currency we detected at capture time.
            "is_reverse_charge": bool(is_rcm),
        },
        "action": action,
    }
    if content_hash:
        # Stash the hash so the dedup query can find an in-flight pending entry
        # too (rare but possible: user sends same receipt twice in quick succession
        # while the first is still awaiting confirmation).
        row.setdefault("resolved_fields", {})["_content_hash"] = content_hash
    res = await db.table("pending_reviews").insert(row).execute()
    return res.data[0]


def _serialize_extracted(e: ExtractedTransaction) -> dict[str, Any]:
    """JSON-safe form of the extraction including value/confidence per field."""
    def fv(v):
        return {"value": v.value, "confidence": v.confidence}
    return {
        "vendor": fv(e.vendor),
        "date": fv(e.date),
        "amount": fv(e.amount),
        "vat_amount": fv(e.vat_amount),
        "currency": fv(e.currency),
        "payment_method_hint": fv(e.payment_method_hint),
        "category_hint": fv(e.category_hint),
        "vendor_trn": fv(e.vendor_trn),
        "line_items": {
            "value": [asdict(i) for i in (e.line_items.value or [])],
            "confidence": e.line_items.confidence,
        },
    }


# ---------------------------------------------------------------------------
# Build Zoho Expense payload for the post / flag actions
# ---------------------------------------------------------------------------

def _build_expense_payload(
    resolved: dict[str, Any],
    decision: ConfidenceDecision,
    cfg,
    resolution: ResolutionResult,
    net: Decimal,
    vat: Decimal,
    is_rcm: bool,
    currency: str = "AED",
) -> dict[str, Any]:
    tax_ids = cfg.zoho_tax_ids or {}
    expense_account = tax_ids.get("_default_expense_account_id")
    tax_treatment = tax_ids.get("_default_tax_treatment")
    place_of_supply = tax_ids.get("_default_place_of_supply")
    standard_tax = tax_ids.get("standard")
    rcm_tax = tax_ids.get("reverse_charge") or standard_tax

    # If we resolved a category-specific account at capture time, prefer it
    # over the per-client _default_expense_account_id (which is usually a
    # generic "Uncategorized" account).
    resolved_account_id = resolved.get("category_account_id") or expense_account
    # Always send NET (pre-tax) to Zoho. Zoho applies the tax_id on top.
    # For RCM, Zoho generates the parallel +/- VAT entries via
    # is_reverse_charge_applied; never pre-add VAT to the amount field.
    payload: dict[str, Any] = {
        "date": str(resolved.get("date") or date_t.today().isoformat()),
        "amount": float(net),
        "description": _short_description(resolved),
        "is_inclusive_tax": False,
        "account_id": resolved_account_id,
        "paid_through_account_id": resolution.zoho_account_id,
        "vendor_name": resolved.get("vendor") or "Unknown",
    }
    if is_rcm:
        # RCM tax_id only when it's a distinct code from the standard rate.
        # Many UAE Zoho orgs only have one "Standard Rate" configured —
        # sending that for RCM inflates gross = net + 5%. Rely on
        # is_reverse_charge_applied alone in that case.
        if rcm_tax and rcm_tax != standard_tax:
            payload["tax_id"] = rcm_tax
        payload["is_reverse_charge_applied"] = True
        # tax_treatment describes the *vendor's* status, not the transaction
        # type. "reverse_charge" is NOT a valid Zoho UAE value — it returns
        # 400 "Invalid value passed for tax_treatment". For foreign suppliers
        # (RCM applies because they're outside the GCC), "non_gcc" is the
        # correct treatment.
        payload["tax_treatment"] = "non_gcc"
    else:
        if standard_tax:
            payload["tax_id"] = standard_tax
        if tax_treatment:
            payload["tax_treatment"] = tax_treatment
    if place_of_supply:
        payload["place_of_supply"] = place_of_supply
    return payload


def _short_description(resolved: dict[str, Any]) -> str:
    items = resolved.get("line_items") or []
    if items:
        descs: list[str] = []
        for i in items[:3]:
            if isinstance(i, dict):
                d = i.get("description")
            else:
                d = getattr(i, "description", "")
            if d:
                descs.append(d)
        if descs:
            return ", ".join(descs)[:200]
    return resolved.get("vendor") or "Expense"


# ---------------------------------------------------------------------------
# Persist a transactions row + document
# ---------------------------------------------------------------------------

async def _save_transaction_row(
    client_id: UUID,
    *,
    resolved: dict[str, Any],
    net: Decimal,
    vat: Decimal,
    gross: Decimal,
    currency: str,
    is_rcm: bool,
    status: str,
    resolution: ResolutionResult,
    flags: list[Any],
    content_hash: str | None = None,
    fx_rate: Decimal = Decimal("1"),
    gross_aed: Decimal | None = None,
    vat_aed: Decimal | None = None,
) -> dict[str, Any]:
    db = await get_db()
    row = {
        "client_id": str(client_id),
        "vendor": resolved.get("vendor"),
        "description": _short_description(resolved),
        "direction": "expense",
        "amount": float(gross),
        "net_amount": float(net),
        "vat_amount": float(vat_aed if vat_aed is not None else vat),
        "currency": currency,
        "fx_rate": float(fx_rate),
        "amount_aed": float(gross_aed if gross_aed is not None else gross),
        "vat_type": "reverse_charge" if is_rcm else "standard",
        "vat_boxes": [4, 11] if is_rcm else [9],
        "tax_point_date": str(resolved.get("date") or date_t.today().isoformat()),
        "is_blocked_vat": False,
        "status": status,
        "routing_reason": "; ".join(f.reason for f in flags) or "auto",
        "zoho_entity_type": "Expense",
        "raw_payload": {
            "resolved": _json_safe_resolved(resolved),
            "payment_resolution": {
                "account_name": resolution.account_name,
                "method": resolution.resolution_method,
            },
        },
        "content_hash": content_hash,
    }
    return (await db.table("transactions").insert(row).execute()).data[0]


def _json_safe_resolved(resolved: dict[str, Any]) -> dict[str, Any]:
    """Convert Decimals + dataclass LineItems into JSON-serializable shapes."""
    out: dict[str, Any] = {}
    for k, v in resolved.items():
        if isinstance(v, Decimal):
            out[k] = str(v)
        elif k == "line_items" and v:
            out[k] = [
                asdict(i) if not isinstance(i, dict) else i
                for i in v
            ]
        else:
            out[k] = v
    return out


# ---------------------------------------------------------------------------
# Core capture flow used by both text + image entry points
# ---------------------------------------------------------------------------

async def _capture(
    extracted: ExtractedTransaction,
    ctx: OrchContext,
    source_kind: str,
    source_text: str | None,
    source_doc: tuple[bytes, str, str] | None,    # (bytes, mime, filename) for images
    message_text: str,
) -> ModuleResult:
    cfg = ctx.cfg
    decision = evaluate(extracted)
    resolution = await resolve(message_text, extracted.payment_method_hint.value, cfg)

    # Treat missing/ambiguous payment as a hold, not a silent default. The
    # follow-up tools (provide_payment_method / register_card) resume the
    # post once the user answers.
    if resolution.state == "needs_method":
        decision.add(
            FieldFlag(
                "payment",
                "How was this paid? (cash / card / bank transfer)",
                "warn",
            ),
            "hold",
        )
    elif resolution.state == "needs_card_digits":
        decision.add(
            FieldFlag(
                "payment",
                "Card mentioned — what are the last 4 digits?",
                "warn",
            ),
            "hold",
        )
    elif resolution.state == "needs_card_label":
        decision.add(
            FieldFlag(
                "payment",
                f"Card ••{resolution.pending_last_four} isn't on file yet — "
                "what would you like to call it? (e.g. 'Company Visa')",
                "warn",
            ),
            "hold",
        )

    is_rcm = _is_foreign_vendor(extracted.vendor.value or "", cfg)

    # Category resolution — translate user's stated category (if any) into
    # a Zoho expense account_id. Vendor alone is intentionally NOT used as
    # a category signal (Carrefour can be groceries / office / meals / etc).
    category_options: list[str] = []
    category_resolved = False
    if (extracted.category_hint.confidence == "high"
            and extracted.category_hint.value
            and ctx.resolver is not None):
        try:
            accounts = await get_expense_accounts(cfg.id, ctx.resolver._zoho)
            match = match_category(extracted.category_hint.value, accounts)
            if match:
                decision.resolved_fields["category_account_id"] = match["account_id"]
                decision.resolved_fields["category_account_name"] = match["account_name"]
                category_resolved = True
            else:
                # Have category text but no matching Zoho account
                category_options = suggest_categories(accounts)
        except Exception:
            logger.exception("Category resolution failed (non-fatal)")
    elif ctx.resolver is not None:
        # No category stated — fetch options so we can prompt the user
        try:
            accounts = await get_expense_accounts(cfg.id, ctx.resolver._zoho)
            category_options = suggest_categories(accounts)
        except Exception:
            logger.exception("Category options fetch failed (non-fatal)")

    if not category_resolved:
        decision.add(
            FieldFlag(
                "category",
                "What was this expense for? Reply with a category to post.",
                "warn",
            ),
            "hold",
        )

    # Duplicate detection — hash image bytes, run dedup, downgrade to "hold"
    # on a match so the user explicitly confirms before posting.
    content_hash: str | None = None
    if source_doc:
        content_hash = sha256_hex(source_doc[0])
    dup_match: DuplicateMatch | None = await find_recent_duplicate(
        cfg.id, "transaction",
        content_hash=content_hash,
        vendor=decision.resolved_fields.get("vendor"),
        amount=decision.resolved_fields.get("amount"),
        when=decision.resolved_fields.get("date"),
    )
    if dup_match:
        decision.add(
            FieldFlag(
                "duplicate",
                f"matches prior {dup_match.kind} via {dup_match.signal}",
                "warn",
            ),
            "hold",
        )

    # If amount is blocked we cannot compute gross → still try to surface
    gross = decision.resolved_fields.get("amount") or Decimal("0")
    currency = decision.resolved_fields.get("currency") or "AED"

    # Multi-currency: convert to AED for VAT 201 reporting + audit trail.
    # The original-currency gross still drives the Zoho post (Zoho handles
    # multi-currency invoicing natively when the org has it enabled).
    fx_rate = Decimal("1")
    gross_aed = gross
    if currency.upper() != "AED" and gross > 0:
        try:
            from transactions.currency import to_aed
            gross_aed, fx_rate = await to_aed(gross, currency)
        except Exception:
            logger.exception(
                "FX conversion failed for %s %s — falling back to no-conversion "
                "(audit trail will show fx_rate=1)", gross, currency,
            )
            gross_aed = gross
            fx_rate = Decimal("1")

    # FTA requires VAT to be computed on the AED amount; we keep the original-
    # currency split for the Zoho payload (Zoho recomputes its own AED amount).
    net, vat = _split_vat(gross, is_rcm) if gross > 0 else (Decimal("0"), Decimal("0"))
    net_aed, vat_aed = (
        _split_vat(gross_aed, is_rcm) if gross_aed > 0 else (Decimal("0"), Decimal("0"))
    )

    documents: list[Document] = []
    if source_doc:
        bytes_, mime, filename = source_doc
        documents.append(Document(
            entity_type="transaction",
            body=bytes_,
            filename=filename,
            mime_type=mime,
        ))

    extra_events: list[dict[str, Any]] = [
        {"event_type": "extracted",
         "payload": {"source_kind": source_kind,
                     "fields": _serialize_extracted(extracted)}},
        {"event_type": "confidence_evaluated",
         "payload": {"action": decision.action,
                     "flags": [asdict(f) for f in decision.flags]}},
        {"event_type": "payment_resolved",
         "payload": {"method": resolution.resolution_method,
                     "account_id": resolution.zoho_account_id,
                     "account_name": resolution.account_name}},
    ]

    # -------- block / hold: write to pending_reviews, no Zoho call --------
    if decision.action in {"block", "hold"}:
        pr = await _save_pending_review(
            cfg.id,
            source_kind=source_kind,
            source_text=source_text,
            extracted=extracted,
            decision=decision,
            action=decision.action,
            resolution=resolution,
            content_hash=content_hash,
            is_rcm=is_rcm,
        )
        needs_category = not category_resolved and decision.action == "hold"
        if dup_match:
            action_label = "🟡 Holding — looks like a duplicate"
        elif needs_category:
            action_label = "🟡 What was this for?"
        elif decision.action == "block":
            action_label = "⛔️ Held for your review — won't post until resolved"
        else:
            action_label = "🟡 Holding for your confirmation"
        reply = _format_confirmation_card(
            extracted, decision, resolution, is_rcm, net, vat, gross, currency, action_label,
            gross_aed=gross_aed, fx_rate=fx_rate,
        )
        if dup_match:
            reply = format_for_user(dup_match) + "\n\n" + reply
        if needs_category and category_options:
            reply += (
                "\n\nReply with one of: "
                + " / ".join(category_options)
                + "\n(or just type what it was for, e.g. 'lunch', 'office supplies')"
            )
        else:
            reply += "\n\nReply 'confirm' to post anyway, 'edit' to adjust, or 'cancel' to discard."
        return ModuleResult(
            reply_to_user=reply,
            documents=documents,
            extra_events=extra_events + [{
                "event_type": "pending_review_created",
                "payload": {"pending_review_id": pr["id"], "action": decision.action},
            }],
            entity_kind="transaction",
            entity_id=pr["id"],
        )

    # -------- post / flag: persist transactions row, declare Zoho write --------
    status = "auto_posted" if decision.action == "post" else "needs_review"
    txn_row = await _save_transaction_row(
        cfg.id,
        resolved=decision.resolved_fields,
        net=net, vat=vat, gross=gross, currency=currency,
        is_rcm=is_rcm, status=status, resolution=resolution,
        flags=decision.flags,
        content_hash=content_hash,
        fx_rate=fx_rate, gross_aed=gross_aed, vat_aed=vat_aed,
    )

    payload = _build_expense_payload(
        decision.resolved_fields, decision, cfg, resolution,
        net, vat, is_rcm, currency=currency,
    )
    # Multi-currency: Zoho's expense API wants the org-internal currency_id
    # (UUID), not the ISO code, plus an exchange_rate when posting in a
    # non-base currency. Resolve from Zoho's /settings/currencies (cached).
    if currency.upper() != "AED" and ctx.resolver is not None:
        try:
            from transactions.currency import get_zoho_currency_id
            ccy_id = await get_zoho_currency_id(
                ctx.resolver._zoho, cfg.id, currency,
            )
            if ccy_id:
                payload["currency_id"] = ccy_id
                payload["exchange_rate"] = float(fx_rate)
            else:
                logger.warning(
                    "Zoho org has no currency configured for %s — posting in AED. "
                    "Enable multi-currency in Zoho Settings → Currencies.",
                    currency,
                )
        except Exception:
            logger.exception("currency_id lookup failed (non-fatal)")
    zoho_writes = [ZohoWrite(
        method="POST",
        endpoint="expenses",
        payload=payload,
        bind_to_entity=("transaction", txn_row["id"]),
    )]

    action_label = "✅ Posting to Zoho Books" if decision.action == "post" \
        else "⚠️ Posting with flags — please review the items below"
    reply = _format_confirmation_card(
        extracted, decision, resolution, is_rcm, net, vat, gross, currency, action_label,
        gross_aed=gross_aed, fx_rate=fx_rate,
    )

    return ModuleResult(
        reply_to_user=reply,
        zoho_writes=zoho_writes,
        documents=documents,
        extra_events=extra_events,
        entity_kind="transaction",
        entity_id=txn_row["id"],
    )


# ---------------------------------------------------------------------------
# Public entry points (handlers passed to orchestrator.engine.process)
# ---------------------------------------------------------------------------

async def capture_text(input: CaptureTextInput, ctx: OrchContext) -> ModuleResult:
    try:
        extracted = await extract_from_text(input.text, ctx.cfg)
    except Exception as e:
        logger.exception("Extraction failed")
        return ModuleResult(reply_to_user=f"Couldn't parse the expense: {e}")
    return await _capture(
        extracted, ctx,
        source_kind="text",
        source_text=input.text,
        source_doc=None,
        message_text=input.text,
    )


async def capture_image(input: CaptureImageInput, ctx: OrchContext) -> ModuleResult:
    try:
        extracted = await extract_from_image(
            input.image_bytes, input.mime, ctx.cfg, caption=input.caption,
        )
    except Exception as e:
        logger.exception("Image extraction failed")
        return ModuleResult(reply_to_user=f"Couldn't read that receipt: {e}")
    # Use caption as message_text for payment-method detection
    return await _capture(
        extracted, ctx,
        source_kind="image",
        source_text=input.caption,
        source_doc=(input.image_bytes, input.mime, f"receipt_{ctx.cfg.id}.jpg"),
        message_text=input.caption or "",
    )
