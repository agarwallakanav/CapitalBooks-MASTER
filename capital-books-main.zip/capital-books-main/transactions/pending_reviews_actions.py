"""Resolve a pending_review (confirm / edit / cancel) — Phase: Transactions Bot.

  confirm_pending_review(input, ctx) → ModuleResult
      Loads latest awaiting_user pending_review row, builds the Zoho Expense
      payload from resolved_fields, declares a ZohoWrite, marks status=resolved.

  cancel_pending_review(input, ctx) → ModuleResult
      Soft-discards the row (status=discarded) so it disappears from queues.
"""
import logging
from datetime import date as date_t, datetime, timezone
from decimal import Decimal
from typing import Any
from uuid import UUID

from categorizer.coa import get_expense_accounts, match_category
from database import get_db
from orchestrator.engine import ModuleResult, OrchContext, ZohoWrite
from transactions.cards import get_card_by_last4, list_cards, save_card

logger = logging.getLogger(__name__)


class PendingReviewAction:
    def __init__(
        self,
        sender: str | None = None,
        category: str | None = None,
        payment_method: str | None = None,
        card_last_4: str | None = None,
    ):
        self.sender = sender
        # If the pending row was holding waiting for a category, this is the
        # user's reply (e.g. "lunch", "office supplies") that we resolve into
        # a Zoho account_id before posting.
        self.category = category
        # Payment follow-up: cash / card / bank_transfer / online — used when
        # the pending row was holding because no payment method was stated.
        self.payment_method = (payment_method or "").strip().lower() or None
        self.card_last_4 = (card_last_4 or "").strip() or None


class RegisterCardAction:
    """User just told us what to call a newly-seen card. We save it to
    client_cards, attach the resolved Zoho account, and then post the
    held expense (single round-trip)."""
    def __init__(
        self,
        label: str,
        sender: str | None = None,
        last_four: str | None = None,
        zoho_account_id: str | None = None,
    ):
        self.label = (label or "").strip()
        self.sender = sender
        self.last_four = (last_four or "").strip() or None
        self.zoho_account_id = (zoho_account_id or "").strip() or None


async def _latest_pending(client_id: UUID) -> dict[str, Any] | None:
    db = await get_db()
    res = (
        await db.table("pending_reviews")
        .select("*")
        .eq("client_id", str(client_id))
        .eq("status", "awaiting_user")
        .order("created_at", desc=True)
        .limit(1)
        .execute()
    )
    return (res.data or [None])[0]


async def confirm_pending_review(input: PendingReviewAction, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    pr = await _latest_pending(cfg.id)
    if not pr:
        return ModuleResult(reply_to_user="No pending review to confirm.")

    resolved = pr["resolved_fields"] or {}
    vendor = resolved.get("vendor") or "Unknown"
    gross = Decimal(str(resolved.get("amount") or 0))
    currency = resolved.get("currency") or "AED"
    when = resolved.get("date") or date_t.today().isoformat()

    tax_ids = cfg.zoho_tax_ids or {}
    default_expense_account = tax_ids.get("_default_expense_account_id")
    standard_tax = tax_ids.get("standard")
    tax_treatment = tax_ids.get("_default_tax_treatment")
    place_of_supply = tax_ids.get("_default_place_of_supply")

    # Category resolution — pending row may carry one from capture, OR the
    # user's confirm message may carry one ("lunch"). User reply wins.
    expense_account = default_expense_account
    category_account_name: str | None = None
    user_category = (input.category or "").strip()
    pending_category_account = resolved.get("category_account_id")
    if user_category and ctx.resolver is not None:
        try:
            accounts = await get_expense_accounts(cfg.id, ctx.resolver._zoho)
            match = match_category(user_category, accounts)
            if match:
                expense_account = match["account_id"]
                category_account_name = match["account_name"]
        except Exception:
            logger.exception("Confirm-time category resolution failed (non-fatal)")
    elif pending_category_account:
        expense_account = pending_category_account
        category_account_name = resolved.get("category_account_name")

    # Payment resolution — user's confirm reply may carry a method
    # (cash/card/bank) or card_last_4; resolve against the cards registry.
    paid_through = resolved.get("payment_zoho_account_id")
    paid_through_label = resolved.get("payment_account_name") or "(unspecified)"
    payment_state = resolved.get("payment_state")

    if input.card_last_4:
        card = await get_card_by_last4(cfg.id, input.card_last_4)
        if card and card.zoho_account_id:
            paid_through = card.zoho_account_id
            paid_through_label = f"{card.label} ••{card.last_four}"
        else:
            # Digits provided but unknown — re-park as needs_card_label so
            # the next reply (a label) can register it.
            db = await get_db()
            new_rf = {
                **resolved,
                "payment_state": "needs_card_label",
                "payment_pending_last_four": input.card_last_4,
            }
            await (db.table("pending_reviews")
                   .update({"resolved_fields": new_rf})
                   .eq("id", pr["id"]).execute())
            return ModuleResult(
                reply_to_user=(
                    f"Card ••{input.card_last_4} isn't on file yet. "
                    "What would you like to call it? "
                    "(e.g. 'Company Visa', 'Neil personal Mastercard')"
                ),
                extra_events=[{
                    "event_type": "pending_review_awaiting_card_label",
                    "payload": {"pending_review_id": pr["id"],
                                "last_four": input.card_last_4},
                }],
            )
    elif input.payment_method:
        method = input.payment_method
        if method in ("card", "credit_card", "debit_card", "visa", "mastercard", "amex"):
            cards = await list_cards(cfg.id)
            if len(cards) == 1 and cards[0].zoho_account_id:
                c = cards[0]
                paid_through = c.zoho_account_id
                paid_through_label = f"{c.label} ••{c.last_four}"
            else:
                # Same re-park pattern — ask for digits.
                db = await get_db()
                new_rf = {**resolved, "payment_state": "needs_card_digits"}
                await (db.table("pending_reviews")
                       .update({"resolved_fields": new_rf})
                       .eq("id", pr["id"]).execute())
                return ModuleResult(
                    reply_to_user="What are the last 4 digits on the card?",
                    extra_events=[{
                        "event_type": "pending_review_awaiting_card_digits",
                        "payload": {"pending_review_id": pr["id"]},
                    }],
                )
        elif method == "cash":
            cash_acct = tax_ids.get("_default_paid_through_account_id")
            if cash_acct:
                paid_through = cash_acct
                paid_through_label = "Petty Cash"
        elif method in ("bank_transfer", "bank", "transfer", "wire", "online"):
            if cfg.default_payment_account:
                paid_through = cfg.default_payment_account
                paid_through_label = "Bank (default)"

    # If the pending hold was for an unresolved payment AND the user's reply
    # didn't include a payment method or card digits, we must NOT silently
    # post with a default account — re-park the review and ask again.
    user_provided_payment = bool(input.payment_method or input.card_last_4)
    if payment_state in ("needs_method", "needs_card_digits", "needs_card_label") \
            and not user_provided_payment:
        # Persist any category we just resolved so the user only has to
        # answer the remaining question, then re-ask the payment one.
        db = await get_db()
        patched_rf = {**resolved}
        if category_account_name:
            patched_rf["category_account_id"] = expense_account
            patched_rf["category_account_name"] = category_account_name
        await (db.table("pending_reviews")
               .update({"resolved_fields": patched_rf})
               .eq("id", pr["id"]).execute())
        prompts = {
            "needs_method": "How was this paid? (cash / card / bank transfer)",
            "needs_card_digits": "What are the last 4 digits on the card?",
            "needs_card_label": (
                f"Card ••{resolved.get('payment_pending_last_four', '----')} "
                "isn't on file yet — what would you like to call it? "
                "(e.g. 'Company Visa')"
            ),
        }
        return ModuleResult(
            reply_to_user=prompts[payment_state],
            extra_events=[{
                "event_type": "pending_review_still_awaiting_payment",
                "payload": {"pending_review_id": pr["id"],
                            "payment_state": payment_state},
            }],
        )

    # Final fallback to the configured default if still unresolved AND
    # the original capture didn't hold for payment (e.g. text expense that
    # already had a payment hint resolve cleanly).
    if not paid_through:
        paid_through = tax_ids.get("_default_paid_through_account_id")
        if paid_through:
            paid_through_label = "Petty Cash (default)"

    # RCM was determined at capture time (foreign supplier or per-client list).
    # If true, use the reverse_charge tax_id; gross stays gross (no inclusive
    # split — RCM expenses pre-include their notional VAT separately).
    is_rcm = bool(resolved.get("is_reverse_charge"))
    rcm_tax = tax_ids.get("reverse_charge") or tax_ids.get("standard")

    if gross > 0:
        if is_rcm:
            net = gross.quantize(Decimal("0.01"))
            vat = (gross * Decimal("0.05")).quantize(Decimal("0.01"))
        else:
            net = (gross / Decimal("1.05")).quantize(Decimal("0.01"))
            vat = (gross - net).quantize(Decimal("0.01"))
    else:
        net, vat = Decimal("0"), Decimal("0")

    payload: dict[str, Any] = {
        "date": when,
        "amount": float(net),
        "description": vendor,
        "is_inclusive_tax": False,
        "account_id": expense_account,
        "paid_through_account_id": paid_through,
        "vendor_name": vendor,
    }
    if is_rcm:
        if rcm_tax and rcm_tax != standard_tax:
            payload["tax_id"] = rcm_tax
        payload["is_reverse_charge_applied"] = True
        # Zoho UAE rejects tax_treatment="reverse_charge" (400 code 2).
        # "non_gcc" is the correct vendor treatment for AWS/Google/etc.
        payload["tax_treatment"] = "non_gcc"
    else:
        if standard_tax:
            payload["tax_id"] = standard_tax
        if tax_treatment:
            payload["tax_treatment"] = tax_treatment
    if place_of_supply:
        payload["place_of_supply"] = place_of_supply

    # Multi-currency — currency_id (UUID) + exchange_rate. Also pre-compute
    # AED amounts for the Supabase row so VAT 201 reporting is correct.
    fx_rate = Decimal("1")
    gross_aed = gross
    vat_aed = vat
    if currency.upper() != "AED":
        try:
            from transactions.currency import (
                get_rate, get_zoho_currency_id, to_aed,
            )
            gross_aed, fx_rate = await to_aed(gross, currency)
            vat_aed = (
                (gross_aed * Decimal("0.05")).quantize(Decimal("0.01"))
                if is_rcm else
                (gross_aed - (gross_aed / Decimal("1.05")).quantize(Decimal("0.01")))
            )
            if ctx.resolver is not None:
                ccy_id = await get_zoho_currency_id(
                    ctx.resolver._zoho, cfg.id, currency,
                )
                if ccy_id:
                    payload["currency_id"] = ccy_id
                    payload["exchange_rate"] = float(fx_rate)
        except Exception:
            logger.exception("Confirm-time currency/FX failed (non-fatal)")

    # Insert the transactions row so we have a CB id to bind to.
    db = await get_db()
    txn_row = (await db.table("transactions").insert({
        "client_id": str(cfg.id),
        "vendor": vendor,
        "description": vendor,
        "direction": "expense",
        "amount": float(gross),
        "net_amount": float(net),
        "vat_amount": float(vat_aed),
        "currency": currency,
        "fx_rate": float(fx_rate),
        "amount_aed": float(gross_aed),
        "vat_type": "reverse_charge" if is_rcm else "standard",
        "vat_boxes": [4, 11] if is_rcm else [9],
        "tax_point_date": when,
        "is_blocked_vat": False,
        "status": "auto_posted",
        "routing_reason": "Confirmed from pending_review",
        "zoho_entity_type": "Expense",
        "raw_payload": {"from_pending_review_id": pr["id"]},
    }).execute()).data[0]

    # Mark pending_review resolved
    await (
        db.table("pending_reviews")
        .update({
            "status": "resolved",
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("id", pr["id"])
        .execute()
    )

    cat_line = f"\nCategory: {category_account_name}" if category_account_name else ""
    return ModuleResult(
        reply_to_user=(
            f"✅ Posted to Zoho Books\n"
            f"Vendor: {vendor}\n"
            f"Amount: {currency} {gross:,.2f} (net {net:,.2f}, VAT {vat:,.2f})"
            f"{cat_line}\n"
            f"Paid with: {paid_through_label}\n"
            f"Date: {when}"
        ),
        zoho_writes=[ZohoWrite(
            method="POST",
            endpoint="expenses",
            payload=payload,
            bind_to_entity=("transaction", txn_row["id"]),
        )],
        extra_events=[
            {"event_type": "pending_review_confirmed",
             "payload": {"pending_review_id": pr["id"],
                         "transaction_id": txn_row["id"]}},
        ],
        entity_kind="transaction",
        entity_id=txn_row["id"],
    )


async def register_card_and_post(
    input: RegisterCardAction, ctx: OrchContext,
) -> ModuleResult:
    """Register a newly-seen card with the user's chosen label, set it as
    the payment account on the most-recent pending_review, and resume the
    post (single round-trip)."""
    cfg = ctx.cfg
    if not input.label:
        return ModuleResult(reply_to_user="I need a label for the card — what should I call it?")

    pr = await _latest_pending(cfg.id)
    if not pr:
        return ModuleResult(
            reply_to_user="No pending expense waiting on a card name.",
        )
    resolved = pr["resolved_fields"] or {}
    last_four = input.last_four or resolved.get("payment_pending_last_four")
    if not last_four:
        return ModuleResult(
            reply_to_user=(
                "I don't have the card's last 4 digits — please re-send "
                "the expense and include the digits (e.g. 'card 4521')."
            ),
        )

    # Pick the best Zoho account for this card. Order:
    #   1. Explicit override from the tool input
    #   2. A Zoho "credit_card" type bank account (best match for a card)
    #   3. The client's default_payment_account
    #   4. The configured petty-cash fallback
    tax_ids = cfg.zoho_tax_ids or {}
    zoho_acct = input.zoho_account_id
    if not zoho_acct and ctx.resolver is not None:
        try:
            resp = await ctx.resolver._zoho.list_entities(
                "bankaccounts", filters={},
            )
            accounts = resp.get("bankaccounts") or []
            cc = next(
                (a for a in accounts if a.get("account_type") == "credit_card"),
                None,
            )
            if cc and cc.get("account_id"):
                zoho_acct = cc["account_id"]
        except Exception:
            logger.exception("Zoho bankaccounts lookup failed (non-fatal)")
    if not zoho_acct:
        zoho_acct = cfg.default_payment_account \
            or tax_ids.get("_default_paid_through_account_id")
    try:
        card = await save_card(
            cfg.id, last_four=last_four, label=input.label,
            zoho_account_id=zoho_acct,
        )
    except Exception as e:
        logger.exception("save_card failed")
        return ModuleResult(reply_to_user=f"Couldn't save the card: {e}")

    # Patch the pending review's resolved_fields so confirm_pending_review
    # picks up the new payment account, then re-invoke confirm.
    db = await get_db()
    new_rf = {
        **resolved,
        "payment_zoho_account_id": card.zoho_account_id,
        "payment_account_name": f"{card.label} ••{card.last_four}",
        "payment_resolution_method": "card_match",
        "payment_state": "resolved",
    }
    await (db.table("pending_reviews")
           .update({"resolved_fields": new_rf})
           .eq("id", pr["id"]).execute())

    # Resume the post — uses the patched payment fields, no new user input.
    return await confirm_pending_review(
        PendingReviewAction(sender=input.sender), ctx,
    )


async def cancel_pending_review(input: PendingReviewAction, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    pr = await _latest_pending(cfg.id)
    if not pr:
        return ModuleResult(reply_to_user="No pending review to cancel.")
    db = await get_db()
    await (
        db.table("pending_reviews")
        .update({
            "status": "discarded",
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("id", pr["id"])
        .execute()
    )
    return ModuleResult(
        reply_to_user="🗑️ Cancelled. The expense was not posted.",
        extra_events=[
            {"event_type": "pending_review_cancelled",
             "payload": {"pending_review_id": pr["id"]}},
        ],
    )
