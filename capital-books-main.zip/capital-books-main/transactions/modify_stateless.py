"""Stateless edit/delete for posted transactions — Phase C-final."""
import json
import logging
from decimal import ROUND_HALF_EVEN, Decimal
from typing import Any
from uuid import UUID

from anthropic import AsyncAnthropic

from config import settings
from database import get_db
from orchestrator.engine import ModuleResult, OrchContext, ZohoWrite
from zoho.entities import endpoint_for

logger = logging.getLogger(__name__)

VAT_RATE = Decimal("0.05")
ONE_PLUS_RATE = Decimal("1.05")
TWO_PLACES = Decimal("0.01")

_anthropic: AsyncAnthropic | None = None


def _claude() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


# ---------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------

class EditInput:
    def __init__(self, instruction: str, sender: str | None = None):
        self.instruction = instruction
        self.sender = sender


class DeleteInput:
    def __init__(self, sender: str | None = None):
        self.sender = sender


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_EDIT_PROMPT = """The user wants to edit a transaction. Current values:
{current}

Their edit request: "{instruction}"

Extract ONLY the fields they want to change. Return JSON like:
{{"vendor": "<new>" or null, "amount": <number> or null, "description": "<new>" or null}}

Use null for fields they didn't mention. Don't guess. JSON only, no prose."""


def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return text.strip()


async def _parse_edit(instruction: str, snapshot: dict[str, Any]) -> dict[str, Any]:
    current = (
        f"  vendor: {snapshot.get('vendor')}\n"
        f"  amount: {snapshot.get('amount')} {snapshot.get('currency')}\n"
        f"  description: {snapshot.get('description')}"
    )
    resp = await _claude().messages.create(
        model=settings.anthropic_model_fast,
        max_tokens=300,
        messages=[{
            "role": "user",
            "content": _EDIT_PROMPT.format(current=current, instruction=instruction),
        }],
    )
    raw = _strip_fences(
        "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    )
    data = json.loads(raw)
    changes: dict[str, Any] = {}
    if data.get("vendor"):
        changes["vendor"] = str(data["vendor"]).strip()
    if data.get("amount") is not None:
        try:
            changes["amount"] = Decimal(str(data["amount"]))
        except Exception:
            pass
    if data.get("description"):
        changes["description"] = str(data["description"]).strip()
    return changes


def _recompute_vat(gross: Decimal, vat_type: str | None) -> tuple[Decimal, Decimal]:
    if vat_type == "standard":
        net = (gross / ONE_PLUS_RATE).quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)
        vat = (gross - net).quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)
        return net, vat
    return gross.quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN), Decimal("0.00")


async def _latest_active_transaction(client_id: UUID) -> dict[str, Any] | None:
    db = await get_db()
    res = (
        await db.table("transactions")
        .select(
            "id, vendor, description, amount, net_amount, vat_amount, currency, "
            "vat_type, status, zoho_entity_type, zoho_entity_id, direction, created_at"
        )
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .in_("status", ["auto_posted", "manually_categorized"])
        .order("created_at", desc=True)
        .limit(1)
        .execute()
    )
    return (res.data or [None])[0]


# ---------------------------------------------------------------------------
# Edit
# ---------------------------------------------------------------------------

async def edit_latest(input: EditInput, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    txn = await _latest_active_transaction(cfg.id)
    if not txn:
        return ModuleResult(reply_to_user="No transactions to edit.")

    snapshot = {
        "vendor": txn["vendor"],
        "amount": float(txn["amount"]),
        "description": txn["description"],
        "currency": txn["currency"],
        "vat_type": txn["vat_type"],
    }
    try:
        changes = await _parse_edit(input.instruction, snapshot)
    except Exception:
        logger.exception("Edit parse failed")
        return ModuleResult(reply_to_user="Couldn't parse the edit. Try 'change vendor to X' or 'amount 600'.")

    if not changes:
        return ModuleResult(reply_to_user="No changes detected. Try again.")

    entity_type = txn["zoho_entity_type"]
    entity_id = txn["zoho_entity_id"]
    endpoint = endpoint_for(entity_type)

    zoho_payload: dict[str, Any] = {}
    supabase_payload: dict[str, Any] = {}
    summary: dict[str, Any] = {}

    if "vendor" in changes:
        zoho_payload["vendor_name"] = changes["vendor"]
        supabase_payload["vendor"] = changes["vendor"]
        summary["vendor"] = changes["vendor"]
    if "description" in changes:
        if entity_type == "Expense":
            zoho_payload["description"] = changes["description"]
        else:
            zoho_payload["notes"] = changes["description"]
        supabase_payload["description"] = changes["description"]
        summary["description"] = changes["description"]
    if "amount" in changes:
        gross = Decimal(changes["amount"])
        net, vat = _recompute_vat(gross, txn.get("vat_type"))
        if entity_type == "Expense":
            zoho_payload["amount"] = float(net)
        else:
            return ModuleResult(
                reply_to_user="Amount edits on bills/invoices need line-item rewrite — not supported yet.",
            )
        supabase_payload["amount"] = float(gross)
        supabase_payload["net_amount"] = float(net)
        supabase_payload["vat_amount"] = float(vat)
        summary["amount"] = f"{gross} (net {net}, vat {vat})"

    # UAE PUT requires these fields
    tax_treatment = (cfg.zoho_tax_ids or {}).get("_default_tax_treatment")
    place_of_supply = (cfg.zoho_tax_ids or {}).get("_default_place_of_supply")
    if tax_treatment:
        zoho_payload["tax_treatment"] = tax_treatment
    if place_of_supply:
        zoho_payload["place_of_supply"] = place_of_supply

    zoho_writes: list[ZohoWrite] = []
    if entity_id and zoho_payload:
        zoho_writes.append(ZohoWrite(
            method="PUT",
            endpoint=f"{endpoint}/{entity_id}",
            payload=zoho_payload,
        ))

    if supabase_payload:
        db = await get_db()
        await db.table("transactions").update(supabase_payload).eq("id", txn["id"]).execute()

    bits = ", ".join(f"{k}: {v}" for k, v in summary.items())
    return ModuleResult(
        reply_to_user=f"✅ Updated in Zoho Books.\nChanges: {bits}",
        zoho_writes=zoho_writes,
        extra_events=[{
            "event_type": "transaction_edited",
            "payload": {"transaction_id": txn["id"], "changes": summary},
        }],
        entity_kind="transaction",
        entity_id=txn["id"],
    )


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------

async def delete_latest(input: DeleteInput, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    txn = await _latest_active_transaction(cfg.id)
    if not txn:
        return ModuleResult(reply_to_user="No transactions to delete.")

    entity_type = txn["zoho_entity_type"]
    entity_id = txn["zoho_entity_id"]
    endpoint = endpoint_for(entity_type)

    zoho_writes: list[ZohoWrite] = []
    if entity_id:
        zoho_writes.append(ZohoWrite(
            method="DELETE",
            endpoint=f"{endpoint}/{entity_id}",
        ))

    # Soft-delete in Supabase regardless of Zoho outcome
    db = await get_db()
    await db.table("transactions").update({"deleted": True}).eq("id", txn["id"]).execute()

    return ModuleResult(
        reply_to_user=(
            f"🗑️ Deleted: {txn['vendor']} — {txn['amount']} {txn['currency']}"
        ),
        zoho_writes=zoho_writes,
        extra_events=[{
            "event_type": "transaction_deleted",
            "payload": {
                "transaction_id": txn["id"],
                "vendor": txn["vendor"],
                "amount": float(txn["amount"]),
            },
        }],
        entity_kind="transaction",
        entity_id=txn["id"],
    )
