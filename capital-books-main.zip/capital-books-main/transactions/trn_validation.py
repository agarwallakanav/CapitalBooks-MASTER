"""Step 2: TRN format validation. UAE TRNs are 15 digits and start with '100'."""
import re

from transactions.models import TransactionContext, TrnValidation

TRN_PATTERN = re.compile(r"^\d{15}$")


async def validate_trn(ctx: TransactionContext) -> TrnValidation:
    trn = (ctx.input.vendor_trn or "").strip()
    if not trn:
        reason = "No TRN found on document"
        if ctx.input.is_tax_invoice and ctx.input.direction == "expense":
            reason += " (required for input VAT claim on tax invoices)"
        return TrnValidation(
            present=False, format_valid=False, starts_with_100=False, reason=reason
        )

    format_valid = bool(TRN_PATTERN.match(trn))
    starts_with_100 = trn.startswith("100")

    reason: str | None = None
    if not format_valid:
        reason = "TRN must be exactly 15 digits"
    elif not starts_with_100:
        reason = "TRN must start with '100'"

    return TrnValidation(
        present=True,
        format_valid=format_valid,
        starts_with_100=starts_with_100,
        reason=reason,
    )
