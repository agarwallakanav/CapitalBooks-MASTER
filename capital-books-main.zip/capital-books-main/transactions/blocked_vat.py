"""Step 5: Block input VAT recovery on non-claimable categories per UAE FTA rules.

Keyword-based heuristic across vendor + description + category hint. Deliberately
deterministic — no AI call — so it runs cheaply in parallel with reverse_charge.
"""
from transactions.models import BlockedVatResult, TransactionContext

BLOCKED_KEYWORDS: dict[str, tuple[str, ...]] = {
    "entertainment": (
        "entertainment", "client dinner", "client lunch", "client event",
        "team outing", "team dinner", "social event", "hospitality",
    ),
    "motor_vehicle_personal": (
        "passenger car", "personal car", "private vehicle",
        "car rental personal", "private use vehicle",
    ),
    "residential": (
        "residential rent", "residential property", "staff accommodation",
        "employee housing", "residential lease",
    ),
}


async def check_blocked_vat(ctx: TransactionContext) -> BlockedVatResult:
    if ctx.input.direction != "expense":
        return BlockedVatResult(is_blocked=False)

    haystack = " ".join(
        s for s in (
            ctx.input.description,
            ctx.input.expense_category_hint,
            ctx.input.vendor,
        ) if s
    ).lower()

    for category, keywords in BLOCKED_KEYWORDS.items():
        for kw in keywords:
            if kw in haystack:
                return BlockedVatResult(
                    is_blocked=True,
                    matched_category=category,
                    reason=f"Matched blocked keyword '{kw}' (category: {category})",
                )

    return BlockedVatResult(is_blocked=False)
