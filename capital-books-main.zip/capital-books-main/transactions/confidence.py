"""Field-level confidence evaluation.

Takes an ExtractedTransaction (from extractor_v2) and decides one of:
  - post   → fully confident, post directly to Zoho
  - flag   → post but mark flagged fields for review
  - hold   → save to pending_reviews; user needs to confirm before posting
  - block  → CANNOT post (e.g. amount is unknown). Must resolve before any
              Zoho write.

Per spec:
  vendor:              low → hold (need human review)
  date:                low → flag (user confirms in card)
  amount:              low → BLOCK (critical)
  vat_amount:          low → flag + cross-check (amount × 0.05 ≈ vat ± 0.50)
  currency:            low → default AED with flag
  payment_method_hint: low/default → flag (show resolved account)
  line_items:          low + multiple lines → hold (complex invoice)
"""
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Literal

from transactions.extractor_v2 import ExtractedTransaction

Action = Literal["post", "flag", "hold", "block"]
_PRIORITY = {"post": 0, "flag": 1, "hold": 2, "block": 3}

VAT_RATE = Decimal("0.05")
VAT_TOLERANCE = Decimal("0.50")


@dataclass
class FieldFlag:
    field: str
    reason: str
    severity: str   # "info" | "warn" | "block"


@dataclass
class ConfidenceDecision:
    action: Action
    flags: list[FieldFlag] = field(default_factory=list)
    resolved_fields: dict[str, Any] = field(default_factory=dict)

    def add(self, flag: FieldFlag, action: Action) -> None:
        self.flags.append(flag)
        if _PRIORITY[action] > _PRIORITY[self.action]:
            self.action = action


def evaluate(extracted: ExtractedTransaction) -> ConfidenceDecision:
    """Walk through every field and combine its individual action into one
    overall verdict. The most restrictive action wins."""
    d = ConfidenceDecision(action="post")

    # ---- vendor ----
    vendor = extracted.vendor.value
    if not vendor:
        d.add(FieldFlag("vendor", "Vendor missing", "block"), "block")
    elif extracted.vendor.confidence != "high":
        d.add(FieldFlag("vendor", "Vendor extracted with low confidence — please confirm", "warn"), "hold")
    else:
        d.resolved_fields["vendor"] = vendor

    # ---- amount (critical) ----
    amount_raw = extracted.amount.value
    if amount_raw is None:
        d.add(FieldFlag("amount", "Amount couldn't be read — can't post without it", "block"), "block")
    elif extracted.amount.confidence != "high":
        d.add(FieldFlag("amount", "Amount is low confidence — verify the value before posting", "block"), "block")
    else:
        d.resolved_fields["amount"] = Decimal(str(amount_raw))

    # ---- date ----
    # Per spec: low date confidence → prompt user to confirm BEFORE posting.
    # This is 'hold' semantics, not 'flag' (which would post and warn).
    date_value = extracted.date.value
    if not date_value:
        d.add(FieldFlag("date", "Date missing — defaulting to today (please confirm)", "warn"), "hold")
        d.resolved_fields["date"] = None    # downstream defaults to today
    elif extracted.date.confidence != "high":
        d.add(FieldFlag("date", f"Date {date_value} is uncertain — please confirm before I post", "warn"), "hold")
        d.resolved_fields["date"] = date_value
    else:
        d.resolved_fields["date"] = date_value

    # ---- currency ----
    currency = (extracted.currency.value or "AED").upper()
    if extracted.currency.confidence != "high":
        d.add(FieldFlag("currency", f"Currency defaulted to {currency} — no symbol detected", "info"), "flag")
    d.resolved_fields["currency"] = currency

    # ---- vat_amount + cross-check ----
    vat_amount = extracted.vat_amount.value
    if "amount" in d.resolved_fields and vat_amount is not None:
        try:
            vat_dec = Decimal(str(vat_amount))
            gross = d.resolved_fields["amount"]
            net = gross / (Decimal("1.0") + VAT_RATE)
            expected_vat = (gross - net).quantize(Decimal("0.01"))
            diff = abs(vat_dec - expected_vat)
            d.resolved_fields["vat_amount"] = vat_dec
            if diff > VAT_TOLERANCE:
                d.add(FieldFlag(
                    "vat_amount",
                    f"VAT {vat_dec} doesn't match 5% of {gross} (expected ≈ {expected_vat})",
                    "warn",
                ), "flag")
        except Exception:
            d.add(FieldFlag("vat_amount", "VAT amount couldn't be parsed", "warn"), "flag")
    elif extracted.vat_amount.confidence != "high":
        d.add(FieldFlag("vat_amount", "VAT amount missing or unclear — using 5% inclusive split", "info"), "flag")

    # ---- payment_method_hint ----
    pmh = extracted.payment_method_hint.value
    if pmh:
        d.resolved_fields["payment_method_hint"] = pmh
        if extracted.payment_method_hint.confidence != "high":
            d.add(FieldFlag("payment_method_hint", "Payment method is a best-guess — confirm the resolved account", "warn"), "flag")
    else:
        d.add(FieldFlag("payment_method_hint", "No payment method indicator — using default account", "info"), "flag")

    # ---- vendor_trn (informational only) ----
    if extracted.vendor_trn.value:
        d.resolved_fields["vendor_trn"] = extracted.vendor_trn.value

    # ---- line_items (complexity check) ----
    items = extracted.line_items.value or []
    if isinstance(items, list) and len(items) > 1 and extracted.line_items.confidence != "high":
        d.add(FieldFlag("line_items", "Multi-line invoice with low-confidence parsing — please review", "warn"), "hold")
    d.resolved_fields["line_items"] = items

    return d
