"""Step 8: Determine the tax point date based on the client's VAT basis.

  accrual:     earlier of invoice_date and payment_date
  realisation: payment_date only (None → HOLD_UNTIL_PAID downstream)
"""
from datetime import date

from transactions.models import TransactionContext


async def determine_tax_point(ctx: TransactionContext) -> date | None:
    basis = ctx.client.vat_basis if ctx.client else "accrual"
    invoice_date = ctx.input.invoice_date
    payment_date = ctx.input.payment_date

    if basis == "realisation":
        return payment_date

    if invoice_date and payment_date:
        return min(invoice_date, payment_date)
    return invoice_date or payment_date
