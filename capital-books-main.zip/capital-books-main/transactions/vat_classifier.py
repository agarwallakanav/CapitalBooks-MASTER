"""Step 3: Classify the supply as standard / zero / exempt / reverse_charge / out_of_scope.

Order:
  1. Check categorization_rules for an exact-pattern vendor match → 95-100 confidence.
  2. Fall back to Claude (fast model) → 70-94 confidence typical.
"""
import json
import logging

from anthropic import AsyncAnthropic

from config import settings
from database import get_db
from transactions.models import TransactionContext, VatClassification, VatType

logger = logging.getLogger(__name__)

_anthropic: AsyncAnthropic | None = None

_VALID_TYPES: set[VatType] = {
    "standard", "zero", "exempt", "reverse_charge", "out_of_scope",
}

_SYSTEM_PROMPT = """You are a UAE VAT classifier. Given a vendor, description, and amount,
classify the supply into exactly one of these categories:

- standard: 5% VAT — THE DEFAULT for almost all UAE retail, services, B2B, and B2C.
  Use this for: any local retail purchase (Carrefour, Lulu, Spinneys, IKEA, Apple, Noon,
  Amazon.ae, etc.); coffee/restaurants (Starbucks, McDonald's, Talabat, Deliveroo);
  ride-hail/transport (Careem, Uber); telecom (Etisalat); fuel (ENOC, ADNOC, Emarat);
  most professional services from UAE-registered suppliers; office supplies, software
  subscriptions from local resellers, equipment, marketing, etc.
- zero: 0% rated — narrow list: exports of goods outside GCC, international transport,
  qualifying education, qualifying healthcare, first sale of new residential property,
  precious metals (gold/silver 99%+ purity).
- exempt: exempt — narrow list: residential rentals (rent of homes), bare land sales,
  local passenger transport (taxi/bus fares to consumer), margin-based financial services.
- reverse_charge: imported services from a FOREIGN supplier ONLY. Vendor must clearly be
  outside the UAE (e.g. Microsoft Ireland, Google Cloud Ireland, Stripe Inc.). Local
  resellers of these brands are still standard.
- out_of_scope: salary, dividends, capital injections, intra-company bank transfers.

CONFIDENCE GUIDANCE:
- Default to standard 5% with confidence 92-97 for any unfamiliar UAE retail vendor.
- Use confidence <70 ONLY when there's genuine ambiguity (e.g. vendor name suggests both
  retail and financial services).
- Use confidence 95+ for any vendor in the standard list above.
- Don't be overly cautious. UAE retail is overwhelmingly standard-rated.

Respond with JSON ONLY, no prose:
{"vat_type": "<one of the categories>", "confidence": <integer 0-100>, "reasoning": "<one short sentence>"}"""


def _client() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


async def _check_rules(ctx: TransactionContext) -> VatClassification | None:
    """Exact-pattern vendor match in categorization_rules → highest-confidence classification."""
    if not ctx.input.vendor:
        return None
    db = await get_db()
    res = (
        await db.table("categorization_rules")
        .select("vendor_pattern, category, vat_type")
        .eq("client_id", str(ctx.input.client_id))
        .execute()
    )
    vendor_lc = ctx.input.vendor.lower()
    for row in res.data or []:
        pattern = (row.get("vendor_pattern") or "").lower().strip()
        vat_type = row.get("vat_type")
        if pattern and vat_type in _VALID_TYPES and pattern in vendor_lc:
            return VatClassification(
                vat_type=vat_type,
                confidence=98,
                reasoning=f"Matched rule '{pattern}' → {row.get('category')}",
                matched_rule=True,
            )
    return None


async def _classify_with_ai(ctx: TransactionContext) -> VatClassification:
    user_msg = (
        f"Vendor: {ctx.input.vendor}\n"
        f"Description: {ctx.input.description}\n"
        f"Amount: {ctx.input.amount} {ctx.input.currency}\n"
        f"Direction: {ctx.input.direction}"
    )
    # Ambiguity heuristic: foreign currency OR TRN missing/malformed OR
    # description mentions services + international cues → escalate to Sonnet.
    # Standard UAE AED transactions with a valid vendor go through Haiku.
    tier = "fast"
    if (ctx.input.currency and ctx.input.currency.upper() != "AED") \
            or not (ctx.input.vendor_trn and ctx.input.vendor_trn.startswith("100")):
        tier = "smart"
    model_id = (settings.anthropic_model_smart if tier == "smart"
                else settings.anthropic_model_fast)
    from router.model_tier import timed
    with timed(
        logger, "vat_classifier",
        model=model_id, tier=tier,
        vendor=(ctx.input.vendor or "?")[:40],
    ) as stats:
        resp = await _client().messages.create(
            model=model_id,
            max_tokens=300,
            system=_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
        )
        usage = getattr(resp, "usage", None)
        if usage:
            stats["tokens_in"] = getattr(usage, "input_tokens", None)
            stats["tokens_out"] = getattr(usage, "output_tokens", None)
    text = "".join(
        block.text for block in resp.content if getattr(block, "type", None) == "text"
    ).strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()

    try:
        data = json.loads(text)
        vat_type = data["vat_type"]
        if vat_type not in _VALID_TYPES:
            raise ValueError(f"Invalid vat_type from model: {vat_type}")
        confidence = max(0, min(100, int(data.get("confidence", 0))))
        return VatClassification(
            vat_type=vat_type,
            confidence=confidence,
            reasoning=str(data.get("reasoning", "")),
        )
    except (json.JSONDecodeError, KeyError, ValueError) as e:
        logger.warning("VAT classifier parse failed: %s | raw=%r", e, text[:200])
        return VatClassification(
            vat_type="standard",
            confidence=50,
            reasoning=f"Classifier output unparseable: {e}",
        )


async def classify_vat(ctx: TransactionContext) -> VatClassification:
    rule_match = await _check_rules(ctx)
    if rule_match is not None:
        return rule_match
    return await _classify_with_ai(ctx)
