"""Stateless expense pipeline — Phase B of the orchestrator migration.

This is the NEW pipeline. It runs the 12 VAT steps (or however many actually
apply to a given input) purely against the inputs and the injected
ClientConfig. It does NOT call Zoho. It does NOT write Supabase. It returns
a ModuleResult that the orchestrator (orchestrator.engine.Engine) executes.

The old transactions.pipeline.run_pipeline is kept untouched so other flows
(bills, edit, delete, image confirmation, tools) keep working until they are
migrated in later phases.

What's preserved here:
  - The full VAT classification → arithmetic → box mapping → tax point → routing
  - The pending-state pattern: HUMAN_REVIEW saves to Redis, just as before
  - Source-document handling: if input has bytes, we declare a Document on
    the ModuleResult and the engine will Storage-upload it
"""
import asyncio
import logging
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any
from uuid import UUID

from orchestrator.engine import ClientConfig, Document, ModuleResult, ZohoWrite
from transactions.blocked_vat import check_blocked_vat
from transactions.box_mapping import map_vat_boxes
from transactions.models import (
    BlockedVatResult,
    BoxAssignments,
    ClientConfig as PipelineClientConfig,
    ReverseChargeResult,
    RoutingDecision,
    TransactionContext,
    TransactionInput,
    TrnValidation,
    VatAmounts,
    VatClassification,
)
from transactions.reverse_charge import detect_reverse_charge
from transactions.routing_decision import decide_routing
from transactions.tax_point import determine_tax_point
from transactions.trn_validation import validate_trn
from transactions.vat_arithmetic import compute_vat_amounts
from transactions.vat_classifier import classify_vat
from zoho.entities import build_entity_payload, endpoint_for

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Bridge: orchestrator.ClientConfig → the old per-pipeline ClientConfig type
# (kept narrow so we can drop the old type when Phase C migrates everything)
# ---------------------------------------------------------------------------

def _shim_client_config(cfg: ClientConfig) -> PipelineClientConfig:
    return PipelineClientConfig(
        id=cfg.id,
        company_name=cfg.company_name,
        vat_basis=cfg.vat_basis,
        entity_type=None,
        foreign_suppliers=cfg.foreign_suppliers,
        confidence_threshold=cfg.confidence_threshold,
        approval_amount_limit=Decimal(str(cfg.approval_amount_limit)),
        zoho_organization_id=cfg.zoho_organization_id,
        zoho_access_token=cfg.zoho_access_token,
        zoho_refresh_token=cfg.zoho_refresh_token,
        zoho_tax_ids=cfg.zoho_tax_ids,
    )


# ---------------------------------------------------------------------------
# Input shape
# ---------------------------------------------------------------------------

class ExpenseInput:
    """All a module needs from the router. Mirrors TransactionInput but is
    decoupled from the old internal shape — Phase C will simplify further."""

    def __init__(
        self,
        tx_input: TransactionInput,
        source_document: bytes | None = None,
        source_filename: str | None = None,
        source_mime: str = "application/pdf",
        sender: str | None = None,
        require_confirmation: bool = False,
    ):
        self.tx_input = tx_input
        self.source_document = source_document
        self.source_filename = source_filename
        self.source_mime = source_mime
        self.sender = sender
        self.require_confirmation = require_confirmation


# ---------------------------------------------------------------------------
# The actual handler
# ---------------------------------------------------------------------------

async def classify_expense(input: ExpenseInput, cfg: ClientConfig) -> ModuleResult:
    """Run the VAT pipeline against an expense input and produce a ModuleResult.

    The orchestrator will then:
      - Upload any attached source document (Layer 1)
      - Execute the Zoho POST /expenses on AUTO_POST (Layers 2+3)
      - Persist the local transactions row + extra audit events
      - Optionally append to Google Sheets (Layer 4)
    """
    pipeline_client = _shim_client_config(cfg)
    ctx = TransactionContext(input=input.tx_input, client=pipeline_client)

    # Steps 2 + 3 in parallel
    ctx.trn, ctx.vat_classification = await asyncio.gather(
        validate_trn(ctx),
        classify_vat(ctx),
    )

    # Steps 4 + 5 in parallel
    ctx.reverse_charge, ctx.blocked_vat = await asyncio.gather(
        detect_reverse_charge(ctx),
        check_blocked_vat(ctx),
    )

    if (
        ctx.reverse_charge.is_reverse_charge
        and ctx.vat_classification
        and ctx.vat_classification.vat_type != "reverse_charge"
    ):
        ctx.vat_classification.vat_type = "reverse_charge"

    # Step 6
    ctx.amounts = await compute_vat_amounts(ctx)

    # Steps 7 + 8 in parallel
    ctx.boxes, ctx.tax_point_date = await asyncio.gather(
        map_vat_boxes(ctx),
        determine_tax_point(ctx),
    )

    # Step 9
    ctx.routing = await decide_routing(ctx)

    if input.require_confirmation and ctx.routing.action == "AUTO_POST":
        ctx.routing = RoutingDecision(
            action="HUMAN_REVIEW",
            status="needs_review",
            reason="Receipt image — please verify the values before I post",
        )

    # Build the audit-friendly summary used in event payloads + WhatsApp replies
    amounts = ctx.amounts
    vat_type = ctx.vat_classification.vat_type if ctx.vat_classification else "unknown"
    confidence = ctx.vat_classification.confidence if ctx.vat_classification else 0
    summary = {
        "vendor": input.tx_input.vendor,
        "currency": input.tx_input.currency,
        "net": str(amounts.net),
        "vat": str(amounts.vat),
        "gross": str(amounts.gross),
        "vat_type": vat_type,
        "confidence": confidence,
        "boxes": ctx.boxes.boxes,
        "tax_point_date": ctx.tax_point_date.isoformat() if ctx.tax_point_date else None,
        "blocked_vat": ctx.blocked_vat.is_blocked if ctx.blocked_vat else False,
        "trn_valid": ctx.trn.is_valid if ctx.trn else False,
    }

    documents: list[Document] = []
    if input.source_document and input.source_filename:
        documents.append(Document(
            entity_type="transaction",
            body=input.source_document,
            filename=input.source_filename,
            mime_type=input.source_mime,
        ))

    extra_events: list[dict[str, Any]] = [
        {"event_type": "classified", "entity_type": "transaction",
         "payload": summary},
        {"event_type": f"routed_{ctx.routing.action.lower()}",
         "entity_type": "transaction",
         "payload": {"reason": ctx.routing.reason}},
    ]

    # ---- HUMAN_REVIEW / MANUAL / HOLD_UNTIL_PAID: persist to Supabase via
    # the old log_transaction path (Phase C will inline this), then save
    # pending state for the user to confirm. NO Zoho writes.
    if ctx.routing.action in {"HUMAN_REVIEW", "MANUAL", "HOLD_UNTIL_PAID"}:
        from router.pending import save_pending
        from transactions.pipeline import log_transaction
        ctx.transaction_id = await log_transaction(ctx)
        if input.sender and ctx.routing.action in {"HUMAN_REVIEW", "MANUAL"}:
            await save_pending(input.sender, ctx)

        if ctx.routing.action == "HOLD_UNTIL_PAID":
            reply = (
                "📌 On hold until paid (realisation basis).\n"
                f"Vendor: {input.tx_input.vendor}, "
                f"{amounts.gross} {input.tx_input.currency}"
            )
        elif ctx.routing.action == "HUMAN_REVIEW":
            reply = (
                "⚠️ Needs your review\n"
                f"Vendor: {input.tx_input.vendor} — {amounts.gross} {input.tx_input.currency}\n"
                f"My guess: {vat_type} ({confidence}%)\n"
                f"Reason: {ctx.routing.reason}\n"
                "Reply 'confirm' to approve, or correct it (e.g. 'no, that's office supplies')."
            )
        else:
            reply = (
                f"❓ Not confident on this one ({confidence}%). Tell me the category — "
                "e.g. 'office supplies, standard VAT'."
            )

        return ModuleResult(
            reply_to_user=reply,
            zoho_writes=[],
            documents=documents,
            extra_events=extra_events,
            entity_kind="transaction",
            entity_id=ctx.transaction_id,
        )

    # ---- AUTO_POST: declare a Zoho write; engine executes
    payload = build_entity_payload(ctx, cfg.zoho_tax_ids)
    endpoint = endpoint_for(input.tx_input.zoho_entity_type)

    # We need an entity_id BEFORE the Zoho call so the engine can bind. Log
    # the local transactions row first (with status auto_posted, zoho_id NULL)
    # via the legacy helper. Phase C inlines this.
    from transactions.pipeline import log_transaction
    ctx.transaction_id = await log_transaction(ctx)

    zoho_writes = [
        ZohoWrite(
            method="POST",
            endpoint=endpoint,
            payload=payload,
            bind_to_entity=("transaction", ctx.transaction_id),
        )
    ]

    reply = (
        "✅ Posted to Zoho Books\n"
        f"Vendor: {input.tx_input.vendor}\n"
        f"Net: {amounts.net} {input.tx_input.currency} | "
        f"VAT: {amounts.vat} | Gross: {amounts.gross}\n"
        f"VAT type: {vat_type}, boxes: {ctx.boxes.boxes}"
    )

    return ModuleResult(
        reply_to_user=reply,
        zoho_writes=zoho_writes,
        documents=documents,
        extra_events=extra_events,
        entity_kind="transaction",
        entity_id=ctx.transaction_id,
    )
