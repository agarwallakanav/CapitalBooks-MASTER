"""Per-client card registry — reads from `client_cards` table with a
fallback to the legacy `clients.card_mapping` JSONB so existing setups
keep working.

  get_card_by_last4(client_id, last_four) → CardRecord | None
  list_cards(client_id)                   → list[CardRecord]
  save_card(client_id, last_four, label,
            zoho_account_id=None, brand=None) → CardRecord
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any
from uuid import UUID

from database import get_db

logger = logging.getLogger(__name__)


@dataclass
class CardRecord:
    last_four: str
    label: str
    zoho_account_id: str | None
    brand: str | None = None
    source: str = "client_cards"   # 'client_cards' | 'card_mapping_legacy'


async def list_cards(client_id: UUID) -> list[CardRecord]:
    """Return all known cards for this client, table first then JSONB fallback."""
    cards: dict[str, CardRecord] = {}
    db = await get_db()
    # 1) New table
    try:
        res = (
            await db.table("client_cards")
            .select("last_four, label, zoho_account_id, brand")
            .eq("client_id", str(client_id))
            .order("created_at", desc=True)
            .execute()
        )
        for row in res.data or []:
            cards[row["last_four"]] = CardRecord(
                last_four=row["last_four"],
                label=row["label"],
                zoho_account_id=row.get("zoho_account_id"),
                brand=row.get("brand"),
                source="client_cards",
            )
    except Exception:
        logger.exception("client_cards lookup failed (continuing with legacy only)")

    # 2) Legacy JSONB — only fill in last-fours not already covered by the table
    try:
        res = (
            await db.table("clients")
            .select("card_mapping")
            .eq("id", str(client_id))
            .single()
            .execute()
        )
        mapping = (res.data or {}).get("card_mapping") or {}
        for last4, entry in mapping.items():
            if last4 in cards:
                continue
            if isinstance(entry, dict):
                cards[last4] = CardRecord(
                    last_four=last4,
                    label=entry.get("label") or f"Card …{last4}",
                    zoho_account_id=entry.get("account_id"),
                    brand=entry.get("brand"),
                    source="card_mapping_legacy",
                )
            else:
                cards[last4] = CardRecord(
                    last_four=last4,
                    label=f"Card …{last4}",
                    zoho_account_id=str(entry),
                    source="card_mapping_legacy",
                )
    except Exception:
        logger.exception("clients.card_mapping fallback lookup failed (non-fatal)")

    return list(cards.values())


async def get_card_by_last4(client_id: UUID, last_four: str) -> CardRecord | None:
    if not last_four or len(last_four) != 4 or not last_four.isdigit():
        return None
    for c in await list_cards(client_id):
        if c.last_four == last_four:
            return c
    return None


async def save_card(
    client_id: UUID,
    last_four: str,
    label: str,
    zoho_account_id: str | None = None,
    brand: str | None = None,
) -> CardRecord:
    """Upsert by (client_id, last_four). Returns the saved record."""
    db = await get_db()
    payload: dict[str, Any] = {
        "client_id": str(client_id),
        "last_four": last_four,
        "label": label.strip()[:80],
    }
    if zoho_account_id:
        payload["zoho_account_id"] = zoho_account_id
    if brand:
        payload["brand"] = brand
    try:
        await db.table("client_cards").upsert(
            payload, on_conflict="client_id,last_four",
        ).execute()
    except Exception:
        logger.exception("client_cards upsert failed")
        raise
    return CardRecord(
        last_four=last_four, label=label,
        zoho_account_id=zoho_account_id, brand=brand,
        source="client_cards",
    )
