"""Step 6: Net / VAT / gross arithmetic with banker's rounding + FX to AED.

Convention: `amount` on TransactionInput is the gross figure printed on the document.
  - standard supplies: net = gross / 1.05, vat = gross - net
  - reverse_charge: gross is the net (no VAT charged); we self-account vat = net * 0.05
  - zero / exempt / out_of_scope: vat = 0
"""
from datetime import date
from decimal import ROUND_HALF_EVEN, Decimal

from transactions.models import TransactionContext, VatAmounts

VAT_RATE = Decimal("0.05")
ONE_PLUS_RATE = Decimal("1.05")
TWO_PLACES = Decimal("0.01")
SIX_PLACES = Decimal("0.000001")


def _round(value: Decimal) -> Decimal:
    return value.quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)


async def fetch_fx_rate(currency: str, on_date: date | None = None) -> Decimal:
    """Placeholder — returns 1.0 for AED, 1.0 for everything else until a real FX
    source (UAE Central Bank daily rates or exchangerate.host) is wired in."""
    if (currency or "AED").upper() == "AED":
        return Decimal("1.0")
    return Decimal("1.0")


async def compute_vat_amounts(ctx: TransactionContext) -> VatAmounts:
    gross_raw = Decimal(ctx.input.amount)
    vat_type = ctx.vat_classification.vat_type if ctx.vat_classification else "out_of_scope"
    is_rc = ctx.reverse_charge.is_reverse_charge if ctx.reverse_charge else False

    if is_rc:
        net = _round(gross_raw)
        vat = _round(net * VAT_RATE)
    elif vat_type == "standard":
        net = _round(gross_raw / ONE_PLUS_RATE)
        vat = _round(gross_raw - net)
    else:
        net = _round(gross_raw)
        vat = Decimal("0.00")

    fx_rate = await fetch_fx_rate(ctx.input.currency, ctx.input.invoice_date)
    fx_rate = fx_rate.quantize(SIX_PLACES, rounding=ROUND_HALF_EVEN)
    amount_aed = _round(gross_raw * fx_rate)

    return VatAmounts(
        net=net,
        vat=vat,
        gross=_round(gross_raw),
        fx_rate=fx_rate,
        amount_aed=amount_aed,
    )
