"""Step 4: Detect imported services subject to reverse charge.

Two signals:
  1. Vendor name matches an entry in ClientConfig.foreign_suppliers (deterministic).
  2. AI VAT classifier (step 3) flagged the supply as 'reverse_charge'.

Runs in parallel with blocked_vat (step 5). Only step 3 is required first.
"""
from transactions.models import ReverseChargeResult, TransactionContext


async def detect_reverse_charge(ctx: TransactionContext) -> ReverseChargeResult:
    if ctx.input.direction != "expense":
        return ReverseChargeResult(is_reverse_charge=False)

    vendor_lc = (ctx.input.vendor or "").lower()
    if ctx.client and vendor_lc:
        for foreign in ctx.client.foreign_suppliers:
            if foreign and foreign.lower() in vendor_lc:
                return ReverseChargeResult(
                    is_reverse_charge=True,
                    reason=f"Vendor matches foreign supplier '{foreign}'",
                )

    if ctx.vat_classification and ctx.vat_classification.vat_type == "reverse_charge":
        return ReverseChargeResult(
            is_reverse_charge=True,
            reason="AI classified supply as reverse charge",
        )

    return ReverseChargeResult(is_reverse_charge=False)
