"""Shared data shapes for the VAT pipeline. One TransactionContext is built up step-by-step."""
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Literal
from uuid import UUID

VatType = Literal["standard", "zero", "exempt", "reverse_charge", "out_of_scope"]
Direction = Literal["income", "expense"]
ZohoEntityType = Literal[
    "Expense", "Bill", "Invoice", "BankTransaction", "Journal", "CustomerPayment",
]
VatBasis = Literal["accrual", "realisation"]
RoutingAction = Literal["AUTO_POST", "HUMAN_REVIEW", "MANUAL", "HOLD_UNTIL_PAID"]
TransactionStatus = Literal[
    "auto_posted", "needs_review", "hold_until_paid",
    "manually_categorized", "rejected", "failed",
]


@dataclass
class TransactionInput:
    client_id: UUID
    direction: Direction
    zoho_entity_type: ZohoEntityType
    vendor: str
    description: str
    amount: Decimal
    currency: str = "AED"
    invoice_date: date | None = None
    payment_date: date | None = None
    vendor_trn: str | None = None
    is_tax_invoice: bool = True
    is_paid: bool = False
    source_document_url: str | None = None
    expense_category_hint: str | None = None
    # AP-only: present when zoho_entity_type == "Bill"
    due_date: date | None = None
    bill_number: str | None = None


@dataclass
class ClientConfig:
    id: UUID
    company_name: str
    vat_basis: VatBasis
    entity_type: str | None
    foreign_suppliers: list[str]
    confidence_threshold: int
    approval_amount_limit: Decimal
    zoho_organization_id: str | None
    zoho_access_token: str | None
    zoho_refresh_token: str | None
    zoho_tax_ids: dict[str, str] = field(default_factory=dict)


@dataclass
class TrnValidation:
    present: bool
    format_valid: bool
    starts_with_100: bool
    reason: str | None = None

    @property
    def is_valid(self) -> bool:
        return self.present and self.format_valid and self.starts_with_100


@dataclass
class VatClassification:
    vat_type: VatType
    confidence: int
    reasoning: str
    matched_rule: bool = False


@dataclass
class ReverseChargeResult:
    is_reverse_charge: bool
    reason: str | None = None


@dataclass
class BlockedVatResult:
    is_blocked: bool
    reason: str | None = None
    matched_category: str | None = None


@dataclass
class VatAmounts:
    net: Decimal
    vat: Decimal
    gross: Decimal
    fx_rate: Decimal
    amount_aed: Decimal


@dataclass
class BoxAssignments:
    boxes: list[int]


@dataclass
class RoutingDecision:
    action: RoutingAction
    status: TransactionStatus
    reason: str


@dataclass
class TransactionContext:
    input: TransactionInput
    client: ClientConfig | None = None
    trn: TrnValidation | None = None
    vat_classification: VatClassification | None = None
    reverse_charge: ReverseChargeResult | None = None
    blocked_vat: BlockedVatResult | None = None
    amounts: VatAmounts | None = None
    boxes: BoxAssignments | None = None
    tax_point_date: date | None = None
    routing: RoutingDecision | None = None
    zoho_entity_id: str | None = None
    transaction_id: UUID | None = None
    errors: list[str] = field(default_factory=list)
