"""Free-form text OR receipt image → TransactionInput via Claude.

Text path: Claude Haiku reads the message body.
Image path: Claude Haiku vision reads the receipt photo (UAE receipts are
often bilingual Arabic/English — Claude handles both natively).
"""
import base64
import json
import logging
from datetime import date
from decimal import Decimal
from uuid import UUID

from anthropic import AsyncAnthropic

from config import settings
from transactions.models import TransactionInput

logger = logging.getLogger(__name__)

_anthropic: AsyncAnthropic | None = None


def _client() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


_SYSTEM_PROMPT = """Extract a UAE bookkeeping transaction from the user's WhatsApp message.

Reply with JSON only — null for any field that isn't mentioned:
{
  "direction": "expense" or "income",
  "vendor": "<vendor or customer>",
  "description": "<short description of goods/services>",
  "amount": <number, the gross/total>,
  "currency": "AED" or other 3-letter ISO code,
  "vendor_trn": "<15-digit TRN if present>" or null,
  "invoice_date": "YYYY-MM-DD" or null,
  "due_date": "YYYY-MM-DD" or null,
  "bill_number": "<supplier's invoice/bill number>" or null,
  "is_paid": true or false
}

Defaults: currency=AED, direction=expense, is_paid=true (cash receipt assumption).
Cash-style expenses ("spent X on Y") are paid; invoices issued or bills received
default to is_paid=false."""


_BILL_SYSTEM_PROMPT = """Extract a UAE vendor bill (accounts payable) from the user's message.

The user is logging a bill they OWE — money going out. NOT a paid receipt.

TODAY'S DATE: {today}
When the user says "due in N days", "net 30", "due Friday", etc. — compute the
absolute date relative to TODAY (above) and return it as YYYY-MM-DD.

Reply with JSON only — null for any field that isn't mentioned:
{{
  "vendor": "<supplier name>",
  "description": "<short description of goods/services billed>",
  "amount": <number, the gross/total>,
  "currency": "AED" or other 3-letter ISO code,
  "vendor_trn": "<15-digit TRN if present>" or null,
  "bill_date": "YYYY-MM-DD" or null,
  "due_date": "YYYY-MM-DD" or null,
  "bill_number": "<supplier's invoice/bill number>" or null
}}

Defaults: currency=AED. Always set a due_date if any timing is mentioned."""


def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return text.strip()


_IMAGE_SYSTEM_PROMPT = """Extract a UAE bookkeeping transaction from a receipt photo.

UAE receipts are often bilingual (Arabic + English). Look for:
  - Vendor name (top of receipt)
  - Total/gross amount (often labelled "Total", "إجمالي", "AED", or "د.إ")
  - VAT registration number / TRN — 15 digits starting with "100"
  - Date — usually printed at top or bottom
  - Items purchased (use as description; summarize to one short phrase)

Reply with JSON only — null for any field that isn't on the receipt:
{
  "direction": "expense",
  "vendor": "<vendor>",
  "description": "<short description of what was purchased>",
  "amount": <gross/total number>,
  "currency": "AED" or other 3-letter ISO,
  "vendor_trn": "<15-digit TRN if printed>" or null,
  "invoice_date": "YYYY-MM-DD" or null,
  "is_paid": true
}

Default: direction=expense, currency=AED, is_paid=true (most receipts are point-of-sale).
If multiple amounts are visible (subtotal, tax, total), use the TOTAL."""


async def extract_from_image(
    image_bytes: bytes,
    mime_type: str,
    client_id: UUID,
    caption: str | None = None,
    today: date | None = None,
) -> TransactionInput:
    """Vision-based receipt extraction. mime_type is whatever WhatsApp sent us
    (typically image/jpeg, sometimes image/png)."""
    if mime_type not in ("image/jpeg", "image/png", "image/gif", "image/webp"):
        # Claude only supports those four — fall back to jpeg, often works
        logger.warning("Unsupported image mime %s, attempting as jpeg", mime_type)
        mime_type = "image/jpeg"

    b64 = base64.standard_b64encode(image_bytes).decode("ascii")
    user_content: list[dict] = [
        {
            "type": "image",
            "source": {"type": "base64", "media_type": mime_type, "data": b64},
        }
    ]
    if caption:
        user_content.append({"type": "text", "text": f"User caption: {caption}"})
    else:
        user_content.append({"type": "text", "text": "Extract this UAE receipt."})

    resp = await _client().messages.create(
        model=settings.anthropic_model_fast,
        max_tokens=500,
        system=_IMAGE_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_content}],
    )
    raw = _strip_fences(
        "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    )
    data = json.loads(raw)
    return _data_to_input(data, client_id, today, fallback_desc=caption or "receipt photo")


def _data_to_input(
    data: dict, client_id: UUID, today: date | None, fallback_desc: str
) -> TransactionInput:
    today = today or date.today()
    direction = data.get("direction") or "expense"
    is_paid = bool(data.get("is_paid", True))
    invoice_date_str = data.get("invoice_date")
    due_date_str = data.get("due_date")
    return TransactionInput(
        client_id=client_id,
        direction=direction,
        zoho_entity_type="Expense" if direction == "expense" else "Invoice",
        vendor=data.get("vendor") or "Unknown",
        description=data.get("description") or fallback_desc,
        amount=Decimal(str(data["amount"])),
        currency=(data.get("currency") or "AED").upper(),
        invoice_date=date.fromisoformat(invoice_date_str) if invoice_date_str else today,
        payment_date=today if is_paid else None,
        vendor_trn=data.get("vendor_trn"),
        is_paid=is_paid,
        due_date=date.fromisoformat(due_date_str) if due_date_str else None,
        bill_number=data.get("bill_number"),
    )


def _data_to_bill_input(
    data: dict, client_id: UUID, today: date | None, fallback_desc: str
) -> TransactionInput:
    today = today or date.today()
    bill_date_str = data.get("bill_date")
    due_date_str = data.get("due_date")
    return TransactionInput(
        client_id=client_id,
        direction="expense",
        zoho_entity_type="Bill",
        vendor=data.get("vendor") or "Unknown",
        description=data.get("description") or fallback_desc,
        amount=Decimal(str(data["amount"])),
        currency=(data.get("currency") or "AED").upper(),
        invoice_date=date.fromisoformat(bill_date_str) if bill_date_str else today,
        payment_date=None,                                # unpaid by definition
        vendor_trn=data.get("vendor_trn"),
        is_paid=False,
        due_date=date.fromisoformat(due_date_str) if due_date_str else None,
        bill_number=data.get("bill_number"),
    )


async def extract_bill(
    text: str, client_id: UUID, today: date | None = None
) -> TransactionInput:
    today = today or date.today()
    resp = await _client().messages.create(
        model=settings.anthropic_model_fast,
        max_tokens=400,
        system=_BILL_SYSTEM_PROMPT.format(today=today.isoformat()),
        messages=[{"role": "user", "content": text}],
    )
    raw = _strip_fences(
        "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    )
    data = json.loads(raw)
    return _data_to_bill_input(data, client_id, today, fallback_desc=text[:200])


async def extract_transaction(
    text: str, client_id: UUID, today: date | None = None
) -> TransactionInput:
    resp = await _client().messages.create(
        model=settings.anthropic_model_fast,
        max_tokens=400,
        system=_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": text}],
    )
    raw = _strip_fences(
        "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    )
    data = json.loads(raw)
    return _data_to_input(data, client_id, today, fallback_desc=text[:200])
