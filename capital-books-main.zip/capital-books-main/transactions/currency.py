"""FX rates + currency detection.

Frankfurter (ECB) supplies daily rates for ~30 floating currencies, but
doesn't carry the GCC currencies (AED, SAR, OMR, BHD, QAR) — those are
pegged to USD, so we hardcode the pegs and pivot every conversion
through USD.

  get_rate("USD", "AED") → 3.6725  (peg)
  get_rate("EUR", "AED") → frankfurter EUR→USD × peg
  get_rate("SAR", "AED") → 3.6725 / 3.75 ≈ 0.9793 (both pegged)

Cached in Redis for 1 hour keyed by (from, to, ISO date). Misses fall
back to a hardcoded recent-snapshot table so a transient API outage
doesn't break the transaction pipeline — failure is logged.
"""
from __future__ import annotations

import json
import logging
from datetime import date
from decimal import Decimal
from typing import Iterable

import httpx

from redis_client import get_redis

logger = logging.getLogger(__name__)

_CACHE_TTL_SECONDS = 3600
_FRANKFURTER = "https://api.frankfurter.app/latest"
_HTTP_TIMEOUT = 8.0

# GCC currencies pegged to USD (rate = local-currency-per-USD).
# Sources: CBUAE / SAMA / CBO / CBB / QCB — these pegs have held for 20+ years.
_USD_PEGS: dict[str, Decimal] = {
    "AED": Decimal("3.6725"),
    "SAR": Decimal("3.75"),
    "OMR": Decimal("0.3850"),
    "BHD": Decimal("0.3760"),
    "QAR": Decimal("3.6400"),
    "USD": Decimal("1"),
}

# Last-resort fallback rates per USD when frankfurter is unreachable.
# Refreshed approx mid-2026; close enough for the bot to keep working.
_FALLBACK_PER_USD: dict[str, Decimal] = {
    "EUR": Decimal("0.92"),
    "GBP": Decimal("0.78"),
    "INR": Decimal("83.50"),
    "JPY": Decimal("155.00"),
    "CNY": Decimal("7.25"),
    "PKR": Decimal("278.00"),
    "PHP": Decimal("58.20"),
    "EGP": Decimal("49.00"),
    "TRY": Decimal("32.40"),
    "ZAR": Decimal("18.50"),
}


def _norm(code: str) -> str:
    return (code or "").strip().upper() or "AED"


async def _frankfurter_per_usd(code: str) -> Decimal | None:
    """Return how many <code> equal 1 USD, via frankfurter."""
    try:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            resp = await http.get(_FRANKFURTER, params={"from": "USD", "to": code})
            resp.raise_for_status()
            data = resp.json()
            rate = (data.get("rates") or {}).get(code)
            if rate is None:
                return None
            return Decimal(str(rate))
    except Exception:
        logger.exception("frankfurter fetch failed for %s", code)
        return None


async def _per_usd(code: str) -> Decimal:
    """How many <code> equal 1 USD. Pegged first, then frankfurter, then fallback."""
    if code in _USD_PEGS:
        return _USD_PEGS[code]
    rate = await _frankfurter_per_usd(code)
    if rate is not None:
        return rate
    fb = _FALLBACK_PER_USD.get(code)
    if fb is not None:
        logger.warning("Using fallback FX rate for %s (frankfurter unreachable)", code)
        return fb
    raise ValueError(f"Unknown currency: {code} (no peg, no API result, no fallback)")


async def get_rate(from_curr: str, to_curr: str = "AED") -> Decimal:
    """Returns: 1 <from_curr> = <result> <to_curr>. Redis-cached 1h."""
    f = _norm(from_curr)
    t = _norm(to_curr)
    if f == t:
        return Decimal("1")

    today = date.today().isoformat()
    cache_key = f"fx:{f}:{t}:{today}"
    redis = await get_redis()
    try:
        cached = await redis.get(cache_key)
        if cached:
            return Decimal(cached)
    except Exception:
        logger.exception("FX cache read failed (continuing without cache)")

    # Pivot through USD: from → USD → to
    f_per_usd = await _per_usd(f)
    t_per_usd = await _per_usd(t)
    # 1 f = (1/f_per_usd) USD; 1 USD = t_per_usd t  →  1 f = t_per_usd / f_per_usd t
    rate = (t_per_usd / f_per_usd).quantize(Decimal("0.0001"))

    try:
        await redis.set(cache_key, str(rate), ex=_CACHE_TTL_SECONDS)
    except Exception:
        logger.exception("FX cache write failed (non-fatal)")
    return rate


async def to_aed(amount: Decimal, from_curr: str) -> tuple[Decimal, Decimal]:
    """Convert <amount> in <from_curr> to AED. Returns (aed_amount, rate_used)."""
    rate = await get_rate(from_curr, "AED")
    aed = (Decimal(str(amount)) * rate).quantize(Decimal("0.01"))
    return aed, rate


# ---------------------------------------------------------------------------
# Currency hint detection — backup to the extractor when LLM extraction is
# low-confidence or absent. The extractor remains the primary path.
# ---------------------------------------------------------------------------

_SYMBOL_MAP: dict[str, str] = {
    "$":  "USD",
    "€":  "EUR",
    "£":  "GBP",
    "¥":  "JPY",
    "₹":  "INR",
    "₨":  "PKR",
    "د.إ": "AED",
    "ر.س": "SAR",
}

_KEYWORD_MAP: dict[str, str] = {
    "usd": "USD", "dollar": "USD", "dollars": "USD", "us$": "USD",
    "eur": "EUR", "euro": "EUR", "euros": "EUR",
    "gbp": "GBP", "pound": "GBP", "pounds": "GBP", "sterling": "GBP",
    "aed": "AED", "dirham": "AED", "dirhams": "AED", "dhs": "AED", "aed.": "AED",
    "sar": "SAR", "riyal": "SAR", "saudi riyal": "SAR", "sr": "SAR",
    "inr": "INR", "rupee": "INR", "rupees": "INR", "rs": "INR",
    "omr": "OMR", "qar": "QAR", "bhd": "BHD",
    "jpy": "JPY", "yen": "JPY",
    "cny": "CNY", "yuan": "CNY", "rmb": "CNY",
    "pkr": "PKR", "egp": "EGP", "try": "TRY", "zar": "ZAR",
}


def detect_currency(text: str) -> str | None:
    """Cheap regex hint. Returns ISO code or None. Used by the extractor as
    a backup signal — Claude's per-field extraction is the primary path."""
    if not text:
        return None
    t = text.lower()
    # Symbols first (more specific)
    for sym, code in _SYMBOL_MAP.items():
        if sym in text:
            return code
    # Word-boundary keyword scan, longest first so 'us$' / 'saudi riyal' win
    for kw in sorted(_KEYWORD_MAP.keys(), key=len, reverse=True):
        if kw in t:
            return _KEYWORD_MAP[kw]
    return None


__all__ = [
    "get_rate", "to_aed", "detect_currency", "get_zoho_currency_id",
    "_USD_PEGS",                         # exposed for tests
]


# ---------------------------------------------------------------------------
# Zoho currency_id lookup — Zoho's expense API needs the org-internal UUID,
# not the ISO code. We cache the (ISO → uuid) map per client in Redis 24h
# since currency configuration rarely changes.
# ---------------------------------------------------------------------------

_ZOHO_CCY_CACHE_TTL = 86_400


async def get_zoho_currency_id(zoho, client_id, iso_code: str) -> str | None:
    """Resolve ISO 4217 → Zoho currency_id for this client's org. Returns
    None when the currency isn't enabled in the Zoho org (multi-currency
    must be turned on in Settings → Currencies)."""
    iso = (iso_code or "").upper()
    if not iso:
        return None
    redis = await get_redis()
    cache_key = f"zoho_ccy_map:{client_id}"
    try:
        cached = await redis.get(cache_key)
        if cached:
            mapping = json.loads(cached)
            return mapping.get(iso)
    except Exception:
        logger.exception("zoho_currency_id cache read failed (continuing)")
        mapping = None

    try:
        resp = await zoho.list_entities("settings/currencies", filters={})
        currencies = resp.get("currencies") or []
        mapping = {
            (c.get("currency_code") or "").upper(): c.get("currency_id")
            for c in currencies if c.get("currency_id")
        }
    except Exception:
        logger.exception("Zoho /settings/currencies fetch failed")
        return None

    try:
        await redis.set(cache_key, json.dumps(mapping), ex=_ZOHO_CCY_CACHE_TTL)
    except Exception:
        logger.exception("zoho_currency_id cache write failed (non-fatal)")
    return mapping.get(iso)
