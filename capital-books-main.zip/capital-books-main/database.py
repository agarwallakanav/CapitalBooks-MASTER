from supabase import AsyncClient, acreate_client

from config import settings

_client: AsyncClient | None = None


async def get_db() -> AsyncClient:
    global _client
    if _client is None:
        _client = await acreate_client(settings.supabase_url, settings.supabase_key)
    return _client


async def close_db() -> None:
    global _client
    _client = None
