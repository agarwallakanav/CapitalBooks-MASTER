"""AP aging report — bucket outstanding bills by days past due.

Same bucket structure as the AR aging report so users get a symmetric view of
money owed vs money owing.
"""
import logging
from dataclasses import dataclass
from datetime import date
from typing import Any
from uuid import UUID

from database import get_db

logger = logging.getLogger(__name__)


@dataclass
class APAgingBuckets:
    current: float = 0.0       # not yet due
    days_1_30: float = 0.0
    days_31_60: float = 0.0
    days_61_90: float = 0.0
    days_over_90: float = 0.0
    by_vendor: dict[str, dict[str, float]] = None

    def total(self) -> float:
        return (
            self.current + self.days_1_30 + self.days_31_60
            + self.days_61_90 + self.days_over_90
        )


def _bucket_for(days_past_due: int) -> str:
    if days_past_due <= 0:
        return "current"
    if days_past_due <= 30:
        return "days_1_30"
    if days_past_due <= 60:
        return "days_31_60"
    if days_past_due <= 90:
        return "days_61_90"
    return "days_over_90"


async def compute_ap_aging(
    client_id: UUID, today: date | None = None
) -> APAgingBuckets:
    today = today or date.today()
    db = await get_db()
    res = (
        await db.table("bills")
        .select("vendor, amount, currency, due_date, status")
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .in_("status", ["unpaid", "scheduled", "overdue"])
        .execute()
    )
    bills = res.data or []

    buckets = APAgingBuckets(by_vendor={})
    for b in bills:
        if not b.get("due_date"):
            continue
        days_past = (today - date.fromisoformat(b["due_date"])).days
        bucket = _bucket_for(days_past)
        amount = float(b.get("amount") or 0)
        setattr(buckets, bucket, getattr(buckets, bucket) + amount)

        vendor = b.get("vendor") or "(unknown)"
        buckets.by_vendor.setdefault(vendor, {})
        buckets.by_vendor[vendor][bucket] = (
            buckets.by_vendor[vendor].get(bucket, 0.0) + amount
        )
    return buckets


async def ap_aging_summary(client_id: UUID, today: date | None = None) -> str:
    b = await compute_ap_aging(client_id, today)
    total = b.total()
    if total == 0:
        return "✅ No outstanding bills payable."

    lines = [
        f"📊 AP Aging — AED {total:,.0f} total owed\n",
        f"Current:       AED {b.current:,.0f}",
        f"1-30 days:     AED {b.days_1_30:,.0f}",
        f"31-60 days:    AED {b.days_31_60:,.0f}",
        f"61-90 days:    AED {b.days_61_90:,.0f}",
        f"90+ days:      AED {b.days_over_90:,.0f}",
    ]
    if b.days_over_90 > 0:
        lines.append(f"\n⚠️ AED {b.days_over_90:,.0f} is over 90 days past due.")

    if b.by_vendor:
        top = sorted(
            b.by_vendor.items(),
            key=lambda kv: -sum(kv[1].values()),
        )[:3]
        lines.append("\nTop owed to vendor:")
        for vendor, vbuckets in top:
            lines.append(f"  • {vendor}: AED {sum(vbuckets.values()):,.0f}")

    return "\n".join(lines)


async def overdue_bills_summary(client_id: UUID, today: date | None = None) -> str:
    """Mirror of AR's overdue_summary but for vendor bills."""
    today = today or date.today()
    db = await get_db()
    res = (
        await db.table("bills")
        .select("vendor, amount, currency, due_date, status")
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .in_("status", ["unpaid", "scheduled", "overdue"])
        .order("due_date", desc=False)
        .execute()
    )
    bills = res.data or []
    if not bills:
        return "✅ No bills due or overdue."

    currency = bills[0].get("currency", "AED")
    total = sum(float(b.get("amount") or 0) for b in bills)
    lines = [
        f"📋 {len(bills)} bill(s) — {currency} {total:,.0f} outstanding\n"
    ]
    for b in bills[:10]:
        due = b.get("due_date")
        if due:
            days = (date.fromisoformat(due) - today).days
            if days < 0:
                tag = f"{-days}d overdue"
            elif days == 0:
                tag = "due today"
            else:
                tag = f"due in {days}d"
        else:
            tag = "no due date"
        lines.append(
            f"• {b.get('vendor')} — {currency} {float(b.get('amount') or 0):,.2f} ({tag})"
        )
    if len(bills) > 10:
        lines.append(f"…and {len(bills) - 10} more")
    return "\n".join(lines)
