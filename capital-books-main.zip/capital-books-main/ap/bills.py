"""Vendor bill ingestion.

Text path: user types something like
    "bill from XYZ Trading for AED 8400 due in 14 days"
Image path: user sends a photo of a supplier invoice.

In both cases we run a Bill-aware extractor → 12-step VAT pipeline (same
classification/box mapping/tax point logic as expenses) → if amount exceeds
the client's approval_threshold or confidence < threshold, save to bills with
status=needs_approval. Otherwise lookup-or-create the Zoho vendor contact +
post a Bill to Zoho.
"""
import logging
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Any
from uuid import UUID

from database import get_db
from transactions.extractor import extract_bill, extract_from_image
from transactions.models import TransactionContext, TransactionInput
from transactions.pipeline import load_client_config, run_pipeline
from whatsapp.media import fetch_media
from whatsapp.sender import send_text
from zoho.client import ZohoBooksClient
from zoho.entities import build_bill_payload


async def _next_bill_number(client_id: UUID) -> str:
    """Sequential per-client bill numbers used when the vendor didn't provide
    one: BILL-YYYYMM-NNNN."""
    db = await get_db()
    today = date.today()
    prefix = f"BILL-{today:%Y%m}"
    res = (
        await db.table("bills")
        .select("bill_number")
        .eq("client_id", str(client_id))
        .like("bill_number", f"{prefix}%")
        .order("bill_number", desc=True)
        .limit(1)
        .execute()
    )
    last = (res.data or [{}])[0].get("bill_number") if res.data else None
    seq = int(last.split("-")[-1]) + 1 if last else 1
    return f"{prefix}-{seq:04d}"

logger = logging.getLogger(__name__)


# ----------------------- Zoho vendor resolution -----------------------

async def _find_or_create_zoho_vendor(
    zoho: ZohoBooksClient, vendor_name: str, vendor_trn: str | None
) -> dict[str, Any]:
    """Bills in Zoho UAE require a vendor_id — free-text vendor_name is rejected.
    Search ONLY for vendor-typed contacts (customer-typed matches can't be
    converted later if Zoho has already registered any transaction against
    them). Create fresh if no vendor match exists."""
    matches = await zoho.search_contacts(vendor_name)
    vendors_only = [c for c in matches if c.get("contact_type") == "vendor"]
    for c in vendors_only:
        if (c.get("contact_name") or "").lower() == vendor_name.lower():
            return c
    if vendors_only:
        return vendors_only[0]

    payload: dict[str, Any] = {
        "contact_name": vendor_name,
        "company_name": vendor_name,
        "contact_type": "vendor",
        "currency_code": "AED",
    }
    if vendor_trn:
        payload["tax_reg_no"] = vendor_trn
    created = await zoho.create_entity("contacts", payload)
    return created.get("contact") or {}


# ----------------------- Persistence -----------------------

async def _save_bill_row(
    client_id: UUID,
    ctx: TransactionContext,
    status: str,
    zoho_bill_id: str | None = None,
    zoho_vendor_id: str | None = None,
) -> dict[str, Any]:
    db = await get_db()
    inp = ctx.input
    amounts = ctx.amounts
    row = {
        "client_id": str(client_id),
        "vendor": inp.vendor,
        "vendor_trn": inp.vendor_trn,
        "bill_number": inp.bill_number,
        "description": inp.description,
        "amount": float(amounts.gross) if amounts else float(inp.amount),
        "net_amount": float(amounts.net) if amounts else None,
        "vat_amount": float(amounts.vat) if amounts else 0.0,
        "currency": inp.currency,
        "fx_rate": float(amounts.fx_rate) if amounts else 1.0,
        "vat_type": ctx.vat_classification.vat_type if ctx.vat_classification else "out_of_scope",
        "vat_boxes": ctx.boxes.boxes if ctx.boxes else [],
        "is_blocked_vat": ctx.blocked_vat.is_blocked if ctx.blocked_vat else False,
        "bill_date": inp.invoice_date.isoformat() if inp.invoice_date else None,
        "due_date": inp.due_date.isoformat() if inp.due_date else None,
        "status": status,
        "confidence_score": ctx.vat_classification.confidence if ctx.vat_classification else 0,
        "routing_reason": ctx.routing.reason if ctx.routing else None,
        "zoho_bill_id": zoho_bill_id,
        "zoho_vendor_id": zoho_vendor_id,
        "source_document_url": inp.source_document_url,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    res = await db.table("bills").insert(row).execute()
    return res.data[0]


# ----------------------- Posting to Zoho -----------------------

async def _post_bill_to_zoho(
    client_config,
    ctx: TransactionContext,
) -> tuple[str | None, str | None]:
    """Returns (zoho_bill_id, zoho_vendor_id) — None on failure."""
    if not (client_config.zoho_organization_id and client_config.zoho_access_token):
        logger.warning("No Zoho creds — skipping bill post for vendor=%s", ctx.input.vendor)
        return None, None

    async with ZohoBooksClient(
        organization_id=client_config.zoho_organization_id,
        access_token=client_config.zoho_access_token,
        refresh_token=client_config.zoho_refresh_token or "",
        client_uuid=client_config.id,
    ) as zoho:
        vendor = await _find_or_create_zoho_vendor(
            zoho, ctx.input.vendor, ctx.input.vendor_trn
        )
        vendor_id = vendor.get("contact_id")
        if not vendor_id:
            raise RuntimeError(f"Couldn't resolve Zoho vendor '{ctx.input.vendor}'")

        # Ensure a bill_number — Zoho UAE rejects bills without one.
        if not ctx.input.bill_number:
            ctx.input.bill_number = await _next_bill_number(client_config.id)
        payload = build_bill_payload(ctx, client_config.zoho_tax_ids, vendor_id=vendor_id)
        resp = await zoho.create_entity(
            "bills", payload, params={"ignore_auto_number_generation": "true"}
        )
    bill = resp.get("bill") or {}
    return bill.get("bill_id"), vendor_id


# ----------------------- Public entry points -----------------------

async def _amount_exceeds_threshold(client_id: UUID, gross: Decimal) -> bool:
    db = await get_db()
    res = await db.table("clients").select("approval_threshold").eq("id", str(client_id)).single().execute()
    threshold = Decimal(str(res.data.get("approval_threshold", "5000")))
    return gross > threshold


async def _ingest(client_id: UUID, tx_input: TransactionInput) -> str:
    """Shared post-extraction flow used by text + image paths. Returns
    the WhatsApp reply body."""
    # Run the VAT pipeline. require_confirmation=False — for bills we gate on
    # amount-vs-approval_threshold and confidence, not on AUTO_POST defaults.
    ctx = await run_pipeline(tx_input, require_confirmation=True)
    # Pipeline will have set routing to HUMAN_REVIEW (require_confirmation) and
    # NOT posted to Zoho. We treat bills as needs_approval at the AP layer.

    amounts = ctx.amounts
    gross = amounts.gross if amounts else tx_input.amount
    over_threshold = await _amount_exceeds_threshold(client_id, gross)
    low_confidence = (
        ctx.vat_classification is None
        or ctx.vat_classification.confidence < (ctx.client.confidence_threshold if ctx.client else 95)
    )

    if over_threshold or low_confidence:
        # Save and wait for manual approval — don't hit Zoho yet
        bill_row = await _save_bill_row(client_id, ctx, status="needs_approval")
        reason_parts = []
        if over_threshold:
            reason_parts.append(f"AED {gross} exceeds your approval threshold")
        if low_confidence:
            conf = ctx.vat_classification.confidence if ctx.vat_classification else 0
            reason_parts.append(f"VAT confidence only {conf}%")
        reason = "; ".join(reason_parts)

        return (
            "⚠️ Bill needs your approval\n"
            f"Vendor: {tx_input.vendor}\n"
            f"Amount: {gross} {tx_input.currency}"
            + (f"\nDue: {tx_input.due_date.isoformat()}" if tx_input.due_date else "")
            + f"\nReason: {reason}\n"
            "Reply 'approve' to post it to Zoho, or 'reject' to discard."
        )

    # Auto-post: lookup vendor, create Zoho Bill, save Supabase row
    client_config = ctx.client
    try:
        zoho_bill_id, vendor_id = await _post_bill_to_zoho(client_config, ctx)
        bill_row = await _save_bill_row(
            client_id, ctx,
            status="unpaid",
            zoho_bill_id=zoho_bill_id,
            zoho_vendor_id=vendor_id,
        )
    except Exception as e:
        logger.exception("Zoho bill post failed for vendor=%s", tx_input.vendor)
        await _save_bill_row(client_id, ctx, status="failed")
        return f"Couldn't post the bill to Zoho: {e}"

    due_str = tx_input.due_date.isoformat() if tx_input.due_date else "no due date"
    return (
        "📥 Bill recorded\n"
        f"Vendor: {tx_input.vendor}\n"
        f"Amount: {amounts.gross} {tx_input.currency}"
        f" (net {amounts.net}, VAT {amounts.vat})\n"
        f"Due: {due_str}\n"
        f"Status: unpaid"
    )


async def handle_bill_request(client_id: UUID, text: str) -> str:
    try:
        tx_input = await extract_bill(text, client_id)
    except Exception as e:
        logger.exception("Bill extraction failed")
        return f"Couldn't parse that bill: {e}. Try: 'bill from XYZ Trading 8400 AED due in 14 days'."
    return await _ingest(client_id, tx_input)


async def handle_bill_image(
    client_id: UUID, message: dict[str, Any]
) -> str:
    image_obj = message.get("image") or {}
    media_id = image_obj.get("id")
    caption = image_obj.get("caption")
    if not media_id:
        return "I couldn't read that image. Try sending it again."

    try:
        img_bytes, mime = await fetch_media(media_id)
    except Exception:
        logger.exception("WhatsApp media fetch failed for bill")
        return "Couldn't download the image from WhatsApp. Try again."

    try:
        tx_input = await extract_from_image(img_bytes, mime, client_id, caption=caption)
        # Recast the image-extracted input as a Bill (not paid; goes through approval)
        tx_input.zoho_entity_type = "Bill"
        tx_input.is_paid = False
        tx_input.payment_date = None
    except Exception as e:
        logger.exception("Bill image extraction failed")
        return f"Couldn't read that bill image: {e}"

    return await _ingest(client_id, tx_input)


# ----------------------- Approval / rejection -----------------------

async def _latest_pending_bill(client_id: UUID) -> dict[str, Any] | None:
    db = await get_db()
    res = (
        await db.table("bills")
        .select("*")
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .eq("status", "needs_approval")
        .order("created_at", desc=True)
        .limit(1)
        .execute()
    )
    return (res.data or [None])[0]


async def approve_pending_bill(client_id: UUID) -> str:
    bill = await _latest_pending_bill(client_id)
    if not bill:
        return "No bill is pending approval."

    client_config = await load_client_config(client_id)

    # Rebuild a minimal TransactionContext so build_bill_payload can run.
    from transactions.models import TransactionContext, TransactionInput, VatAmounts, VatClassification
    inp = TransactionInput(
        client_id=client_id,
        direction="expense",
        zoho_entity_type="Bill",
        vendor=bill["vendor"],
        description=bill.get("description") or "",
        amount=Decimal(str(bill["amount"])),
        currency=bill.get("currency", "AED"),
        invoice_date=date.fromisoformat(bill["bill_date"]) if bill.get("bill_date") else date.today(),
        due_date=date.fromisoformat(bill["due_date"]) if bill.get("due_date") else None,
        vendor_trn=bill.get("vendor_trn"),
        bill_number=bill.get("bill_number"),
        is_paid=False,
    )
    ctx = TransactionContext(input=inp, client=client_config)
    ctx.vat_classification = VatClassification(
        vat_type=bill.get("vat_type") or "standard",
        confidence=int(bill.get("confidence_score") or 0),
        reasoning="re-applied from approval",
    )
    ctx.amounts = VatAmounts(
        net=Decimal(str(bill.get("net_amount") or bill["amount"])),
        vat=Decimal(str(bill.get("vat_amount") or 0)),
        gross=Decimal(str(bill["amount"])),
        fx_rate=Decimal(str(bill.get("fx_rate") or 1)),
        amount_aed=Decimal(str(bill["amount"])),
    )

    try:
        zoho_bill_id, vendor_id = await _post_bill_to_zoho(client_config, ctx)
    except Exception as e:
        logger.exception("Approval post failed for bill %s", bill["id"])
        return f"Couldn't post the bill to Zoho: {e}"

    db = await get_db()
    await (
        db.table("bills")
        .update({
            "status": "unpaid",
            "zoho_bill_id": zoho_bill_id,
            "zoho_vendor_id": vendor_id,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("id", bill["id"])
        .execute()
    )
    return f"✅ Approved + posted to Zoho.\n{bill['vendor']} — {bill['amount']} {bill['currency']}"


async def reject_pending_bill(client_id: UUID) -> str:
    bill = await _latest_pending_bill(client_id)
    if not bill:
        return "No bill is pending approval."
    db = await get_db()
    await (
        db.table("bills")
        .update({
            "status": "rejected",
            "deleted": True,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("id", bill["id"])
        .execute()
    )
    return f"🗑️ Rejected: {bill['vendor']} — {bill['amount']} {bill['currency']}"
