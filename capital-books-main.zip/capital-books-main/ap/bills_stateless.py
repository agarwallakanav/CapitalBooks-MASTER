"""Stateless AP bill processing — Phase C of the orchestrator migration.

Two entry points:

  - classify_and_record_bill(input, ctx) → ModuleResult
      Run the VAT pipeline against a bill input, decide approval gate vs
      auto-post, and (on auto-post) declare the Zoho writes.

  - approve_or_reject_pending_bill(input, ctx) → ModuleResult
      Find the latest needs_approval bill and either post it to Zoho
      (action='approve') or soft-delete it (action='reject').

Both use ctx.resolver.resolve_vendor for the Zoho vendor lookup-or-create
so the engine owns the connection + audit events.
"""
import logging
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Any, Literal

from database import get_db
from orchestrator.engine import Document, ModuleResult, OrchContext, ZohoWrite
from transactions.dedup import find_recent_duplicate, format_for_user
from transactions.models import (
    ClientConfig as PipelineClientConfig,
    TransactionContext,
    TransactionInput,
)
from zoho.entities import build_bill_payload

logger = logging.getLogger(__name__)


def _shim(cfg) -> PipelineClientConfig:
    """Bridge orchestrator.ClientConfig → the old pipeline ClientConfig.
    Phase D will remove this when the pipeline modules drop the old type."""
    return PipelineClientConfig(
        id=cfg.id,
        company_name=cfg.company_name,
        vat_basis=cfg.vat_basis,
        entity_type=None,
        foreign_suppliers=cfg.foreign_suppliers,
        confidence_threshold=cfg.confidence_threshold,
        approval_amount_limit=Decimal(str(cfg.approval_amount_limit)),
        zoho_organization_id=cfg.zoho_organization_id,
        zoho_access_token=cfg.zoho_access_token,
        zoho_refresh_token=cfg.zoho_refresh_token,
        zoho_tax_ids=cfg.zoho_tax_ids,
    )


# ---------------------------------------------------------------------------
# Input shapes
# ---------------------------------------------------------------------------

class BillInput:
    """A bill ready for the pipeline + orchestrator."""

    def __init__(self, tx_input: TransactionInput, sender: str | None = None):
        self.tx_input = tx_input
        self.sender = sender


class BillDecisionInput:
    """Approve or reject the most recent needs_approval bill for this client."""

    def __init__(self, action: Literal["approve", "reject"], sender: str | None = None):
        self.action = action
        self.sender = sender


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _next_bill_number(client_id, today: date | None = None) -> str:
    today = today or date.today()
    prefix = f"BILL-{today:%Y%m}"
    db = await get_db()
    res = (
        await db.table("bills")
        .select("bill_number")
        .eq("client_id", str(client_id))
        .like("bill_number", f"{prefix}%")
        .order("bill_number", desc=True)
        .limit(1)
        .execute()
    )
    last = (res.data or [{}])[0].get("bill_number") if res.data else None
    seq = int(last.split("-")[-1]) + 1 if last else 1
    return f"{prefix}-{seq:04d}"


async def _save_bill_row(
    client_id, ctx: TransactionContext, status: str,
    zoho_bill_id: str | None = None, zoho_vendor_id: str | None = None,
) -> dict[str, Any]:
    """Persist a bill row in Supabase. Lives here for now; Phase D will route
    even this write through the orchestrator."""
    db = await get_db()
    inp = ctx.input
    amounts = ctx.amounts
    row = {
        "client_id": str(client_id),
        "vendor": inp.vendor,
        "vendor_trn": inp.vendor_trn,
        "bill_number": inp.bill_number,
        "description": inp.description,
        "amount": float(amounts.gross) if amounts else float(inp.amount),
        "net_amount": float(amounts.net) if amounts else None,
        "vat_amount": float(amounts.vat) if amounts else 0.0,
        "currency": inp.currency,
        "fx_rate": float(amounts.fx_rate) if amounts else 1.0,
        "vat_type": ctx.vat_classification.vat_type if ctx.vat_classification else "out_of_scope",
        "vat_boxes": ctx.boxes.boxes if ctx.boxes else [],
        "is_blocked_vat": ctx.blocked_vat.is_blocked if ctx.blocked_vat else False,
        "bill_date": inp.invoice_date.isoformat() if inp.invoice_date else None,
        "due_date": inp.due_date.isoformat() if inp.due_date else None,
        "status": status,
        "confidence_score": ctx.vat_classification.confidence if ctx.vat_classification else 0,
        "routing_reason": ctx.routing.reason if ctx.routing else None,
        "zoho_bill_id": zoho_bill_id,
        "zoho_vendor_id": zoho_vendor_id,
        "source_document_url": inp.source_document_url,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    res = await db.table("bills").insert(row).execute()
    return res.data[0]


async def _amount_exceeds_threshold(client_id, gross: Decimal) -> bool:
    db = await get_db()
    res = await db.table("clients").select("approval_threshold").eq("id", str(client_id)).single().execute()
    threshold = Decimal(str(res.data.get("approval_threshold", "5000")))
    return gross > threshold


# ---------------------------------------------------------------------------
# Entry: ingest a new bill
# ---------------------------------------------------------------------------

async def classify_and_record_bill(input: BillInput, ctx: OrchContext) -> ModuleResult:
    """Run the VAT pipeline against the bill input, decide approval gate vs
    auto-post, and return a ModuleResult with the Zoho writes the engine
    should execute (only when auto-posting)."""
    from transactions.pipeline import run_pipeline

    cfg = ctx.cfg
    tx_input = input.tx_input
    # skip_transaction_log: bills live in the bills table, not transactions.
    pipeline_ctx = await run_pipeline(
        tx_input, require_confirmation=True, skip_transaction_log=True,
    )

    amounts = pipeline_ctx.amounts
    gross = amounts.gross if amounts else tx_input.amount
    confidence = (
        pipeline_ctx.vat_classification.confidence
        if pipeline_ctx.vat_classification else 0
    )

    over_threshold = await _amount_exceeds_threshold(cfg.id, gross)
    low_confidence = confidence < cfg.confidence_threshold

    # Duplicate detection — vendor + amount within ±7 days. For bills the
    # invoice_date is the truthful "when this happened"; fall back to due_date.
    dup_when = tx_input.invoice_date or tx_input.due_date
    dup_match = await find_recent_duplicate(
        cfg.id, "bill",
        vendor=tx_input.vendor,
        amount=gross,
        when=dup_when,
    )

    extra_events: list[dict[str, Any]] = [
        {"event_type": "bill_extracted",
         "payload": {
             "vendor": tx_input.vendor,
             "gross": str(gross),
             "vat_type": pipeline_ctx.vat_classification.vat_type if pipeline_ctx.vat_classification else None,
             "confidence": confidence,
             "due_date": tx_input.due_date.isoformat() if tx_input.due_date else None,
         }},
    ]

    if over_threshold or low_confidence or dup_match:
        # Save needs_approval; do NOT call Zoho. User will approve later.
        bill_row = await _save_bill_row(cfg.id, pipeline_ctx, status="needs_approval")
        reason_parts = []
        if dup_match:
            reason_parts.append(
                f"possible duplicate of bill {dup_match.extra.get('bill_number') or dup_match.entity_id[:8]}"
            )
        if over_threshold:
            reason_parts.append(f"AED {gross} exceeds your approval threshold")
        if low_confidence:
            reason_parts.append(f"VAT confidence only {confidence}%")
        reason = "; ".join(reason_parts)
        extra_events.append({
            "event_type": "bill_flagged_for_approval",
            "payload": {"reason": reason, "bill_id": bill_row["id"]},
        })
        dup_header = format_for_user(dup_match) + "\n\n" if dup_match else ""
        reply = (
            dup_header
            + "⚠️ Bill needs your approval\n"
            + f"Vendor: {tx_input.vendor}\n"
            + f"Amount: {gross} {tx_input.currency}"
            + (f"\nDue: {tx_input.due_date.isoformat()}" if tx_input.due_date else "")
            + f"\nReason: {reason}\n"
            + "Reply 'approve' to post it to Zoho, or 'reject' to discard."
        )
        return ModuleResult(
            reply_to_user=reply,
            zoho_writes=[],
            extra_events=extra_events,
            entity_kind="bill",
            entity_id=bill_row["id"],
        )

    # Auto-post path: resolve vendor + emit POST /bills
    vendor_id: str | None = None
    if ctx.resolver is not None:
        try:
            vendor_id = await ctx.resolver.resolve_vendor(
                tx_input.vendor, tx_input.vendor_trn
            )
        except Exception as exc:
            logger.exception("Vendor resolution failed for %s", tx_input.vendor)
            bill_row = await _save_bill_row(cfg.id, pipeline_ctx, status="failed")
            return ModuleResult(
                reply_to_user=f"Couldn't resolve vendor in Zoho: {exc}",
                extra_events=extra_events + [{
                    "event_type": "bill_zoho_skipped",
                    "payload": {"reason": "vendor_resolve_failed"},
                }],
                entity_kind="bill",
                entity_id=bill_row["id"],
            )

    if not tx_input.bill_number:
        tx_input.bill_number = await _next_bill_number(cfg.id)

    payload = build_bill_payload(pipeline_ctx, cfg.zoho_tax_ids, vendor_id=vendor_id)

    # Save the bill row first so the engine can bind the Zoho id back.
    bill_row = await _save_bill_row(
        cfg.id, pipeline_ctx, status="unpaid",
        zoho_vendor_id=vendor_id,
    )

    zoho_writes = [
        ZohoWrite(
            method="POST",
            endpoint="bills",
            payload=payload,
            params={"ignore_auto_number_generation": "true"},
            bind_to_entity=("bill", bill_row["id"]),
        )
    ]

    due_str = tx_input.due_date.isoformat() if tx_input.due_date else "no due date"
    reply = (
        "📥 Bill recorded\n"
        f"Vendor: {tx_input.vendor}\n"
        f"Amount: {amounts.gross} {tx_input.currency}"
        f" (net {amounts.net}, VAT {amounts.vat})\n"
        f"Due: {due_str}\n"
        f"Status: unpaid"
    )

    return ModuleResult(
        reply_to_user=reply,
        zoho_writes=zoho_writes,
        extra_events=extra_events + [{
            "event_type": "bill_auto_posted",
            "payload": {"bill_id": bill_row["id"]},
        }],
        entity_kind="bill",
        entity_id=bill_row["id"],
    )


# ---------------------------------------------------------------------------
# Entry: approve or reject the latest pending bill
# ---------------------------------------------------------------------------

async def _latest_pending_bill(client_id) -> dict[str, Any] | None:
    db = await get_db()
    res = (
        await db.table("bills")
        .select("*")
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .eq("status", "needs_approval")
        .order("created_at", desc=True)
        .limit(1)
        .execute()
    )
    return (res.data or [None])[0]


async def approve_or_reject_pending_bill(
    input: BillDecisionInput, ctx: OrchContext
) -> ModuleResult:
    cfg = ctx.cfg
    bill = await _latest_pending_bill(cfg.id)
    if not bill:
        return ModuleResult(reply_to_user="No bill is pending approval.")

    if input.action == "reject":
        db = await get_db()
        await (
            db.table("bills")
            .update({
                "status": "rejected",
                "deleted": True,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            })
            .eq("id", bill["id"])
            .execute()
        )
        return ModuleResult(
            reply_to_user=(
                f"🗑️ Rejected: {bill['vendor']} — {bill['amount']} {bill['currency']}"
            ),
            extra_events=[{
                "event_type": "bill_rejected",
                "payload": {"bill_id": bill["id"], "vendor": bill["vendor"]},
            }],
            entity_kind="bill",
            entity_id=bill["id"],
        )

    # approve: resolve vendor + post to Zoho
    vendor_id = bill.get("zoho_vendor_id")
    if not vendor_id and ctx.resolver is not None:
        try:
            vendor_id = await ctx.resolver.resolve_vendor(
                bill["vendor"], bill.get("vendor_trn"),
            )
        except Exception as exc:
            return ModuleResult(
                reply_to_user=f"Couldn't resolve vendor in Zoho: {exc}",
                extra_events=[{
                    "event_type": "bill_approve_failed",
                    "payload": {"bill_id": bill["id"], "stage": "vendor_resolve"},
                }],
            )

    # Rebuild a TransactionContext from the saved bill so build_bill_payload works.
    from transactions.models import (
        TransactionContext, TransactionInput, VatAmounts, VatClassification,
    )
    inp = TransactionInput(
        client_id=cfg.id,
        direction="expense",
        zoho_entity_type="Bill",
        vendor=bill["vendor"],
        description=bill.get("description") or "",
        amount=Decimal(str(bill["amount"])),
        currency=bill.get("currency", "AED"),
        invoice_date=date.fromisoformat(bill["bill_date"]) if bill.get("bill_date") else date.today(),
        due_date=date.fromisoformat(bill["due_date"]) if bill.get("due_date") else None,
        vendor_trn=bill.get("vendor_trn"),
        bill_number=bill.get("bill_number") or await _next_bill_number(cfg.id),
        is_paid=False,
    )
    pctx = TransactionContext(input=inp, client=_shim(cfg))
    pctx.vat_classification = VatClassification(
        vat_type=bill.get("vat_type") or "standard",
        confidence=int(bill.get("confidence_score") or 0),
        reasoning="re-applied from approval",
    )
    pctx.amounts = VatAmounts(
        net=Decimal(str(bill.get("net_amount") or bill["amount"])),
        vat=Decimal(str(bill.get("vat_amount") or 0)),
        gross=Decimal(str(bill["amount"])),
        fx_rate=Decimal(str(bill.get("fx_rate") or 1)),
        amount_aed=Decimal(str(bill["amount"])),
    )

    payload = build_bill_payload(pctx, cfg.zoho_tax_ids, vendor_id=vendor_id)

    db = await get_db()
    await (
        db.table("bills")
        .update({
            "status": "unpaid",
            "zoho_vendor_id": vendor_id,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("id", bill["id"])
        .execute()
    )

    return ModuleResult(
        reply_to_user=(
            f"✅ Approved + posting to Zoho.\n"
            f"{bill['vendor']} — {bill['amount']} {bill['currency']}"
        ),
        zoho_writes=[
            ZohoWrite(
                method="POST",
                endpoint="bills",
                payload=payload,
                params={"ignore_auto_number_generation": "true"},
                bind_to_entity=("bill", bill["id"]),
            )
        ],
        extra_events=[{
            "event_type": "bill_approved",
            "payload": {"bill_id": bill["id"]},
        }],
        entity_kind="bill",
        entity_id=bill["id"],
    )
