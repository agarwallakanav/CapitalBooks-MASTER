"""Pay or schedule a vendor bill.

  "pay bill to XYZ"               → find unpaid bill matching XYZ → post VendorPayment to Zoho → status=paid
  "schedule payment to XYZ Thursday" → set scheduled_payment_date, status=scheduled (no Zoho call)

Vendor name matching is fuzzy (case-insensitive substring on the bills table).
If multiple candidates match, the most recent unpaid one wins; if none, we
respond with a "couldn't find" message.
"""
import json
import logging
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any
from uuid import UUID

from anthropic import AsyncAnthropic

from config import settings
from database import get_db
from transactions.pipeline import load_client_config
from zoho.client import ZohoBooksClient

logger = logging.getLogger(__name__)

_anthropic: AsyncAnthropic | None = None


def _claude() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


_PARSE_PROMPT = """Parse a UAE business owner's bill-payment instruction.

Reply with JSON only:
{
  "vendor": "<vendor name they mentioned>",
  "amount": <number or null>,
  "action": "pay" or "schedule",
  "scheduled_date": "YYYY-MM-DD" or null
}

For "schedule" actions, resolve relative dates to absolute YYYY-MM-DD.
Today is {today}. Examples:
  "pay bill to ACME Trading"        → action=pay
  "schedule payment to XYZ Thursday" → action=schedule, scheduled_date=<next thursday>
  "pay 2500 to Etisalat"            → action=pay, amount=2500"""


def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return text.strip()


async def _parse_instruction(text: str) -> dict[str, Any]:
    today = date.today().isoformat()
    resp = await _claude().messages.create(
        model=settings.anthropic_model_fast,
        max_tokens=250,
        messages=[{
            "role": "user",
            "content": f"{_PARSE_PROMPT.format(today=today)}\n\nMessage: {text}",
        }],
    )
    raw = _strip_fences(
        "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    )
    return json.loads(raw)


async def _find_unpaid_bill(
    client_id: UUID, vendor: str, amount: float | None = None
) -> dict[str, Any] | None:
    db = await get_db()
    q = (
        db.table("bills")
        .select("*")
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .in_("status", ["unpaid", "scheduled"])
        .ilike("vendor", f"%{vendor}%")
        .order("due_date", desc=False)
    )
    if amount is not None:
        # Bracket amount within 1% tolerance
        q = q.gte("amount", amount * 0.99).lte("amount", amount * 1.01)
    res = await q.execute()
    return (res.data or [None])[0]


async def _post_zoho_vendor_payment(
    client_config,
    bill: dict[str, Any],
) -> dict[str, Any]:
    """Create a VendorPayment in Zoho that closes out the bill."""
    if not (
        client_config.zoho_organization_id
        and client_config.zoho_access_token
        and bill.get("zoho_bill_id")
        and bill.get("zoho_vendor_id")
    ):
        raise RuntimeError("Bill or client lacks Zoho ids — can't post payment")

    payload = {
        "vendor_id": bill["zoho_vendor_id"],
        "payment_mode": "Bank Transfer",
        "amount": float(bill["amount"]),
        "date": date.today().isoformat(),
        "bills": [{
            "bill_id": bill["zoho_bill_id"],
            "amount_applied": float(bill["amount"]),
        }],
    }
    async with ZohoBooksClient(
        organization_id=client_config.zoho_organization_id,
        access_token=client_config.zoho_access_token,
        refresh_token=client_config.zoho_refresh_token or "",
        client_uuid=client_config.id,
    ) as zoho:
        return await zoho.create_entity("vendorpayments", payload)


async def _mark_paid(bill_id: str) -> None:
    db = await get_db()
    await (
        db.table("bills")
        .update({
            "status": "paid",
            "paid_date": date.today().isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("id", bill_id)
        .execute()
    )


async def _mark_scheduled(bill_id: str, on: date) -> None:
    db = await get_db()
    await (
        db.table("bills")
        .update({
            "status": "scheduled",
            "scheduled_payment_date": on.isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("id", bill_id)
        .execute()
    )


async def handle_payment_request(client_id: UUID, text: str) -> str:
    try:
        parsed = await _parse_instruction(text)
    except Exception:
        logger.exception("Payment instruction parse failed")
        return "I couldn't understand that. Try: 'pay bill to ACME Trading' or 'schedule payment to XYZ for Thursday'."

    vendor = (parsed.get("vendor") or "").strip()
    if not vendor:
        return "Tell me which vendor — e.g. 'pay bill to Etisalat'."

    bill = await _find_unpaid_bill(client_id, vendor, parsed.get("amount"))
    if not bill:
        return f"No unpaid or scheduled bill matches '{vendor}'."

    action = parsed.get("action") or "pay"

    if action == "schedule":
        scheduled_str = parsed.get("scheduled_date")
        if not scheduled_str:
            return "When should I schedule it? Try 'next Thursday' or a specific date."
        try:
            scheduled = date.fromisoformat(scheduled_str)
        except ValueError:
            return f"Couldn't read the date '{scheduled_str}'."
        await _mark_scheduled(bill["id"], scheduled)
        return (
            f"📅 Scheduled payment\n"
            f"Vendor: {bill['vendor']}\n"
            f"Amount: {bill['amount']} {bill['currency']}\n"
            f"On: {scheduled.isoformat()}"
        )

    # action == "pay"
    client_config = await load_client_config(client_id)
    try:
        await _post_zoho_vendor_payment(client_config, bill)
    except Exception as e:
        logger.exception("Zoho VendorPayment failed for bill %s", bill["id"])
        return f"Couldn't post the payment to Zoho: {e}"

    await _mark_paid(bill["id"])
    return (
        f"💸 Paid\n"
        f"Vendor: {bill['vendor']}\n"
        f"Amount: {bill['amount']} {bill['currency']}\n"
        f"Date: {date.today().isoformat()}"
    )
