"""Vendor listing — Zoho contacts filtered + enriched with bill activity.

list_vendors(input, ctx) → ModuleResult

Filters:
  default          → all vendors, top 15 by activity (bill count)
  owed             → vendors with open / overdue / partially-paid bills
  paid_this_month  → vendors we've paid in the current calendar month
  inactive         → vendors with no bills in the last 90 days

If the matching set is >15, builds an Excel file and sends as a WhatsApp
document (returning the __SUPPRESS_REPLY__ sentinel so the orchestrator
doesn't echo a duplicate text bubble). Otherwise the list goes inline.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from io import BytesIO
from typing import Any, Literal

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from orchestrator.engine import ModuleResult, OrchContext

logger = logging.getLogger(__name__)

FilterKind = Literal["default", "owed", "paid_this_month", "inactive"]
_INLINE_CAP = 15


@dataclass
class ListVendorsQuery:
    sender: str | None = None
    filter_kind: FilterKind = "default"


# ---------------------------------------------------------------------------

def _safe_date(s: str | None) -> date | None:
    if not s:
        return None
    try:
        return date.fromisoformat(str(s)[:10])
    except ValueError:
        return None


def _format_money(amt: float, currency: str = "AED") -> str:
    return f"{currency} {amt:,.2f}"


def _aggregate_by_vendor(bills: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Returns {vendor_id: {count, outstanding, last_amount, last_date, last_currency}}."""
    agg: dict[str, dict[str, Any]] = {}
    for b in bills:
        vid = b.get("vendor_id") or b.get("contact_id") or ""
        if not vid:
            continue
        bal = float(b.get("balance") or 0)
        amt = float(b.get("total") or 0)
        d = _safe_date(b.get("date") or b.get("bill_date"))
        row = agg.setdefault(vid, {
            "count": 0, "outstanding": 0.0,
            "last_amount": 0.0, "last_date": None, "last_currency": "AED",
        })
        row["count"] += 1
        row["outstanding"] += bal
        if d and (row["last_date"] is None or d > row["last_date"]):
            row["last_date"] = d
            row["last_amount"] = amt
            row["last_currency"] = b.get("currency_code") or "AED"
    return agg


def _filter_vendors(
    vendors: list[dict[str, Any]],
    by_vendor: dict[str, dict[str, Any]],
    filter_kind: FilterKind,
    paid_this_month_ids: set[str],
) -> list[tuple[dict[str, Any], dict[str, Any]]]:
    """Returns [(vendor, agg), ...] filtered + sorted per filter_kind."""
    today = date.today()
    pairs: list[tuple[dict[str, Any], dict[str, Any]]] = []
    for v in vendors:
        vid = v.get("contact_id")
        if not vid:
            continue
        agg = by_vendor.get(vid, {
            "count": 0, "outstanding": 0.0,
            "last_amount": 0.0, "last_date": None, "last_currency": "AED",
        })

        if filter_kind == "owed":
            if agg["outstanding"] <= 0:
                continue
        elif filter_kind == "paid_this_month":
            if vid not in paid_this_month_ids:
                continue
        elif filter_kind == "inactive":
            last = agg["last_date"]
            if last and (today - last).days <= 90:
                continue

        pairs.append((v, agg))

    # Sort: owed → by outstanding desc; paid_this_month → by last_date desc;
    # inactive → alphabetical; default → bill count desc, then alpha.
    if filter_kind == "owed":
        pairs.sort(key=lambda p: -p[1]["outstanding"])
    elif filter_kind == "paid_this_month":
        pairs.sort(key=lambda p: (p[1]["last_date"] or date.min), reverse=True)
    elif filter_kind == "inactive":
        pairs.sort(key=lambda p: (p[0].get("contact_name") or "").lower())
    else:
        pairs.sort(
            key=lambda p: (-p[1]["count"], (p[0].get("contact_name") or "").lower())
        )
    return pairs


# ---------------------------------------------------------------------------

async def _fetch_paid_this_month(zoho) -> set[str]:
    """Vendor IDs we've paid (vendor_payments) this calendar month."""
    today = date.today()
    start = today.replace(day=1).isoformat()
    end = today.isoformat()
    try:
        resp = await zoho.list_entities("vendorpayments", filters={
            "per_page": 200, "date_after": start, "date_before": end,
        })
        ids = {p.get("vendor_id") for p in (resp.get("vendorpayments") or [])}
        return {i for i in ids if i}
    except Exception:
        logger.exception("vendorpayments fetch failed (non-fatal)")
        return set()


async def list_vendors(
    input: ListVendorsQuery, ctx: OrchContext,
) -> ModuleResult:
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected.")
    z = ctx.resolver._zoho

    try:
        contacts_resp = await z.list_entities("contacts", filters={
            "contact_type": "vendor",
            "status": "active",
            "per_page": 200,
        })
        vendors = contacts_resp.get("contacts") or []
        logger.info(
            "Zoho GET /contacts?contact_type=vendor&status=active → %d contacts",
            len(vendors),
        )
    except Exception as e:
        logger.exception("vendor fetch failed")
        return ModuleResult(reply_to_user=f"Couldn't pull vendors: {e}")

    # Bills across the most useful statuses (single fetch, group locally)
    bills: list[dict[str, Any]] = []
    try:
        for status in ("open", "overdue", "paid", "partially_paid"):
            r = await z.list_entities("bills", filters={
                "status": status, "per_page": 200,
            })
            bills.extend(r.get("bills") or [])
    except Exception:
        logger.exception("bills fetch failed (non-fatal — listing without activity)")

    by_vendor = _aggregate_by_vendor(bills)
    paid_ids = (await _fetch_paid_this_month(z)
                if input.filter_kind == "paid_this_month" else set())

    pairs = _filter_vendors(vendors, by_vendor, input.filter_kind, paid_ids)
    total = len(pairs)
    if total == 0:
        return ModuleResult(reply_to_user=_empty_message(input.filter_kind))

    if total <= _INLINE_CAP:
        return ModuleResult(
            reply_to_user=_format_inline(pairs, input.filter_kind),
            extra_events=[{
                "event_type": "vendors_listed",
                "payload": {"filter": input.filter_kind, "count": total},
            }],
        )

    # Large result set → build xlsx and send as WhatsApp document
    return await _list_as_excel(pairs, input, ctx)


# ---------------------------------------------------------------------------

def _header(filter_kind: FilterKind, total: int, shown: int) -> str:
    if filter_kind == "owed":
        return f"📋 *Vendors you owe money to* ({total})"
    if filter_kind == "paid_this_month":
        return f"📋 *Vendors paid this month* ({total})"
    if filter_kind == "inactive":
        return f"📋 *Inactive vendors (no bills in 90+ days)* ({total})"
    if shown < total:
        return f"📋 *Top {shown} vendors* (of {total} total)"
    return f"📋 *Your vendors ({total} total)*"


def _format_inline(
    pairs: list[tuple[dict[str, Any], dict[str, Any]]],
    filter_kind: FilterKind,
) -> str:
    total = len(pairs)
    lines = [_header(filter_kind, total, total), ""]
    for i, (vendor, agg) in enumerate(pairs, 1):
        name = vendor.get("contact_name") or "(unnamed)"
        line = f"{i}. {name}"
        if filter_kind == "owed":
            line += f" — owed: {_format_money(agg['outstanding'])}"
        elif filter_kind == "paid_this_month":
            d = agg["last_date"]
            if d:
                line += (f" — last paid: {_format_money(agg['last_amount'], agg['last_currency'])}"
                         f" ({d.strftime('%-d %b')})")
        elif filter_kind == "inactive":
            d = agg["last_date"]
            line += (f" — last activity: {d.isoformat() if d else 'never'}")
        else:
            count = agg["count"]
            d = agg["last_date"]
            if d:
                line += (f" — last bill: {_format_money(agg['last_amount'], agg['last_currency'])}"
                         f" ({d.strftime('%-d %b')})")
            if count > 1:
                line += f", {count} bills"
        lines.append(line)
    return "\n".join(lines)


def _empty_message(filter_kind: FilterKind) -> str:
    if filter_kind == "owed":
        return "✅ No vendors with outstanding balances."
    if filter_kind == "paid_this_month":
        return "No vendor payments recorded this month yet."
    if filter_kind == "inactive":
        return "No inactive vendors — everyone has activity within the last 90 days."
    return "No vendors found. Add one by recording a bill ('bill from XYZ 1000 AED due in 14 days')."


# ---------------------------------------------------------------------------
# Excel export when set > 15
# ---------------------------------------------------------------------------

_NAVY = "1A2332"; _GREEN = "4CAF50"; _ALT = "F4F6F8"
_AED_FMT = '_-* #,##0.00 [$AED]_-;-* #,##0.00 [$AED]_-'


def _build_vendor_xlsx(
    pairs: list[tuple[dict[str, Any], dict[str, Any]]],
    filter_kind: FilterKind,
) -> bytes:
    wb = Workbook(); ws = wb.active; ws.title = "Vendors"
    headers = ["#", "Vendor", "Email", "Phone", "Currency",
               "Bills (total)", "Outstanding (AED)",
               "Last bill amount", "Last bill date"]
    for c, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=_NAVY)
    for i, (v, agg) in enumerate(pairs, 1):
        r = i + 1
        ws.cell(row=r, column=1, value=i)
        ws.cell(row=r, column=2, value=v.get("contact_name") or "")
        ws.cell(row=r, column=3, value=v.get("email") or "")
        ws.cell(row=r, column=4, value=v.get("phone") or "")
        ws.cell(row=r, column=5, value=v.get("currency_code") or "AED")
        ws.cell(row=r, column=6, value=agg["count"])
        ws.cell(row=r, column=7, value=round(agg["outstanding"], 2))
        ws.cell(row=r, column=8, value=round(agg["last_amount"], 2))
        ws.cell(row=r, column=9, value=agg["last_date"].isoformat() if agg["last_date"] else "")
        if r % 2 == 0:
            for c in range(1, len(headers) + 1):
                ws.cell(row=r, column=c).fill = PatternFill("solid", fgColor=_ALT)
    for c in (7, 8):
        for r in range(2, len(pairs) + 2):
            ws.cell(row=r, column=c).number_format = _AED_FMT
    ws.freeze_panes = "A2"
    for col_idx in range(1, len(headers) + 1):
        col = get_column_letter(col_idx)
        max_len = len(headers[col_idx - 1])
        for r in range(1, ws.max_row + 1):
            v = ws.cell(row=r, column=col_idx).value
            if v is None: continue
            max_len = max(max_len, len(str(v)))
        ws.column_dimensions[col].width = min(max_len + 3, 50)

    buf = BytesIO(); wb.save(buf)
    return buf.getvalue()


async def _list_as_excel(
    pairs: list[tuple[dict[str, Any], dict[str, Any]]],
    input: ListVendorsQuery,
    ctx: OrchContext,
) -> ModuleResult:
    import time as _time
    from ar.storage import upload_bytes
    from whatsapp.sender import send_document
    xlsx = _build_vendor_xlsx(pairs, input.filter_kind)
    safe_filter = input.filter_kind
    key = f"vendor_lists/{ctx.cfg.id}/vendors_{safe_filter}_{int(_time.time())}.xlsx"
    file_url = await upload_bytes(
        key, xlsx,
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    caption = (
        f"📋 Vendor List — {ctx.cfg.company_name}\n"
        f"{len(pairs)} vendors"
        + (f" ({input.filter_kind})" if input.filter_kind != "default" else "")
    )
    try:
        await send_document(
            to=input.sender or "", link=file_url,
            filename=f"vendors_{safe_filter}.xlsx",
            caption=caption,
        )
        return ModuleResult(
            reply_to_user="__SUPPRESS_REPLY__",
            extra_events=[{
                "event_type": "vendors_exported",
                "payload": {"filter": input.filter_kind, "count": len(pairs)},
            }],
        )
    except Exception as e:
        logger.exception("WhatsApp document send failed for vendor list")
        return ModuleResult(
            reply_to_user=f"⚠️ Built the list but couldn't send the attachment: {e}\nDirect link: {file_url}",
        )
