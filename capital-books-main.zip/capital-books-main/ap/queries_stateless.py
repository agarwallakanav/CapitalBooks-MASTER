"""AP read-layer — queries that hit Zoho directly (not our Supabase mirror).

Parallel to ar/queries_stateless.py:
  query_vendor_payment_status(name, ctx)
      "did I pay Etisalat?" / "is the X bill paid?" / "when is the Y bill due?"
      → list a vendor's open + recently-paid bills with due dates.

  query_overdue_bills(ctx)
      Bills past due_date or due within 3 days.

  query_ap_aging(ctx)
      AP aging buckets (current / 1-30 / 31-60 / 61-90 / 90+) + top vendors owed.

  query_total_owed(ctx)
      "how much do I owe?" — single number across all outstanding bills.

  mark_bill_paid_simple(vendor_name, ctx)
      Quick toggle when the user says "mark the Etisalat bill paid".
      Looks up the vendor's most recent open bill, declares a Zoho
      VendorPayment write using the client's default payment account.
      No multi-turn payment-method cascade (use ap.payments_stateless for that).
"""
import logging
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any

from orchestrator.engine import ModuleResult, OrchContext, ZohoWrite

logger = logging.getLogger(__name__)


@dataclass
class VendorPaymentQuery:
    vendor_name: str
    sender: str | None = None


@dataclass
class MarkPaidQuery:
    vendor_name: str
    sender: str | None = None


@dataclass
class _Empty:
    sender: str | None = None


# ---------------------------------------------------------------------------
# Vendor payment status
# ---------------------------------------------------------------------------

async def query_vendor_payment_status(
    input: VendorPaymentQuery, ctx: OrchContext
) -> ModuleResult:
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected — can't check payment status.")
    try:
        contacts = await ctx.resolver._zoho.search_contacts(input.vendor_name)
        vendors = [c for c in contacts if c.get("contact_type") == "vendor"]
        if not vendors:
            return ModuleResult(
                reply_to_user=f"I don't see *{input.vendor_name}* as a vendor in Zoho.",
            )
        vendor = vendors[0]
        vendor_id = vendor.get("contact_id")
        resp = await ctx.resolver._zoho.list_entities(
            "bills",
            filters={"vendor_id": vendor_id, "per_page": 25},
        )
    except Exception as e:
        logger.exception("Vendor payment status query failed")
        return ModuleResult(reply_to_user=f"Couldn't reach Zoho: {e}")

    bills = resp.get("bills") or []
    if not bills:
        return ModuleResult(reply_to_user=f"*{vendor.get('contact_name')}*: no bills on file.")

    open_bills = [b for b in bills if b.get("status") in {"open", "overdue", "partially_paid"}]
    paid_bills = [b for b in bills if b.get("status") == "paid"]
    currency = bills[0].get("currency_code", "AED")

    total_open = sum(float(b.get("balance") or 0) for b in open_bills)
    total_paid = sum(float(b.get("total") or 0) for b in paid_bills[:10])

    lines = [f"*{vendor.get('contact_name')}*"]
    if open_bills:
        lines.append(f"💸 Owed: {currency} {total_open:,.2f} across {len(open_bills)} bill(s)")
        for b in open_bills[:5]:
            tag = "OVERDUE" if b.get("status") == "overdue" else b.get("status")
            lines.append(
                f"  • {b.get('bill_number')} — {currency} "
                f"{float(b.get('balance') or 0):,.2f} ({tag}, due {b.get('due_date')})"
            )
    else:
        lines.append("✅ No open bills.")
    if paid_bills:
        lines.append("")
        lines.append(f"✅ Recently paid (last {len(paid_bills[:10])}): {currency} {total_paid:,.2f}")
        for b in paid_bills[:3]:
            lines.append(
                f"  • {b.get('bill_number')} — {currency} "
                f"{float(b.get('total') or 0):,.2f} on {b.get('last_payment_date') or b.get('date')}"
            )

    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{
            "event_type": "ap_vendor_status_queried",
            "payload": {"vendor_id": vendor_id, "open_count": len(open_bills)},
        }],
    )


# ---------------------------------------------------------------------------
# Overdue bills
# ---------------------------------------------------------------------------

async def query_overdue_bills(input: _Empty, ctx: OrchContext) -> ModuleResult:
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected.")

    today = date.today()
    threshold = today + timedelta(days=3)
    try:
        resp_overdue = await ctx.resolver._zoho.list_entities(
            "bills", filters={"per_page": 50, "status": "overdue"},
        )
        overdue = resp_overdue.get("bills") or []
        resp_open = await ctx.resolver._zoho.list_entities(
            "bills", filters={"per_page": 50, "status": "open"},
        )
        due_soon = [
            b for b in (resp_open.get("bills") or [])
            if b.get("due_date") and date.fromisoformat(b["due_date"]) <= threshold
        ]
    except Exception as e:
        logger.exception("AP overdue query failed")
        return ModuleResult(reply_to_user=f"Couldn't reach Zoho: {e}")

    if not overdue and not due_soon:
        return ModuleResult(reply_to_user="✅ No bills overdue or due within 3 days.")

    currency = (overdue or due_soon)[0].get("currency_code", "AED")
    lines: list[str] = []
    if overdue:
        total = sum(float(b.get("balance") or 0) for b in overdue)
        lines.append(f"⚠️ {len(overdue)} overdue bill(s) — {currency} {total:,.2f} owed")
        for b in overdue[:10]:
            days_over = (today - date.fromisoformat(b["due_date"])).days if b.get("due_date") else "?"
            lines.append(
                f"  • {b.get('vendor_name')} — {currency} "
                f"{float(b.get('balance') or 0):,.2f} ({days_over}d overdue)"
            )
    if due_soon:
        if lines:
            lines.append("")
        total = sum(float(b.get("balance") or 0) for b in due_soon)
        lines.append(f"📅 {len(due_soon)} due within 3 days — {currency} {total:,.2f}")
        for b in due_soon[:10]:
            d = (date.fromisoformat(b["due_date"]) - today).days if b.get("due_date") else "?"
            tag = "due today" if d == 0 else f"due in {d}d"
            lines.append(
                f"  • {b.get('vendor_name')} — {currency} "
                f"{float(b.get('balance') or 0):,.2f} ({tag})"
            )

    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{
            "event_type": "ap_overdue_queried",
            "payload": {"overdue_count": len(overdue), "due_soon_count": len(due_soon)},
        }],
    )


# ---------------------------------------------------------------------------
# AP aging
# ---------------------------------------------------------------------------

async def query_ap_aging(input: _Empty, ctx: OrchContext) -> ModuleResult:
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected.")

    today = date.today()
    try:
        resp = await ctx.resolver._zoho.list_entities(
            "bills", filters={"per_page": 200, "status": "open"},
        )
        overdue_resp = await ctx.resolver._zoho.list_entities(
            "bills", filters={"per_page": 100, "status": "overdue"},
        )
    except Exception as e:
        logger.exception("AP aging query failed")
        return ModuleResult(reply_to_user=f"Couldn't reach Zoho: {e}")

    bills = (resp.get("bills") or []) + (overdue_resp.get("bills") or [])
    buckets = {"current": 0.0, "d1_30": 0.0, "d31_60": 0.0, "d61_90": 0.0, "d90p": 0.0}
    by_vendor: dict[str, float] = {}
    currency = "AED"

    for b in bills:
        bal = float(b.get("balance") or 0)
        if bal <= 0:
            continue
        currency = b.get("currency_code", currency)
        due = b.get("due_date")
        days_past = (today - date.fromisoformat(due)).days if due else 0
        if days_past <= 0:
            buckets["current"] += bal
        elif days_past <= 30:
            buckets["d1_30"] += bal
        elif days_past <= 60:
            buckets["d31_60"] += bal
        elif days_past <= 90:
            buckets["d61_90"] += bal
        else:
            buckets["d90p"] += bal
        v = b.get("vendor_name") or "?"
        by_vendor[v] = by_vendor.get(v, 0.0) + bal

    total = sum(buckets.values())
    if total == 0:
        return ModuleResult(reply_to_user="✅ No outstanding bills.")

    lines = [
        f"📊 AP Aging — {currency} {total:,.0f} owed",
        "",
        f"Current:     {currency} {buckets['current']:,.0f}",
        f"1-30 days:   {currency} {buckets['d1_30']:,.0f}",
        f"31-60 days:  {currency} {buckets['d31_60']:,.0f}",
        f"61-90 days:  {currency} {buckets['d61_90']:,.0f}",
        f"90+ days:    {currency} {buckets['d90p']:,.0f}",
    ]
    if buckets["d90p"] > 0:
        lines.append("")
        lines.append(f"⚠️ {currency} {buckets['d90p']:,.0f} is over 90 days past due.")
    if by_vendor:
        top = sorted(by_vendor.items(), key=lambda kv: -kv[1])[:3]
        lines.append("")
        lines.append("Top owed to vendor:")
        for name, bal in top:
            lines.append(f"  • {name}: {currency} {bal:,.0f}")

    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{
            "event_type": "ap_aging_queried",
            "payload": {"total_owed": total, "over_90_days": buckets["d90p"]},
        }],
    )


# ---------------------------------------------------------------------------
# Total owed — single-number summary across all open + overdue bills
# ---------------------------------------------------------------------------

async def query_total_owed(input: _Empty, ctx: OrchContext) -> ModuleResult:
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected.")
    try:
        open_resp = await ctx.resolver._zoho.list_entities(
            "bills", filters={"per_page": 200, "status": "open"},
        )
        overdue_resp = await ctx.resolver._zoho.list_entities(
            "bills", filters={"per_page": 100, "status": "overdue"},
        )
    except Exception as e:
        logger.exception("Total-owed query failed")
        return ModuleResult(reply_to_user=f"Couldn't reach Zoho: {e}")

    bills = (open_resp.get("bills") or []) + (overdue_resp.get("bills") or [])
    total = sum(float(b.get("balance") or 0) for b in bills)
    overdue_total = sum(
        float(b.get("balance") or 0)
        for b in bills if b.get("status") == "overdue"
    )
    currency = (bills[0].get("currency_code") if bills else "AED") or "AED"

    if total == 0:
        return ModuleResult(reply_to_user="✅ Nothing outstanding — all bills are paid.")

    lines = [f"💸 You owe {currency} {total:,.2f} across {len(bills)} bill(s)"]
    if overdue_total > 0:
        lines.append(f"⚠️ Of which {currency} {overdue_total:,.2f} is overdue")

    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{
            "event_type": "ap_total_owed_queried",
            "payload": {"total_owed": total, "overdue_total": overdue_total,
                        "bill_count": len(bills)},
        }],
    )


# ---------------------------------------------------------------------------
# Simple mark bill paid — for the "mark the X bill paid" shortcut.
# Heavier method-cascade flow lives in ap/payments_stateless.py.
# ---------------------------------------------------------------------------

async def mark_bill_paid_simple(input: MarkPaidQuery, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected.")

    # 1) Find vendor
    try:
        contacts = await ctx.resolver._zoho.search_contacts(input.vendor_name)
        vendors = [c for c in contacts if c.get("contact_type") == "vendor"]
        if not vendors:
            return ModuleResult(reply_to_user=f"I don't see *{input.vendor_name}* as a vendor in Zoho.")
        vendor = vendors[0]
        vendor_id = vendor.get("contact_id")
        bills_resp = await ctx.resolver._zoho.list_entities(
            "bills",
            filters={"vendor_id": vendor_id, "per_page": 25},
        )
    except Exception as e:
        logger.exception("mark_bill_paid_simple lookup failed")
        return ModuleResult(reply_to_user=f"Couldn't reach Zoho: {e}")

    # 2) Find oldest unpaid bill for this vendor
    open_bills = [
        b for b in (bills_resp.get("bills") or [])
        if b.get("status") in {"open", "overdue", "partially_paid"}
    ]
    if not open_bills:
        return ModuleResult(
            reply_to_user=f"*{vendor.get('contact_name')}*: no open bills to mark paid.",
        )
    bill = sorted(open_bills, key=lambda b: b.get("due_date") or "9999")[0]
    bill_id = bill.get("bill_id")
    balance = float(bill.get("balance") or 0)
    currency = bill.get("currency_code", "AED")

    # 3) Resolve default payment account — must be configured per client
    paid_through = (cfg.default_payment_account
                    or (cfg.zoho_tax_ids or {}).get("_default_paid_through_account_id"))
    if not paid_through:
        return ModuleResult(
            reply_to_user=(
                "No default payment account configured. "
                "Use the full 'pay bill to X' flow so I can ask which card/account to use."
            ),
            extra_events=[{
                "event_type": "ap_mark_paid_no_default_account",
                "payload": {"bill_id": bill_id, "vendor_id": vendor_id},
            }],
        )

    # 4) Declare a single Zoho VendorPayment write — orchestrator executes
    payment_payload = {
        "vendor_id": vendor_id,
        "payment_mode": "default",
        "paid_through_account_id": paid_through,
        "amount": balance,
        "date": date.today().isoformat(),
        "bills": [{"bill_id": bill_id, "amount_applied": balance}],
    }

    return ModuleResult(
        reply_to_user=(
            f"💸 Marking *{vendor.get('contact_name')}* bill paid\n"
            f"Bill #: {bill.get('bill_number')}\n"
            f"Amount: {currency} {balance:,.2f}"
        ),
        zoho_writes=[ZohoWrite(
            method="POST",
            endpoint="vendorpayments",
            payload=payment_payload,
        )],
        extra_events=[{
            "event_type": "ap_bill_marked_paid",
            "payload": {"bill_id": bill_id, "vendor_id": vendor_id,
                        "amount": balance},
        }],
        entity_kind="bill",
    )
