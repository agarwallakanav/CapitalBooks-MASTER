"""Multi-turn vendor bill payment.

Turn 1 — initiate_payment("pay bill to BigCorp")
  - Resolve which bill (fuzzy match by vendor + optional amount)
  - Verify it's still unpaid (read Supabase, optionally re-confirm in Zoho)
  - Save payment_intent state to Redis
  - Reply: "How was this paid? bank transfer / cash / card / not yet"

Turn 2 — confirm_payment_method(method, card_last_4=None)
  - Load payment_intent state
  - If method == "not_yet" → clear state, no payment recorded
  - If method == "card" and no last_4 → ask for it (stage transition)
  - Else → run payment account cascade → post VendorPayment to Zoho → mark paid
"""
import json
import logging
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Any, Literal

from anthropic import AsyncAnthropic

from config import settings
from database import get_db
from orchestrator.engine import ModuleResult, OrchContext, ZohoWrite
from router.pending import (
    clear_payment_intent,
    load_payment_intent,
    save_payment_intent,
)

logger = logging.getLogger(__name__)

_anthropic: AsyncAnthropic | None = None


def _claude() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


# ---------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------

class InitiatePaymentInput:
    """User said something like 'pay bill to X' / 'settle Etisalat'."""

    def __init__(self, text: str, sender: str | None = None):
        self.text = text
        self.sender = sender


class ConfirmPaymentInput:
    """User has named a method (and possibly a card last-4)."""

    def __init__(
        self,
        method: str,
        sender: str | None = None,
        card_last_4: str | None = None,
        scheduled_date: str | None = None,
    ):
        self.method = method.strip().lower().replace("-", "_").replace(" ", "_")
        self.sender = sender
        self.card_last_4 = card_last_4
        self.scheduled_date = scheduled_date


# ---------------------------------------------------------------------------
# Helpers — parse + lookup
# ---------------------------------------------------------------------------

_INIT_PROMPT = """Parse a UAE business owner's bill-payment instruction.

Reply with JSON only:
{
  "vendor": "<vendor name they mentioned>",
  "amount": <number or null>
}"""


def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return text.strip()


async def _parse_initiation(text: str) -> dict[str, Any]:
    resp = await _claude().messages.create(
        model=settings.anthropic_model_fast,
        max_tokens=200,
        messages=[{"role": "user", "content": f"{_INIT_PROMPT}\n\nMessage: {text}"}],
    )
    raw = _strip_fences(
        "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    )
    return json.loads(raw)


async def _find_unpaid_bill(
    client_id, vendor: str, amount: float | None = None,
) -> dict[str, Any] | None:
    db = await get_db()
    q = (
        db.table("bills")
        .select("*")
        .eq("client_id", str(client_id))
        .eq("deleted", False)
        .in_("status", ["unpaid", "scheduled"])
        .ilike("vendor", f"%{vendor}%")
        .order("due_date", desc=False)
    )
    if amount is not None:
        q = q.gte("amount", amount * 0.99).lte("amount", amount * 1.01)
    res = await q.execute()
    return (res.data or [None])[0]


def _pretty_date(iso: str | None) -> str:
    if not iso:
        return "no due date"
    try:
        d = date.fromisoformat(iso)
        return d.strftime("%A %-d %b %Y")
    except Exception:
        return iso


# ---------------------------------------------------------------------------
# Payment account cascade
# ---------------------------------------------------------------------------

def resolve_paid_through_account(
    cfg, method: str, card_last_4: str | None = None,
) -> tuple[str | None, str | None, str]:
    """Returns (paid_through_account_id, payment_mode_label, error_or_empty_reason).

    Cascade:
      cash         → zoho_tax_ids._default_paid_through_account_id (Petty Cash)
      bank_transfer→ cfg.default_payment_account
      card + last4 → cfg.card_mapping[last_4].account_id
      (anything else → error)
    """
    card_mapping = cfg.card_mapping or {}
    tax_ids = cfg.zoho_tax_ids or {}

    if method in {"cash", "petty_cash"}:
        acct = tax_ids.get("_default_paid_through_account_id")
        if not acct:
            return None, None, "No cash account configured in zoho_tax_ids."
        return acct, "Cash", ""

    if method in {"bank_transfer", "bank", "transfer", "wire"}:
        if not cfg.default_payment_account:
            return None, None, (
                "No default_payment_account set on your client config. "
                "Configure it in Supabase or specify a card instead."
            )
        return cfg.default_payment_account, "Bank Transfer", ""

    if method == "card":
        if not card_last_4:
            return None, None, "Need the last 4 digits of the card."
        entry = card_mapping.get(card_last_4)
        if not entry:
            return None, None, (
                f"No card ending {card_last_4} on file. Configured cards: "
                f"{list(card_mapping.keys()) or 'none'}"
            )
        acct = entry.get("account_id") if isinstance(entry, dict) else entry
        label = (entry.get("label") or f"Card …{card_last_4}") if isinstance(entry, dict) else f"Card …{card_last_4}"
        return acct, label, ""

    if method in {"not_yet", "no", "cancel", "abort", "nevermind", "never_mind"}:
        return None, None, "cancel"

    return None, None, f"Unrecognized payment method '{method}'. Try: bank transfer / cash / card / not yet."


# ---------------------------------------------------------------------------
# Turn 1 — initiate
# ---------------------------------------------------------------------------

async def initiate_payment(input: InitiatePaymentInput, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg

    try:
        parsed = await _parse_initiation(input.text)
    except Exception:
        logger.exception("Initiation parse failed")
        return ModuleResult(
            reply_to_user="I couldn't tell which vendor. Try 'pay bill to ACME Trading'.",
        )

    vendor = (parsed.get("vendor") or "").strip()
    if not vendor:
        return ModuleResult(reply_to_user="Tell me which vendor.")

    bill = await _find_unpaid_bill(cfg.id, vendor, parsed.get("amount"))
    if not bill:
        return ModuleResult(reply_to_user=f"No unpaid bill matches '{vendor}'.")

    # Save the intent + ask for method
    intent = {
        "stage": "awaiting_method",
        "bill_id": bill["id"],
        "vendor": bill["vendor"],
        "amount": float(bill["amount"]),
        "currency": bill.get("currency", "AED"),
        "due_date": bill.get("due_date"),
        "zoho_bill_id": bill.get("zoho_bill_id"),
        "zoho_vendor_id": bill.get("zoho_vendor_id"),
    }
    if input.sender:
        await save_payment_intent(input.sender, intent)

    cards_hint = ""
    if cfg.card_mapping:
        cards_hint = f"\nCards on file: {', '.join(cfg.card_mapping.keys())}"

    reply = (
        f"You have an open bill to *{bill['vendor']}* for "
        f"{bill.get('currency','AED')} {bill['amount']:,.2f}"
        + (f" (due {_pretty_date(bill.get('due_date'))})." if bill.get("due_date") else ".")
        + "\n\nHow was this paid?\n"
        "• 'bank transfer'\n"
        "• 'cash'\n"
        "• 'card' (I'll ask which one)\n"
        "• 'not yet' (just checking)"
        + cards_hint
    )

    return ModuleResult(
        reply_to_user=reply,
        extra_events=[{
            "event_type": "payment_initiated",
            "payload": {"bill_id": bill["id"], "vendor": bill["vendor"]},
        }],
        entity_kind="bill",
        entity_id=bill["id"],
    )


# ---------------------------------------------------------------------------
# Turn 2 — confirm
# ---------------------------------------------------------------------------

async def confirm_payment(input: ConfirmPaymentInput, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    if not input.sender:
        return ModuleResult(reply_to_user="Lost track of which phone — try again.")

    intent = await load_payment_intent(input.sender)
    if not intent:
        return ModuleResult(reply_to_user="No payment in progress. Try 'pay bill to <vendor>' first.")

    method = input.method
    acct, mode_label, msg = resolve_paid_through_account(cfg, method, input.card_last_4)

    # Cancel path
    if msg == "cancel":
        await clear_payment_intent(input.sender)
        return ModuleResult(
            reply_to_user="OK — no payment recorded. The bill is still open.",
            extra_events=[{
                "event_type": "payment_cancelled",
                "payload": {"bill_id": intent["bill_id"]},
            }],
            entity_kind="bill",
            entity_id=intent["bill_id"],
        )

    # Card without last_4 — stage transition, keep intent open
    if method == "card" and not input.card_last_4:
        intent["stage"] = "awaiting_card_last4"
        await save_payment_intent(input.sender, intent)
        cards_hint = ""
        if cfg.card_mapping:
            cards_hint = f" (cards on file: {', '.join(cfg.card_mapping.keys())})"
        return ModuleResult(
            reply_to_user=f"Which card? Last 4 digits please{cards_hint}.",
        )

    # Error message → relay without clearing state so user can retry
    if not acct:
        return ModuleResult(reply_to_user=f"⚠️ {msg}\nTry again or say 'cancel'.")

    # Schedule path: just update due / scheduled_payment_date
    if input.scheduled_date:
        try:
            sched = date.fromisoformat(input.scheduled_date)
        except ValueError:
            return ModuleResult(reply_to_user=f"Couldn't read date '{input.scheduled_date}'.")
        db = await get_db()
        await (
            db.table("bills")
            .update({
                "status": "scheduled",
                "scheduled_payment_date": sched.isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat(),
            })
            .eq("id", intent["bill_id"])
            .execute()
        )
        await clear_payment_intent(input.sender)
        return ModuleResult(
            reply_to_user=(
                "📅 Scheduled payment\n"
                f"Vendor: {intent['vendor']}\n"
                f"Amount: {intent['currency']} {intent['amount']:,.2f}\n"
                f"On: {sched.isoformat()}\n"
                f"From: {mode_label}"
            ),
            extra_events=[{
                "event_type": "payment_scheduled",
                "payload": {
                    "bill_id": intent["bill_id"],
                    "scheduled_date": sched.isoformat(),
                    "paid_through_account_id": acct,
                },
            }],
            entity_kind="bill",
            entity_id=intent["bill_id"],
        )

    # Live payment: declare a Zoho VendorPayment write
    if not (intent.get("zoho_bill_id") and intent.get("zoho_vendor_id")):
        return ModuleResult(
            reply_to_user=(
                "That bill isn't fully synced to Zoho yet — can't post a payment until it is."
            ),
            extra_events=[{
                "event_type": "payment_blocked_missing_zoho_ids",
                "payload": {"bill_id": intent["bill_id"]},
            }],
        )

    payment_payload: dict[str, Any] = {
        "vendor_id": intent["zoho_vendor_id"],
        "payment_mode": mode_label,
        "paid_through_account_id": acct,
        "amount": float(intent["amount"]),
        "date": date.today().isoformat(),
        "bills": [{
            "bill_id": intent["zoho_bill_id"],
            "amount_applied": float(intent["amount"]),
        }],
    }

    # Optimistically mark paid; if Zoho fails the audit log captures it.
    db = await get_db()
    await (
        db.table("bills")
        .update({
            "status": "paid",
            "paid_date": date.today().isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("id", intent["bill_id"])
        .execute()
    )
    await clear_payment_intent(input.sender)

    return ModuleResult(
        reply_to_user=(
            "💸 Paid\n"
            f"Vendor: {intent['vendor']}\n"
            f"Amount: {intent['currency']} {intent['amount']:,.2f}\n"
            f"Via: {mode_label}\n"
            f"Date: {date.today().isoformat()}"
        ),
        zoho_writes=[
            ZohoWrite(
                method="POST",
                endpoint="vendorpayments",
                payload=payment_payload,
                bind_to_entity=("bill", intent["bill_id"]),
            )
        ],
        extra_events=[{
            "event_type": "payment_recorded",
            "payload": {
                "bill_id": intent["bill_id"],
                "method": method,
                "card_last_4": input.card_last_4,
                "paid_through_account_id": acct,
            },
        }],
        entity_kind="bill",
        entity_id=intent["bill_id"],
    )
