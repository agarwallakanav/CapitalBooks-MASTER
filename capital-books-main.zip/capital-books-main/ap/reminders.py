"""Daily AP reminder sweep.

Runs once per day. For each active client:
  - Bills due within REMINDER_LEAD_DAYS → WhatsApp "upcoming payments" summary
  - Bills past due_date and still unpaid/scheduled → promote to status='overdue'
    + send an overdue alert

Both summaries go to the business owner's phone (client.phone). The job is
wired into the same APScheduler instance that runs the categorizer.
"""
import asyncio
import logging
from datetime import date, timedelta
from typing import Any

from database import get_db
from whatsapp.sender import send_text

logger = logging.getLogger(__name__)

REMINDER_LEAD_DAYS = 3


async def _active_clients() -> list[dict[str, Any]]:
    db = await get_db()
    res = await db.table("clients").select("id, phone, company_name").eq("is_active", True).execute()
    return [r for r in (res.data or []) if r.get("phone")]


async def _upcoming(client_id: str, today: date) -> list[dict[str, Any]]:
    threshold = today + timedelta(days=REMINDER_LEAD_DAYS)
    db = await get_db()
    res = (
        await db.table("bills")
        .select("vendor, amount, currency, due_date, status")
        .eq("client_id", client_id)
        .eq("deleted", False)
        .in_("status", ["unpaid", "scheduled"])
        .gte("due_date", today.isoformat())
        .lte("due_date", threshold.isoformat())
        .order("due_date", desc=False)
        .execute()
    )
    return res.data or []


async def _promote_overdue(client_id: str, today: date) -> list[dict[str, Any]]:
    db = await get_db()
    res = (
        await db.table("bills")
        .select("id, vendor, amount, currency, due_date")
        .eq("client_id", client_id)
        .eq("deleted", False)
        .in_("status", ["unpaid", "scheduled"])
        .lt("due_date", today.isoformat())
        .execute()
    )
    overdue = res.data or []
    if overdue:
        ids = [b["id"] for b in overdue]
        try:
            await (
                db.table("bills")
                .update({"status": "overdue"})
                .in_("id", ids)
                .execute()
            )
        except Exception:
            logger.exception("Failed to promote bills to overdue")
    return overdue


def _format_upcoming(rows: list[dict[str, Any]], today: date) -> str | None:
    if not rows:
        return None
    currency = rows[0].get("currency", "AED")
    total = sum(float(r.get("amount") or 0) for r in rows)
    lines = [
        f"📅 Upcoming bills (next {REMINDER_LEAD_DAYS}d) — {currency} {total:,.0f} total\n"
    ]
    for r in rows[:10]:
        due = date.fromisoformat(r["due_date"]) if r.get("due_date") else None
        days = (due - today).days if due else None
        if days is None:
            tag = "?"
        elif days == 0:
            tag = "due today"
        elif days == 1:
            tag = "due tomorrow"
        else:
            tag = f"due in {days}d"
        lines.append(
            f"• {r.get('vendor')} — {currency} {float(r.get('amount') or 0):,.2f} ({tag})"
        )
    if len(rows) > 10:
        lines.append(f"…and {len(rows) - 10} more")
    return "\n".join(lines)


def _format_overdue(rows: list[dict[str, Any]], today: date) -> str | None:
    if not rows:
        return None
    currency = rows[0].get("currency", "AED")
    total = sum(float(r.get("amount") or 0) for r in rows)
    lines = [f"⚠️ {len(rows)} bill(s) now OVERDUE — {currency} {total:,.0f}\n"]
    for r in rows[:10]:
        due = date.fromisoformat(r["due_date"]) if r.get("due_date") else None
        days_overdue = (today - due).days if due else "?"
        lines.append(
            f"• {r.get('vendor')} — {currency} {float(r.get('amount') or 0):,.2f} "
            f"({days_overdue}d overdue)"
        )
    if len(rows) > 10:
        lines.append(f"…and {len(rows) - 10} more")
    return "\n".join(lines)


async def sweep_client(client_row: dict[str, Any], today: date | None = None) -> None:
    today = today or date.today()
    client_id = client_row["id"]
    phone = client_row["phone"]

    # 1) Demote stale unpaid/scheduled bills → overdue + alert
    overdue = await _promote_overdue(client_id, today)
    overdue_msg = _format_overdue(overdue, today)
    if overdue_msg:
        try:
            await send_text(phone, overdue_msg)
        except Exception:
            logger.exception("Overdue reminder send failed for %s", phone)

    # 2) Upcoming bills
    upcoming = await _upcoming(client_id, today)
    upcoming_msg = _format_upcoming(upcoming, today)
    if upcoming_msg:
        try:
            await send_text(phone, upcoming_msg)
        except Exception:
            logger.exception("Upcoming reminder send failed for %s", phone)


async def sweep_all_clients() -> None:
    """Job entry point — invoked by APScheduler."""
    clients = await _active_clients()
    if not clients:
        logger.info("AP reminders: no eligible clients")
        return
    logger.info("AP reminders: sweeping %d clients", len(clients))
    results = await asyncio.gather(
        *(sweep_client(c) for c in clients), return_exceptions=True
    )
    for c, r in zip(clients, results):
        if isinstance(r, Exception):
            logger.error("AP reminder sweep failed for %s: %s", c["id"], r)
