"""Zoho chart-of-accounts fetcher + fuzzy category matcher.

Used at expense-capture time to translate a free-form category string
("lunch", "office supplies", "fuel") into a real Zoho expense account_id.

Caches the COA per-client in Redis for 1 hour so we don't hit Zoho on
every expense.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any
from uuid import UUID

from redis_client import get_redis

logger = logging.getLogger(__name__)

_CACHE_TTL_SECONDS = 3600


def _key(client_id: UUID) -> str:
    return f"coa_expense_accounts:{client_id}"


async def get_expense_accounts(client_id: UUID, zoho) -> list[dict[str, Any]]:
    """Returns list of {account_id, account_name, account_code} for all
    expense-type accounts in this Zoho org. Cached 1h per client."""
    redis = await get_redis()
    cached = await redis.get(_key(client_id))
    if cached:
        try:
            return json.loads(cached)
        except json.JSONDecodeError:
            pass

    accounts: list[dict[str, Any]] = []
    try:
        resp = await zoho.list_entities("chartofaccounts", filters={
            "filter_by": "AccountType.Expense", "per_page": 200,
        })
        for a in (resp.get("chartofaccounts") or []):
            accounts.append({
                "account_id": a.get("account_id"),
                "account_name": a.get("account_name") or "",
                "account_code": a.get("account_code") or "",
            })
    except Exception:
        logger.exception("COA fetch failed (returning empty list)")
        return []

    try:
        await redis.set(_key(client_id), json.dumps(accounts), ex=_CACHE_TTL_SECONDS)
    except Exception:
        logger.exception("COA cache write failed (non-fatal)")
    return accounts


# ---------------------------------------------------------------------------
# Fuzzy matching — common UAE bookkeeping category names → Zoho account names
# ---------------------------------------------------------------------------

# Each canonical category maps to substrings we'll look for inside Zoho account
# names. First substring hit wins, so put the most specific first.
_CATEGORY_SUBSTRINGS: dict[str, tuple[str, ...]] = {
    "meals":            ("meals", "entertain", "food", "staff welfare"),
    "fuel":             ("fuel", "petrol", "gas"),
    "travel":           ("travel", "transport", "taxi", "uber"),
    "office supplies":  ("office supplies", "stationery", "office expense"),
    "utilities":        ("utilities", "electricity", "water", "telecom", "telephone", "internet"),
    "rent":             ("rent",),
    "salaries":         ("salar", "wage", "payroll"),
    "marketing":        ("marketing", "advertising", "promotion"),
    "professional":     ("professional", "consulting", "legal", "audit"),
    "repairs":          ("repair", "maintenance"),
    "insurance":        ("insurance",),
    "bank charges":     ("bank", "charges", "fees"),
    "software":         ("software", "subscription", "saas", "cloud", "hosting",
                         "it and internet", "internet", "it expense"),
    "groceries":        ("grocery", "groceries", "supermarket"),
    "training":         ("training", "course", "education"),
    "snacks":           ("meals", "staff welfare", "pantry"),
}

# Aliases — purpose-words only, never vendor names.
# Vendor name is NOT a category signal: Carrefour can be groceries/office/lunch,
# Careem can be rides/food delivery/shipping, etc. Adding a vendor here would
# silently mis-categorize.
_ALIASES: dict[str, str] = {
    "food": "meals",
    "lunch": "meals",
    "dinner": "meals",
    "breakfast": "meals",
    "coffee": "meals",
    "snacks": "snacks",
    "petrol": "fuel",
    "gas": "fuel",
    "diesel": "fuel",
    "flight": "travel",
    "flights": "travel",
    "hotel": "travel",
    "ride": "travel",
    "rides": "travel",
    "taxi": "travel",
    "stationery": "office supplies",
    "supplies": "office supplies",
    "electricity": "utilities",
    "water bill": "utilities",
    "internet bill": "utilities",
    "phone bill": "utilities",
    "wage": "salaries",
    "wages": "salaries",
    "payroll": "salaries",
    "advertising": "marketing",
    "ads": "marketing",
    "consulting": "professional",
    "legal": "professional",
    "audit": "professional",
    "subscription": "software",
    "subscriptions": "software",
    "saas": "software",
    "cloud": "software",
    "cloud services": "software",
    "cloud hosting": "software",
    "hosting": "software",
    "domain": "software",
    "course": "training",
    "training": "training",
    "education": "training",
}


def _canonicalize(category: str) -> str:
    c = (category or "").strip().lower()
    c = re.sub(r"\s+", " ", c)
    if c in _CATEGORY_SUBSTRINGS:
        return c
    if c in _ALIASES:
        return _ALIASES[c]
    # First word alias
    first = c.split(" ", 1)[0]
    if first in _ALIASES:
        return _ALIASES[first]
    return c


def match_category(
    category: str | None,
    accounts: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Returns the best-matching expense account dict, or None.
    Strategy: canonicalize the category, look up its substring list, scan
    Zoho account names for the first substring hit (case-insensitive)."""
    if not category or not accounts:
        return None
    canonical = _canonicalize(category)
    needles = _CATEGORY_SUBSTRINGS.get(canonical, (canonical,))

    name_to_account = {
        (a.get("account_name") or "").lower(): a for a in accounts
    }
    # 1) Exact name match wins
    for needle in needles:
        if needle in name_to_account:
            return name_to_account[needle]
    # 2) Substring match against canonical needles
    for needle in needles:
        for name, account in name_to_account.items():
            if needle in name:
                return account
    # 3) Fallback: direct substring of the user-typed category against COA
    # account names. Lets "cloud services" hit a "Cloud Services" account
    # even when there's no canonical alias for it.
    cat_words = [w for w in canonical.split() if len(w) >= 3]
    for name, account in name_to_account.items():
        if any(w in name for w in cat_words):
            return account
    return None


def suggest_categories(accounts: list[dict[str, Any]], limit: int = 6) -> list[str]:
    """Returns a short list of category names to show in 'what was this
    for?' prompts. Prefers our canonical names; falls back to actual Zoho
    account names if the COA is non-standard."""
    have_match = []
    name_set = {(a.get("account_name") or "").lower() for a in accounts}
    for canonical, needles in _CATEGORY_SUBSTRINGS.items():
        for needle in needles:
            if any(needle in n for n in name_set):
                have_match.append(canonical)
                break
        if len(have_match) >= limit:
            break
    if have_match:
        return have_match
    # Fallback: top N Zoho account names verbatim
    return [a.get("account_name") for a in accounts[:limit] if a.get("account_name")]
