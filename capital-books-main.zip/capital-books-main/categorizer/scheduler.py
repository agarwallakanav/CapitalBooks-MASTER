"""APScheduler job: every CATEGORIZER_INTERVAL_MINUTES, sweep all active clients
and categorize any uncategorized QB entities."""
import asyncio
import logging
from typing import Any
from uuid import UUID

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from categorizer.classifier import (
    BATCH_SIZE,
    Classification,
    EntityToClassify,
    classify_in_chunks,
)
from categorizer.rules_engine import (
    get_rules_for_client,
    increment_usage,
    match_rule,
    upsert_rule,
)
from config import settings
from database import get_db
from orchestrator.audit import record_event
from orchestrator.engine import load_client_config
from orchestrator.zoho_client import ClientCredentials, ZohoClient
from zoho.client import ZohoBooksClient   # kept for compatibility, will retire

logger = logging.getLogger(__name__)

_scheduler: AsyncIOScheduler | None = None

# Zoho endpoints we sweep for uncategorized entries.
# (Zoho doesn't use SyncToken — we PUT the full updated row.)
SWEEP_ENTITIES: tuple[tuple[str, str], ...] = (
    ("Expense", "expenses"),
    ("Bill", "bills"),
    ("Invoice", "invoices"),
    ("BankTransaction", "banktransactions"),
)

CONFIDENCE_RULE_PROMOTION = 95  # save as a rule when AI is this confident


async def _active_clients() -> list[dict[str, Any]]:
    db = await get_db()
    res = (
        await db.table("clients")
        .select(
            "id, zoho_organization_id, zoho_access_token, zoho_refresh_token, "
            "zoho_token_expires_at"
        )
        .eq("is_active", True)
        .execute()
    )
    return [
        r for r in (res.data or [])
        if r.get("zoho_organization_id") and r.get("zoho_access_token") and r.get("zoho_refresh_token")
    ]


async def _query_uncategorized(
    zoho, endpoint: str
) -> list[dict[str, Any]]:
    """Pull the most recent N entities; filter for missing account_id in Python.
    Zoho's filter_by query params are limited so we paginate + filter locally."""
    try:
        resp = await zoho.list_entities(endpoint, filters={"per_page": 50})
    except Exception:
        logger.exception("Query failed for %s", endpoint)
        return []
    return resp.get(endpoint) or []


def _is_uncategorized(entity_type: str, entity: dict[str, Any]) -> bool:
    """Zoho entities are 'uncategorized' if their account_id / line account_ids are missing."""
    if entity_type == "Expense":
        return not entity.get("account_id")
    if entity_type == "BankTransaction":
        return not (entity.get("from_account_id") and entity.get("to_account_id"))
    # Bill / Invoice — check first line item's account_id
    line_items = entity.get("line_items") or []
    if not line_items:
        return False
    return not line_items[0].get("account_id")


def _to_classify(entity_type: str, entity: dict[str, Any]) -> EntityToClassify:
    vendor = (
        entity.get("vendor_name")
        or entity.get("customer_name")
        or entity.get("contact_name")
        or ""
    )
    description = (
        entity.get("description")
        or entity.get("notes")
        or (entity.get("line_items") or [{}])[0].get("description")
        or ""
    )
    amount = float(entity.get("total") or entity.get("amount") or 0)
    entity_id = (
        entity.get(f"{entity_type.lower()}_id")
        or entity.get("expense_id")
        or entity.get("bill_id")
        or entity.get("invoice_id")
        or entity.get("transaction_id")
        or entity.get("id")
        or ""
    )
    return EntityToClassify(
        id=str(entity_id), entity_type=entity_type, vendor=vendor,
        description=description, amount=amount,
    )


async def _apply_classification_to_zoho(
    zoho,
    entity_type: str,
    endpoint: str,
    entity: dict[str, Any],
    classification: Classification,
) -> None:
    """PUT a partial update tagging the entry with the AI category in notes.

    NOTE: resolving classification.account_hint → real account_id requires a
    GET /chartofaccounts lookup, left as a follow-up. For now we record the
    category in `description` / `notes` so it's visible in Zoho.
    """
    notes = f"[auto-categorized: {classification.category}] {entity.get('notes') or entity.get('description') or ''}"
    field = "notes" if entity_type in {"Bill", "Invoice", "Journal"} else "description"
    entity_id = (
        entity.get(f"{entity_type.lower()}_id")
        or entity.get("expense_id")
        or entity.get("bill_id")
        or entity.get("invoice_id")
        or entity.get("transaction_id")
        or entity.get("id")
    )
    if not entity_id:
        return
    try:
        await zoho.update_entity(endpoint, str(entity_id), {field: notes})
    except Exception:
        logger.exception("Zoho update failed for %s/%s", entity_type, entity_id)


async def _record_classification_locally(
    client_id: UUID,
    entity_type: str,
    zoho_entity_id: str,
    classification: Classification,
) -> None:
    db = await get_db()
    await (
        db.table("transactions")
        .upsert({
            "client_id": str(client_id),
            "zoho_entity_type": entity_type,
            "zoho_entity_id": zoho_entity_id,
            "category": classification.category,
            "account_code": classification.account_hint,
            "vat_type": classification.vat_type,
            "confidence_score": classification.confidence,
            "status": "auto_posted",
            "direction": "expense" if entity_type in {"Expense", "Bill"} else "income",
            "amount": 0,  # placeholder when the categorizer is the source of truth
        }, on_conflict="zoho_entity_id")
        .execute()
    )


async def sweep_client(client_row: dict[str, Any]) -> dict[str, int]:
    """Categorize everything pending for one client. Returns counts per outcome.

    Phase C-final: uses orchestrator.zoho_client.ZohoClient + records every
    sweep as a transaction_event so daily-cap monitoring stays accurate."""
    client_id = UUID(client_row["id"])
    rules = await get_rules_for_client(client_id)
    counts = {"total": 0, "rule_matched": 0, "ai_classified": 0, "skipped": 0}

    cfg = await load_client_config(client_id)
    creds = ClientCredentials(
        client_id=client_id,
        organization_id=cfg.zoho_organization_id,
        api_domain=cfg.api_domain,
        access_token=cfg.zoho_access_token,
        refresh_token=cfg.zoho_refresh_token,
        token_expires_at=cfg.zoho_token_expires_at,
    )

    async with ZohoClient(creds) as zoho:
        await record_event(
            client_id,
            event_type="categorizer_sweep_started",
            actor="categorizer",
            payload={"entity_types": [e[0] for e in SWEEP_ENTITIES]},
        )
        for entity_type, endpoint in SWEEP_ENTITIES:
            entities = await _query_uncategorized(zoho, endpoint)
            uncategorized = [e for e in entities if _is_uncategorized(entity_type, e)]
            counts["total"] += len(uncategorized)

            needs_ai: list[tuple[dict, EntityToClassify]] = []
            for entity in uncategorized:
                to_cls = _to_classify(entity_type, entity)
                rule = match_rule(to_cls.vendor, rules)
                if rule:
                    classification = Classification(
                        id=to_cls.id,
                        category=rule.category,
                        confidence=98,
                        account_hint=rule.account_code,
                        vat_type=rule.vat_type,
                        reasoning=f"Matched rule: {rule.vendor_pattern}",
                    )
                    await _apply_classification_to_zoho(zoho, entity_type, endpoint, entity, classification)
                    await _record_classification_locally(client_id, entity_type, to_cls.id, classification)
                    await increment_usage(rule.id)
                    counts["rule_matched"] += 1
                else:
                    needs_ai.append((entity, to_cls))

            if needs_ai:
                ai_results = await classify_in_chunks([t for _, t in needs_ai])
                by_id = {c.id: c for c in ai_results}
                for entity, to_cls in needs_ai:
                    classification = by_id.get(to_cls.id)
                    if not classification:
                        counts["skipped"] += 1
                        continue
                    await _apply_classification_to_zoho(zoho, entity_type, endpoint, entity, classification)
                    await _record_classification_locally(client_id, entity_type, to_cls.id, classification)
                    counts["ai_classified"] += 1

                    if (
                        classification.confidence >= CONFIDENCE_RULE_PROMOTION
                        and to_cls.vendor
                    ):
                        try:
                            await upsert_rule(
                                client_id=client_id,
                                vendor_pattern=to_cls.vendor.split()[0]
                                    if " " in to_cls.vendor else to_cls.vendor,
                                category=classification.category,
                                account_code=classification.account_hint,
                                vat_type=classification.vat_type,
                            )
                        except Exception:
                            logger.exception("Rule promotion failed (non-fatal)")

    return counts


async def sweep_all_clients() -> None:
    clients = await _active_clients()
    if not clients:
        logger.info("Categorizer sweep: no eligible clients")
        return

    logger.info("Categorizer sweep: %d clients", len(clients))
    results = await asyncio.gather(
        *(sweep_client(c) for c in clients), return_exceptions=True
    )
    for client, result in zip(clients, results):
        if isinstance(result, Exception):
            logger.error("Sweep failed for client %s: %s", client["id"], result)
        else:
            logger.info("Sweep done for %s: %s", client["id"], result)


def start_scheduler() -> AsyncIOScheduler:
    global _scheduler
    if _scheduler is not None:
        return _scheduler
    _scheduler = AsyncIOScheduler()
    _scheduler.add_job(
        sweep_all_clients,
        trigger="interval",
        minutes=settings.categorizer_interval_minutes,
        id="categorizer_sweep",
        coalesce=True,
        max_instances=1,
        next_run_time=None,  # don't fire immediately on boot
    )
    # AP reminders: daily at 08:00 UAE time (UTC+4 ≈ 04:00 UTC)
    from ap.reminders import sweep_all_clients as ap_sweep
    _scheduler.add_job(
        ap_sweep,
        trigger="cron",
        hour=4,
        minute=0,
        id="ap_reminders",
        coalesce=True,
        max_instances=1,
    )
    # Daily briefing + customer follow-ups: 09:00 UAE (05:00 UTC)
    from reminders.daily_briefing import sweep_all_clients as briefing_sweep
    _scheduler.add_job(
        briefing_sweep,
        trigger="cron",
        hour=5,
        minute=0,
        id="daily_briefing",
        coalesce=True,
        max_instances=1,
    )
    _scheduler.start()
    logger.info(
        "Categorizer scheduler started (every %d min) + AP reminders (daily 08:00 UAE) + Daily briefing (09:00 UAE)",
        settings.categorizer_interval_minutes,
    )
    return _scheduler


def stop_scheduler() -> None:
    global _scheduler
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None
