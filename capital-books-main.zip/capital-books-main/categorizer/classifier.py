"""Batch AI categorization. Sends 10-20 transactions in a single Claude prompt."""
import json
import logging
from dataclasses import dataclass

from anthropic import AsyncAnthropic

from config import settings

logger = logging.getLogger(__name__)

BATCH_SIZE = 15

_anthropic: AsyncAnthropic | None = None


def _client() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


@dataclass
class EntityToClassify:
    id: str              # QB entity id
    entity_type: str     # Purchase, Bill, etc.
    vendor: str
    description: str
    amount: float


@dataclass
class Classification:
    id: str
    category: str
    confidence: int
    account_hint: str | None
    vat_type: str | None
    reasoning: str


_SYSTEM_PROMPT = """You categorize UAE bookkeeping transactions for Zoho Books.

For each transaction in the input array, return one classification.
Categories should match common chart-of-accounts names for an SME:
office supplies, software & subscriptions, professional fees, rent,
utilities, salaries, marketing, travel, meals & entertainment, fuel,
bank fees, insurance, repairs & maintenance, telephone & internet,
cost of goods sold, sales revenue, other income, etc.

VAT types: standard, zero, exempt, reverse_charge, out_of_scope.
Confidence: 95-100 if the vendor/description is unambiguous; 70-94 if reasonable
inference; <70 only if guessing.

Respond with JSON ONLY, exactly this shape:
{"classifications": [
  {"id": "<input id>", "category": "<category>", "account_hint": "<account name>",
   "vat_type": "<vat type>", "confidence": <0-100>, "reasoning": "<short>"}
]}"""


def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return text.strip()


async def classify_batch(entities: list[EntityToClassify]) -> list[Classification]:
    if not entities:
        return []

    user_msg = json.dumps([
        {
            "id": e.id,
            "entity_type": e.entity_type,
            "vendor": e.vendor,
            "description": e.description,
            "amount": e.amount,
        }
        for e in entities
    ])

    resp = await _client().messages.create(
        model=settings.anthropic_model_fast,
        max_tokens=2000,
        system=_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_msg}],
    )
    raw = _strip_fences(
        "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    )

    try:
        data = json.loads(raw)
        return [
            Classification(
                id=c["id"],
                category=c.get("category") or "uncategorized",
                confidence=max(0, min(100, int(c.get("confidence", 0)))),
                account_hint=c.get("account_hint"),
                vat_type=c.get("vat_type"),
                reasoning=str(c.get("reasoning", "")),
            )
            for c in data.get("classifications", [])
        ]
    except (json.JSONDecodeError, KeyError, ValueError, TypeError) as e:
        logger.warning("Batch classifier parse failed: %s | raw=%r", e, raw[:300])
        return []


async def classify_in_chunks(entities: list[EntityToClassify]) -> list[Classification]:
    """Split into batches of BATCH_SIZE to keep prompts tight and parseable."""
    out: list[Classification] = []
    for i in range(0, len(entities), BATCH_SIZE):
        chunk = entities[i:i + BATCH_SIZE]
        out.extend(await classify_batch(chunk))
    return out
