"""Per-client vendor → category rules. Learned over time from corrections."""
import logging
import re
from dataclasses import dataclass
from typing import Any
from uuid import UUID

from database import get_db

logger = logging.getLogger(__name__)


@dataclass
class Rule:
    id: str
    vendor_pattern: str
    category: str
    account_code: str | None
    vat_type: str | None
    times_used: int


async def get_rules_for_client(client_id: UUID) -> list[Rule]:
    db = await get_db()
    res = (
        await db.table("categorization_rules")
        .select("*")
        .eq("client_id", str(client_id))
        .execute()
    )
    return [
        Rule(
            id=row["id"],
            vendor_pattern=row["vendor_pattern"],
            category=row["category"],
            account_code=row.get("account_code"),
            vat_type=row.get("vat_type"),
            times_used=row.get("times_used") or 0,
        )
        for row in (res.data or [])
    ]


def match_rule(vendor: str, rules: list[Rule]) -> Rule | None:
    if not vendor:
        return None
    vendor_lc = vendor.lower()
    # Prefer longer patterns first — more specific wins
    for rule in sorted(rules, key=lambda r: -len(r.vendor_pattern)):
        if rule.vendor_pattern.lower() in vendor_lc:
            return rule
    return None


async def upsert_rule(
    client_id: UUID,
    vendor_pattern: str,
    category: str,
    account_code: str | None = None,
    vat_type: str | None = None,
) -> None:
    db = await get_db()
    existing = (
        await db.table("categorization_rules")
        .select("id, times_used")
        .eq("client_id", str(client_id))
        .eq("vendor_pattern", vendor_pattern)
        .maybe_single()
        .execute()
    )
    if existing.data:
        await (
            db.table("categorization_rules")
            .update({
                "category": category,
                "account_code": account_code,
                "vat_type": vat_type,
                "times_used": (existing.data.get("times_used") or 0) + 1,
            })
            .eq("id", existing.data["id"])
            .execute()
        )
    else:
        await (
            db.table("categorization_rules")
            .insert({
                "client_id": str(client_id),
                "vendor_pattern": vendor_pattern,
                "category": category,
                "account_code": account_code,
                "vat_type": vat_type,
                "times_used": 1,
            })
            .execute()
        )


async def increment_usage(rule_id: str) -> None:
    db = await get_db()
    # Read-modify-write — fine for low contention; promote to RPC if needed
    res = (
        await db.table("categorization_rules")
        .select("times_used")
        .eq("id", rule_id)
        .single()
        .execute()
    )
    current = res.data.get("times_used") if res.data else 0
    await (
        db.table("categorization_rules")
        .update({"times_used": (current or 0) + 1})
        .eq("id", rule_id)
        .execute()
    )


_VAT_KEYWORDS = {
    "standard": ("standard", "5%", "vat"),
    "zero": ("zero-rated", "zero rated", "0%"),
    "exempt": ("exempt",),
    "reverse_charge": ("reverse charge", "rcm"),
    "out_of_scope": ("out of scope", "out-of-scope"),
}


def _vat_type_from_text(text: str) -> str | None:
    t = (text or "").lower()
    for vat_type, kws in _VAT_KEYWORDS.items():
        if any(kw in t for kw in kws):
            return vat_type
    return None


_CATEGORY_PATTERN = re.compile(
    r"(?:no,?\s*(?:it'?s|that'?s|these are)\s+|category\s*[:=]?\s*)([a-z][a-z\s&/-]{2,40})",
    re.IGNORECASE,
)


def _category_from_text(text: str) -> str | None:
    m = _CATEGORY_PATTERN.search(text or "")
    if m:
        return m.group(1).strip().lower().replace("  ", " ")
    return None


async def save_rule_from_correction(
    client_id: UUID, vendor: str, correction_text: str
) -> None:
    """Best-effort parse of user's free-text correction into a stored rule."""
    if not vendor:
        return
    category = _category_from_text(correction_text)
    vat_type = _vat_type_from_text(correction_text)
    if not category and not vat_type:
        logger.debug("Could not extract rule from correction: %r", correction_text)
        return
    await upsert_rule(
        client_id=client_id,
        vendor_pattern=vendor.split()[0] if " " in vendor else vendor,
        category=category or "uncategorized",
        vat_type=vat_type,
    )
