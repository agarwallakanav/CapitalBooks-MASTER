"""Voluntary Disclosure (Form 211) detection.

UAE rule: corrections to a *previously filed* VAT return require a
Voluntary Disclosure if the net error exceeds AED 10,000. Below that,
the correction can be made in the next regular return.

detect_voluntary_disclosures(input, ctx) → ModuleResult
    For each row in `vat_filings` (CB's record of what the user
    authorized), checks the Supabase `transactions` table for entries with
    a tax_point_date inside the filed period but a created_at *after*
    the filing date. Reports net VAT delta + threshold tagging.

This module does NOT compute VAT. It compares two read-only sources:
CB's filing-authorization log and CB's transaction audit log.

Zoho doesn't expose a public "list of filed returns" endpoint, so we
rely on CB's own record (populated by vat/filing.py:authorize_filing).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from database import get_db
from orchestrator.engine import ModuleResult, OrchContext

logger = logging.getLogger(__name__)

_VOLUNTARY_DISCLOSURE_THRESHOLD_AED = 10_000.00


@dataclass
class DisclosureRequest:
    sender: str | None = None


async def _list_cb_filings(client_id) -> list[dict[str, Any]]:
    db = await get_db()
    try:
        res = (
            await db.table("vat_filings")
            .select("id, period_label, from_date, to_date, filed_at, totals")
            .eq("client_id", str(client_id))
            .order("to_date", desc=True)
            .limit(25)
            .execute()
        )
        return res.data or []
    except Exception:
        logger.exception("vat_filings query failed")
        return []


async def _posted_after_filing(
    client_id, from_date: str, to_date: str, filed_at: str
) -> list[dict[str, Any]]:
    db = await get_db()
    try:
        res = (
            await db.table("transactions")
            .select("id, vendor, amount_aed, vat_amount, tax_point_date, created_at")
            .eq("client_id", str(client_id))
            .gte("tax_point_date", from_date)
            .lte("tax_point_date", to_date)
            .gt("created_at", filed_at)
            .execute()
        )
        return res.data or []
    except Exception:
        logger.exception("Post-filing transaction lookup failed")
        return []


async def detect_voluntary_disclosures(
    input: DisclosureRequest, ctx: OrchContext
) -> ModuleResult:
    cfg = ctx.cfg
    filings = await _list_cb_filings(cfg.id)
    if not filings:
        return ModuleResult(
            reply_to_user=(
                "No filed VAT returns on record yet — nothing to check for "
                "voluntary disclosures. (CB records each filing the moment "
                "you authorize it.)"
            ),
            extra_events=[{
                "event_type": "vat_disclosure_check_no_filings",
                "payload": {},
            }],
        )

    suspects: list[dict[str, Any]] = []
    for f in filings:
        from_date = f.get("from_date")
        to_date = f.get("to_date")
        filed_at = f.get("filed_at")
        period_label = f.get("period_label") or f"{from_date} → {to_date}"
        if not (from_date and to_date and filed_at):
            continue

        late_txns = await _posted_after_filing(cfg.id, from_date, to_date, filed_at)
        if not late_txns:
            continue
        net_delta = sum(float(t.get("vat_amount") or 0) for t in late_txns)
        if abs(net_delta) < 0.01:
            continue

        requires_vd = abs(net_delta) > _VOLUNTARY_DISCLOSURE_THRESHOLD_AED
        suspects.append({
            "filing_id": f.get("id"),
            "period": period_label,
            "filed_at": filed_at,
            "txn_count": len(late_txns),
            "net_vat_delta": round(net_delta, 2),
            "requires_voluntary_disclosure": requires_vd,
        })

    if not suspects:
        return ModuleResult(
            reply_to_user="✅ No voluntary disclosure situations detected.",
            extra_events=[{
                "event_type": "vat_disclosure_check_clean",
                "payload": {"filings_checked": len(filings)},
            }],
        )

    lines = ["🚨 *Possible Voluntary Disclosures (Form 211)*", ""]
    for s in suspects:
        tag = "Required" if s["requires_voluntary_disclosure"] else "Below threshold"
        lines.append(
            f"• *{s['period']}* — {s['txn_count']} txn(s) posted after filing\n"
            f"  Net VAT delta: AED {s['net_vat_delta']:+,.2f}  ({tag})"
        )
    lines.append("")
    lines.append(
        "Submit a Form 211 for each *Required* row before the next filing. "
        "For below-threshold rows, fold the correction into the next return."
    )

    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{
            "event_type": "vat_disclosure_situations_detected",
            "payload": {
                "filings_checked": len(filings),
                "suspects": suspects,
                "threshold_aed": _VOLUNTARY_DISCLOSURE_THRESHOLD_AED,
            },
        }],
    )
