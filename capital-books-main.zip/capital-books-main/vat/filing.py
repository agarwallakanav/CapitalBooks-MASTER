"""VAT 201 filing — CB authorizes, Zoho files to EmaraTax.

authorize_filing(input, ctx) → ModuleResult
    Handles the user's "FILE" / "FILE ANYWAY" reply after they've reviewed
    a return via vat/review.py.

IMPORTANT: There is no public CB→FTA submission API. Zoho is the
FTA-recognised Digital Tax Integrator; the actual EmaraTax push is
triggered from inside Zoho (UI button today; programmatic endpoint may
be exposed later — see TODO below). CB's job is:

  1. Verify the user just reviewed a return (filing_intent in Redis).
  2. Optionally enforce "no override unless user typed FILE ANYWAY".
  3. Log a `vat_filing_authorized` audit event tying the user's consent
     to the exact totals they saw.
  4. Reply with a deep link into Zoho where the actual EmaraTax push
     happens, plus the post-filing payment due date.

If/when Zoho exposes a "POST /vatreturns/{id}/submit" endpoint we can
swap the deep-link reply for a real ZohoWrite. The audit trail stays
identical.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any

from database import get_db
from orchestrator.engine import ModuleResult, OrchContext
from redis_client import get_redis

logger = logging.getLogger(__name__)

# UAE VAT payment is due 28 days after the period end.
_PAYMENT_DAYS_AFTER_PERIOD_END = 28


@dataclass
class FilingAuthorization:
    sender: str           # WhatsApp phone — used to look up filing_intent
    override: bool = False  # True if user typed "FILE ANYWAY"


def _zoho_return_deep_link(api_domain: str, org_id: str, return_id: str) -> str:
    """Return a clickable Zoho Books URL to the VAT return detail page.
    The user clicks "Submit to EmaraTax" from there.

    api_domain is the API host (e.g. "www.zohoapis.com"); the user-facing
    Books URL lives on books.zoho.<tld>. We derive the tld from api_domain.
    """
    # api_domain is like "www.zohoapis.com" / ".eu" / ".in" / ".com.au"
    tld = api_domain.replace("www.zohoapis.", "").replace("zohoapis.", "")
    if not tld:
        tld = "com"
    return (f"https://books.zoho.{tld}/app/{org_id}#/vat/returns/{return_id}")


def _payment_due_date(to_date_iso: str) -> str | None:
    try:
        end = date.fromisoformat(to_date_iso)
    except (TypeError, ValueError):
        return None
    return (end + timedelta(days=_PAYMENT_DAYS_AFTER_PERIOD_END)).isoformat()


async def authorize_filing(
    input: FilingAuthorization, ctx: OrchContext
) -> ModuleResult:
    cfg = ctx.cfg
    redis = await get_redis()
    raw = await redis.get(f"vat_filing_intent:{input.sender}")
    if not raw:
        return ModuleResult(
            reply_to_user=(
                "I don't have a reviewed return ready to file. "
                "Reply *review VAT* first so I can pull the draft from Zoho."
            ),
            extra_events=[{
                "event_type": "vat_filing_no_intent",
                "payload": {"sender_hash": str(hash(input.sender))[-6:]},
            }],
        )

    try:
        intent = json.loads(raw)
    except json.JSONDecodeError:
        await redis.delete(f"vat_filing_intent:{input.sender}")
        return ModuleResult(
            reply_to_user="Filing intent was corrupted — please rerun *review VAT*.",
        )

    ready = intent.get("ready_for_filing")
    flags = intent.get("flags") or []

    # If CB flagged warnings and the user did not explicitly override, stop.
    if not ready and not input.override:
        warn_flags = [f for f in flags if f.get("severity") == "warn"]
        flag_lines = "\n".join(f"  • {f.get('kind')}" for f in warn_flags) or "  • (see review)"
        return ModuleResult(
            reply_to_user=(
                "🚨 The reviewed return still has open flags:\n"
                f"{flag_lines}\n\n"
                "Reply *FILE ANYWAY* to authorize despite the flags "
                "(this is logged), or fix the issues in Zoho first."
            ),
            extra_events=[{
                "event_type": "vat_filing_blocked_on_flags",
                "payload": {"flag_count": len(warn_flags)},
            }],
        )

    return_id = intent.get("vat_return_id")        # may be None — we lack a Zoho API for this today
    period_label = intent.get("period_label")
    totals = intent.get("totals") or {}
    from_date = intent.get("from_date")
    to_date = intent.get("to_date")
    payment_due = _payment_due_date(to_date) if to_date else None

    # TODO: when Zoho exposes a programmatic "submit to EmaraTax" endpoint,
    # replace the deep-link reply with a real ZohoWrite, e.g.:
    #   zoho_writes=[ZohoWrite(
    #     method="POST",
    #     endpoint=f"vatreturns/{return_id}/submit",
    #     payload={"acknowledge_filing": True},
    #   )]
    # Until then, CB only logs the authorization; the user clicks the link
    # and Zoho pushes to EmaraTax from its side.
    deep_link = ""
    if cfg.zoho_organization_id and return_id:
        deep_link = _zoho_return_deep_link(
            cfg.api_domain, cfg.zoho_organization_id, return_id,
        )

    # Persist the authorized filing to vat_filings — disclosures.py reads
    # from this. CB is the system of record for "what was authorized";
    # Zoho is the system of record for "what was actually pushed".
    if from_date and to_date:
        try:
            db = await get_db()
            await db.table("vat_filings").insert({
                "client_id": str(cfg.id),
                "period_label": period_label,
                "from_date": from_date,
                "to_date": to_date,
                "totals": totals,
                "override_used": bool(input.override),
                "zoho_deep_link": "",  # set below once we build it
                "zoho_vat_return_id": return_id,
            }).execute()
        except Exception:
            logger.exception("vat_filings insert failed (non-fatal — event still logged)")

    # Clear the intent — single-use authorization.
    await redis.delete(f"vat_filing_intent:{input.sender}")

    net_payable = totals.get("net_payable") or 0
    net_refundable = totals.get("net_refundable") or 0
    money_line = ""
    if net_payable > 0:
        money_line = f"💸 Pay AED {net_payable:,.2f} to FTA by *{payment_due or 'period-end + 28 days'}*"
    elif net_refundable > 0:
        money_line = f"💰 Refund due to you: AED {net_refundable:,.2f}"

    lines = [
        "✅ *Filing authorized*",
        f"Period: {period_label}",
        f"Output VAT: AED {(totals.get('output_vat') or 0):,.2f}",
        f"Input VAT:  AED {(totals.get('input_vat') or 0):,.2f}",
    ]
    if money_line:
        lines.append(money_line)
    lines.append("")
    if deep_link:
        lines.append("Open the return in Zoho to push it to EmaraTax:")
        lines.append(deep_link)
    else:
        lines.append(
            "Open Zoho Books → VAT Returns to push this to EmaraTax. "
            "(I couldn't build a deep link — org_id missing.)"
        )
    lines.append("")
    lines.append("I've logged your authorization with the exact totals above.")

    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{
            "event_type": "vat_filing_authorized",
            "payload": {
                "vat_return_id": return_id,
                "period": period_label,
                "totals": totals,
                "override_used": bool(input.override),
                "payment_due_date": payment_due,
                "zoho_deep_link": deep_link,
            },
        }],
        entity_kind="vat_return",
        entity_id=return_id,
    )
