"""VAT return review — query Zoho's tax summary + cross-validate.

review_current_return(input, ctx) → ModuleResult
    Pulls the tax summary for the period from Zoho's `/reports/taxsummary`,
    cross-checks output/input tax totals against the underlying
    invoices/bills, surfaces flags, and stashes the validated summary as
    a `filing_intent` in Redis so a follow-up "FILE" can authorize it.

The module performs ZERO VAT computation. It only:
  - Reads totals from Zoho's tax-summary report
  - Sums invoices/bills in the same period from Zoho's list endpoints
  - Flags variances and voluntary-disclosure situations

CB owns review + authorization. Zoho owns submission to EmaraTax.

NOTE: Zoho Books' public API does not expose `/vatreturns` — only the tax
summary report. We treat that report as the source of truth for the
numbers that will land on the VAT 201 form. The actual EmaraTax push
happens in Zoho's UI (see vat/filing.py for the authorization flow).
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from datetime import date
from typing import Any

from orchestrator.engine import ModuleResult, OrchContext
from redis_client import get_redis

logger = logging.getLogger(__name__)

# Threshold beyond which a difference between CB and Zoho totals is flagged.
# Small float-rounding noise below this is suppressed.
_VARIANCE_FLAG_AED = 1.00

# UAE FTA threshold for voluntary disclosure (Form 211): corrections to a
# previously filed return where the net impact exceeds AED 10,000.
_VOLUNTARY_DISCLOSURE_AED = 10_000.00


@dataclass
class ReviewRequest:
    """Optional period override — empty means 'current quarter to date'."""
    period: str | None = None      # "2026-Q1" / "2026-04" / "2026-01-01..2026-03-31"
    sender: str | None = None      # phone, for stashing filing_intent in Redis


# ---------------------------------------------------------------------------
# Period parsing — supports "YYYY-Qn", "YYYY-MM", and "YYYY-MM-DD..YYYY-MM-DD"
# ---------------------------------------------------------------------------

_QUARTER_RE = re.compile(r"^(\d{4})[-\s]?Q([1-4])$", re.IGNORECASE)
_MONTH_RE = re.compile(r"^(\d{4})-(\d{2})$")
_RANGE_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})\s*\.\.\s*(\d{4}-\d{2}-\d{2})$")


def _parse_period(period: str | None) -> tuple[date, date, str]:
    """Returns (from_date, to_date, label). Defaults to current quarter."""
    today = date.today()
    if not period:
        q = (today.month - 1) // 3 + 1
        start = date(today.year, (q - 1) * 3 + 1, 1)
        return start, today, f"{today.year}-Q{q} (to date)"

    m = _QUARTER_RE.match(period.strip())
    if m:
        year = int(m.group(1))
        q = int(m.group(2))
        start_month = (q - 1) * 3 + 1
        start = date(year, start_month, 1)
        end_month = start_month + 2
        end = date(year, end_month, 28)
        # Snap end to actual last day of end_month
        next_month = date(year + (1 if end_month == 12 else 0),
                          1 if end_month == 12 else end_month + 1, 1)
        from datetime import timedelta
        end = next_month - timedelta(days=1)
        return start, end, f"{year}-Q{q}"

    m = _MONTH_RE.match(period.strip())
    if m:
        year, mo = int(m.group(1)), int(m.group(2))
        start = date(year, mo, 1)
        from datetime import timedelta
        next_month = date(year + (1 if mo == 12 else 0),
                          1 if mo == 12 else mo + 1, 1)
        end = next_month - timedelta(days=1)
        return start, end, period.strip()

    m = _RANGE_RE.match(period.strip())
    if m:
        return date.fromisoformat(m.group(1)), date.fromisoformat(m.group(2)), period

    # Unrecognized — fall through to current quarter, but flag in label
    q = (today.month - 1) // 3 + 1
    start = date(today.year, (q - 1) * 3 + 1, 1)
    return start, today, f"{today.year}-Q{q} (couldn't parse '{period}')"


# ---------------------------------------------------------------------------
# Zoho API surface — uses /reports/taxsummary (which exists publicly)
# ---------------------------------------------------------------------------

async def _fetch_tax_summary(
    ctx: OrchContext, from_date: date, to_date: date
) -> dict[str, Any] | None:
    try:
        resp = await ctx.resolver._zoho.report("taxsummary", filters={
            "from_date": from_date.isoformat(),
            "to_date": to_date.isoformat(),
        })
    except Exception as e:
        logger.exception("Tax summary API call failed")
        raise RuntimeError(
            f"Couldn't reach Zoho tax summary: {e}. "
            f"Check that UAE VAT is set up in Zoho Books for this org."
        ) from e

    # Zoho's actual shape: {code, message, tax: [...rows], page_context: {...}}
    # — verified live 2026-06. Older docs/orgs may also send tax_summary etc.
    rows = resp.get("tax") or resp.get("taxes") or resp.get("tax_codes")
    if isinstance(rows, list):
        return {"taxes": rows, "from_date": from_date.isoformat(),
                "to_date": to_date.isoformat()}

    summary = (resp.get("tax_summary") or resp.get("taxsummary")
               or resp.get("tax_information") or {})
    if not summary:
        try:
            top_keys = list(resp.keys())[:20]
            sample = {k: (type(resp[k]).__name__,
                          (len(resp[k]) if hasattr(resp[k], "__len__") else None))
                      for k in top_keys}
            logger.warning("tax_summary empty parse — top-level shape: %s", sample)
        except Exception:
            pass
        return None
    return summary


def _extract_totals(tax_summary: dict[str, Any]) -> dict[str, float]:
    """Pull headline numbers from a Zoho tax-summary response.
    Sums per-tax-code rows when explicit totals aren't provided."""
    def _f(*keys) -> float:
        for k in keys:
            v = tax_summary.get(k)
            if v is not None:
                try:
                    return float(v)
                except (TypeError, ValueError):
                    continue
        return 0.0

    output_total = _f("total_output_tax", "total_output_vat", "output_tax_total")
    input_total = _f("total_input_tax", "total_input_vat", "input_tax_total")

    if output_total == 0 and input_total == 0:
        # Fall back to summing rows. Zoho's per-row shape varies by org
        # version — we cover the common variants and log the first row
        # so future shape drift is visible.
        rows = tax_summary.get("taxes") or tax_summary.get("tax_codes") or []
        if rows:
            try:
                logger.info("tax_summary row sample: keys=%s", list(rows[0].keys())[:20])
            except Exception:
                pass
        for row in rows:
            try:
                # Variant A: flat output_tax / input_tax
                ot = float(row.get("output_tax") or 0)
                it = float(row.get("input_tax") or 0)
                # Variant B: nested sales_taxes / purchase_taxes blobs
                if ot == 0:
                    st = row.get("sales_taxes") or row.get("sales_tax") or {}
                    ot = float(st.get("vat_amount") or st.get("tax_amount") or 0)
                if it == 0:
                    pt = row.get("purchase_taxes") or row.get("purchase_tax") or {}
                    it = float(pt.get("vat_amount") or pt.get("tax_amount") or 0)
                # Variant C: tax_amount + direction field
                if ot == 0 and it == 0:
                    amt = float(row.get("tax_amount") or 0)
                    direction = (row.get("direction") or row.get("type") or "").lower()
                    if "output" in direction or "sales" in direction:
                        ot = amt
                    elif "input" in direction or "purchase" in direction:
                        it = amt
                output_total += ot
                input_total += it
            except (TypeError, ValueError):
                continue

    adjustments = _f("adjustments", "tax_adjustments", "total_adjustments")
    net_payable = _f("net_tax_payable", "net_vat_payable", "tax_payable")
    net_refundable = _f("net_tax_refundable", "net_vat_refundable", "refund_due")

    # Derive net if neither explicit field is present
    if net_payable == 0 and net_refundable == 0:
        derived = output_total - input_total + adjustments
        if derived >= 0:
            net_payable = round(derived, 2)
        else:
            net_refundable = round(-derived, 2)

    return {
        "output_vat": round(output_total, 2),
        "input_vat": round(input_total, 2),
        "adjustments": round(adjustments, 2),
        "net_payable": round(net_payable, 2),
        "net_refundable": round(net_refundable, 2),
    }


async def _sum_invoices_period(
    ctx: OrchContext, from_date: str, to_date: str
) -> tuple[float, int]:
    total, count = 0.0, 0
    try:
        resp = await ctx.resolver._zoho.list_entities("invoices", filters={
            "date_after": from_date, "date_before": to_date,
            "status": "paid,sent,overdue,partially_paid",
            "per_page": 200,
        })
        for inv in (resp.get("invoices") or []):
            total += float(inv.get("tax_total") or inv.get("total_tax") or 0)
            count += 1
    except Exception:
        logger.exception("Invoice period sum failed (non-fatal)")
    return total, count


async def _sum_bills_period(
    ctx: OrchContext, from_date: str, to_date: str
) -> tuple[float, int]:
    total, count = 0.0, 0
    try:
        resp = await ctx.resolver._zoho.list_entities("bills", filters={
            "date_after": from_date, "date_before": to_date,
            "per_page": 200,
        })
        for bill in (resp.get("bills") or []):
            total += float(bill.get("tax_total") or bill.get("total_tax") or 0)
            count += 1
    except Exception:
        logger.exception("Bill period sum failed (non-fatal)")
    return total, count


# ---------------------------------------------------------------------------
# Main entry
# ---------------------------------------------------------------------------

async def review_current_return(input: ReviewRequest, ctx: OrchContext) -> ModuleResult:
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected.")

    from_date, to_date, period_label = _parse_period(input.period)

    try:
        tax_summary = await _fetch_tax_summary(ctx, from_date, to_date)
    except RuntimeError as e:
        return ModuleResult(reply_to_user=str(e))

    if tax_summary is None:
        return ModuleResult(
            reply_to_user=(
                f"Zoho returned an empty tax summary for {period_label}. "
                "Likely either no taxable activity in the period, or UAE VAT "
                "isn't fully set up in this Zoho org (Settings → Taxes)."
            ),
            extra_events=[{
                "event_type": "vat_review_empty_summary",
                "payload": {"period": period_label,
                            "from": from_date.isoformat(),
                            "to": to_date.isoformat()},
            }],
        )

    totals = _extract_totals(tax_summary)
    inv_total, inv_count = await _sum_invoices_period(
        ctx, from_date.isoformat(), to_date.isoformat(),
    )
    bill_total, bill_count = await _sum_bills_period(
        ctx, from_date.isoformat(), to_date.isoformat(),
    )

    output_variance = totals["output_vat"] - inv_total
    input_variance = totals["input_vat"] - bill_total

    flags: list[dict[str, Any]] = []
    issues: list[str] = []

    if abs(output_variance) > _VARIANCE_FLAG_AED:
        flags.append({
            "kind": "output_tax_variance", "severity": "warn",
            "zoho_summary": totals["output_vat"], "invoices_sum": inv_total,
            "delta": round(output_variance, 2),
        })
        issues.append(
            f"Output VAT on the summary (AED {totals['output_vat']:,.2f}) "
            f"differs from sum of invoices (AED {inv_total:,.2f}) by "
            f"AED {output_variance:+,.2f}"
        )

    if abs(input_variance) > _VARIANCE_FLAG_AED:
        flags.append({
            "kind": "input_tax_variance", "severity": "warn",
            "zoho_summary": totals["input_vat"], "bills_sum": bill_total,
            "delta": round(input_variance, 2),
        })
        issues.append(
            f"Input VAT on the summary (AED {totals['input_vat']:,.2f}) "
            f"differs from sum of bills (AED {bill_total:,.2f}) by "
            f"AED {input_variance:+,.2f}"
        )

    if abs(totals["adjustments"]) > _VOLUNTARY_DISCLOSURE_AED:
        flags.append({
            "kind": "voluntary_disclosure_likely", "severity": "warn",
            "adjustments": totals["adjustments"],
            "threshold": _VOLUNTARY_DISCLOSURE_AED,
        })
        issues.append(
            "Adjustments exceed AED 10,000 — may require a Voluntary "
            "Disclosure (Form 211) instead of a regular filing."
        )

    ready = not any(f.get("severity") == "warn" for f in flags)

    lines = [
        f"📋 *VAT 201 review — {period_label}*",
        f"Period: {from_date.isoformat()} → {to_date.isoformat()}",
        "",
        f"Output VAT: AED {totals['output_vat']:,.2f}   ({inv_count} invoices)",
        f"Input VAT:  AED {totals['input_vat']:,.2f}   ({bill_count} bills)",
        f"Adjustments: AED {totals['adjustments']:,.2f}",
    ]
    if totals["net_payable"] > 0:
        lines.append(f"*Net payable: AED {totals['net_payable']:,.2f}*")
    elif totals["net_refundable"] > 0:
        lines.append(f"*Net refundable: AED {totals['net_refundable']:,.2f}*")
    else:
        lines.append("*Net: AED 0.00*")

    if issues:
        lines.append("")
        lines.append("⚠️ *CB checks flagged:*")
        for i in issues:
            lines.append(f"  • {i}")

    lines.append("")
    if ready:
        lines.append("✅ All CB checks passed.")
        lines.append("Reply *FILE* to authorize Zoho to push this to EmaraTax.")
    else:
        lines.append("🚨 Resolve the flags above before filing.")
        lines.append("Reply *FILE ANYWAY* to override (logged for audit).")

    if input.sender:
        redis = await get_redis()
        intent = {
            "period_label": period_label,
            "from_date": from_date.isoformat(),
            "to_date": to_date.isoformat(),
            "totals": totals,
            "flags": flags,
            "ready_for_filing": ready,
        }
        await redis.set(f"vat_filing_intent:{input.sender}",
                        json.dumps(intent), ex=3600)

    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{
            "event_type": "vat_return_reviewed",
            "payload": {
                "period": period_label,
                "from": from_date.isoformat(), "to": to_date.isoformat(),
                "totals": totals, "flag_count": len(flags),
                "ready_for_filing": ready, "flags": flags,
                "invoices_in_period": inv_count,
                "bills_in_period": bill_count,
            },
        }],
        entity_kind="vat_return",
    )
