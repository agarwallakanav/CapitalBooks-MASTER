"""VAT 201 Bot — review-and-authorize layer over Zoho's filing pipeline.

Zoho Books is an FTA-recognised Digital Tax Integrator and pushes returns
directly to EmaraTax. CapitalBooks does NOT compute VAT, and it does NOT call
EmaraTax. All numbers come from Zoho's VAT Returns API; CB validates them
against the underlying invoices/bills and authorizes the Zoho-side filing.
"""
