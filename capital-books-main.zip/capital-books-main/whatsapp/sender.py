"""Outbound WhatsApp Business API messages via Meta Graph API."""
import logging
from typing import Any

import httpx

from config import settings

logger = logging.getLogger(__name__)

GRAPH_API_VERSION = "v18.0"


def _url() -> str:
    return f"https://graph.facebook.com/{GRAPH_API_VERSION}/{settings.whatsapp_phone_number_id}/messages"


def _headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {settings.whatsapp_access_token}",
        "Content-Type": "application/json",
    }


async def _post(payload: dict[str, Any]) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=20.0) as http:
        resp = await http.post(_url(), headers=_headers(), json=payload)
        if resp.status_code >= 400:
            logger.error("WhatsApp send failed (%s): %s", resp.status_code, resp.text)
        resp.raise_for_status()
        return resp.json()


async def _remember(resp: dict[str, Any], body: str) -> None:
    """Stash (wamid → body) so the inbound webhook can resolve quoted-reply
    context. Fire-and-forget — failure is non-fatal."""
    try:
        wamid = ((resp.get("messages") or [{}])[0]).get("id")
        if not wamid or not body:
            return
        from router.pending import remember_outbound
        await remember_outbound(wamid, body)
    except Exception:
        logger.exception("wamid stash failed (non-fatal)")


async def send_text(to: str, body: str) -> dict[str, Any]:
    resp = await _post({
        "messaging_product": "whatsapp",
        "to": to,
        "type": "text",
        "text": {"body": body, "preview_url": False},
    })
    await _remember(resp, body)
    return resp


async def send_document(to: str, link: str, filename: str, caption: str = "") -> dict[str, Any]:
    resp = await _post({
        "messaging_product": "whatsapp",
        "to": to,
        "type": "document",
        "document": {"link": link, "filename": filename, "caption": caption},
    })
    # Document quote context: use the caption (the human-meaningful part)
    await _remember(resp, caption or f"[document: {filename}]")
    return resp


async def send_image(to: str, link: str, caption: str = "") -> dict[str, Any]:
    resp = await _post({
        "messaging_product": "whatsapp",
        "to": to,
        "type": "image",
        "image": {"link": link, "caption": caption},
    })
    await _remember(resp, caption or "[image]")
    return resp
