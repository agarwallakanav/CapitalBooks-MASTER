"""FastAPI router for the WhatsApp Business API webhook.

Endpoints:
  GET  /webhook/whatsapp — Meta verification handshake
  POST /webhook/whatsapp — incoming message envelope

POST acknowledges within milliseconds, then processes each message in a
background task; Meta retries non-2xx responses, so we must reply 200 fast.
"""
import logging
from typing import Any, Iterator

from fastapi import APIRouter, BackgroundTasks, HTTPException, Query, Request
from fastapi.responses import PlainTextResponse

from config import settings
from router.handler import handle_incoming_message

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/webhook/whatsapp", tags=["whatsapp"])


@router.get("", response_class=PlainTextResponse)
async def verify(
    hub_mode: str = Query(alias="hub.mode"),
    hub_verify_token: str = Query(alias="hub.verify_token"),
    hub_challenge: str = Query(alias="hub.challenge"),
) -> str:
    if hub_mode == "subscribe" and hub_verify_token == settings.whatsapp_verify_token:
        return hub_challenge
    raise HTTPException(status_code=403, detail="Verify token mismatch")


@router.post("")
async def receive(request: Request, background_tasks: BackgroundTasks) -> dict[str, str]:
    body = await request.json()
    for message in iter_messages(body):
        background_tasks.add_task(handle_incoming_message, message)
    return {"status": "ok"}


def iter_messages(payload: dict[str, Any]) -> Iterator[dict[str, Any]]:
    """Yield normalized message dicts from a WhatsApp Cloud API webhook payload.

    Status receipts (delivery / read) live under a different key and are skipped.
    """
    for entry in payload.get("entry") or []:
        for change in entry.get("changes") or []:
            value = change.get("value") or {}
            for msg in value.get("messages") or []:
                yield {
                    "from": msg.get("from"),
                    "type": msg.get("type"),
                    "text": (msg.get("text") or {}).get("body"),
                    "image": msg.get("image"),
                    # Document attachments: PDF, xlsx, csv, etc. Meta gives us
                    # the same {id, mime_type, filename, caption} shape as image.
                    "document": msg.get("document"),
                    # Reply-quote: present when the user "replied to" one of
                    # our prior messages. Shape: {id, from} — id is the wamid
                    # of the quoted message.
                    "context": msg.get("context"),
                    "id": msg.get("id"),
                    "timestamp": msg.get("timestamp"),
                }
