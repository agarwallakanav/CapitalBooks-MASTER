"""Fetch media (image/document/voice) sent via WhatsApp.

Meta's incoming-message webhook only includes a `media_id`, not the binary.
We have to call their metadata endpoint to get a short-lived CDN URL, then
fetch the binary from that URL — both calls authenticated with our access token.
"""
import logging

import httpx

from config import settings

logger = logging.getLogger(__name__)

GRAPH_API_VERSION = "v18.0"


async def fetch_media(media_id: str) -> tuple[bytes, str]:
    """Resolve a WhatsApp media_id → (binary, mime_type).

    Two-step: Meta's metadata endpoint returns a CDN URL valid for ~5 minutes;
    we then fetch the binary from that URL with the same bearer token.
    """
    headers = {"Authorization": f"Bearer {settings.whatsapp_access_token}"}
    async with httpx.AsyncClient(timeout=30.0) as http:
        meta = await http.get(
            f"https://graph.facebook.com/{GRAPH_API_VERSION}/{media_id}",
            headers=headers,
        )
        meta.raise_for_status()
        meta_json = meta.json()
        url = meta_json.get("url")
        mime_type = meta_json.get("mime_type", "image/jpeg")
        if not url:
            raise ValueError(f"No 'url' in WhatsApp media metadata for {media_id}")
        bin_resp = await http.get(url, headers=headers)
        bin_resp.raise_for_status()
        return bin_resp.content, mime_type
