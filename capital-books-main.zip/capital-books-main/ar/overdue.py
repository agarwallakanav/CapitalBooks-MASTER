"""Overdue invoice check — outstanding invoices that are due within 3 days or past due."""
import logging
from datetime import date, timedelta
from typing import Any
from uuid import UUID

from database import get_db

logger = logging.getLogger(__name__)

OVERDUE_LOOKAHEAD_DAYS = 3


async def get_overdue_invoices(client_id: UUID, today: date | None = None) -> list[dict[str, Any]]:
    today = today or date.today()
    threshold = today + timedelta(days=OVERDUE_LOOKAHEAD_DAYS)
    db = await get_db()
    res = (
        await db.table("invoices")
        .select("invoice_number, customer_name, total, currency, due_date, status")
        .eq("client_id", str(client_id))
        .in_("status", ["sent", "overdue"])
        .lte("due_date", threshold.isoformat())
        .order("due_date", desc=False)
        .execute()
    )
    invoices = res.data or []
    # Promote past-due to status='overdue' in-place (best-effort)
    past_due_ids = [
        inv["invoice_number"] for inv in invoices
        if inv.get("due_date") and date.fromisoformat(inv["due_date"]) < today
        and inv.get("status") == "sent"
    ]
    if past_due_ids:
        try:
            await (
                db.table("invoices")
                .update({"status": "overdue"})
                .eq("client_id", str(client_id))
                .in_("invoice_number", past_due_ids)
                .execute()
            )
        except Exception:
            logger.exception("Failed to promote sent→overdue (non-fatal)")
    return invoices


async def overdue_summary(client_id: UUID, today: date | None = None) -> str:
    today = today or date.today()
    invoices = await get_overdue_invoices(client_id, today)
    if not invoices:
        return "✅ No invoices overdue or due within 3 days."

    total_outstanding = sum(float(i.get("total") or 0) for i in invoices)
    currency = invoices[0].get("currency", "AED")

    lines = [f"⚠️ {len(invoices)} invoice(s) need attention — {currency} {total_outstanding:,.2f} outstanding\n"]
    for inv in invoices[:10]:
        due = inv.get("due_date") or "?"
        days = (date.fromisoformat(inv["due_date"]) - today).days if inv.get("due_date") else None
        if days is None:
            tag = "?"
        elif days < 0:
            tag = f"{-days}d overdue"
        elif days == 0:
            tag = "due today"
        else:
            tag = f"due in {days}d"
        lines.append(
            f"• {inv['invoice_number']} — {inv.get('customer_name')} — "
            f"{currency} {float(inv.get('total') or 0):,.2f} ({tag})"
        )
    if len(invoices) > 10:
        lines.append(f"…and {len(invoices) - 10} more")
    return "\n".join(lines)
