"""Parse natural-language invoice requests into structured data via Claude.

  Input:  "invoice ABC Corp for AED 5000 for consulting"
  Output: {customer_name, amount, description, currency, ...}
"""
import json
import logging
from dataclasses import dataclass
from decimal import Decimal

from anthropic import AsyncAnthropic

from config import settings

logger = logging.getLogger(__name__)

_anthropic: AsyncAnthropic | None = None


def _client() -> AsyncAnthropic:
    global _anthropic
    if _anthropic is None:
        _anthropic = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _anthropic


@dataclass
class InvoiceRequest:
    customer_name: str
    description: str
    amount: Decimal
    currency: str = "AED"
    # None means the user didn't specify due terms — caller asks instead of
    # silently defaulting to net-14.
    due_days: int | None = None


_SYSTEM_PROMPT = """Parse a UAE business owner's invoice request from WhatsApp.

Reply with JSON only:
{
  "customer_name": "<exact customer name>",
  "description": "<short description of goods/services>",
  "amount": <gross number, includes VAT if mentioned>,
  "currency": "<ISO 4217 like AED/USD/EUR/GBP/SAR/INR>",
  "due_days": <integer if user explicitly said due/net/days, else null>
}

Currency detection rules:
  $ / dollar / USD       → USD
  € / euro               → EUR
  £ / pound / sterling   → GBP
  ₹ / rupee / Rs / INR   → INR
  SAR / riyal / SR       → SAR (Saudi Riyal)
  AED / dirham / dhs     → AED (UAE Dirham — never Moroccan)
  ¥ / yen                → JPY
  yuan / RMB             → CNY
  Default AED when no currency signal is present.

Due date rules — resolve to an integer whenever the user stated ANY due-timing:
  "due today" / "make this due today" / "on receipt" / "due on receipt" → due_days: 0
  "due tomorrow" / "make this due tomorrow"                             → due_days: 1
  "in N days" / "N days" / "net N"                                      → due_days: N
  "next week" / "in a week"                                              → due_days: 7
  "next month" / "in a month"                                            → due_days: 30
  "end of week" / "by friday" (or any weekday)                          → due_days: (days from today until that weekday)
  "end of month" / "by month end"                                        → due_days: (days until end of current month)
  Explicit date like "due 4 July 2026" / "by 15 August" / "on 2026-07-04"
    → due_days: (that date - TODAY, in days). If the year is omitted and
      the month/day is in the past, assume next year.

Only set due_days: null when the user gave NO due-timing signal at all.
"Today", "tomorrow", "on receipt", and any explicit calendar date are ALL
clear signals — never null in those cases.

TODAY'S DATE will be provided in the user message. Use it to compute
due_days for relative phrases and explicit dates."""


def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return text.strip()


async def parse_invoice_request(text: str) -> InvoiceRequest:
    from datetime import date as _date
    today = _date.today()
    user_content = (
        f"TODAY'S DATE: {today.isoformat()} ({today.strftime('%A, %d %B %Y')})\n\n"
        f"Request: {text}"
    )
    resp = await _client().messages.create(
        model=settings.anthropic_model_fast,
        max_tokens=300,
        system=_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_content}],
    )
    raw = _strip_fences(
        "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
    )
    data = json.loads(raw)
    raw_due = data.get("due_days")
    due_days = int(raw_due) if isinstance(raw_due, (int, float)) and raw_due else None
    return InvoiceRequest(
        customer_name=data["customer_name"],
        description=data.get("description") or "Professional services",
        amount=Decimal(str(data["amount"])),
        currency=(data.get("currency") or "AED").upper(),
        due_days=due_days,
    )
