"""Post-payment receipt flow.

Triggered when Stripe POSTs `checkout.session.completed` to our webhook.

For each successful payment:
  1. Look up the invoice in Supabase by stripe_session_id
  2. Pull customer contact (phone) from Zoho — used for WhatsApp notification
  3. Post a CustomerPayment in Zoho linked to the invoice → marks it paid there
  4. Render bilingual SIMPLIFIED TAX RECEIPT PDF with sequential RCP-YYYY-NNN number
  5. Upload to Supabase Storage → signed URL
  6. Update the Supabase invoice row (status=paid, paid_date, receipt_number, receipt_url)
  7. Send WhatsApp confirmations: to the business owner always, to the customer
     if their phone is on record in Zoho

Idempotent: re-running on an already-paid invoice is a no-op.
"""
import logging
from datetime import date
from decimal import Decimal
from typing import Any
from uuid import UUID

from ar.storage import upload_pdf
from ar.templates.receipt_pdf import ReceiptData, render_receipt_pdf
from database import get_db
from whatsapp.sender import send_document, send_text
from zoho.client import ZohoBooksClient

logger = logging.getLogger(__name__)


async def _next_receipt_number(client_id: UUID) -> str:
    """Sequential per-client receipt numbers: RCP-YYYY-NNN."""
    db = await get_db()
    year = date.today().year
    prefix = f"RCP-{year}"
    res = (
        await db.table("invoices")
        .select("receipt_number")
        .eq("client_id", str(client_id))
        .like("receipt_number", f"{prefix}%")
        .order("receipt_number", desc=True)
        .limit(1)
        .execute()
    )
    last = (res.data or [{}])[0].get("receipt_number") if res.data else None
    seq = int(last.split("-")[-1]) + 1 if last else 1
    return f"{prefix}-{seq:03d}"


def _normalize_phone(raw: str | None) -> str | None:
    """Strip +, spaces, dashes, parens. WhatsApp wants E.164 without leading +."""
    if not raw:
        return None
    digits = "".join(ch for ch in raw if ch.isdigit())
    return digits or None


async def _zoho_get_customer(
    zoho: ZohoBooksClient, customer_id: str
) -> dict[str, Any]:
    try:
        resp = await zoho.get_entity("contacts", customer_id)
        return resp.get("contact") or {}
    except Exception:
        logger.exception("Failed to fetch Zoho contact %s", customer_id)
        return {}


async def _post_zoho_customer_payment(
    zoho: ZohoBooksClient,
    customer_id: str,
    zoho_invoice_id: str,
    amount: Decimal,
    payment_intent: str | None,
) -> dict[str, Any]:
    payload = {
        "customer_id": customer_id,
        "payment_mode": "stripe",
        "amount": float(amount),
        "date": date.today().isoformat(),
        "reference_number": payment_intent or "",
        "invoices": [
            {"invoice_id": zoho_invoice_id, "amount_applied": float(amount)}
        ],
    }
    return await zoho.create_entity("customerpayments", payload)


async def handle_payment_success(stripe_session: dict[str, Any]) -> None:
    metadata = stripe_session.get("metadata") or {}
    invoice_number = metadata.get("invoice_number")
    client_id_str = metadata.get("client_id")

    if not (invoice_number and client_id_str):
        logger.warning(
            "Stripe session missing capitalbooks metadata: id=%s",
            stripe_session.get("id"),
        )
        return

    db = await get_db()
    invoice_res = (
        await db.table("invoices")
        .select("*")
        .eq("client_id", client_id_str)
        .eq("invoice_number", invoice_number)
        .single()
        .execute()
    )
    invoice = invoice_res.data
    if not invoice:
        logger.warning(
            "Invoice not found for Stripe session: client=%s number=%s",
            client_id_str, invoice_number,
        )
        return
    if invoice.get("status") == "paid":
        logger.info("Invoice %s already paid — skipping", invoice_number)
        return

    client_res = (
        await db.table("clients").select("*").eq("id", client_id_str).single().execute()
    )
    client = client_res.data or {}

    client_uuid = UUID(client_id_str)
    amount_paid = Decimal(str(invoice["total"]))
    payment_intent = stripe_session.get("payment_intent")
    currency = invoice.get("currency", "AED")
    zoho_invoice_id = invoice.get("zoho_invoice_id")

    customer_contact: dict[str, Any] = {}
    pdf_url = ""
    receipt_number = await _next_receipt_number(client_uuid)

    # ---- Zoho: pull customer contact + post payment ----
    if client.get("zoho_organization_id") and zoho_invoice_id:
        try:
            async with ZohoBooksClient(
                organization_id=client["zoho_organization_id"],
                access_token=client["zoho_access_token"],
                refresh_token=client["zoho_refresh_token"],
                client_uuid=client_uuid,
            ) as zoho:
                # Look up the invoice in Zoho to get customer_id
                inv_resp = await zoho.get_entity("invoices", zoho_invoice_id)
                zoho_invoice = inv_resp.get("invoice") or {}
                customer_id = zoho_invoice.get("customer_id")

                if customer_id:
                    customer_contact = await _zoho_get_customer(zoho, customer_id)
                    try:
                        await _post_zoho_customer_payment(
                            zoho, customer_id, zoho_invoice_id, amount_paid, payment_intent,
                        )
                    except Exception:
                        logger.exception(
                            "Zoho CustomerPayment failed for invoice %s — receipt will still be issued",
                            invoice_number,
                        )
        except Exception:
            logger.exception("Zoho payment flow failed for invoice %s", invoice_number)

    # ---- Render receipt PDF ----
    receipt_data = ReceiptData(
        receipt_number=receipt_number,
        invoice_number=invoice_number,
        payment_date=date.today(),
        company_name=client.get("company_name", ""),
        company_trn=client.get("trn", ""),
        customer_name=invoice.get("customer_name", ""),
        customer_trn=invoice.get("customer_trn") or customer_contact.get("gst_no"),
        amount_paid=amount_paid,
        vat_amount=Decimal(str(invoice.get("vat_amount", 0))),
        currency=currency,
        payment_method="Stripe",
        stripe_payment_intent=payment_intent,
    )
    try:
        pdf_bytes = render_receipt_pdf(receipt_data)
        pdf_url = await upload_pdf(
            f"receipts/{client_id_str}/{receipt_number}.pdf", pdf_bytes
        )
    except Exception:
        logger.exception("Receipt PDF/upload failed for %s", receipt_number)

    # ---- Persist payment state ----
    try:
        await (
            db.table("invoices")
            .update({
                "status": "paid",
                "paid_date": date.today().isoformat(),
                "stripe_payment_intent": payment_intent,
                "receipt_number": receipt_number,
                "receipt_url": pdf_url,
            })
            .eq("id", invoice["id"])
            .execute()
        )
    except Exception:
        logger.exception("Failed to mark invoice %s paid in Supabase", invoice_number)

    # ---- WhatsApp notifications ----
    owner_phone = client.get("phone")
    customer_phone = _normalize_phone(
        customer_contact.get("mobile") or customer_contact.get("phone")
    )

    owner_msg = (
        f"💰 Payment received\n"
        f"Invoice {invoice_number} — {invoice.get('customer_name')}\n"
        f"Amount: {currency} {amount_paid:,.2f} (incl. VAT {currency} "
        f"{float(invoice.get('vat_amount') or 0):,.2f})\n"
        f"Receipt: {receipt_number}"
    )

    if owner_phone:
        try:
            await send_text(owner_phone, owner_msg)
            if pdf_url:
                await send_document(
                    owner_phone, pdf_url, f"{receipt_number}.pdf",
                    f"Receipt for invoice {invoice_number}",
                )
        except Exception:
            logger.exception("Failed to notify business owner %s", owner_phone)

    if customer_phone and customer_phone != owner_phone:
        customer_msg = (
            f"Hi {invoice.get('customer_name')},\n"
            f"Thank you — your payment of {currency} {amount_paid:,.2f} for invoice "
            f"{invoice_number} has been received. ✅\n"
            f"Receipt {receipt_number} attached."
        )
        try:
            await send_text(customer_phone, customer_msg)
            if pdf_url:
                await send_document(
                    customer_phone, pdf_url, f"{receipt_number}.pdf",
                    f"Receipt for invoice {invoice_number}",
                )
        except Exception:
            # Customer's number may not be WhatsApp-enabled or whitelisted in
            # Meta's test list — fall back to non-fatal log.
            logger.warning(
                "Customer WhatsApp notification failed for %s (likely not WA-enabled or not in Meta test list)",
                customer_phone,
            )
