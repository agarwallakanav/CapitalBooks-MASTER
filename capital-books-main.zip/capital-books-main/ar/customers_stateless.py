"""Customer listing — Zoho contacts (customer type) enriched with invoice activity.

list_customers(input, ctx) → ModuleResult

Filters:
  default          → ALL active customers, top 15 by invoice count
                     (NOT only those with balances)
  owed             → customers with outstanding invoices
  paid_this_month  → customers we've received payment from this month
  inactive         → customers with no invoice in last 90 days

Same shape + sizing rules as ap/vendors_stateless.list_vendors: ≤15 inline,
otherwise build an Excel and send as a WhatsApp document.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date
from io import BytesIO
from typing import Any, Literal

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from orchestrator.engine import ModuleResult, OrchContext

logger = logging.getLogger(__name__)

FilterKind = Literal["default", "owed", "paid_this_month", "inactive"]
_INLINE_CAP = 15
_NAVY = "1A2332"; _ALT = "F4F6F8"
_AED_FMT = '_-* #,##0.00 [$AED]_-;-* #,##0.00 [$AED]_-'


@dataclass
class ListCustomersQuery:
    sender: str | None = None
    filter_kind: FilterKind = "default"


def _safe_date(s: str | None) -> date | None:
    if not s:
        return None
    try:
        return date.fromisoformat(str(s)[:10])
    except ValueError:
        return None


def _format_money(amt: float, currency: str = "AED") -> str:
    return f"{currency} {amt:,.2f}"


def _aggregate_by_customer(invoices: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Returns {customer_id: {count, outstanding, last_amount, last_date, last_currency}}."""
    agg: dict[str, dict[str, Any]] = {}
    for inv in invoices:
        cid = inv.get("customer_id") or inv.get("contact_id") or ""
        if not cid:
            continue
        bal = float(inv.get("balance") or 0)
        amt = float(inv.get("total") or 0)
        d = _safe_date(inv.get("date") or inv.get("invoice_date"))
        row = agg.setdefault(cid, {
            "count": 0, "outstanding": 0.0,
            "last_amount": 0.0, "last_date": None, "last_currency": "AED",
        })
        row["count"] += 1
        row["outstanding"] += bal
        if d and (row["last_date"] is None or d > row["last_date"]):
            row["last_date"] = d
            row["last_amount"] = amt
            row["last_currency"] = inv.get("currency_code") or "AED"
    return agg


async def _fetch_paid_this_month(zoho) -> set[str]:
    today = date.today()
    start = today.replace(day=1).isoformat()
    end = today.isoformat()
    try:
        resp = await zoho.list_entities("customerpayments", filters={
            "per_page": 200, "date_after": start, "date_before": end,
        })
        ids = {p.get("customer_id") for p in (resp.get("customerpayments") or [])}
        return {i for i in ids if i}
    except Exception:
        logger.exception("customerpayments fetch failed (non-fatal)")
        return set()


def _filter_customers(
    customers: list[dict[str, Any]],
    by_customer: dict[str, dict[str, Any]],
    filter_kind: FilterKind,
    paid_this_month_ids: set[str],
) -> list[tuple[dict[str, Any], dict[str, Any]]]:
    today = date.today()
    pairs: list[tuple[dict[str, Any], dict[str, Any]]] = []
    for c in customers:
        cid = c.get("contact_id")
        if not cid:
            continue
        agg = by_customer.get(cid, {
            "count": 0, "outstanding": 0.0,
            "last_amount": 0.0, "last_date": None, "last_currency": "AED",
        })
        if filter_kind == "owed":
            if agg["outstanding"] <= 0:
                continue
        elif filter_kind == "paid_this_month":
            if cid not in paid_this_month_ids:
                continue
        elif filter_kind == "inactive":
            last = agg["last_date"]
            if last and (today - last).days <= 90:
                continue
        pairs.append((c, agg))

    if filter_kind == "owed":
        pairs.sort(key=lambda p: -p[1]["outstanding"])
    elif filter_kind == "paid_this_month":
        pairs.sort(key=lambda p: (p[1]["last_date"] or date.min), reverse=True)
    elif filter_kind == "inactive":
        pairs.sort(key=lambda p: (p[0].get("contact_name") or "").lower())
    else:
        # default: ALL customers, alphabetical so the user can scan
        pairs.sort(key=lambda p: (p[0].get("contact_name") or "").lower())
    return pairs


async def list_customers(
    input: ListCustomersQuery, ctx: OrchContext,
) -> ModuleResult:
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected.")
    z = ctx.resolver._zoho

    # Pull ALL active customers — no receivables filter, no Supabase shortcut.
    try:
        contacts_resp = await z.list_entities("contacts", filters={
            "contact_type": "customer",
            "status": "active",
            "per_page": 200,
        })
        customers = contacts_resp.get("contacts") or []
        logger.info(
            "Zoho GET /contacts?contact_type=customer&status=active → %d contacts",
            len(customers),
        )
    except Exception as e:
        logger.exception("customer fetch failed")
        return ModuleResult(reply_to_user=f"Couldn't pull customers: {e}")

    # Pull invoices across the useful statuses (single fetch per status,
    # grouped locally). 'draft' is excluded — customers with only drafts
    # still show up via the contacts call, just with count=0.
    invoices: list[dict[str, Any]] = []
    try:
        for status in ("sent", "overdue", "paid", "partially_paid"):
            r = await z.list_entities("invoices", filters={
                "status": status, "per_page": 200,
            })
            invoices.extend(r.get("invoices") or [])
        logger.info("Zoho invoices fetched across statuses → %d total", len(invoices))
    except Exception:
        logger.exception("invoices fetch failed (non-fatal — listing without activity)")

    by_customer = _aggregate_by_customer(invoices)
    paid_ids = (await _fetch_paid_this_month(z)
                if input.filter_kind == "paid_this_month" else set())

    pairs = _filter_customers(customers, by_customer, input.filter_kind, paid_ids)
    total = len(pairs)
    if total == 0:
        return ModuleResult(reply_to_user=_empty_message(input.filter_kind))

    if total <= _INLINE_CAP:
        return ModuleResult(
            reply_to_user=_format_inline(pairs, input.filter_kind),
            extra_events=[{
                "event_type": "customers_listed",
                "payload": {"filter": input.filter_kind, "count": total},
            }],
        )
    return await _list_as_excel(pairs, input, ctx)


def _header(filter_kind: FilterKind, total: int, shown: int) -> str:
    if filter_kind == "owed":
        return f"📋 *Customers who owe you* ({total})"
    if filter_kind == "paid_this_month":
        return f"📋 *Customers who paid this month* ({total})"
    if filter_kind == "inactive":
        return f"📋 *Inactive customers (no invoice in 90+ days)* ({total})"
    if shown < total:
        return f"📋 *Customers* — showing {shown} of {total}"
    return f"📋 *Your customers ({total} total)*"


def _format_inline(
    pairs: list[tuple[dict[str, Any], dict[str, Any]]],
    filter_kind: FilterKind,
) -> str:
    total = len(pairs)
    lines = [_header(filter_kind, total, total), ""]
    total_receivables = 0.0
    for i, (cust, agg) in enumerate(pairs, 1):
        name = cust.get("contact_name") or "(unnamed)"
        out = agg["outstanding"]
        total_receivables += out
        if filter_kind == "owed":
            line = f"{i}. {name} — owed: {_format_money(out)}"
            if agg["count"] > 1:
                line += f" ({agg['count']} invoices)"
        elif filter_kind == "paid_this_month":
            d = agg["last_date"]
            line = f"{i}. {name}"
            if d:
                line += (f" — last paid {_format_money(agg['last_amount'], agg['last_currency'])}"
                         f" on {d.strftime('%-d %b')}")
        elif filter_kind == "inactive":
            d = agg["last_date"]
            line = f"{i}. {name} — last activity: {d.isoformat() if d else 'never'}"
        else:
            # Default: ALL customers, with outstanding even if 0
            if out > 0:
                line = f"{i}. {name} — {_format_money(out)} outstanding"
                if agg["count"] > 1:
                    line += f" ({agg['count']} invoices)"
            else:
                line = f"{i}. {name} — AED 0"
        lines.append(line)
    if filter_kind in ("default", "owed") and total_receivables > 0:
        lines.append("")
        lines.append(f"*Total receivables: {_format_money(total_receivables)}*")
    return "\n".join(lines)


def _empty_message(filter_kind: FilterKind) -> str:
    if filter_kind == "owed":
        return "✅ No customers with outstanding invoices."
    if filter_kind == "paid_this_month":
        return "No customer payments received this month yet."
    if filter_kind == "inactive":
        return "No inactive customers — everyone has activity within the last 90 days."
    return "No customers in Zoho yet. Create your first invoice and the customer gets added."


def _build_customer_xlsx(
    pairs: list[tuple[dict[str, Any], dict[str, Any]]],
    filter_kind: FilterKind,
) -> bytes:
    wb = Workbook(); ws = wb.active; ws.title = "Customers"
    headers = ["#", "Customer", "Email", "Phone", "Currency",
               "Invoices", "Outstanding (AED)",
               "Last invoice amount", "Last invoice date"]
    for c, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=_NAVY)
    for i, (cust, agg) in enumerate(pairs, 1):
        r = i + 1
        ws.cell(row=r, column=1, value=i)
        ws.cell(row=r, column=2, value=cust.get("contact_name") or "")
        ws.cell(row=r, column=3, value=cust.get("email") or "")
        ws.cell(row=r, column=4, value=cust.get("phone") or "")
        ws.cell(row=r, column=5, value=cust.get("currency_code") or "AED")
        ws.cell(row=r, column=6, value=agg["count"])
        ws.cell(row=r, column=7, value=round(agg["outstanding"], 2))
        ws.cell(row=r, column=8, value=round(agg["last_amount"], 2))
        ws.cell(row=r, column=9, value=agg["last_date"].isoformat() if agg["last_date"] else "")
        if r % 2 == 0:
            for c in range(1, len(headers) + 1):
                ws.cell(row=r, column=c).fill = PatternFill("solid", fgColor=_ALT)
    for c in (7, 8):
        for r in range(2, len(pairs) + 2):
            ws.cell(row=r, column=c).number_format = _AED_FMT
    ws.freeze_panes = "A2"
    for col_idx in range(1, len(headers) + 1):
        col = get_column_letter(col_idx)
        max_len = len(headers[col_idx - 1])
        for r in range(1, ws.max_row + 1):
            v = ws.cell(row=r, column=col_idx).value
            if v is None: continue
            max_len = max(max_len, len(str(v)))
        ws.column_dimensions[col].width = min(max_len + 3, 50)
    buf = BytesIO(); wb.save(buf)
    return buf.getvalue()


async def _list_as_excel(
    pairs: list[tuple[dict[str, Any], dict[str, Any]]],
    input: ListCustomersQuery,
    ctx: OrchContext,
) -> ModuleResult:
    import time as _time
    from ar.storage import upload_bytes
    from whatsapp.sender import send_document
    xlsx = _build_customer_xlsx(pairs, input.filter_kind)
    safe_filter = input.filter_kind
    key = f"customer_lists/{ctx.cfg.id}/customers_{safe_filter}_{int(_time.time())}.xlsx"
    file_url = await upload_bytes(
        key, xlsx,
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    caption = (
        f"📋 Customer List — {ctx.cfg.company_name}\n"
        f"{len(pairs)} customers"
        + (f" ({input.filter_kind})" if input.filter_kind != "default" else "")
    )
    try:
        await send_document(
            to=input.sender or "", link=file_url,
            filename=f"customers_{safe_filter}.xlsx",
            caption=caption,
        )
        return ModuleResult(
            reply_to_user="__SUPPRESS_REPLY__",
            extra_events=[{
                "event_type": "customers_exported",
                "payload": {"filter": input.filter_kind, "count": len(pairs)},
            }],
        )
    except Exception as e:
        logger.exception("WhatsApp document send failed for customer list")
        return ModuleResult(
            reply_to_user=f"⚠️ Built the list but couldn't send the attachment: {e}\nDirect link: {file_url}",
        )
