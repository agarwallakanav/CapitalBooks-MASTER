"""AR aging report — buckets outstanding invoices by days past due."""
import logging
from dataclasses import dataclass
from datetime import date
from typing import Any
from uuid import UUID

from database import get_db

logger = logging.getLogger(__name__)


@dataclass
class AgingBuckets:
    current: float = 0.0      # not yet due
    days_1_30: float = 0.0
    days_31_60: float = 0.0
    days_61_90: float = 0.0
    days_over_90: float = 0.0
    by_customer: dict[str, dict[str, float]] = None

    def total(self) -> float:
        return (
            self.current + self.days_1_30 + self.days_31_60
            + self.days_61_90 + self.days_over_90
        )


def _bucket_for(days_past_due: int) -> str:
    if days_past_due <= 0:
        return "current"
    if days_past_due <= 30:
        return "days_1_30"
    if days_past_due <= 60:
        return "days_31_60"
    if days_past_due <= 90:
        return "days_61_90"
    return "days_over_90"


async def compute_aging(client_id: UUID, today: date | None = None) -> AgingBuckets:
    today = today or date.today()
    db = await get_db()
    res = (
        await db.table("invoices")
        .select("customer_name, total, currency, due_date, status")
        .eq("client_id", str(client_id))
        .in_("status", ["sent", "overdue"])
        .execute()
    )
    invoices = res.data or []

    buckets = AgingBuckets(by_customer={})
    for inv in invoices:
        if not inv.get("due_date"):
            continue
        days_past = (today - date.fromisoformat(inv["due_date"])).days
        bucket = _bucket_for(days_past)
        amount = float(inv.get("total") or 0)
        setattr(buckets, bucket, getattr(buckets, bucket) + amount)

        cust = inv.get("customer_name") or "(unknown)"
        buckets.by_customer.setdefault(cust, {})
        buckets.by_customer[cust][bucket] = (
            buckets.by_customer[cust].get(bucket, 0.0) + amount
        )
    return buckets


async def aging_summary(client_id: UUID, today: date | None = None) -> str:
    b = await compute_aging(client_id, today)
    total = b.total()
    if total == 0:
        return "✅ No outstanding receivables."

    lines = [
        f"📊 AR Aging — AED {total:,.0f} total outstanding\n",
        f"Current:       AED {b.current:,.0f}",
        f"1-30 days:     AED {b.days_1_30:,.0f}",
        f"31-60 days:    AED {b.days_31_60:,.0f}",
        f"61-90 days:    AED {b.days_61_90:,.0f}",
        f"90+ days:      AED {b.days_over_90:,.0f}",
    ]
    if b.days_over_90 > 0:
        lines.append(f"\n⚠️ AED {b.days_over_90:,.0f} is over 90 days — consider collection action.")

    # Top 3 customers by total outstanding
    if b.by_customer:
        top = sorted(
            b.by_customer.items(),
            key=lambda kv: -sum(kv[1].values()),
        )[:3]
        lines.append("\nTop owed by customer:")
        for cust, buckets in top:
            lines.append(f"  • {cust}: AED {sum(buckets.values()):,.0f}")

    return "\n".join(lines)
