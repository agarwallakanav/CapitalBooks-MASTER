"""Short payment URL → Stripe Checkout redirect.

Mounted at GET /pay/{invoice_number}. Looks up the invoice in Supabase,
fetches stripe_checkout_url, and 302s to it. If the URL is missing or the
invoice doesn't exist, returns 404 with a plain-text message.

Keeps WhatsApp messages clean: instead of a 400-char Stripe URL, the bot
sends https://<your-domain>/pay/INV-202606-0017.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException
from fastapi.responses import RedirectResponse

from config import settings
from database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(tags=["payments"])


@router.get("/pay/{invoice_number}")
async def pay_redirect(invoice_number: str):
    db = await get_db()
    try:
        res = (
            await db.table("invoices")
            .select("stripe_checkout_url, status, invoice_number")
            .eq("invoice_number", invoice_number)
            .limit(1)
            .execute()
        )
    except Exception:
        logger.exception("invoice lookup failed for %s", invoice_number)
        raise HTTPException(503, "Payment service temporarily unavailable")

    if not res.data:
        raise HTTPException(404, f"Invoice {invoice_number} not found")
    row = res.data[0]
    if row.get("status") == "paid":
        # Friendlier than a Stripe error page when the user revisits an old link
        return RedirectResponse(
            url=f"{settings.public_base_url}/paid?inv={invoice_number}",
            status_code=302,
        )
    url = row.get("stripe_checkout_url")
    if not url:
        raise HTTPException(404, "Payment link not configured for this invoice")
    return RedirectResponse(url=url, status_code=302)


def short_pay_url(invoice_number: str) -> str:
    """Public-facing short URL for a Stripe Checkout. Used in WhatsApp + email.

    When the base URL is an ngrok free-tier host, append the
    ngrok-skip-browser-warning=true query param so the click bypasses
    ngrok's interstitial warning page. After our endpoint 302s to Stripe,
    ngrok is out of the loop, so this only matters for the first hop.
    """
    base = settings.public_base_url.rstrip("/")
    url = f"{base}/pay/{invoice_number}"
    if "ngrok-" in base or ".ngrok" in base:
        url += "?ngrok-skip-browser-warning=true"
    return url
