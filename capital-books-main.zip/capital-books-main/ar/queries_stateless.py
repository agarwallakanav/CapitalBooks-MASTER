"""AR read-layer — queries that hit Zoho directly (not our Supabase mirror).

  query_customer_payment_status(name, ctx)
      "did ABC Corp pay?" → list their open + recently-paid invoices.

  query_overdue_invoices(ctx)
      Invoices past due_date or due within 3 days.

  query_aging_report(ctx)
      Zoho's customer aging summary, formatted into current / 1-30 / 31-60 /
      61-90 / 90+ buckets with totals.
"""
import logging
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any

from orchestrator.engine import ModuleResult, OrchContext

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------

@dataclass
class CustomerPaymentQuery:
    customer_name: str
    sender: str | None = None


@dataclass
class _Empty:
    sender: str | None = None


# ---------------------------------------------------------------------------
# Customer payment status
# ---------------------------------------------------------------------------

async def query_customer_payment_status(
    input: CustomerPaymentQuery, ctx: OrchContext
) -> ModuleResult:
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected — can't check payment status.")
    try:
        # Resolve customer first; if no match we report cleanly.
        contacts = await ctx.resolver._zoho.search_contacts(input.customer_name)
        customer_contacts = [c for c in contacts if c.get("contact_type") != "vendor"]
        if not customer_contacts:
            return ModuleResult(
                reply_to_user=f"I don't see *{input.customer_name}* as a customer in Zoho.",
            )
        customer = customer_contacts[0]
        customer_id = customer.get("contact_id")

        resp = await ctx.resolver._zoho.list_entities(
            "invoices",
            filters={"customer_id": customer_id, "per_page": 25},
        )
    except Exception as e:
        logger.exception("Customer payment status query failed")
        return ModuleResult(reply_to_user=f"Couldn't reach Zoho: {e}")

    invoices = resp.get("invoices") or []
    if not invoices:
        return ModuleResult(
            reply_to_user=f"*{customer.get('contact_name')}*: no invoices on file.",
        )

    open_invs = [i for i in invoices if i.get("status") in {"sent", "overdue", "partially_paid"}]
    paid_invs = [i for i in invoices if i.get("status") == "paid"]

    currency = invoices[0].get("currency_code", "AED")
    total_open = sum(float(i.get("balance") or 0) for i in open_invs)
    total_paid = sum(float(i.get("total") or 0) for i in paid_invs[:10])

    lines = [f"*{customer.get('contact_name')}*"]
    if open_invs:
        lines.append(f"💸 Outstanding: {currency} {total_open:,.2f} across {len(open_invs)} invoice(s)")
        for inv in open_invs[:5]:
            tag = "OVERDUE" if inv.get("status") == "overdue" else inv.get("status")
            lines.append(
                f"  • {inv.get('invoice_number')} — {currency} "
                f"{float(inv.get('balance') or 0):,.2f} ({tag}, due {inv.get('due_date')})"
            )
    else:
        lines.append("✅ No open invoices.")
    if paid_invs:
        lines.append("")
        lines.append(f"✅ Recently paid (last {len(paid_invs[:10])}): {currency} {total_paid:,.2f}")
        for inv in paid_invs[:3]:
            lines.append(
                f"  • {inv.get('invoice_number')} — {currency} "
                f"{float(inv.get('total') or 0):,.2f} on {inv.get('last_payment_date') or inv.get('date')}"
            )

    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{
            "event_type": "ar_customer_status_queried",
            "payload": {"customer_id": customer_id, "open_count": len(open_invs)},
        }],
    )


# ---------------------------------------------------------------------------
# Overdue / due-soon list
# ---------------------------------------------------------------------------

async def query_overdue_invoices(input: _Empty, ctx: OrchContext) -> ModuleResult:
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected.")

    today = date.today()
    threshold = today + timedelta(days=3)
    try:
        resp = await ctx.resolver._zoho.list_entities(
            "invoices",
            filters={"per_page": 50, "status": "overdue"},
        )
        overdue = resp.get("invoices") or []

        resp_open = await ctx.resolver._zoho.list_entities(
            "invoices",
            filters={"per_page": 50, "status": "sent"},
        )
        due_soon = [
            i for i in (resp_open.get("invoices") or [])
            if i.get("due_date")
            and date.fromisoformat(i["due_date"]) <= threshold
        ]
    except Exception as e:
        logger.exception("Overdue query failed")
        return ModuleResult(reply_to_user=f"Couldn't reach Zoho: {e}")

    if not overdue and not due_soon:
        return ModuleResult(reply_to_user="✅ No invoices are overdue or due within 3 days.")

    currency = (overdue or due_soon)[0].get("currency_code", "AED")
    lines: list[str] = []
    if overdue:
        total = sum(float(i.get("balance") or 0) for i in overdue)
        lines.append(f"⚠️ {len(overdue)} overdue — {currency} {total:,.2f} outstanding")
        for i in overdue[:10]:
            days_over = (today - date.fromisoformat(i["due_date"])).days if i.get("due_date") else "?"
            lines.append(
                f"  • {i.get('customer_name')} — {currency} "
                f"{float(i.get('balance') or 0):,.2f} ({days_over}d overdue)"
            )
    if due_soon:
        if lines:
            lines.append("")
        total = sum(float(i.get("balance") or 0) for i in due_soon)
        lines.append(f"📅 {len(due_soon)} due within 3 days — {currency} {total:,.2f}")
        for i in due_soon[:10]:
            d = (date.fromisoformat(i["due_date"]) - today).days if i.get("due_date") else "?"
            tag = "due today" if d == 0 else f"due in {d}d"
            lines.append(
                f"  • {i.get('customer_name')} — {currency} "
                f"{float(i.get('balance') or 0):,.2f} ({tag})"
            )

    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{
            "event_type": "ar_overdue_queried",
            "payload": {"overdue_count": len(overdue), "due_soon_count": len(due_soon)},
        }],
    )


# ---------------------------------------------------------------------------
# Aging report
# ---------------------------------------------------------------------------

async def query_aging_report(input: _Empty, ctx: OrchContext) -> ModuleResult:
    if ctx.resolver is None:
        return ModuleResult(reply_to_user="Zoho isn't connected.")

    today = date.today()
    try:
        resp = await ctx.resolver._zoho.list_entities(
            "invoices",
            filters={"per_page": 200, "status": "unpaid"},
        )
    except Exception as e:
        logger.exception("Aging query failed")
        return ModuleResult(reply_to_user=f"Couldn't reach Zoho: {e}")

    invoices = resp.get("invoices") or []
    buckets = {"current": 0.0, "d1_30": 0.0, "d31_60": 0.0, "d61_90": 0.0, "d90p": 0.0}
    by_customer: dict[str, float] = {}
    currency = "AED"

    for inv in invoices:
        bal = float(inv.get("balance") or 0)
        if bal <= 0:
            continue
        currency = inv.get("currency_code", currency)
        due = inv.get("due_date")
        days_past = (today - date.fromisoformat(due)).days if due else 0
        if days_past <= 0:
            buckets["current"] += bal
        elif days_past <= 30:
            buckets["d1_30"] += bal
        elif days_past <= 60:
            buckets["d31_60"] += bal
        elif days_past <= 90:
            buckets["d61_90"] += bal
        else:
            buckets["d90p"] += bal
        c = inv.get("customer_name") or "?"
        by_customer[c] = by_customer.get(c, 0.0) + bal

    total = sum(buckets.values())
    if total == 0:
        return ModuleResult(reply_to_user="✅ No outstanding receivables.")

    lines = [
        f"📊 AR Aging — {currency} {total:,.0f} outstanding",
        "",
        f"Current:     {currency} {buckets['current']:,.0f}",
        f"1-30 days:   {currency} {buckets['d1_30']:,.0f}",
        f"31-60 days:  {currency} {buckets['d31_60']:,.0f}",
        f"61-90 days:  {currency} {buckets['d61_90']:,.0f}",
        f"90+ days:    {currency} {buckets['d90p']:,.0f}",
    ]
    if buckets["d90p"] > 0:
        lines.append("")
        lines.append(f"⚠️ {currency} {buckets['d90p']:,.0f} is over 90 days past due.")
    if by_customer:
        top = sorted(by_customer.items(), key=lambda kv: -kv[1])[:3]
        lines.append("")
        lines.append("Top owed by customer:")
        for name, bal in top:
            lines.append(f"  • {name}: {currency} {bal:,.0f}")

    return ModuleResult(
        reply_to_user="\n".join(lines),
        extra_events=[{
            "event_type": "ar_aging_queried",
            "payload": {"total_outstanding": total,
                        "over_90_days": buckets["d90p"]},
        }],
    )
