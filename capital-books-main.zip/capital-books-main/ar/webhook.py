"""Stripe webhook receiver. Verifies signature, dispatches checkout.session.completed."""
import logging
from uuid import UUID

import stripe
from fastapi import APIRouter, Header, HTTPException, Request

from config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhook/stripe", tags=["stripe"])


@router.post("")
async def stripe_webhook(
    request: Request,
    stripe_signature: str = Header(default="", alias="Stripe-Signature"),
) -> dict[str, str]:
    payload = await request.body()
    try:
        event = stripe.Webhook.construct_event(
            payload, stripe_signature, settings.stripe_webhook_secret
        )
    except (ValueError, stripe.error.SignatureVerificationError) as e:
        logger.warning("Stripe signature verification failed: %s", e)
        raise HTTPException(status_code=400, detail="Invalid signature")

    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        try:
            await _handle_payment_success(session)
        except Exception:
            logger.exception(
                "Receipt flow raised — returning 200 anyway to stop Stripe retries on app bugs"
            )
    else:
        logger.debug("Ignoring Stripe event type: %s", event["type"])

    return {"status": "ok"}


async def _handle_payment_success(session: dict) -> None:
    """Phase C: routes through the orchestrator. The orchestrator handles
    Zoho writes + receipt PDF storage; this function then sends the WhatsApp
    notifications (the engine doesn't talk to WhatsApp directly)."""
    from ar.receipt_stateless import (
        PaymentSuccessInput,
        process_payment_success,
        update_invoice_receipt_url,
    )
    from database import get_db
    from orchestrator.engine import process
    from whatsapp.sender import send_document, send_text

    metadata = session.get("metadata") or {}
    client_id_str = metadata.get("client_id")
    if not client_id_str:
        logger.warning("Stripe session missing client_id metadata")
        return

    client_id = UUID(client_id_str)
    result = await process(client_id, process_payment_success, PaymentSuccessInput(session))

    # Patch the receipt URL back onto the invoice row + send WhatsApp notifications
    if result.entity_id and result.documents:
        for doc in result.documents:
            if doc.signed_url and doc.entity_type == "receipt":
                try:
                    await update_invoice_receipt_url(str(result.entity_id), doc.signed_url)
                except Exception:
                    logger.exception("Failed to patch receipt_url")
                # Notify business owner
                db = await get_db()
                client_row = (
                    await db.table("clients").select("phone").eq("id", client_id_str).single().execute()
                ).data
                owner_phone = (client_row or {}).get("phone")
                if owner_phone:
                    try:
                        await send_text(owner_phone, result.reply_to_user)
                        await send_document(
                            owner_phone, doc.signed_url, doc.filename,
                            "Payment receipt",
                        )
                    except Exception:
                        logger.exception("Owner notification failed")
                break
