"""Send invoice emails via Gmail SMTP.

Single public function: send_invoice_email(...). Synchronous from the caller's
perspective (we await asyncio.to_thread); the actual SMTP transaction is
blocking but cheap (~1-2s). Returns (success, error_message).

Why no asyncio email lib: smtplib is fine and means no extra dep. The
to_thread offload keeps the event loop free while smtp talks to gmail.

HTML template is inline — mobile-first, single column, max-width 600px,
inline styles only (gmail strips <style> blocks). Mint green accent
(#4CAF50) matches the invoice PDF branding from CLAUDE.md.
"""
from __future__ import annotations

import asyncio
import logging
import smtplib
from decimal import Decimal
from email.message import EmailMessage
from typing import Any

from config import settings

logger = logging.getLogger(__name__)

_SMTP_HOST = "smtp.gmail.com"
_SMTP_PORT = 465        # SSL


def _render_html(
    *,
    company_name: str,
    customer_name: str,
    invoice_number: str,
    amount: Decimal,
    currency: str,
    due_date: str,
    payment_url: str,
    description: str | None = None,
) -> str:
    """Mobile-first inline-styled HTML. Gmail / Outlook on phone friendly."""
    amount_str = f"{currency} {amount:,.2f}"
    pay_button = ""
    if payment_url:
        pay_button = f"""
          <tr>
            <td align="center" style="padding:24px 24px 8px 24px;">
              <a href="{payment_url}"
                 style="display:inline-block;background:#4CAF50;color:#ffffff;
                        text-decoration:none;font-weight:600;padding:14px 32px;
                        border-radius:6px;font-size:16px;">
                Pay {amount_str}
              </a>
            </td>
          </tr>
          <tr>
            <td align="center" style="padding:0 24px 24px 24px;font-size:12px;color:#888;">
              Secured by Stripe
            </td>
          </tr>"""
    desc_row = ""
    if description:
        desc_row = f"""
          <tr>
            <td style="padding:8px 24px;color:#444;font-size:14px;">
              <strong>For:</strong> {description}
            </td>
          </tr>"""

    return f"""<!doctype html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f4f6f8;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#1a2332;">
  <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="background:#f4f6f8;padding:24px 0;">
    <tr><td align="center">
      <table role="presentation" cellpadding="0" cellspacing="0" width="600"
             style="background:#ffffff;border-radius:8px;overflow:hidden;max-width:600px;width:100%;
                    box-shadow:0 1px 3px rgba(0,0,0,0.08);">
        <tr>
          <td style="background:#1a2332;color:#ffffff;padding:24px;">
            <div style="font-size:20px;font-weight:600;">{company_name}</div>
            <div style="font-size:13px;opacity:0.7;margin-top:4px;">Invoice {invoice_number}</div>
          </td>
        </tr>
        <tr>
          <td style="padding:24px;color:#1a2332;font-size:16px;line-height:1.5;">
            Hi {customer_name},<br /><br />
            Please find attached your invoice from <strong>{company_name}</strong>.
            You can pay securely online using the button below, or reply to this
            email if you have any questions.
          </td>
        </tr>
        <tr>
          <td style="padding:0 24px;">
            <table role="presentation" cellpadding="0" cellspacing="0" width="100%"
                   style="background:#f9fafb;border-radius:6px;padding:16px;">
              <tr>
                <td style="font-size:13px;color:#666;padding-bottom:4px;">Amount due</td>
                <td style="font-size:13px;color:#666;padding-bottom:4px;text-align:right;">Due date</td>
              </tr>
              <tr>
                <td style="font-size:18px;font-weight:600;color:#1a2332;">{amount_str}</td>
                <td style="font-size:14px;color:#1a2332;text-align:right;">{due_date}</td>
              </tr>
            </table>
          </td>
        </tr>
        {desc_row}
        {pay_button}
        <tr>
          <td style="padding:16px 24px 24px 24px;color:#888;font-size:12px;border-top:1px solid #eee;">
            This invoice was sent via CapitalBooks on behalf of {company_name}.
            The PDF is attached for your records.
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""


def _render_text(
    *, company_name: str, customer_name: str, invoice_number: str,
    amount: Decimal, currency: str, due_date: str, payment_url: str,
    description: str | None,
) -> str:
    """Plain-text fallback for mail clients that don't render HTML."""
    lines = [
        f"Hi {customer_name},",
        "",
        f"Please find attached your invoice {invoice_number} from {company_name}.",
        "",
        f"Amount due: {currency} {amount:,.2f}",
        f"Due date:   {due_date}",
    ]
    if description:
        lines.append(f"For: {description}")
    if payment_url:
        lines += ["", f"Pay online: {payment_url}"]
    lines += [
        "",
        f"— Sent via CapitalBooks on behalf of {company_name}",
    ]
    return "\n".join(lines)


async def send_invoice_email(
    *,
    to_email: str,
    bcc_email: str | None,
    company_name: str,
    customer_name: str,
    invoice_number: str,
    amount: Decimal,
    currency: str,
    due_date: str,
    payment_url: str,
    pdf_bytes: bytes | None,
    pdf_filename: str | None = None,
    description: str | None = None,
) -> tuple[bool, str]:
    if not settings.gmail_address or not settings.gmail_app_password:
        return False, "Gmail credentials not configured (GMAIL_ADDRESS / GMAIL_APP_PASSWORD)"
    if not to_email:
        return False, "No recipient email"

    msg = EmailMessage()
    msg["Subject"] = f"Invoice {invoice_number} from {company_name}"
    msg["From"] = f"{company_name} <{settings.gmail_address}>"
    msg["To"] = to_email
    if bcc_email and bcc_email.lower() != to_email.lower():
        msg["Bcc"] = bcc_email
    msg["Reply-To"] = bcc_email or settings.gmail_address

    msg.set_content(_render_text(
        company_name=company_name, customer_name=customer_name,
        invoice_number=invoice_number, amount=amount, currency=currency,
        due_date=due_date, payment_url=payment_url, description=description,
    ))
    msg.add_alternative(_render_html(
        company_name=company_name, customer_name=customer_name,
        invoice_number=invoice_number, amount=amount, currency=currency,
        due_date=due_date, payment_url=payment_url, description=description,
    ), subtype="html")

    if pdf_bytes:
        msg.add_attachment(
            pdf_bytes,
            maintype="application", subtype="pdf",
            filename=pdf_filename or f"{invoice_number}.pdf",
        )

    def _send_sync() -> None:
        with smtplib.SMTP_SSL(_SMTP_HOST, _SMTP_PORT, timeout=15) as smtp:
            smtp.login(settings.gmail_address, settings.gmail_app_password)
            smtp.send_message(msg)

    try:
        await asyncio.to_thread(_send_sync)
        return True, ""
    except smtplib.SMTPAuthenticationError as e:
        logger.exception("Gmail SMTP auth failed")
        return False, f"Gmail auth failed — check GMAIL_APP_PASSWORD ({e.smtp_code})"
    except Exception as e:
        logger.exception("Invoice email send failed")
        return False, str(e)
