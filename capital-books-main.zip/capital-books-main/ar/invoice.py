"""Create Zoho invoice → render PDF → upload to S3 → Stripe Checkout link → WhatsApp.

Flow when a user says "invoice ABC Corp AED 5000 for consulting":
  1. Parse request (Claude)
  2. Fuzzy-match contact in Zoho Books; create if missing
  3. Create Zoho Invoice with 5% VAT (using client's standard tax_id)
  4. Render bilingual PDF (ReportLab) and upload to S3
  5. Create Stripe Checkout Session
  6. Persist invoice row in Supabase
  7. Return WhatsApp reply text
"""
import logging
from datetime import date, timedelta
from decimal import Decimal
from uuid import UUID, uuid4

import stripe

from ar.parser import InvoiceRequest, parse_invoice_request
from ar.storage import upload_pdf
from config import settings
from database import get_db
from transactions.pipeline import load_client_config
from zoho.client import ZohoBooksClient

logger = logging.getLogger(__name__)

VAT_RATE = Decimal("0.05")


async def _next_invoice_number(client_id: UUID) -> str:
    """Sequential per-client invoice numbers: INV-YYYYMM-NNNN."""
    db = await get_db()
    today = date.today()
    prefix = f"INV-{today:%Y%m}"
    res = (
        await db.table("invoices")
        .select("invoice_number")
        .eq("client_id", str(client_id))
        .like("invoice_number", f"{prefix}%")
        .order("invoice_number", desc=True)
        .limit(1)
        .execute()
    )
    last = (res.data or [{}])[0].get("invoice_number")
    seq = int(last.split("-")[-1]) + 1 if last else 1
    return f"{prefix}-{seq:04d}"


async def _find_or_create_zoho_customer(
    zoho: ZohoBooksClient, customer_name: str
) -> dict:
    """Fuzzy match by name; create if absent."""
    matches = await zoho.search_contacts(customer_name)
    if matches:
        return matches[0]
    created = await zoho.create_contact(customer_name, contact_type="customer")
    return created.get("contact") or {}


async def _create_zoho_invoice(
    zoho: ZohoBooksClient,
    customer_id: str,
    request: InvoiceRequest,
    invoice_number: str,
    due: date,
    tax_ids: dict[str, str],
) -> dict:
    net = request.amount / (Decimal("1.0") + VAT_RATE)
    line_item: dict = {
        "name": request.description[:100],
        "description": request.description,
        "rate": float(net),
        "quantity": 1,
    }
    if tax_ids.get("standard"):
        line_item["tax_id"] = tax_ids["standard"]
    payload = {
        "customer_id": customer_id,
        "invoice_number": invoice_number,
        "date": date.today().isoformat(),
        "due_date": due.isoformat(),
        "currency_code": request.currency,
        "is_inclusive_tax": False,
        "line_items": [line_item],
    }
    # Zoho auto-numbers invoices by default; this flag lets us use our own number scheme.
    resp = await zoho.create_entity(
        "invoices", payload, params={"ignore_auto_number_generation": "true"}
    )
    invoice = resp.get("invoice") or {}
    invoice_id = invoice.get("invoice_id")
    # Transition draft → sent so the customer-facing invoice_url becomes accessible.
    # No email is fired (we'll deliver via WhatsApp). Best-effort: don't fail the whole
    # request if the status transition errors.
    if invoice_id:
        try:
            await zoho._request("POST", f"invoices/{invoice_id}/status/sent")
            invoice["status"] = "sent"
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning("Failed to mark invoice as sent: %s", e)
    return invoice


async def _create_stripe_checkout(
    client_row: dict,
    invoice_number: str,
    description: str,
    amount: Decimal,
    currency: str,
) -> tuple[str, str]:
    """Returns (checkout_url, session_id). Amount is the gross — Stripe takes minor units."""
    stripe.api_key = client_row.get("stripe_secret_key") or settings.stripe_secret_key
    session = await _to_thread(
        stripe.checkout.Session.create,
        mode="payment",
        success_url=f"https://capitalbooks.app/paid?inv={invoice_number}",
        cancel_url=f"https://capitalbooks.app/cancelled?inv={invoice_number}",
        line_items=[{
            "quantity": 1,
            "price_data": {
                "currency": currency.lower(),
                "product_data": {"name": description, "description": invoice_number},
                "unit_amount": int(amount * 100),
            },
        }],
        metadata={
            "invoice_number": invoice_number,
            "client_id": str(client_row["id"]),
        },
    )
    return session.url, session.id


async def _to_thread(fn, *args, **kwargs):
    import asyncio
    return await asyncio.to_thread(lambda: fn(*args, **kwargs))


async def handle_invoice_request(client_id: UUID, text: str) -> str:
    """Top-level entry. Returns the WhatsApp reply body."""
    try:
        req = await parse_invoice_request(text)
    except Exception as e:
        logger.exception("Invoice parse failed")
        return f"Couldn't parse that invoice request: {e}. Try: 'invoice ABC Corp 5000 AED for consulting'."

    client_config = await load_client_config(client_id)
    if not (client_config.zoho_organization_id and client_config.zoho_access_token):
        return "Your Zoho Books isn't connected yet. Contact support to link it."

    db = await get_db()
    client_row = (
        await db.table("clients").select("*").eq("id", str(client_id)).single().execute()
    ).data
    if not client_row:
        return "Client config not found."

    invoice_number = await _next_invoice_number(client_id)
    due = date.today() + timedelta(days=req.due_days)

    pdf_url = ""
    try:
        async with ZohoBooksClient(
            organization_id=client_config.zoho_organization_id,
            access_token=client_config.zoho_access_token,
            refresh_token=client_config.zoho_refresh_token or "",
            client_uuid=client_id,
        ) as zoho:
            customer = await _find_or_create_zoho_customer(zoho, req.customer_name)
            customer_id = customer.get("contact_id") or customer.get("customer_id")
            if not customer_id:
                return f"Couldn't create customer '{req.customer_name}' in Zoho Books."
            zoho_invoice = await _create_zoho_invoice(
                zoho, customer_id, req, invoice_number, due, client_config.zoho_tax_ids,
            )
            # Fetch Zoho's rendered invoice PDF + host it on Supabase Storage so the
            # WhatsApp link goes straight to the PDF (no customer portal login).
            zoho_invoice_id = zoho_invoice.get("invoice_id")
            if zoho_invoice_id:
                try:
                    pdf_bytes = await zoho.download_pdf("invoices", zoho_invoice_id)
                    pdf_url = await upload_pdf(
                        f"invoices/{client_id}/{invoice_number}.pdf", pdf_bytes
                    )
                except Exception:
                    logger.exception("PDF fetch/upload failed (non-fatal)")
                    pdf_url = zoho_invoice.get("invoice_url") or ""
    except Exception as e:
        logger.exception("Zoho invoice creation failed")
        return f"Zoho Books invoice creation failed: {e}"

    net = req.amount / (Decimal("1.0") + VAT_RATE)

    # Stripe checkout
    try:
        checkout_url, session_id = await _create_stripe_checkout(
            client_row, invoice_number, req.description, req.amount, req.currency,
        )
    except Exception as e:
        logger.exception("Stripe checkout creation failed (non-fatal)")
        checkout_url, session_id = "", ""

    # Persist
    await db.table("invoices").insert({
        "client_id": str(client_id),
        "invoice_number": invoice_number,
        "customer_name": req.customer_name,
        "amount": float(net),
        "vat_amount": float(req.amount - net),
        "total": float(req.amount),
        "currency": req.currency,
        "status": "sent",
        "pdf_url": pdf_url,
        "zoho_invoice_id": zoho_invoice.get("invoice_id"),
        "stripe_session_id": session_id,
        "due_date": due.isoformat(),
    }).execute()

    lines = [
        f"🧾 Invoice {invoice_number} created",
        f"Customer: {req.customer_name}",
        f"Amount: {req.currency} {req.amount:,.2f} (incl. {req.currency} {req.amount - net:,.2f} VAT)",
        f"Due: {due.isoformat()}",
    ]
    if pdf_url:
        lines.append(f"Invoice: {pdf_url}")
    if checkout_url:
        lines.append(f"Pay: {checkout_url}")
    return "\n".join(lines)
