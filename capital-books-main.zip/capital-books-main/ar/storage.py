"""PDF storage via Supabase Storage.

Uses a private bucket; access is via short-lived signed URLs (7-day expiry,
matching what we did with S3 presigned URLs). The supabase-py storage API is
sync-only (it's a thin wrapper over storage3), so we run uploads in a thread.
"""
import asyncio
import logging
from functools import lru_cache
from typing import Any

from supabase import Client, create_client

from config import settings

logger = logging.getLogger(__name__)

BUCKET = "capitalbooks-pdfs"
SIGNED_URL_TTL_SECONDS = 604800  # 7 days


@lru_cache
def _sb_sync() -> Client:
    return create_client(settings.supabase_url, settings.supabase_key)


def _ensure_bucket_sync() -> None:
    """Create the bucket if it doesn't exist. Idempotent. Buckets storing
    invoices/receipts are public — these docs are meant to be shared and
    signed URLs get mangled in WhatsApp transit (InvalidJWT errors)."""
    sb = _sb_sync()
    try:
        existing = sb.storage.list_buckets()
        if any(b.id == BUCKET for b in existing):
            return
    except Exception:
        logger.exception("Listing buckets failed; will attempt create")
    try:
        sb.storage.create_bucket(BUCKET, options={"public": True})
        logger.info("Created Supabase Storage bucket: %s (public)", BUCKET)
    except Exception as e:
        if "already exists" not in str(e).lower():
            raise


def _upload_sync(key: str, body: bytes, content_type: str) -> None:
    _ensure_bucket_sync()
    sb = _sb_sync()
    sb.storage.from_(BUCKET).upload(
        path=key,
        file=body,
        file_options={"content-type": content_type, "upsert": "true"},
    )


def _public_url_sync(key: str) -> str:
    sb = _sb_sync()
    url = sb.storage.from_(BUCKET).get_public_url(key)
    # storage3 sometimes appends a trailing '?' — strip it
    return url.rstrip("?")


def _signed_url_sync(key: str, ttl: int) -> str:
    # Retained for back-compat callers; routes to public URL since the bucket
    # is now public (no auth needed, link works in WhatsApp).
    return _public_url_sync(key)


async def upload_pdf(key: str, body: bytes) -> str:
    """Upload a PDF and return a 7-day signed URL."""
    await asyncio.to_thread(_upload_sync, key, body, "application/pdf")
    return await asyncio.to_thread(_signed_url_sync, key, SIGNED_URL_TTL_SECONDS)


async def upload_bytes(
    key: str, body: bytes, content_type: str = "application/octet-stream"
) -> str:
    await asyncio.to_thread(_upload_sync, key, body, content_type)
    return await asyncio.to_thread(_signed_url_sync, key, SIGNED_URL_TTL_SECONDS)
