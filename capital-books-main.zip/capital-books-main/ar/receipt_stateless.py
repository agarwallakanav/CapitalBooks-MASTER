"""Stateless payment-receipt flow — Phase C of the orchestrator migration.

Triggered by the Stripe webhook in ar/webhook.py. Steps:
  1. Look up the invoice in Supabase by stripe_session_id / invoice_number
  2. Resolve the Zoho customer (so we know phone for notification)
  3. Post a CustomerPayment to Zoho linked to the invoice
  4. Render a SIMPLIFIED TAX RECEIPT PDF (ReportLab)
  5. Upload via engine Document layer
  6. Persist receipt_number + receipt_url + status=paid on the invoice
  7. Return reply text (engine doesn't send WhatsApp; webhook does)

Notifications (WhatsApp text + document) happen in the webhook handler after
engine.execute returns, using the signed URL the engine attached to the
Document.
"""
import logging
from datetime import date
from decimal import Decimal
from typing import Any
from uuid import UUID

from ar.templates.receipt_pdf import ReceiptData, render_receipt_pdf
from database import get_db
from orchestrator.engine import Document, ModuleResult, OrchContext, ZohoWrite

logger = logging.getLogger(__name__)


class PaymentSuccessInput:
    """Carries everything the Stripe webhook handler extracted from the event."""

    def __init__(self, stripe_session: dict[str, Any]):
        self.stripe_session = stripe_session


async def _next_receipt_number(client_id) -> str:
    db = await get_db()
    year = date.today().year
    prefix = f"RCP-{year}"
    res = (
        await db.table("invoices")
        .select("receipt_number")
        .eq("client_id", str(client_id))
        .like("receipt_number", f"{prefix}%")
        .order("receipt_number", desc=True)
        .limit(1)
        .execute()
    )
    last = (res.data or [{}])[0].get("receipt_number") if res.data else None
    seq = int(last.split("-")[-1]) + 1 if last else 1
    return f"{prefix}-{seq:03d}"


def _normalize_phone(raw: str | None) -> str | None:
    if not raw:
        return None
    digits = "".join(ch for ch in raw if ch.isdigit())
    return digits or None


async def process_payment_success(input: PaymentSuccessInput, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg
    session = input.stripe_session
    metadata = session.get("metadata") or {}
    invoice_number = metadata.get("invoice_number")
    client_id_str = metadata.get("client_id")

    if not (invoice_number and client_id_str):
        return ModuleResult(
            reply_to_user="",
            extra_events=[{
                "event_type": "stripe_session_missing_metadata",
                "payload": {"session_id": session.get("id")},
            }],
        )

    db = await get_db()
    invoice_res = (
        await db.table("invoices")
        .select("*")
        .eq("client_id", client_id_str)
        .eq("invoice_number", invoice_number)
        .single()
        .execute()
    )
    invoice = invoice_res.data
    if not invoice:
        return ModuleResult(
            reply_to_user="",
            extra_events=[{
                "event_type": "invoice_not_found_for_session",
                "payload": {"invoice_number": invoice_number},
            }],
        )
    if invoice.get("status") == "paid":
        return ModuleResult(
            reply_to_user="",
            extra_events=[{
                "event_type": "payment_replay_ignored",
                "payload": {"invoice_id": invoice["id"]},
            }],
            entity_kind="invoice",
            entity_id=invoice["id"],
        )

    amount_paid = Decimal(str(invoice["total"]))
    payment_intent = session.get("payment_intent")
    currency = invoice.get("currency", "AED")
    zoho_invoice_id = invoice.get("zoho_invoice_id")

    # Look up the Zoho contact to recover customer phone (best-effort)
    customer_contact: dict[str, Any] = {}
    if ctx.resolver and zoho_invoice_id:
        try:
            inv = await ctx.resolver._zoho.get_entity("invoices", zoho_invoice_id)
            customer_id = (inv.get("invoice") or {}).get("customer_id")
            if customer_id:
                contact_resp = await ctx.resolver._zoho.get_entity("contacts", customer_id)
                customer_contact = contact_resp.get("contact") or {}
        except Exception:
            logger.exception("Zoho contact lookup failed (non-fatal)")

    # Receipt number
    client_uuid = UUID(client_id_str)
    receipt_number = await _next_receipt_number(client_uuid)

    # Render PDF
    pdf_bytes: bytes | None = None
    try:
        client_row = (
            await db.table("clients").select("*").eq("id", client_id_str).single().execute()
        ).data
        pdf_bytes = render_receipt_pdf(ReceiptData(
            receipt_number=receipt_number,
            invoice_number=invoice_number,
            payment_date=date.today(),
            company_name=client_row.get("company_name", "") if client_row else "",
            company_trn=client_row.get("trn", "") if client_row else "",
            customer_name=invoice.get("customer_name", ""),
            customer_trn=invoice.get("customer_trn") or customer_contact.get("gst_no"),
            amount_paid=amount_paid,
            vat_amount=Decimal(str(invoice.get("vat_amount", 0))),
            currency=currency,
            payment_method="Stripe",
            stripe_payment_intent=payment_intent,
        ))
    except Exception:
        logger.exception("Receipt PDF render failed")

    # Update invoice row + receipt_number now (Storage URL comes after engine
    # uploads the Document; the webhook caller will patch receipt_url).
    await (
        db.table("invoices")
        .update({
            "status": "paid",
            "paid_date": date.today().isoformat(),
            "stripe_payment_intent": payment_intent,
            "receipt_number": receipt_number,
        })
        .eq("id", invoice["id"])
        .execute()
    )

    # Declarative Zoho write for the CustomerPayment
    zoho_writes: list[ZohoWrite] = []
    if zoho_invoice_id and ctx.resolver:
        # We need the customer_id from the invoice — pulled above into customer_contact's
        # source. Re-derive from invoice we already fetched.
        try:
            inv_again = await ctx.resolver._zoho.get_entity("invoices", zoho_invoice_id)
            customer_id = (inv_again.get("invoice") or {}).get("customer_id")
            if customer_id:
                zoho_writes.append(ZohoWrite(
                    method="POST",
                    endpoint="customerpayments",
                    payload={
                        "customer_id": customer_id,
                        "payment_mode": "stripe",
                        "amount": float(amount_paid),
                        "date": date.today().isoformat(),
                        "reference_number": payment_intent or "",
                        "invoices": [{
                            "invoice_id": zoho_invoice_id,
                            "amount_applied": float(amount_paid),
                        }],
                    },
                    bind_to_entity=("invoice", invoice["id"]),
                ))
        except Exception:
            logger.exception("Customer-id resolution failed")

    documents: list[Document] = []
    if pdf_bytes:
        documents.append(Document(
            entity_type="receipt",
            body=pdf_bytes,
            filename=f"{receipt_number}.pdf",
            entity_id=invoice["id"],
        ))

    # Engine's reply isn't user-facing for webhook flows — the webhook handler
    # uses it to compose the WhatsApp message. Keep it terse but informative.
    reply = (
        f"💰 Payment received for {invoice_number}\n"
        f"From: {invoice.get('customer_name')}\n"
        f"Amount: {currency} {amount_paid:,.2f}"
    )

    return ModuleResult(
        reply_to_user=reply,
        zoho_writes=zoho_writes,
        documents=documents,
        extra_events=[
            {"event_type": "payment_received",
             "payload": {
                 "invoice_id": invoice["id"],
                 "amount": float(amount_paid),
                 "stripe_payment_intent": payment_intent,
                 "receipt_number": receipt_number,
             }},
        ],
        entity_kind="invoice",
        entity_id=invoice["id"],
    )


async def update_invoice_receipt_url(invoice_id: str, receipt_url: str) -> None:
    db = await get_db()
    await db.table("invoices").update({"receipt_url": receipt_url}).eq("id", invoice_id).execute()
