"""Tax-invoice-on-demand for completed sales — AR Bot rebuild.

The client (the UAE SME using CapitalBooks) tells us *"got AED 5000 from ABC
Corp today for consulting"*. Their customer ALREADY paid — they're just
asking us to generate the proper Tax Invoice for their books.

Flow:
  1. Parse the client's message → SaleInput (customer, amount, date, description)
  2. Resolve the Zoho customer (lookup-or-create)
  3. Search Zoho invoices for an existing matching invoice for this customer
     (same amount + within 3 days). If found, return its PDF — don't create
     a duplicate.
  4. If not found, create the invoice, transition draft → sent, immediately
     record a CustomerPayment for the full amount, then fetch the PDF.
  5. Store the PDF in Supabase Storage via the engine Document layer.
  6. Persist a row in the invoices table.

TODO (July 2027): The "create-and-immediately-mark-paid" model is incompatible
with PINT AE async issue/acknowledge cycle that becomes mandatory under UAE
e-invoicing Phase 2. We need to rework this so the invoice is issued, the
ASP forwards it for clearance, and the payment is recorded only after the
acknowledge response. Track via FTA e-invoicing program updates.
"""
import asyncio
import logging
from datetime import date, timedelta
from decimal import Decimal
from typing import Any

from ar.parser import parse_invoice_request
from database import get_db
from orchestrator.engine import Document, ModuleResult, OrchContext, ZohoWrite

logger = logging.getLogger(__name__)

VAT_RATE = Decimal("0.05")


class SaleInput:
    """Client message announcing a completed sale they want a tax invoice for."""

    def __init__(self, text: str, sender: str | None = None):
        self.text = text
        self.sender = sender


# Re-exported so both AR paths use the same Zoho-aware allocator.
from ar.invoice_stateless import _next_invoice_number  # noqa: E402


async def _search_existing_invoice(
    ctx: OrchContext,
    customer_id: str,
    amount: Decimal,
    on_or_after: date,
) -> dict[str, Any] | None:
    """Return a matching Zoho invoice (same customer, same total, recent) or
    None. Avoids issuing duplicates if the client says "got paid by ABC"
    twice in a row."""
    if ctx.resolver is None:
        return None
    try:
        resp = await ctx.resolver._zoho.list_entities(
            "invoices",
            filters={
                "customer_id": customer_id,
                "date_after": on_or_after.isoformat(),
            },
        )
    except Exception:
        logger.exception("Existing-invoice search failed (non-fatal)")
        return None
    for inv in resp.get("invoices") or []:
        if abs(Decimal(str(inv.get("total") or 0)) - amount) < Decimal("0.01"):
            return inv
    return None


def _build_invoice_payload(
    customer_id: str,
    request,
    invoice_number: str,
    today: date,
    due: date,
    tax_ids: dict[str, Any],
) -> dict[str, Any]:
    net = request.amount / (Decimal("1.0") + VAT_RATE)
    line_item: dict[str, Any] = {
        "name": request.description[:100],
        "description": request.description,
        "rate": float(net),
        "quantity": 1,
    }
    if tax_ids.get("standard"):
        line_item["tax_id"] = tax_ids["standard"]
    return {
        "customer_id": customer_id,
        "invoice_number": invoice_number,
        "date": today.isoformat(),
        "due_date": due.isoformat(),
        "currency_code": request.currency,
        "is_inclusive_tax": False,
        "line_items": [line_item],
    }


async def record_completed_sale(input: SaleInput, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg

    # 1) Parse
    try:
        req = await parse_invoice_request(input.text)
    except Exception as e:
        return ModuleResult(
            reply_to_user=(
                f"Couldn't parse that sale: {e}. "
                "Try 'got AED 5000 from ABC Corp today for consulting'."
            ),
        )

    if ctx.resolver is None:
        return ModuleResult(
            reply_to_user="Your Zoho Books isn't connected yet. Contact support to link it.",
        )

    db = await get_db()
    today = date.today()

    # 2) Resolve customer
    try:
        customer_id = await ctx.resolver.resolve_customer(req.customer_name)
    except Exception as e:
        logger.exception("Customer resolve failed")
        return ModuleResult(reply_to_user=f"Couldn't resolve customer in Zoho: {e}")
    if not customer_id:
        return ModuleResult(reply_to_user=f"Couldn't create customer '{req.customer_name}' in Zoho.")

    # 3) Idempotency: search for an existing matching invoice
    try:
        existing = await _search_existing_invoice(
            ctx, customer_id, req.amount, today - timedelta(days=7),
        )
    except Exception:
        existing = None

    if existing:
        zoho_invoice_id = existing.get("invoice_id")
        try:
            pdf_bytes = await ctx.resolver.download_entity_pdf("invoices", zoho_invoice_id)
        except Exception:
            pdf_bytes = None
        reply_lines = [
            "📑 Tax invoice already exists for that sale — not duplicating.",
            f"Customer: {req.customer_name}",
            f"Amount: {req.currency} {req.amount:,.2f}",
            f"Zoho invoice #: {existing.get('invoice_number')}",
            f"Status: {existing.get('status')}",
        ]
        documents: list[Document] = []
        if pdf_bytes:
            documents.append(Document(
                entity_type="invoice",
                body=pdf_bytes,
                filename=f"{existing.get('invoice_number')}.pdf",
            ))
        return ModuleResult(
            reply_to_user="\n".join(reply_lines),
            documents=documents,
            extra_events=[{
                "event_type": "sale_invoice_matched_existing",
                "payload": {
                    "zoho_invoice_id": zoho_invoice_id,
                    "customer_name": req.customer_name,
                    "amount": float(req.amount),
                },
            }],
            entity_kind="invoice",
        )

    # 4) Create + mark sent + record payment + fetch PDF
    invoice_number = await _next_invoice_number(
        cfg.id,
        zoho=ctx.resolver._zoho if ctx.resolver is not None else None,
    )
    due = today  # paid same day — due_date is today
    payload = _build_invoice_payload(customer_id, req, invoice_number, today, due, cfg.zoho_tax_ids)

    try:
        resp = await ctx.resolver._zoho.create_entity(
            "invoices", payload, params={"ignore_auto_number_generation": "true"}
        )
    except Exception as e:
        logger.exception("Zoho invoice create failed")
        return ModuleResult(reply_to_user=f"Zoho Books invoice creation failed: {e}")

    zoho_invoice = resp.get("invoice") or {}
    zoho_invoice_id = zoho_invoice.get("invoice_id")
    if not zoho_invoice_id:
        return ModuleResult(reply_to_user="Zoho didn't return an invoice id — please retry.")

    # Mark sent (else PDF endpoint won't render properly)
    try:
        await ctx.resolver.mark_invoice_sent(zoho_invoice_id)
    except Exception:
        logger.exception("Mark-as-sent failed (non-fatal)")

    # Record the CustomerPayment immediately — sale is already paid.
    payment_payload = {
        "customer_id": customer_id,
        "payment_mode": "cash",   # client received outside Stripe; cash is a safe default
        "amount": float(req.amount),
        "date": today.isoformat(),
        "reference_number": f"CB-sale-{invoice_number}",
        "invoices": [{"invoice_id": zoho_invoice_id, "amount_applied": float(req.amount)}],
    }
    try:
        await ctx.resolver._zoho.create_entity("customerpayments", payment_payload)
    except Exception:
        logger.exception("CustomerPayment post failed — invoice issued but not marked paid")

    # Fetch the rendered PDF
    pdf_bytes = None
    try:
        pdf_bytes = await ctx.resolver.download_entity_pdf("invoices", zoho_invoice_id)
    except Exception:
        logger.exception("PDF fetch failed (non-fatal)")

    # Persist invoices row (status=paid directly — sale was already paid)
    net = req.amount / (Decimal("1.0") + VAT_RATE)
    inv_row = (await db.table("invoices").insert({
        "client_id": str(cfg.id),
        "invoice_number": invoice_number,
        "customer_name": req.customer_name,
        "amount": float(net),
        "vat_amount": float(req.amount - net),
        "total": float(req.amount),
        "currency": req.currency,
        "status": "paid",
        "zoho_invoice_id": zoho_invoice_id,
        "due_date": due.isoformat(),
        "paid_date": today.isoformat(),
    }).execute()).data[0]

    documents: list[Document] = []
    if pdf_bytes:
        documents.append(Document(
            entity_type="invoice",
            body=pdf_bytes,
            filename=f"{invoice_number}.pdf",
            entity_id=inv_row["id"],
        ))

    reply_lines = [
        f"🧾 Tax invoice issued + marked paid",
        f"Invoice #: {invoice_number}",
        f"Customer: {req.customer_name}",
        f"Amount: {req.currency} {req.amount:,.2f}"
        f" (net {req.currency} {net:,.2f}, VAT {req.currency} {(req.amount - net):,.2f})",
        f"Date: {today.isoformat()}",
        "Status: PAID",
    ]
    return ModuleResult(
        reply_to_user="\n".join(reply_lines),
        documents=documents,
        extra_events=[
            {"event_type": "sale_invoice_created",
             "payload": {"invoice_number": invoice_number,
                         "zoho_invoice_id": zoho_invoice_id,
                         "amount": float(req.amount),
                         "customer_name": req.customer_name}},
            {"event_type": "sale_invoice_marked_paid",
             "payload": {"zoho_invoice_id": zoho_invoice_id,
                         "amount": float(req.amount)}},
        ],
        entity_kind="invoice",
        entity_id=inv_row["id"],
    )


async def attach_signed_url_to_invoice(invoice_id: str, signed_url: str) -> None:
    db = await get_db()
    await db.table("invoices").update({"pdf_url": signed_url}).eq("id", invoice_id).execute()
