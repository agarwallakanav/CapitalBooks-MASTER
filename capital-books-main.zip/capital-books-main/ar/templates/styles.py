"""Shared palette + helpers for invoice and receipt templates."""
from reportlab.lib.colors import HexColor

NAVY = HexColor("#1a2332")
GREEN = HexColor("#4CAF50")
GOLD = HexColor("#D4AF37")
LIGHT_GRAY = HexColor("#F4F4F4")
DARK_GRAY = HexColor("#333333")
WHITE = HexColor("#FFFFFF")

FONT_BODY = "Helvetica"
FONT_BOLD = "Helvetica-Bold"


def shape_arabic(text: str) -> str:
    """Reshape + bidi-process Arabic so it renders right-to-left in PDFs."""
    if not text:
        return ""
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(text))
    except Exception:
        return text
