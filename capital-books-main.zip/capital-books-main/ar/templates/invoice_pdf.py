"""Bilingual Arabic/English invoice PDF generator.

Layout:
  ┌──────────────────────────────────────────────────────┐
  │ COMPANY HEADER (navy)        | TAX INVOICE (gold)    │
  ├──────────────────────────────────────────────────────┤
  │ BILL TO       | INVOICE #    | DATE                  │
  ├──────────────────────────────────────────────────────┤
  │ LINE ITEMS                                            │
  ├──────────────────────────────────────────────────────┤
  │ Subtotal | VAT 5% | TOTAL (green)                     │
  ├──────────────────────────────────────────────────────┤
  │ Bank details | TRN box (green) | AI confidence badge  │
  └──────────────────────────────────────────────────────┘
"""
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from io import BytesIO

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas

from ar.templates.styles import (
    DARK_GRAY,
    FONT_BODY,
    FONT_BOLD,
    GOLD,
    GREEN,
    LIGHT_GRAY,
    NAVY,
    WHITE,
    shape_arabic,
)


@dataclass
class LineItem:
    description: str
    quantity: float
    unit_price: Decimal
    vat_rate: Decimal = Decimal("0.05")

    @property
    def subtotal(self) -> Decimal:
        return Decimal(self.quantity) * self.unit_price

    @property
    def vat(self) -> Decimal:
        return self.subtotal * self.vat_rate

    @property
    def total(self) -> Decimal:
        return self.subtotal + self.vat


@dataclass
class InvoiceData:
    invoice_number: str
    issue_date: date
    due_date: date
    company_name: str
    company_trn: str
    company_address: str
    bank_name: str
    iban: str
    customer_name: str
    customer_trn: str | None
    customer_address: str | None
    line_items: list[LineItem]
    currency: str = "AED"
    ai_confidence: int = 0
    logo_url: str | None = None
    notes: str = ""
    arabic_notes: str = ""

    @property
    def subtotal(self) -> Decimal:
        return sum((li.subtotal for li in self.line_items), Decimal("0"))

    @property
    def vat_total(self) -> Decimal:
        return sum((li.vat for li in self.line_items), Decimal("0"))

    @property
    def grand_total(self) -> Decimal:
        return self.subtotal + self.vat_total


def render_invoice_pdf(data: InvoiceData) -> bytes:
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4

    # ---- Header band (navy)
    c.setFillColor(NAVY)
    c.rect(0, height - 32 * mm, width, 32 * mm, stroke=0, fill=1)

    c.setFillColor(WHITE)
    c.setFont(FONT_BOLD, 20)
    c.drawString(15 * mm, height - 16 * mm, data.company_name)
    c.setFont(FONT_BODY, 9)
    c.drawString(15 * mm, height - 22 * mm, data.company_address)
    c.drawString(15 * mm, height - 27 * mm, f"TRN: {data.company_trn}")

    c.setFillColor(GOLD)
    c.setFont(FONT_BOLD, 18)
    c.drawRightString(width - 15 * mm, height - 18 * mm, "TAX INVOICE")
    c.setFont(FONT_BODY, 9)
    c.setFillColor(WHITE)
    c.drawRightString(width - 15 * mm, height - 24 * mm, shape_arabic("فاتورة ضريبية"))

    # ---- Bill-to + meta
    y = height - 50 * mm
    c.setFillColor(NAVY)
    c.setFont(FONT_BOLD, 11)
    c.drawString(15 * mm, y, "BILL TO")
    c.drawString(115 * mm, y, "INVOICE #")
    c.drawString(155 * mm, y, "DATE")

    c.setFillColor(DARK_GRAY)
    c.setFont(FONT_BODY, 10)
    c.drawString(15 * mm, y - 6 * mm, data.customer_name)
    if data.customer_trn:
        c.drawString(15 * mm, y - 11 * mm, f"TRN: {data.customer_trn}")
    if data.customer_address:
        c.drawString(15 * mm, y - 16 * mm, data.customer_address[:60])

    c.setFont(FONT_BOLD, 10)
    c.drawString(115 * mm, y - 6 * mm, data.invoice_number)
    c.drawString(155 * mm, y - 6 * mm, data.issue_date.isoformat())
    c.setFont(FONT_BODY, 9)
    c.drawString(155 * mm, y - 11 * mm, f"Due: {data.due_date.isoformat()}")

    # ---- Line items
    table_top = y - 30 * mm
    _draw_line_items(c, data, table_top, width)

    # ---- Totals
    totals_top = table_top - (10 + 8 * len(data.line_items)) * mm
    _draw_totals(c, data, totals_top, width)

    # ---- Footer: bank, TRN box, AI badge
    _draw_footer(c, data, width)

    c.showPage()
    c.save()
    return buf.getvalue()


def _draw_line_items(c: canvas.Canvas, data: InvoiceData, top: float, width: float) -> None:
    # Header row
    c.setFillColor(NAVY)
    c.rect(15 * mm, top, width - 30 * mm, 8 * mm, stroke=0, fill=1)
    c.setFillColor(WHITE)
    c.setFont(FONT_BOLD, 9)
    c.drawString(18 * mm, top + 2.5 * mm, "DESCRIPTION")
    c.drawRightString(120 * mm, top + 2.5 * mm, "QTY")
    c.drawRightString(150 * mm, top + 2.5 * mm, "UNIT PRICE")
    c.drawRightString(width - 18 * mm, top + 2.5 * mm, "TOTAL")

    c.setFillColor(DARK_GRAY)
    c.setFont(FONT_BODY, 9)
    row_h = 8 * mm
    for i, item in enumerate(data.line_items):
        y_row = top - (i + 1) * row_h
        if i % 2 == 0:
            c.setFillColor(LIGHT_GRAY)
            c.rect(15 * mm, y_row, width - 30 * mm, row_h, stroke=0, fill=1)
        c.setFillColor(DARK_GRAY)
        c.drawString(18 * mm, y_row + 2.5 * mm, item.description[:60])
        c.drawRightString(120 * mm, y_row + 2.5 * mm, f"{item.quantity:g}")
        c.drawRightString(150 * mm, y_row + 2.5 * mm, f"{item.unit_price:,.2f}")
        c.drawRightString(width - 18 * mm, y_row + 2.5 * mm, f"{item.total:,.2f}")


def _draw_totals(c: canvas.Canvas, data: InvoiceData, top: float, width: float) -> None:
    c.setFont(FONT_BODY, 10)
    c.setFillColor(DARK_GRAY)
    c.drawRightString(150 * mm, top, "Subtotal")
    c.drawRightString(width - 18 * mm, top, f"{data.currency} {data.subtotal:,.2f}")

    c.drawRightString(150 * mm, top - 6 * mm, "VAT (5%)")
    c.drawRightString(width - 18 * mm, top - 6 * mm, f"{data.currency} {data.vat_total:,.2f}")

    # Grand total band in green
    c.setFillColor(GREEN)
    c.rect(115 * mm, top - 16 * mm, width - 130 * mm, 9 * mm, stroke=0, fill=1)
    c.setFillColor(WHITE)
    c.setFont(FONT_BOLD, 12)
    c.drawRightString(150 * mm, top - 13.5 * mm, "TOTAL")
    c.drawRightString(width - 18 * mm, top - 13.5 * mm, f"{data.currency} {data.grand_total:,.2f}")


def _draw_footer(c: canvas.Canvas, data: InvoiceData, width: float) -> None:
    y = 50 * mm

    # Bank details (left)
    c.setFillColor(NAVY)
    c.setFont(FONT_BOLD, 10)
    c.drawString(15 * mm, y, "BANK DETAILS")
    c.setFillColor(DARK_GRAY)
    c.setFont(FONT_BODY, 9)
    c.drawString(15 * mm, y - 5 * mm, f"Bank: {data.bank_name}")
    c.drawString(15 * mm, y - 10 * mm, f"IBAN: {data.iban}")
    c.drawString(15 * mm, y - 15 * mm, f"Beneficiary: {data.company_name}")

    # TRN validation box (right, green outlined)
    box_x = 115 * mm
    box_w = width - 130 * mm
    c.setStrokeColor(GREEN)
    c.setLineWidth(1.2)
    c.rect(box_x, y - 18 * mm, box_w, 22 * mm, stroke=1, fill=0)
    c.setFillColor(GREEN)
    c.setFont(FONT_BOLD, 9)
    c.drawString(box_x + 3 * mm, y - 4 * mm, "✓ TRN VALIDATED")
    c.setFillColor(DARK_GRAY)
    c.setFont(FONT_BODY, 8)
    c.drawString(box_x + 3 * mm, y - 10 * mm, f"Supplier TRN: {data.company_trn}")
    if data.customer_trn:
        c.drawString(box_x + 3 * mm, y - 14 * mm, f"Customer TRN: {data.customer_trn}")

    # AI confidence badge (very bottom)
    if data.ai_confidence:
        c.setFillColor(GOLD)
        c.setFont(FONT_BOLD, 8)
        c.drawRightString(
            width - 15 * mm, 15 * mm,
            f"🤖 AI confidence: {data.ai_confidence}%",
        )

    # Arabic notes (right-to-left)
    if data.arabic_notes:
        c.setFillColor(DARK_GRAY)
        c.setFont(FONT_BODY, 9)
        c.drawRightString(width - 15 * mm, 25 * mm, shape_arabic(data.arabic_notes))

    if data.notes:
        c.setFillColor(DARK_GRAY)
        c.setFont(FONT_BODY, 9)
        c.drawString(15 * mm, 25 * mm, data.notes[:80])
