"""Resume invoice email delivery after the user replies with an address.

Triggered when there's an active invoice_email_intent (set by
ar/invoice_stateless.py:create_invoice when the customer had no email on
Zoho file).

Two replies handled:
  provide_invoice_email(email)  → update Zoho contact, fetch PDF, send email
  skip_invoice_email()          → discard the intent silently
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from decimal import Decimal

from ar.email_delivery import send_invoice_email
from database import get_db
from orchestrator.engine import ModuleResult, OrchContext
from router.pending import (
    clear_invoice_email_intent,
    load_invoice_email_intent,
)

logger = logging.getLogger(__name__)

_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


@dataclass
class ProvideEmailInput:
    email: str
    sender: str | None = None


@dataclass
class SkipEmailInput:
    sender: str | None = None


async def provide_invoice_email(
    input: ProvideEmailInput, ctx: OrchContext,
) -> ModuleResult:
    if not input.sender:
        return ModuleResult(reply_to_user="No active session — try sending the invoice command again.")

    intent = await load_invoice_email_intent(input.sender)
    if not intent:
        return ModuleResult(
            reply_to_user="No invoice waiting on an email address. Create one first.",
        )

    email = (input.email or "").strip()
    if not _EMAIL_RE.match(email):
        return ModuleResult(
            reply_to_user=f"'{email}' doesn't look like a valid email address.",
        )

    # Update Zoho contact with the new email so next invoice doesn't ask
    # again. Zoho UAE requires writing through contact_persons[].
    if ctx.resolver is not None and intent.get("customer_id"):
        try:
            from ar.invoice_stateless import _set_primary_contact_email
            await _set_primary_contact_email(
                ctx, intent["customer_id"], email,
                intent.get("customer_name") or "Customer",
            )
        except Exception:
            logger.exception("Failed to update Zoho contact email (non-fatal)")

    # Refetch the PDF so the attachment works
    pdf_bytes: bytes | None = None
    if ctx.resolver is not None and intent.get("zoho_invoice_id"):
        try:
            pdf_bytes = await ctx.resolver.download_entity_pdf(
                "invoices", intent["zoho_invoice_id"],
            )
        except Exception:
            logger.exception("Invoice PDF refetch failed (non-fatal — sending without)")

    sent_ok, sent_err = await send_invoice_email(
        to_email=email,
        bcc_email=intent.get("owner_email"),
        company_name=intent.get("company_name") or "CapitalBooks",
        customer_name=intent.get("customer_name") or "Customer",
        invoice_number=intent.get("invoice_number") or "",
        amount=Decimal(str(intent.get("amount") or 0)),
        currency=intent.get("currency") or "AED",
        due_date=intent.get("due_date") or "",
        payment_url=intent.get("payment_url") or "",
        pdf_bytes=pdf_bytes,
        pdf_filename=f"{intent.get('invoice_number')}.pdf" if intent.get("invoice_number") else None,
        description=intent.get("description"),
    )

    await clear_invoice_email_intent(input.sender)

    if not sent_ok:
        return ModuleResult(
            reply_to_user=f"⚠️ Couldn't send email: {sent_err}",
            extra_events=[{
                "event_type": "invoice_email_failed",
                "payload": {
                    "invoice_number": intent.get("invoice_number"),
                    "to": email,
                    "error": sent_err,
                    "source": "followup",
                },
            }],
        )

    return ModuleResult(
        reply_to_user=(
            f"📧 Invoice {intent.get('invoice_number')} sent to {email}"
            + (f" (cc {intent.get('owner_email')})" if intent.get("owner_email") else "")
            + ". PDF attached, payment link included."
        ),
        extra_events=[{
            "event_type": "invoice_email_sent",
            "payload": {
                "invoice_number": intent.get("invoice_number"),
                "to": email,
                "bcc": intent.get("owner_email"),
                "source": "followup",
            },
        }],
    )


async def skip_invoice_email(
    input: SkipEmailInput, ctx: OrchContext,
) -> ModuleResult:
    if input.sender:
        await clear_invoice_email_intent(input.sender)
    return ModuleResult(
        reply_to_user="👍 Skipped — payment link is in the WhatsApp message above.",
        extra_events=[{
            "event_type": "invoice_email_skipped",
            "payload": {},
        }],
    )
