"""Stateless customer invoice creation — Phase C of the orchestrator migration.

Flow:
  1. Parse the user's text via Claude → InvoiceRequest
  2. Resolve Zoho customer (lookup-or-create) via ctx.resolver
  3. Build invoice payload + POST it via ctx.resolver (multi-step Zoho dance
     is too procedural to express as declarative ZohoWrites — but each call
     still records an audit event via the resolver)
  4. Transition invoice draft → sent
  5. Fetch the rendered PDF via Zoho
  6. Upload PDF to Supabase Storage (engine handles via Document layer)
  7. Create Stripe Checkout Session
  8. Persist the invoices row
  9. Return reply with PDF + Stripe links
"""
import asyncio
import logging
from datetime import date, timedelta
from decimal import Decimal
from typing import Any

import stripe

from ar.email_delivery import send_invoice_email
from ar.parser import parse_invoice_request
from ar.pay_redirect import short_pay_url
from config import settings
from database import get_db
from orchestrator.engine import Document, ModuleResult, OrchContext
from router.pending import save_invoice_email_intent
from transactions.dedup import find_recent_duplicate, format_for_user

logger = logging.getLogger(__name__)

VAT_RATE = Decimal("0.05")


class InvoiceInput:
    def __init__(
        self,
        text: str,
        sender: str | None = None,
        force: bool = False,
        customer_email: str | None = None,
    ):
        self.text = text
        self.sender = sender
        # When True, skip the duplicate check (used when user says
        # "create invoice anyway" after a soft-block).
        self.force = force
        # Optional explicit override — if the user said "email to billing@X"
        # in the same command, this is "billing@X". Wins over any address on
        # the Zoho customer record, and we update the contact to match.
        self.customer_email = (customer_email or "").strip() or None


_MONTH_NAMES = {
    "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
    "july": 7, "august": 8, "september": 9, "october": 10, "november": 11,
    "december": 12,
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "jun": 6, "jul": 7, "aug": 8,
    "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12,
}


def _infer_due_days_from_text(text: str) -> int | None:
    """Fallback for when the LLM parser missed an obvious due signal.

    Handles the flat-out common cases: today / tomorrow / on receipt /
    net N / in N days / net-N / a bare 'DD Month [YYYY]' date. Returns
    the day-delta from today, or None if nothing matches — caller falls
    through to the user prompt."""
    import re
    from datetime import date, datetime
    t = (text or "").lower()
    today = date.today()

    if re.search(r"\b(due\s+)?today\b", t) or "on receipt" in t:
        return 0
    if re.search(r"\b(due\s+)?tomorrow\b", t):
        return 1

    # "in N days" / "in N weeks" / "net N" / "N days"
    m = re.search(r"\b(?:net\s*|in\s+|due\s+in\s+)?(\d+)\s*(day|days|week|weeks|month|months)\b", t)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        if "week" in unit:
            return n * 7
        if "month" in unit:
            return n * 30
        return n
    m = re.search(r"\bnet\s*(\d+)\b", t)
    if m:
        return int(m.group(1))

    # ISO YYYY-MM-DD
    m = re.search(r"\b(\d{4})-(\d{2})-(\d{2})\b", t)
    if m:
        try:
            d = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            return (d - today).days
        except ValueError:
            pass

    # "4 July" or "4 July 2026" or "July 4" / "July 4, 2026"
    m = re.search(
        r"\b(\d{1,2})\s+"
        r"(january|february|march|april|may|june|july|august|september|october|november|december|"
        r"jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec)"
        r"(?:\s+(\d{4}))?\b",
        t,
    )
    if m:
        day = int(m.group(1))
        month = _MONTH_NAMES.get(m.group(2))
        year = int(m.group(3)) if m.group(3) else today.year
        try:
            d = date(year, month, day)
            if d < today and not m.group(3):
                d = date(year + 1, month, day)
            return (d - today).days
        except (ValueError, TypeError):
            pass
    m = re.search(
        r"\b(january|february|march|april|may|june|july|august|september|october|november|december|"
        r"jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec)"
        r"\s+(\d{1,2})(?:\s*,?\s*(\d{4}))?\b",
        t,
    )
    if m:
        month = _MONTH_NAMES.get(m.group(1))
        day = int(m.group(2))
        year = int(m.group(3)) if m.group(3) else today.year
        try:
            d = date(year, month, day)
            if d < today and not m.group(3):
                d = date(year + 1, month, day)
            return (d - today).days
        except (ValueError, TypeError):
            pass

    return None


async def _next_invoice_number(client_id, zoho=None) -> str:
    """Next invoice number = max(local-supabase, zoho) + 1.

    Zoho reserves invoice numbers permanently — even after delete — so we
    have to ask Zoho for the highest existing INV-YYYYMM-NNNN in the
    current month, not just our Supabase mirror. Otherwise after any
    cleanup or first run after data loss we'll keep proposing numbers
    Zoho already burned, hitting 400 "Invoice INV-... already exists".
    """
    today = date.today()
    prefix = f"INV-{today:%Y%m}"

    # 1) Highest sequence in our Supabase mirror
    db = await get_db()
    local_seq = 0
    try:
        res = (
            await db.table("invoices")
            .select("invoice_number")
            .eq("client_id", str(client_id))
            .like("invoice_number", f"{prefix}%")
            .order("invoice_number", desc=True)
            .limit(1)
            .execute()
        )
        if res.data:
            last = res.data[0].get("invoice_number") or ""
            try:
                local_seq = int(last.rsplit("-", 1)[-1])
            except ValueError:
                pass
    except Exception:
        logger.exception("Supabase invoice-number probe failed (non-fatal)")

    # 2) Highest sequence in Zoho for the same month (deleted numbers stay
    # reserved, so this is the authoritative ceiling)
    zoho_seq = 0
    if zoho is not None:
        try:
            resp = await zoho.list_entities("invoices", filters={
                "invoice_number_contains": prefix,
                "per_page": 200,
            })
            for inv in (resp.get("invoices") or []):
                num = inv.get("invoice_number") or ""
                if not num.startswith(prefix):
                    continue
                try:
                    seq = int(num.rsplit("-", 1)[-1])
                    if seq > zoho_seq:
                        zoho_seq = seq
                except ValueError:
                    continue
        except Exception:
            logger.exception("Zoho invoice-number probe failed (non-fatal)")

    next_seq = max(local_seq, zoho_seq) + 1
    return f"{prefix}-{next_seq:04d}"


def _build_invoice_payload(
    customer_id: str,
    req,
    invoice_number: str,
    due: date,
    tax_ids: dict[str, Any],
) -> dict[str, Any]:
    net = req.amount / (Decimal("1.0") + VAT_RATE)
    line_item: dict[str, Any] = {
        "name": req.description[:100],
        "description": req.description,
        "rate": float(net),
        "quantity": 1,
    }
    if tax_ids.get("standard"):
        line_item["tax_id"] = tax_ids["standard"]
    return {
        "customer_id": customer_id,
        "invoice_number": invoice_number,
        "date": date.today().isoformat(),
        "due_date": due.isoformat(),
        "currency_code": req.currency,
        "is_inclusive_tax": False,
        "line_items": [line_item],
    }


async def _create_stripe_session(
    client_row: dict[str, Any],
    invoice_number: str,
    description: str,
    amount: Decimal,
    currency: str,
) -> tuple[str, str]:
    """Create a Stripe Checkout Session. Returns (url, session_id) or ('', '')
    on failure (non-fatal — invoice still posts)."""
    stripe.api_key = client_row.get("stripe_secret_key") or settings.stripe_secret_key
    if not stripe.api_key:
        return "", ""
    try:
        session = await asyncio.to_thread(
            lambda: stripe.checkout.Session.create(
                mode="payment",
                success_url=f"https://capitalbooks.app/paid?inv={invoice_number}",
                cancel_url=f"https://capitalbooks.app/cancelled?inv={invoice_number}",
                line_items=[{
                    "quantity": 1,
                    "price_data": {
                        "currency": currency.lower(),
                        "product_data": {"name": description, "description": invoice_number},
                        "unit_amount": int(amount * 100),
                    },
                }],
                metadata={"invoice_number": invoice_number, "client_id": str(client_row["id"])},
            )
        )
        return session.url, session.id
    except Exception:
        logger.exception("Stripe session creation failed (non-fatal)")
        return "", ""


async def create_invoice(input: InvoiceInput, ctx: OrchContext) -> ModuleResult:
    cfg = ctx.cfg

    # 1) Parse
    try:
        req = await parse_invoice_request(input.text)
    except Exception as e:
        return ModuleResult(
            reply_to_user=(
                f"Couldn't parse that invoice request: {e}. "
                "Try 'invoice ABC Corp 5000 AED for consulting'."
            ),
        )

    if ctx.resolver is None:
        return ModuleResult(
            reply_to_user="Your Zoho Books isn't connected yet. Contact support to link it.",
        )

    # Belt-and-suspenders: even after the parser tightening, catch the
    # obvious cases in Python so we NEVER get stuck in a "confirm due
    # date" loop when the user's message actually contains one.
    if req.due_days is None:
        req.due_days = _infer_due_days_from_text(input.text)

    if req.due_days is None:
        return ModuleResult(
            reply_to_user=(
                f"📅 When's this invoice due for *{req.customer_name}*?\n"
                "Reply with one of:\n"
                "  • 'net 7' / 'net 14' / 'net 30' — standard terms\n"
                "  • 'in 5 days' / 'in 2 weeks'\n"
                "  • 'on receipt' — due immediately\n"
                "  • a specific date like '15 July'\n\n"
                "Then I'll resend the invoice command with the due included."
            ),
            extra_events=[{
                "event_type": "invoice_due_date_prompt",
                "payload": {"customer": req.customer_name, "amount": float(req.amount)},
            }],
        )

    # Duplicate detection — customer + amount within ±7 days. Soft-block:
    # we don't create the invoice; user can re-send "create invoice anyway"
    # (or any rewording without dup signals — value-tuple match is the only
    # signal here since there's no source image for outbound invoices).
    if not input.force:
        dup_match = await find_recent_duplicate(
            cfg.id, "invoice",
            vendor=req.customer_name,
            amount=req.amount,
            when=None,
        )
        if dup_match:
            return ModuleResult(
                reply_to_user=(
                    format_for_user(dup_match)
                    + "\n\nI haven't created a new invoice. "
                    + "Reply 'create invoice anyway' to send a second one, "
                    + "or ignore this message to keep just the original."
                ),
                extra_events=[{
                    "event_type": "invoice_dedup_blocked",
                    "payload": {
                        "prior_invoice_id": dup_match.entity_id,
                        "prior_invoice_number": dup_match.extra.get("invoice_number"),
                        "customer": req.customer_name,
                        "amount": float(req.amount),
                    },
                }],
            )

    # Pull client row (needed for Stripe key + invoice_template + company info)
    db = await get_db()
    client_row = (
        await db.table("clients").select("*").eq("id", str(cfg.id)).single().execute()
    ).data
    if not client_row:
        return ModuleResult(reply_to_user="Client config not found.")

    invoice_number = await _next_invoice_number(
        cfg.id,
        zoho=ctx.resolver._zoho if ctx.resolver is not None else None,
    )
    due = date.today() + timedelta(days=req.due_days)

    # 2) Resolve customer
    try:
        customer_id = await ctx.resolver.resolve_customer(req.customer_name)
    except Exception as e:
        logger.exception("Customer resolution failed")
        return ModuleResult(reply_to_user=f"Couldn't resolve customer in Zoho: {e}")
    if not customer_id:
        return ModuleResult(reply_to_user=f"Couldn't create '{req.customer_name}' in Zoho.")

    # 3) Create invoice — multi-step Zoho via shared client
    payload = _build_invoice_payload(customer_id, req, invoice_number, due, cfg.zoho_tax_ids)
    try:
        resp = await ctx.resolver._zoho.create_entity(
            "invoices", payload, params={"ignore_auto_number_generation": "true"}
        )
    except Exception as e:
        logger.exception("Zoho invoice creation failed")
        return ModuleResult(reply_to_user=f"Zoho Books invoice creation failed: {e}")

    zoho_invoice = resp.get("invoice") or {}
    zoho_invoice_id = zoho_invoice.get("invoice_id")
    if not zoho_invoice_id:
        return ModuleResult(reply_to_user="Zoho didn't return an invoice id — please retry.")

    # 4) Mark sent
    try:
        await ctx.resolver.mark_invoice_sent(zoho_invoice_id)
    except Exception:
        logger.exception("Mark-as-sent failed (non-fatal; PDF link may not work yet)")

    # 5) Fetch the Zoho-rendered PDF
    pdf_bytes: bytes | None = None
    try:
        pdf_bytes = await ctx.resolver.download_entity_pdf("invoices", zoho_invoice_id)
    except Exception:
        logger.exception("Invoice PDF fetch failed")

    # 6) Stripe Checkout (independent of Zoho)
    checkout_url, session_id = await _create_stripe_session(
        client_row, invoice_number, req.description, req.amount, req.currency,
    )

    # 7) Persist the invoices row (orchestrator binding is via local id alone
    # since Zoho id is already known)
    net = req.amount / (Decimal("1.0") + VAT_RATE)
    insert = {
        "client_id": str(cfg.id),
        "invoice_number": invoice_number,
        "customer_name": req.customer_name,
        "amount": float(net),
        "vat_amount": float(req.amount - net),
        "total": float(req.amount),
        "currency": req.currency,
        "status": "sent",
        "zoho_invoice_id": zoho_invoice_id,
        "stripe_session_id": session_id or None,
        "stripe_checkout_url": checkout_url or None,
        "due_date": due.isoformat(),
    }
    inv_row = (await db.table("invoices").insert(insert).execute()).data[0]
    invoice_id = inv_row["id"]

    # 8) Documents (PDF goes through engine Document layer → Storage upload + audit)
    documents: list[Document] = []
    if pdf_bytes:
        documents.append(Document(
            entity_type="invoice",
            body=pdf_bytes,
            filename=f"{invoice_number}.pdf",
            entity_id=invoice_id,
        ))

    # 9) Email delivery — Zoho contact email or user-provided override.
    # If neither exists, stash an intent and ask the user.
    customer_email, email_source = await _resolve_customer_email(
        ctx, customer_id, input.customer_email,
        customer_name=req.customer_name,
    )
    if input.customer_email and email_source == "user_override":
        # Sync the contact record so future invoices use the new address.
        # Zoho UAE doesn't persist a top-level `email` write — it has to go
        # through contact_persons. (See ar/customer_contacts.set_primary_email.)
        try:
            await _set_primary_contact_email(
                ctx, customer_id, input.customer_email, req.customer_name,
            )
        except Exception:
            logger.exception("Failed to update Zoho contact email (non-fatal)")

    email_events: list[dict[str, Any]] = []
    email_status_line = ""
    if customer_email:
        owner_bcc = client_row.get("email")
        sent_ok, sent_err = await send_invoice_email(
            to_email=customer_email,
            bcc_email=owner_bcc,
            company_name=client_row.get("company_name") or cfg.company_name,
            customer_name=req.customer_name,
            invoice_number=invoice_number,
            amount=req.amount,
            currency=req.currency,
            due_date=due.isoformat(),
            payment_url=short_pay_url(invoice_number) if checkout_url else "",
            pdf_bytes=pdf_bytes,
            pdf_filename=f"{invoice_number}.pdf",
            description=req.description,
        )
        email_events.append({
            "event_type": "invoice_email_sent" if sent_ok else "invoice_email_failed",
            "payload": {
                "invoice_number": invoice_number,
                "to": customer_email,
                "bcc": owner_bcc,
                "source": email_source,
                "error": sent_err if not sent_ok else None,
            },
        })
        if sent_ok:
            email_status_line = (
                f"📧 Emailed to {customer_email}"
                + (f" (cc {owner_bcc})" if owner_bcc and owner_bcc != customer_email else "")
            )
        else:
            email_status_line = f"⚠️ Couldn't email: {sent_err}"
    elif input.sender:
        # No email — stash so the next reply (an address) resumes delivery.
        await save_invoice_email_intent(input.sender, {
            "invoice_id": invoice_id,
            "invoice_number": invoice_number,
            "customer_name": req.customer_name,
            "customer_id": customer_id,
            "amount": float(req.amount),
            "currency": req.currency,
            "due_date": due.isoformat(),
            "payment_url": short_pay_url(invoice_number) if checkout_url else "",
            "description": req.description,
            "owner_email": client_row.get("email"),
            "company_name": client_row.get("company_name") or cfg.company_name,
            # PDF will be re-fetched from Zoho on resume (we don't stash bytes)
            "zoho_invoice_id": zoho_invoice_id,
        })
        email_status_line = (
            f"📧 No email on file for {req.customer_name}. "
            "Reply with their email to send it, or 'skip' to keep just the WhatsApp link."
        )

    # 10) Reply — one fact per line, no wrapping. Use the short /pay/<inv>
    # redirect URL instead of the raw 400-char Stripe URL.
    lines = [
        f"🧾 Invoice {invoice_number} created",
        f"Customer: {req.customer_name}",
        f"Amount:   {req.currency} {req.amount:,.2f}",
        f"VAT:      {req.currency} {req.amount - net:,.2f}",
        f"Due:      {due.isoformat()}",
    ]
    if checkout_url:
        lines.append(f"Pay:      {short_pay_url(invoice_number)}")
    if email_status_line:
        lines.append(email_status_line)

    return ModuleResult(
        reply_to_user="\n".join(lines),
        documents=documents,
        extra_events=[
            {"event_type": "invoice_created",
             "payload": {
                 "invoice_number": invoice_number,
                 "zoho_invoice_id": zoho_invoice_id,
                 "stripe_session_id": session_id or None,
             }},
            *email_events,
        ],
        entity_kind="invoice",
        entity_id=invoice_id,
    )


async def _set_primary_contact_email(
    ctx: OrchContext, customer_id: str, email: str, customer_name: str,
) -> None:
    """Persist a customer email by writing to Zoho's contact_persons. UAE
    Books rejects writes to the top-level contact `email` field — and even
    the contact_persons endpoint rejects `is_primary_contact` in the body
    (returns 400 'Invalid Element is_primary_contact'). The correct dance:

      1. POST /contacts/contactpersons        ← create (no is_primary_contact)
         OR PUT  /contacts/contactpersons/{id} ← update existing
      2. POST /contacts/contactpersons/{id}/primary  ← mark as primary

    The 'primary' action endpoint is best-effort; if it fails, the read
    path also falls back to contact_persons[0] so the email still lands.
    """
    z = ctx.resolver._zoho
    detail = await z.get_entity("contacts", customer_id)
    contact = detail.get("contact") or {}
    persons = contact.get("contact_persons") or []
    primary = next((p for p in persons if p.get("is_primary_contact")), None) or (
        persons[0] if persons else None
    )

    if primary:
        cp_id = primary.get("contact_person_id")
        payload = {
            "contact_id": customer_id,
            "email": email,
            "first_name": primary.get("first_name") or "Billing",
        }
        if primary.get("last_name"):
            payload["last_name"] = primary["last_name"]
        logger.info(
            "Zoho write: PUT /contacts/contactpersons/%s for %s — payload=%s",
            cp_id, customer_name, payload,
        )
        await z._request(
            "PUT", f"contacts/contactpersons/{cp_id}", json=payload,
        )
    else:
        payload = {
            "contact_id": customer_id,
            "email": email,
            "first_name": "Billing",
            "last_name": customer_name[:50],
        }
        logger.info(
            "Zoho write: POST /contacts/contactpersons for %s — payload=%s",
            customer_name, payload,
        )
        resp = await z._request("POST", "contacts/contactpersons", json=payload)
        new_cp = (resp.get("contact_person") or {}).get("contact_person_id")
        if new_cp:
            try:
                await z._request("POST", f"contacts/contactpersons/{new_cp}/primary")
                logger.info(
                    "Marked contact_person %s as primary for %s",
                    new_cp, customer_name,
                )
            except Exception:
                logger.exception(
                    "Mark-as-primary failed (non-fatal — read path "
                    "falls back to contact_persons[0])",
                )


async def _resolve_customer_email(
    ctx: OrchContext, customer_id: str, override: str | None,
    *, customer_name: str = "",
) -> tuple[str | None, str]:
    """Returns (email, source). source ∈ {'user_override', 'zoho_top_level',
    'zoho_primary_contact_person', 'zoho_contact_person_fallback', ''}."""
    if override:
        logger.info(
            "Customer %s email lookup: %s from user_override",
            customer_name or customer_id, override,
        )
        return override, "user_override"
    try:
        resp = await ctx.resolver._zoho.get_entity("contacts", customer_id)
        contact = resp.get("contact") or {}
        # Try fields in order: top-level → primary contact_person → first cp
        email = (contact.get("email") or "").strip()
        source = "zoho_top_level" if email else ""
        if not email:
            persons = contact.get("contact_persons") or []
            for p in persons:
                if p.get("is_primary_contact") and p.get("email"):
                    email = p["email"]
                    source = "zoho_primary_contact_person"
                    break
            if not email and persons:
                email = (persons[0].get("email") or "").strip()
                if email:
                    source = "zoho_contact_person_fallback"
        logger.info(
            "Customer %s email lookup: %s from %s",
            customer_name or customer_id,
            email or "not found",
            source or "(no email anywhere)",
        )
        if email:
            return email, source
    except Exception:
        logger.exception("Zoho contact email lookup failed (non-fatal)")
        logger.info(
            "Customer %s email lookup: not found (Zoho lookup raised)",
            customer_name or customer_id,
        )
    return None, ""


# Engine's Document layer uploads to Storage but doesn't write the URL back to
# the invoices row. Patch: after engine.execute() the caller (router/tools)
# can update the row. To avoid asking modules to know about engine internals,
# we expose a helper.
async def update_invoice_pdf_url(invoice_id: str, signed_url: str) -> None:
    db = await get_db()
    await db.table("invoices").update({"pdf_url": signed_url}).eq("id", invoice_id).execute()
